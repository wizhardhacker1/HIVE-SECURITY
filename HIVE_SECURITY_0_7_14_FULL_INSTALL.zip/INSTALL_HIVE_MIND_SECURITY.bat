@echo off
setlocal EnableExtensions
set "VERSION=0.7.14"
set "APPROOT=%LOCALAPPDATA%\HiveMindSecurity"
set "APPDIR=%APPROOT%\app"
set "DATADIR=%APPROOT%\data"
set "PAYLOAD=%~dp0payload"

echo ====================================================
echo   HIVE SECURITY %VERSION% FULL WINDOWS INSTALLER
echo ====================================================
echo   Includes LOCAL AI: Ollama + Meta Llama 3.2 3B
echo ====================================================
echo.

if not exist "%PAYLOAD%\requirements.txt" goto :payloadfail
if not exist "%PAYLOAD%\app\main.py" goto :payloadfail
if not exist "%PAYLOAD%\app\static\login.html" goto :payloadfail
if not exist "%PAYLOAD%\STOP_HIVE_MIND_SECURITY.ps1" goto :payloadfail
if not exist "%PAYLOAD%\START_SERVER.ps1" goto :payloadfail
if not exist "%PAYLOAD%\WAIT_FOR_PORTAL.py" goto :payloadfail
if not exist "%PAYLOAD%\launcher.py" goto :payloadfail
if not exist "%PAYLOAD%\CREATE_SHORTCUTS.ps1" goto :payloadfail
if not exist "%PAYLOAD%\ENSURE_LOCAL_AI.ps1" goto :payloadfail
if not exist "%PAYLOAD%\SETUP_LOCAL_AI.bat" goto :payloadfail
if not exist "%PAYLOAD%\app\static\hivemind.ico" goto :payloadfail

where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (set "PY=py -3") else (set "PY=python")
%PY% --version >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python 3.11 or newer is required.
  pause
  exit /b 3
)

if not exist "%APPROOT%" mkdir "%APPROOT%"
if not exist "%APPDIR%" mkdir "%APPDIR%"
if not exist "%DATADIR%" mkdir "%DATADIR%"
set "HMS_DATA_DIR=%DATADIR%"

echo [1/11] Stopping any previous HIVE SECURITY server...
powershell -NoProfile -ExecutionPolicy Bypass -File "%PAYLOAD%\STOP_HIVE_MIND_SECURITY.ps1" -Port 8765 -FailIfForeign
set "STOPRC=%ERRORLEVEL%"
if %STOPRC% GEQ 9 (
  echo ERROR: Could not safely free port 8765. No application files were changed.
  echo If another application owns port 8765, close it and run this installer again.
  pause
  exit /b %STOPRC%
)

echo [2/11] Copying complete application payload...
xcopy "%PAYLOAD%\*" "%APPDIR%\" /E /I /Y /Q >nul
if errorlevel 1 goto :copyfail
if not exist "%APPDIR%\requirements.txt" goto :copyfail
if not exist "%APPDIR%\app\main.py" goto :copyfail
if not exist "%APPDIR%\app\static\login.html" goto :copyfail
if not exist "%APPDIR%\ENSURE_LOCAL_AI.ps1" goto :copyfail

echo [3/11] Creating private Python environment...
if not exist "%APPDIR%\.venv\Scripts\python.exe" (
  %PY% -m venv "%APPDIR%\.venv"
  if errorlevel 1 (
    echo ERROR: Failed to create the Python virtual environment.
    pause
    exit /b 6
  )
)

echo [4/11] Installing Python dependencies...
"%APPDIR%\.venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :pipfail
"%APPDIR%\.venv\Scripts\python.exe" -m pip install -r "%APPDIR%\requirements.txt"
if errorlevel 1 goto :pipfail

echo [5/11] Verifying the installed HIVE SECURITY payload...
pushd "%APPDIR%"
"%APPDIR%\.venv\Scripts\python.exe" -c "from pathlib import Path; import app.main as m; expected='%VERSION%'; assert m.VERSION == expected, f'Wrong installed version: {m.VERSION} (expected {expected})'; assert (m.STATIC/'login.html').is_file(); assert Path('run.py').is_file(); assert Path('ENSURE_LOCAL_AI.ps1').is_file(); assert Path('SETUP_LOCAL_AI.bat').is_file(); assert Path('launcher.py').is_file(); assert (m.STATIC/'hivemind.ico').is_file(); assert (m.STATIC/'manifest.webmanifest').is_file(); print(f'HIVE SECURITY {expected} payload verification passed.')"
set "VERIFYRC=%ERRORLEVEL%"
popd
if not "%VERIFYRC%"=="0" goto :verifyfail

echo [6/11] Checking/installing Ollama for LOCAL AI...
echo         Existing Ollama installations are reused.
echo         If missing, HIVE SECURITY installs Ollama from the official Windows source.
powershell -NoProfile -ExecutionPolicy Bypass -File "%APPDIR%\ENSURE_LOCAL_AI.ps1" -Model "llama3.2:3b" -ApiPort 11434
if errorlevel 1 goto :aifail

echo [7/11] Verifying Meta Llama 3.2 3B local inference...
echo         Ollama API: http://127.0.0.1:11434
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $t=Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 10; if(-not ($t.models.name -match '^llama3\.2:3b')){throw 'llama3.2:3b is not installed'}; Write-Host 'LOCAL AI VERIFIED: Ollama + llama3.2:3b'"
if errorlevel 1 goto :aifail

echo [8/11] Building Windows application launcher...
if not exist "%APPROOT%\build" mkdir "%APPROOT%\build" >nul 2>nul
if not exist "%APPROOT%\bin" mkdir "%APPROOT%\bin" >nul 2>nul
rmdir /S /Q "%APPROOT%\build\launcher" >nul 2>nul
rmdir /S /Q "%APPROOT%\build\spec" >nul 2>nul
"%APPDIR%\.venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --windowed --name HiveMindSecurity --icon "%APPDIR%\app\static\hivemind.ico" --distpath "%APPROOT%\bin" --workpath "%APPROOT%\build\launcher" --specpath "%APPROOT%\build\spec" "%APPDIR%\launcher.py"
if errorlevel 1 goto :exefail
if not exist "%APPROOT%\bin\HiveMindSecurity.exe" goto :exefail
copy /Y "%APPROOT%\bin\HiveMindSecurity.exe" "%APPROOT%\HiveMindSecurity.exe" >nul
if not exist "%APPROOT%\HiveMindSecurity.exe" goto :exefail

echo [9/11] Creating launchers and branded shortcuts...
copy /Y "%APPDIR%\START_HIVE_MIND_SECURITY.bat" "%APPROOT%\START_HIVE_MIND_SECURITY.bat" >nul
copy /Y "%APPDIR%\STOP_HIVE_MIND_SECURITY.bat" "%APPROOT%\STOP_HIVE_MIND_SECURITY.bat" >nul
copy /Y "%APPDIR%\STOP_HIVE_MIND_SECURITY.ps1" "%APPROOT%\STOP_HIVE_MIND_SECURITY.ps1" >nul
copy /Y "%APPDIR%\SETUP_LOCAL_AI.bat" "%APPROOT%\SETUP_LOCAL_AI.bat" >nul
copy /Y "%APPDIR%\ENSURE_LOCAL_AI.ps1" "%APPROOT%\ENSURE_LOCAL_AI.ps1" >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%APPDIR%\CREATE_SHORTCUTS.ps1" -ExePath "%APPROOT%\HiveMindSecurity.exe" -AppRoot "%APPROOT%"
if errorlevel 1 goto :shortcutfail

echo [10/11] Verifying browser branding...
if not exist "%APPDIR%\app\static\favicon.ico" goto :brandingfail
if not exist "%APPDIR%\app\static\icon-192.png" goto :brandingfail
if not exist "%APPDIR%\app\static\icon-512.png" goto :brandingfail
if not exist "%APPDIR%\app\static\manifest.webmanifest" goto :brandingfail

echo [11/11] Starting and checking the secure portal...
call "%APPROOT%\START_HIVE_MIND_SECURITY.bat"
if errorlevel 1 (
  echo ERROR: Installation completed, but the secure portal did not start successfully.
  echo Application files remain installed at: %APPDIR%
  pause
  exit /b 11
)

echo.
echo ====================================================
echo INSTALL COMPLETE - HIVE SECURITY %VERSION%
echo Launcher EXE: %APPROOT%\HiveMindSecurity.exe
echo Application: %APPDIR%
echo Persistent data: %DATADIR%
echo Secure portal: http://127.0.0.1:8765/login
echo LOCAL AI: READY - OLLAMA + META LLAMA 3.2 3B
echo Local AI API: http://127.0.0.1:11434
echo ====================================================
exit /b 0

:aifail
echo.
echo ERROR: HIVE SECURITY LOCAL AI provisioning failed.
echo HIVE SECURITY requires Ollama with Meta Llama 3.2 3B for its local AI features.
echo Internet access is required the first time Ollama/model files must be downloaded.
echo You can retry LOCAL AI setup later with:
echo   %APPROOT%\SETUP_LOCAL_AI.bat
pause
exit /b 18

:exefail
echo ERROR: Could not build the HiveMindSecurity.exe launcher.
pause
exit /b 15

:shortcutfail
echo ERROR: HiveMindSecurity.exe was built, but Windows shortcuts could not be created.
echo The launcher is available at: %APPROOT%\HiveMindSecurity.exe
pause
exit /b 16

:brandingfail
echo ERROR: Browser branding files are missing from the installed application.
pause
exit /b 17

:payloadfail
echo ERROR: Installer payload is incomplete.
echo Extract the ENTIRE ZIP before running this installer.
pause
exit /b 2

:copyfail
echo ERROR: Core application or LOCAL AI setup files were not copied correctly.
pause
exit /b 5

:pipfail
echo ERROR: Dependency installation failed.
echo Requirements file: %APPDIR%\requirements.txt
pause
exit /b 7

:verifyfail
echo ERROR: Application verification failed. HIVE SECURITY was not started.
pause
exit /b 8
