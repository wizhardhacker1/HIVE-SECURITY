import ctypes
import os
import subprocess
import sys
import time
import urllib.request
import webbrowser
from pathlib import Path

APPROOT = Path(os.environ.get('LOCALAPPDATA', str(Path.home() / 'AppData' / 'Local'))) / 'HiveMindSecurity'
APPDIR = APPROOT / 'app'
LOGDIR = APPROOT / 'logs'
URL = 'http://127.0.0.1:8765/login'


def message(title: str, text: str, error: bool = False) -> None:
    flags = 0x10 if error else 0x40
    try:
        ctypes.windll.user32.MessageBoxW(None, text, title, flags)
    except Exception:
        pass


def ready() -> bool:
    try:
        req = urllib.request.Request(URL, headers={'User-Agent': 'HIVE-SECURITY-Launcher/0.7.14'})
        with urllib.request.urlopen(req, timeout=1.5) as r:
            return 200 <= getattr(r, 'status', 200) < 400
    except Exception:
        return False


def read_logs() -> str:
    parts = []
    for name in ('server.err.log', 'server.log'):
        p = LOGDIR / name
        if p.exists():
            try:
                txt = p.read_text(encoding='utf-8', errors='replace')[-6000:]
                if txt.strip():
                    parts.append(f'--- {name} ---\n{txt}')
            except Exception:
                pass
    return '\n\n'.join(parts) or 'No server log output was available.'


def run_hidden(args, cwd=None, timeout=30):
    creationflags = 0
    startupinfo = None
    if os.name == 'nt':
        creationflags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = 0
    return subprocess.run(args, cwd=str(cwd) if cwd else None, capture_output=True, text=True,
                          timeout=timeout, creationflags=creationflags, startupinfo=startupinfo)


def start_server(pyexe: Path, run_py: Path) -> int:
    """Start the FastAPI backend detached; never wait for the long-running server process."""
    LOGDIR.mkdir(parents=True, exist_ok=True)
    out_path = LOGDIR / 'server.log'
    err_path = LOGDIR / 'server.err.log'
    creationflags = 0
    startupinfo = None
    if os.name == 'nt':
        creationflags = (getattr(subprocess, 'CREATE_NO_WINDOW', 0) |
                         getattr(subprocess, 'DETACHED_PROCESS', 0) |
                         getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0))
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = 0
    out = open(out_path, 'ab', buffering=0)
    err = open(err_path, 'ab', buffering=0)
    try:
        p = subprocess.Popen([str(pyexe), str(run_py)], cwd=str(APPDIR), stdin=subprocess.DEVNULL,
                             stdout=out, stderr=err, creationflags=creationflags,
                             startupinfo=startupinfo, close_fds=True)
        (APPROOT / 'server.pid').write_text(str(p.pid), encoding='ascii')
        return p.pid
    finally:
        out.close(); err.close()


def main() -> int:
    if ready():
        webbrowser.open(URL)
        return 0

    pyexe = APPDIR / '.venv' / 'Scripts' / 'python.exe'
    stop_ps1 = APPROOT / 'STOP_HIVE_MIND_SECURITY.ps1'
    run_py = APPDIR / 'run.py'

    missing = [str(p) for p in (pyexe, stop_ps1, run_py) if not p.exists()]
    if missing:
        message('HIVE SECURITY', 'The installation is incomplete. Re-run INSTALL_HIVE_SECURITY.bat.\n\nMissing:\n' + '\n'.join(missing), True)
        return 12

    LOGDIR.mkdir(parents=True, exist_ok=True)
    try:
        stop = run_hidden(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(stop_ps1),
                           '-Port', '8765', '-FailIfForeign'], cwd=APPROOT, timeout=20)
    except Exception as e:
        message('HIVE SECURITY', f'Could not inspect port 8765.\n\n{e}', True)
        return 9

    if stop.returncode >= 9:
        details = (stop.stderr or stop.stdout or '').strip()
        message('HIVE SECURITY', 'Port 8765 is being used by another application. Close that application and try again.' + (f'\n\n{details}' if details else ''), True)
        return 9

    try:
        start_server(pyexe, run_py)
    except Exception as e:
        message('HIVE SECURITY', f'Could not start the local secure portal.\n\n{e}\n\nLogs:\n{read_logs()}', True)
        return 14

    deadline = time.time() + 75
    while time.time() < deadline:
        if ready():
            webbrowser.open(URL)
            return 0
        time.sleep(0.5)

    message('HIVE SECURITY', 'The backend was launched, but the secure portal did not become ready within 75 seconds.\n\nLogs:\n' + read_logs(), True)
    return 11


if __name__ == '__main__':
    raise SystemExit(main())
