HIVE SECURITY 0.7.19 - FULL WINDOWS INSTALLER
INCLUDING LOCAL AI: OLLAMA + META LLAMA 3.2 3B

1. Extract the ENTIRE ZIP to a normal folder.
2. Double-click INSTALL_HIVE_MIND_SECURITY.bat.
3. The installer creates/updates %LOCALAPPDATA%\HiveMindSecurity\app and preserves persistent data in %LOCALAPPDATA%\HiveMindSecurity\data.
4. It installs Hive Mind Python dependencies into a private virtual environment and builds the branded HiveMindSecurity.exe launcher.
5. It checks for Ollama. If Ollama is already installed, that installation is reused. If it is missing, the installer installs the official Windows Ollama package.
6. It checks for Meta Llama 3.2 3B (llama3.2:3b). If the model is missing it downloads it, then performs a real local inference health check before HIVE SECURITY installation is reported complete.
7. Ollama remains on the local loopback API at http://127.0.0.1:11434 for HIVE SECURITY local AI features.
8. First-time Ollama/model provisioning requires internet access. The Llama 3.2 3B Ollama model is about 2 GB, so allow time and disk space for the download.
9. A repair/retry script is installed at %LOCALAPPDATA%\HiveMindSecurity\SETUP_LOCAL_AI.bat.
10. Desktop/Start Menu shortcuts and browser icons use the HIVE SECURITY shield.
11. The built-in Pentest Scanner does not require Nessus or Nmap. Optional SSH/WinRM support is part of HIVE SECURITY's own Python environment.
12. Credentialed scanning requires the target system to permit the selected protocol and valid authorized credentials.

Normal launcher:
%LOCALAPPDATA%\HiveMindSecurity\HiveMindSecurity.exe

Persistent data:
%LOCALAPPDATA%\HiveMindSecurity\data

Local AI:
Ollama API: http://127.0.0.1:11434
Model: llama3.2:3b

0.7.19 UI THEME UPDATE
- Restores HIVE SECURITY's red/black visual identity across the navigation hierarchy.
- Navigation group headings use red emphasis, dark red gradients, and clear dividers.
- Child navigation items are consistently indented beneath the correct group.
- Active/hover states use red/charcoal treatments rather than gold/yellow decoration.
- MITRE ATT&CK decorative highlights and selected-row accents were aligned to the red/black theme; semantic warning colors remain available for actual warning states.

0.7.19 PENTEST REPORT STUDIO
- New Pentest Report Studio workspace for professional, evidence-grounded penetration-test reporting.
- Create report projects with client, assessment type, author, classification, and lifecycle status.
- Attach encrypted PDF/DOCX/TXT/MD/CSV/JSON/XML/HTML sources plus PNG/JPG evidence screenshots.
- Reuse already imported third-party pentest reports and link analyst-reviewed tracked findings.
- Local Ollama + llama3.2:3b drafts executive summary, scope, objectives, methodology, attack surface, risk summary, findings narrative, remediation roadmap, conclusion, and limitations from project evidence only.
- Every AI-generated section remains editable before delivery.
- Professional HIVE SECURITY PDF includes red/black branding, severity summary, detailed findings, evidence/remediation, evidence images with captions, and a source appendix with SHA-256 references.
- The desktop launcher now starts the long-running backend detached and polls portal readiness for up to 75 seconds instead of waiting on START_SERVER.ps1.

0.7.19 ATT&CK CLEANUP + EXTERNAL LINKS
- Cascades ATT&CK correlations when their source STIG, pentest scan/report finding, or tracked finding is deleted.
- Adds orphan cleanup during ATT&CK rebuild plus a Clean Orphans + Rebuild control.
- Adds a dedicated External Intelligence Links page and OSIRIS AI link.
