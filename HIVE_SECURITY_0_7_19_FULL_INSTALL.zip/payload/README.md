# HIVE SECURITY 0.7.19

## Built-in Authorized Pentest Scanner

HIVE SECURITY now includes a local-first vulnerability/exposure scanner that does not require Nessus or Nmap. The scanner performs bounded TCP service discovery, HTTP/TLS posture checks, selected exposed-service and legacy-banner checks, optional credentialed read-only inventory, encrypted result storage, tracked-finding import, and PDF reporting.

### Scan profiles
- Quick: common infrastructure/application ports.
- Standard: TCP 1-1024 plus common database, management, cache, search, and web application ports.
- Targets: one IP, DNS name, or CIDR up to /27 (32 usable hosts).
- Authorization confirmation is mandatory before a scan can start.
- No exploit execution, password spraying, persistence, destructive checks, stealth/evasion, or automatic scope expansion.

### Credentialed scanning
Administrator User Information now includes an optional encrypted scan credential profile per HIVE SECURITY user:
- SSH username + password and/or private key for Linux/Unix read-only inventory.
- Windows WinRM username + password + optional domain for read-only inventory/configuration queries.
- Secrets are encrypted at rest with the HIVE SECURITY local data key and are never returned to the browser after saving.
- Analysts may use only their own saved credential profile; administrators can select configured profiles.

### Reports and findings
Each completed scan produces an encrypted-at-rest PDF pentest scan report. Findings can also be imported into the existing Tracked Finding Register for remediation, ownership, status updates, and remediation reporting.


## Pentest Report Studio

0.7.19 adds a dedicated **Pentest Report Studio**. Analysts can create a report project, attach encrypted assessment documents and PNG/JPG evidence screenshots, reuse previously imported third-party pentest reports, link tracked findings, and use the local `llama3.2:3b` model to draft evidence-grounded report prose. The executive summary, scope, objectives, methodology, attack surface, risk summary, findings narrative, remediation roadmap, conclusion, and limitations remain editable by the analyst.

The final HIVE SECURITY PDF uses professional red/black branding and includes a severity summary, detailed finding evidence and remediation, analyst-captioned evidence images, and a SHA-256 source appendix. The local 3B model is text-only, so screenshots are included as evidence but are not silently interpreted by AI.

## Launcher reliability

The Windows launcher now starts the FastAPI backend as a detached process and polls the portal for up to 75 seconds. This avoids the earlier false 20-second PowerShell timeout while preserving the existing port-ownership safety check and server logs.

## Existing platform capabilities
0.7.19 retains the secure local portal, user administration/RBAC, unified operations, SOC/IR lifecycle, vulnerability board, STIG helper/import, third-party pentest report ingestion, tracked findings/remediation PDFs, threat feeds/integrations, Red/Blue/Purple workspaces, playbooks, GRC frameworks, Analyst Toolbox, and the Security+/SecurityX/CISSP/LFCS/CEH learning and exam system.

Persistent application data remains under `%LOCALAPPDATA%\HiveMindSecurity\data` and is preserved during upgrades.

## Local AI provisioning in 0.7.19

The full Windows installer now treats LOCAL AI as an installation component rather than an optional undocumented post-step. It checks for Ollama, installs Ollama from its official Windows distribution when missing, provisions `llama3.2:3b`, verifies the loopback API on `127.0.0.1:11434`, and runs a real inference health check. Existing Ollama/model installations are reused. `SETUP_LOCAL_AI.bat` remains available for repair/retry.

## STIG remediation guidance in 0.7.19
Imported STIG findings now use the authoritative Fix Text when it is present in CKL/CKLB/XCCDF content. If an imported result omits Fix Text, HIVE SECURITY generates conservative supplemental remediation guidance from the rule title, IDs, and finding details for common Windows security controls. Unknown rules remain explicit rather than inventing registry values or commands. Re-import older scan files to populate guidance for legacy findings.
## MITRE ATT&CK automatic correlation and source cleanup in 0.7.19

HIVE SECURITY now correlates security evidence into ATT&CK Coverage automatically. Open STIG findings are represented as **Control Gaps**, built-in scanner and pentest findings as **Exposed** attack paths, explicit team findings as **Observed**, Purple Team tests as **Validated**, and local-AI extracted third-party report findings as **Suggested** until analyst review.

The ATT&CK workspace now includes a visual technique matrix, asset-centric attack-vector paths, confidence/evidence for every mapping, detection counts, and analyst review/edit/dismiss controls. Correlation covers STIG imports, native STIG checks, built-in pentest scans (even when scan findings were not separately imported), uploaded third-party pentest findings, team findings, Purple validation, and detection engineering mappings.

The correlation engine deliberately distinguishes exposure/control weakness from actual observed attacker behavior so the dashboard does not claim compromise merely because a vulnerable service or failed control exists.


## OSIRIS Global Intelligence (0.7.19)
HIVE SECURITY includes a native, keyless OSIRIS Intelligence integration backed by `https://osirisai.live` public read APIs. The Global Intelligence workspace provides selectable cyber attacks, malware, conflicts, GDELT, infrastructure, maritime, earthquake, fire, and weather map layers, an intelligence feed, feed-health handling, right-click Region Dossiers, IOC pivots, and HIVE MITRE ATT&CK correlation for retained cyber evidence. OSIRIS remains an external intelligence source; geographic proximity and third-party telemetry are context, not proof of activity against a HIVE asset.

## ATT&CK lifecycle cleanup (0.7.19)
Deleting a STIG scan/history item, built-in pentest scan, tracked finding, or imported pentest report now removes ATT&CK correlations derived from the deleted source. Rebuild Correlation also performs an orphan check, and the new Clean Orphans + Rebuild action removes stale derived mappings left by older versions. Independent mappings from surviving sources remain.

## External Intelligence Links (0.7.19)
A dedicated Threat & Response workspace now exposes the full OSINT/analyst launchpad instead of hiding it only inside Interactive Kill Chain. It includes OSINT Framework, Shodan, Censys, VirusTotal, AbuseIPDB, GreyNoise, urlscan.io, SecurityTrails, crt.sh, CISA KEV, MITRE ATT&CK, Cyber Kill Chain, and OSIRIS AI (`https://osirisai.live/`).

## Analyst Toolbox external links consolidation (0.7.19)
All external intelligence and OSINT links are now available only from Analyst Toolbox. The separate Threat & Response external-links page and the Interactive Kill Chain launchpad were removed to keep one authoritative external-resource location. OSIRIS AI remains in the centralized list and the native OSIRIS Global Intelligence workspace remains available as an internal HIVE feature.
