param(
    [Parameter(Mandatory=$true)][string]$ExePath,
    [Parameter(Mandatory=$true)][string]$AppRoot
)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $ExePath)) { throw "Launcher EXE not found: $ExePath" }

$desktop = [Environment]::GetFolderPath('Desktop')
$programs = [Environment]::GetFolderPath('Programs')
$startFolder = Join-Path $programs 'Hive Mind Security'
New-Item -ItemType Directory -Path $startFolder -Force | Out-Null

$wsh = New-Object -ComObject WScript.Shell
foreach ($linkPath in @(
    (Join-Path $desktop 'Hive Mind Security.lnk'),
    (Join-Path $startFolder 'Hive Mind Security.lnk')
)) {
    $shortcut = $wsh.CreateShortcut($linkPath)
    $shortcut.TargetPath = $ExePath
    $shortcut.WorkingDirectory = $AppRoot
    $shortcut.IconLocation = "$ExePath,0"
    $shortcut.Description = 'Hive Mind Security'
    $shortcut.Save()
}

$stopBat = Join-Path $AppRoot 'STOP_HIVE_MIND_SECURITY.bat'
if (Test-Path -LiteralPath $stopBat) {
    $stopLink = $wsh.CreateShortcut((Join-Path $startFolder 'Stop Hive Mind Security.lnk'))
    $stopLink.TargetPath = $stopBat
    $stopLink.WorkingDirectory = $AppRoot
    $stopLink.IconLocation = "$ExePath,0"
    $stopLink.Description = 'Stop Hive Mind Security local server'
    $stopLink.Save()
}
Write-Host 'Desktop and Start Menu shortcuts created.'
