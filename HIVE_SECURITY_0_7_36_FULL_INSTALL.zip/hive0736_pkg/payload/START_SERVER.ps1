param(
    [Parameter(Mandatory=$true)][string]$PythonExe,
    [Parameter(Mandatory=$true)][string]$AppDir,
    [Parameter(Mandatory=$true)][string]$LogDir,
    [Parameter(Mandatory=$true)][string]$PidFile
)
$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
$stdout = Join-Path $LogDir 'server.log'
$stderr = Join-Path $LogDir 'server.err.log'
Remove-Item $stdout,$stderr -Force -ErrorAction SilentlyContinue
$p = Start-Process -FilePath $PythonExe -ArgumentList @('run.py') -WorkingDirectory $AppDir -RedirectStandardOutput $stdout -RedirectStandardError $stderr -WindowStyle Hidden -PassThru
Set-Content -LiteralPath $PidFile -Value $p.Id -Encoding ascii
Write-Host "Started Hive Mind Security server process $($p.Id)."
exit 0
