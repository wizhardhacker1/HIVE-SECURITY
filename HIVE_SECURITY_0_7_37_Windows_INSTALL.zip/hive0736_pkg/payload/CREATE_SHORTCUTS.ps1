param(
    [Parameter(Mandatory=$true)][string]$ExePath,
    [Parameter(Mandatory=$true)][string]$AppRoot
)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $ExePath)) { throw "Launcher EXE not found: $ExePath" }

$desktop = [Environment]::GetFolderPath('Desktop')
$programs = [Environment]::GetFolderPath('Programs')
$startFolder = Join-Path $programs 'HIVE SECURITY'
$legacyStartFolder = Join-Path $programs 'Hive Mind Security'
New-Item -ItemType Directory -Path $startFolder -Force | Out-Null
New-Item -ItemType Directory -Path $legacyStartFolder -Force | Out-Null

$wsh = New-Object -ComObject WScript.Shell
$links = @(
    (Join-Path $desktop 'HIVE SECURITY.lnk'),
    (Join-Path $desktop 'Hive Mind Security.lnk'),
    (Join-Path $startFolder 'HIVE SECURITY.lnk'),
    (Join-Path $legacyStartFolder 'Hive Mind Security.lnk')
)
foreach ($linkPath in $links) {
    $shortcut = $wsh.CreateShortcut($linkPath)
    $shortcut.TargetPath = $ExePath
    $shortcut.Arguments = ''
    $shortcut.WorkingDirectory = $AppRoot
    $shortcut.IconLocation = "$ExePath,0"
    $shortcut.Description = 'HIVE SECURITY'
    $shortcut.WindowStyle = 7
    $shortcut.Save()
}

$stopBat = Join-Path $AppRoot 'STOP_HIVE_MIND_SECURITY.bat'
if (Test-Path -LiteralPath $stopBat) {
    foreach ($folder in @($startFolder,$legacyStartFolder)) {
        $stopName = if ($folder -eq $startFolder) { 'Stop HIVE SECURITY.lnk' } else { 'Stop Hive Mind Security.lnk' }
        $stopLink = $wsh.CreateShortcut((Join-Path $folder $stopName))
        $stopLink.TargetPath = $stopBat
        $stopLink.WorkingDirectory = $AppRoot
        $stopLink.IconLocation = "$ExePath,0"
        $stopLink.Description = 'Stop HIVE SECURITY local server'
        $stopLink.Save()
    }
}
Write-Host 'HIVE SECURITY desktop and Start Menu shortcuts created.'
