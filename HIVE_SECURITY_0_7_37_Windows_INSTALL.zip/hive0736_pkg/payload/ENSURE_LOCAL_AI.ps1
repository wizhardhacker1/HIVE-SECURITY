param(
  [string]$Model = 'llama3.2:3b',
  [int]$ApiPort = 11434
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

function Write-Step([string]$Message) {
  Write-Host "[LOCAL AI] $Message"
}

function Find-Ollama {
  $cmd = Get-Command ollama -ErrorAction SilentlyContinue
  if ($cmd -and $cmd.Source) { return $cmd.Source }

  $candidates = @(
    (Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'),
    (Join-Path $env:LOCALAPPDATA 'Ollama\ollama.exe'),
    (Join-Path $env:ProgramFiles 'Ollama\ollama.exe')
  )
  if (${env:ProgramFiles(x86)}) {
    $candidates += (Join-Path ${env:ProgramFiles(x86)} 'Ollama\ollama.exe')
  }
  foreach ($candidate in $candidates) {
    if ($candidate -and (Test-Path $candidate)) { return $candidate }
  }
  return $null
}

function Test-OllamaApi {
  try {
    $r = Invoke-RestMethod -Uri "http://127.0.0.1:$ApiPort/api/tags" -Method Get -TimeoutSec 5
    return $true
  } catch {
    return $false
  }
}

function Start-OllamaApi([string]$OllamaExe) {
  if (Test-OllamaApi) { return }
  Write-Step 'Starting the loopback Ollama service...'
  Start-Process -FilePath $OllamaExe -ArgumentList 'serve' -WindowStyle Hidden | Out-Null
  for ($i = 0; $i -lt 30; $i++) {
    Start-Sleep -Seconds 1
    if (Test-OllamaApi) { return }
  }
  throw "Ollama did not become ready on 127.0.0.1:$ApiPort."
}

Write-Step 'Checking for Ollama...'
$ollama = Find-Ollama

if (-not $ollama) {
  Write-Step 'Ollama is not installed. Installing it now...'
  $winget = Get-Command winget -ErrorAction SilentlyContinue
  if ($winget) {
    & $winget.Source install --id Ollama.Ollama -e --accept-package-agreements --accept-source-agreements --disable-interactivity
    if ($LASTEXITCODE -ne 0) {
      Write-Step "winget returned exit code $LASTEXITCODE; trying the official Ollama Windows installer script."
    }
    Start-Sleep -Seconds 3
    $ollama = Find-Ollama
  }

  if (-not $ollama) {
    Write-Step 'Using the official Ollama Windows install script from ollama.com...'
    $installScript = Join-Path $env:TEMP 'hivemind_ollama_install.ps1'
    Invoke-WebRequest -Uri 'https://ollama.com/install.ps1' -OutFile $installScript -UseBasicParsing
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $installScript
    $installRc = $LASTEXITCODE
    Remove-Item $installScript -Force -ErrorAction SilentlyContinue
    if ($installRc -ne 0) { throw "Ollama installer returned exit code $installRc." }
    Start-Sleep -Seconds 5
    $ollama = Find-Ollama
  }
}

if (-not $ollama) {
  throw 'Ollama installation completed but ollama.exe could not be located.'
}

$versionText = (& $ollama --version 2>&1 | Out-String).Trim()
Write-Step "Found $versionText"

Start-OllamaApi -OllamaExe $ollama

Write-Step "Checking for Meta Llama 3.2 3B ($Model)..."
& $ollama show $Model *> $null
if ($LASTEXITCODE -ne 0) {
  Write-Step 'Model is not installed. Downloading it now (about 2 GB; internet access is required)...'
  & $ollama pull $Model
  if ($LASTEXITCODE -ne 0) { throw "Failed to download $Model." }
} else {
  Write-Step 'Model is already installed; no model download is needed.'
}

Write-Step 'Verifying the model is listed by the local API...'
$tags = Invoke-RestMethod -Uri "http://127.0.0.1:$ApiPort/api/tags" -Method Get -TimeoutSec 10
$names = @($tags.models | ForEach-Object { $_.name })
$present = $false
foreach ($name in $names) {
  if ($name -eq $Model -or $name -eq "$Model`:latest") { $present = $true; break }
}
if (-not $present) {
  # Ollama can normalize aliases; `ollama show` is the final authoritative check.
  & $ollama show $Model *> $null
  if ($LASTEXITCODE -ne 0) { throw "$Model was not found after provisioning." }
}

Write-Step 'Running a local inference health check...'
$body = @{
  model = $Model
  prompt = 'Reply with exactly: HIVE MIND LOCAL AI READY'
  stream = $false
  options = @{ num_predict = 12; temperature = 0 }
} | ConvertTo-Json -Depth 5

try {
  $reply = Invoke-RestMethod -Uri "http://127.0.0.1:$ApiPort/api/generate" -Method Post -ContentType 'application/json' -Body $body -TimeoutSec 180
  if (-not $reply.response) { throw 'The model returned an empty response.' }
} catch {
  throw "Local inference health check failed: $($_.Exception.Message)"
}

Write-Step "READY - Ollama is running on 127.0.0.1:$ApiPort and $Model produced a response."
exit 0
