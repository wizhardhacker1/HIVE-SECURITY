@echo off
setlocal EnableExtensions
TITLE Hive Mind Security - Local AI Setup
echo.
echo ====================================================
echo   HIVE MIND SECURITY - LOCAL AI PROVISIONING
echo   OLLAMA + META LLAMA 3.2 3B
echo ====================================================
echo.
echo This checks for Ollama, installs it when missing, provisions
echo llama3.2:3b, starts the loopback service, and runs an inference test.
echo Model data stays local after the initial download.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0ENSURE_LOCAL_AI.ps1" -Model "llama3.2:3b" -ApiPort 11434
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" (
  echo LOCAL AI SETUP FAILED. Exit code: %RC%
  echo Check internet access and Windows security policy, then run this file again.
  pause
  exit /b %RC%
)
echo LOCAL AI READY - LLAMA 3.2 3B
pause
exit /b 0
