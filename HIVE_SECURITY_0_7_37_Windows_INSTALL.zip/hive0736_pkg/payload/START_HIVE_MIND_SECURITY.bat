@echo off
setlocal EnableExtensions
set "VERSION=0.7.37"
set "APPROOT=%LOCALAPPDATA%\HiveMindSecurity"
set "LAUNCHER=%APPROOT%\HiveMindSecurity.exe"

if not exist "%LAUNCHER%" (
  echo ERROR: HIVE SECURITY launcher is missing:
  echo   %LAUNCHER%
  echo Re-run INSTALL_HIVE_SECURITY.bat.
  pause
  exit /b 12
)

rem The EXE is a windowed launcher. It starts the backend with pythonw.exe as a
rem detached background process, so HIVE does not depend on this cmd.exe window.
start "" "%LAUNCHER%"
endlocal
exit /b 0
