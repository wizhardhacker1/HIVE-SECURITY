param(
    [Parameter(Mandatory=$true)][string]$PythonExe,
    [Parameter(Mandatory=$true)][string]$AppDir,
    [Parameter(Mandatory=$true)][string]$LogDir,
    [Parameter(Mandatory=$true)][string]$PidFile
)
$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
$stdout = Join-Path $LogDir 'server.log'
$stderr = Join-Path $LogDir 'server.err.log'

# Use pythonw.exe whenever available so the backend owns no console window.
$serverExe = $PythonExe
$pythonw = Join-Path (Split-Path -Parent $PythonExe) 'pythonw.exe'
if (Test-Path -LiteralPath $pythonw) { $serverExe = $pythonw }

$p = Start-Process -FilePath $serverExe -ArgumentList @('run.py') -WorkingDirectory $AppDir `
    -RedirectStandardOutput $stdout -RedirectStandardError $stderr -WindowStyle Hidden -PassThru
Set-Content -LiteralPath $PidFile -Value $p.Id -Encoding ascii
exit 0
