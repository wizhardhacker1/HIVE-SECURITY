@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0STOP_HIVE_MIND_SECURITY.ps1" -Port 8765
set "RC=%ERRORLEVEL%"
endlocal & exit /b %RC%
