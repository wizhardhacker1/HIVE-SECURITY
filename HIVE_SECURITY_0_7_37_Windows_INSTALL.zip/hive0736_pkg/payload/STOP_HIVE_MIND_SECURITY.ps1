param(
    [int]$Port = 8765,
    [switch]$FailIfForeign
)

$ErrorActionPreference = 'Stop'

function Get-ListeningProcessIds {
    param([int]$LocalPort)
    $ids = @()
    try {
        $ids = Get-NetTCPConnection -LocalPort $LocalPort -State Listen -ErrorAction Stop |
            Select-Object -ExpandProperty OwningProcess -Unique
    }
    catch {
        # Fallback for systems where Get-NetTCPConnection is unavailable.
        try {
            $lines = & netstat.exe -ano -p TCP 2>$null
            foreach ($line in $lines) {
                if ($line -match '^\s*TCP\s+\S+:' + [regex]::Escape([string]$LocalPort) + '\s+\S+\s+LISTENING\s+(\d+)\s*$') {
                    $ids += [int]$Matches[1]
                }
            }
            $ids = $ids | Sort-Object -Unique
        }
        catch {
            $ids = @()
        }
    }
    return @($ids)
}

$processIds = Get-ListeningProcessIds -LocalPort $Port
foreach ($procId in $processIds) {
    try {
        $proc = Get-CimInstance Win32_Process -Filter "ProcessId=$procId" -ErrorAction Stop
        $commandLine = [string]$proc.CommandLine
        $executable = [string]$proc.ExecutablePath
        $isHiveMind = (
            $commandLine -match '(?i)HiveMindSecurity' -or
            $executable -match '(?i)HiveMindSecurity' -or
            $commandLine -match '(?i)(^|[\\/\s])run\.py(\s|$)'
        )

        if ($isHiveMind) {
            Stop-Process -Id $procId -Force -ErrorAction Stop
            Write-Host "Stopped Hive Mind Security process $procId on port $Port."
        }
        elseif ($FailIfForeign) {
            Write-Host "Port $Port is already used by another application (PID $procId)." -ForegroundColor Red
            exit 9
        }
    }
    catch {
        # A process can disappear between the socket lookup and process query.
        if (Get-Process -Id $procId -ErrorAction SilentlyContinue) {
            Write-Host "Unable to inspect or stop process $procId on port ${Port}: $($_.Exception.Message)" -ForegroundColor Red
            exit 10
        }
    }
}

Start-Sleep -Milliseconds 500
$remaining = Get-ListeningProcessIds -LocalPort $Port
if ($remaining.Count -gt 0 -and $FailIfForeign) {
    Write-Host "Port $Port is still in use after the stop attempt (PID(s): $($remaining -join ', '))." -ForegroundColor Red
    exit 9
}

exit 0
