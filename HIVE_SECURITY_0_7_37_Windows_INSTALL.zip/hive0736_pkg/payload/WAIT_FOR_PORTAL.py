from __future__ import annotations
import sys
import time
import urllib.error
import urllib.request

url = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8765/login"
timeout = float(sys.argv[2]) if len(sys.argv) > 2 else 25.0
deadline = time.monotonic() + timeout
last_error = ""
print(f"Checking {url}", flush=True)
while time.monotonic() < deadline:
    try:
        with urllib.request.urlopen(url, timeout=1.5) as response:
            if response.status == 200:
                print("Secure portal responded HTTP 200.", flush=True)
                raise SystemExit(0)
            last_error = f"HTTP {response.status}"
    except Exception as exc:
        last_error = f"{type(exc).__name__}: {exc}"
    print(".", end="", flush=True)
    time.sleep(0.5)
print("", flush=True)
print(f"Portal readiness check failed: {last_error or 'no response'}", flush=True)
raise SystemExit(1)
