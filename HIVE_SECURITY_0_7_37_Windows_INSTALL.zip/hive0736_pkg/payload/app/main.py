from __future__ import annotations
import asyncio, base64, binascii, hashlib, html, ipaddress, json, mimetypes, os, re, secrets, socket, sqlite3, ssl, subprocess, tempfile, time, urllib.parse, zipfile, uuid
from contextvars import ContextVar
from io import BytesIO
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import httpx
import xml.etree.ElementTree as ET
from cryptography.fernet import Fernet, InvalidToken
from fastapi import FastAPI, HTTPException, UploadFile, File, Request, Response
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from pypdf import PdfReader
from docx import Document
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from app.providers import fetch_provider, test_provider, send_test

ROOT=Path(__file__).resolve().parent.parent
DATA=Path(os.getenv('HMS_DATA_DIR',Path(os.getenv('LOCALAPPDATA',ROOT))/'HiveMindSecurity'/'data' if os.getenv('LOCALAPPDATA') else ROOT/'data'))
DATA.mkdir(parents=True,exist_ok=True)
DB=DATA/'hive_mind_security.db'; KEYFILE=DATA/'.hms.key'; BACKUPS=DATA/'backups'; BACKUPS.mkdir(exist_ok=True)
REPORT_STORE=DATA/'pentest_reports'; REPORT_STORE.mkdir(exist_ok=True)
REMEDIATION_STORE=DATA/'remediation_reports'; REMEDIATION_STORE.mkdir(exist_ok=True)
SCAN_REPORT_STORE=DATA/'scan_reports'; SCAN_REPORT_STORE.mkdir(exist_ok=True)
PENTEST_STUDIO_STORE=DATA/'pentest_studio'; PENTEST_STUDIO_STORE.mkdir(exist_ok=True)
STATIC=ROOT/'app'/'static'; APPDATA=ROOT/'app'/'data'; VERSION='0.7.37'
app=FastAPI(title='HIVE SECURITY',version=VERSION,description='Cybersecurity mission command, SOC, threat intelligence, team operations, GRC, live integrations, security toolbox, and certification academy.')
app.mount('/static',StaticFiles(directory=STATIC),name='static')

NEWS_FEEDS=[
 ('CISA Advisories','https://www.cisa.gov/cybersecurity-advisories/all.xml','Government / Advisories','https://www.cisa.gov/news-events/cybersecurity-advisories'),
 ('BleepingComputer','https://www.bleepingcomputer.com/feed/','Breaking / Malware / Ransomware','https://www.bleepingcomputer.com/'),
 ('The Hacker News','https://feeds.feedburner.com/TheHackersNews','Threat Intelligence / Vulnerabilities','https://thehackernews.com/'),
 ('Dark Reading','https://www.darkreading.com/rss.xml','Enterprise / Threat Research','https://www.darkreading.com/'),
 ('SecurityWeek','https://feeds.feedburner.com/securityweek','Enterprise / ICS / Vulnerabilities','https://www.securityweek.com/'),
 ('Cybersecurity Dive','https://www.cybersecuritydive.com/feeds/news/','Business / Regulation / Strategy','https://www.cybersecuritydive.com/'),
 ('CyberScoop','https://cyberscoop.com/feed/','Government / Policy / National Security','https://cyberscoop.com/'),
 ('The Record','https://therecord.media/feed','Cybercrime / Global Incidents','https://therecord.media/'),
 ('Krebs on Security','https://krebsonsecurity.com/feed/','Investigations / Cybercrime','https://krebsonsecurity.com/')
]
CERTS={
 'hive-security':{'name':'HIVE SECURITY Academy','exam':'Application Fundamentals','type':'guided beginner + operational assessment','domains':['Cybersecurity Foundations','Navigation & Workflow','Assets & Scanning','STIG & Compliance','Findings & Remediation','Threat Intelligence & SOC','MITRE ATT&CK & Kill Chain','Team Workspaces','Evidence & Reporting','Local AI & Administration']},
 'security-plus':{'name':'CompTIA Security+','exam':'SY0-701','type':'multiple-choice','domains':['General Security Concepts','Threats, Vulnerabilities & Mitigations','Security Architecture','Security Operations','Security Program Management & Oversight']},
 'securityx':{'name':'CompTIA SecurityX','exam':'CAS-005','type':'scenario','domains':['Governance, Risk, and Compliance','Security Architecture','Security Engineering','Security Operations']},
 'cissp':{'name':'ISC2 CISSP','exam':'Current outline','type':'scenario','domains':['Security and Risk Management','Asset Security','Security Architecture and Engineering','Communication and Network Security','Identity and Access Management','Security Assessment and Testing','Security Operations','Software Development Security']},
 'lfcs':{'name':'Linux Foundation Certified System Administrator','exam':'LFCS','type':'performance-based','domains':['Operations and Deployment','Networking','Storage','Essential Commands','Users and Groups']},
 'ceh':{'name':'EC-Council Certified Ethical Hacker','exam':'CEH v13 / 312-50','type':'knowledge + practical preparation','domains':['Introduction to Ethical Hacking','Footprinting and Reconnaissance','Scanning Networks','Enumeration','Vulnerability Analysis','System Hacking','Malware Threats','Sniffing','Social Engineering','Denial-of-Service','Session Hijacking','Evading IDS, Firewalls, and Honeypots','Hacking Web Servers','Hacking Web Applications','SQL Injection','Hacking Wireless Networks','Hacking Mobile Platforms','IoT and OT Hacking','Cloud Computing','Cryptography']}
}


EXAM_REQUIREMENTS={
 'hive-security':{'official_format':'40-question HIVE SECURITY certification assessment • self-paced','official_pass':'Training benchmark only — 80% recommended','practice_pass_percent':80,'practice_note':'This course teaches HIVE SECURITY and beginner cybersecurity workflows. It is product training, not an external certification.'},
 'security-plus':{'official_format':'Maximum 90 questions • 90 minutes • multiple-choice + performance-based','official_pass':'750 on a 100–900 scaled score','practice_pass_percent':83,'practice_note':'Hive Mind uses 83% as a conservative raw-score practice threshold. CompTIA uses scaled scoring, so this is not an official raw-score conversion.'},
 'securityx':{'official_format':'Maximum 90 questions • 165 minutes • multiple-choice + performance-based','official_pass':'Pass/fail only; CompTIA does not publish a scaled passing score','practice_pass_percent':80,'practice_note':'Because CompTIA does not publish a numeric SecurityX cut score, Hive Mind uses 80% as a readiness threshold, not an official passing score.'},
 'cissp':{'official_format':'CAT • 100–150 items • 3 hours • multiple-choice + advanced item types','official_pass':'700 out of 1000 scaled points','practice_pass_percent':70,'practice_note':'Hive Mind uses 70% as a practice threshold. ISC2 uses psychometric scaled scoring; 70% raw is not an official conversion of 700/1000.'},
 'lfcs':{'official_format':'Performance-based command-line exam • 2 hours','official_pass':'66% practice benchmark used by the LFCS study guide in Hive Mind','practice_pass_percent':66,'practice_note':'Hive Mind applies the 66% benchmark to its knowledge checks. The real LFCS is performance-based, so hands-on lab performance remains essential.'},
 'ceh':{'official_format':'125 multiple-choice questions • 4 hours','official_pass':'Form-dependent cut score; EC-Council states typical passing cut scores range from 65% to 85%','practice_pass_percent':85,'practice_note':'Hive Mind uses the top of EC-Council’s published typical cut-score range (85%) as a conservative practice threshold.'}
}
for _cert,_req in EXAM_REQUIREMENTS.items():
 if _cert in CERTS: CERTS[_cert]['requirements']=_req

BANKS={k:json.loads((APPDATA/f'{f}.json').read_text(encoding='utf-8')) for k,f in {'hive-security':'hive_security','security-plus':'security_plus','securityx':'securityx','cissp':'cissp','lfcs':'lfcs','ceh':'ceh'}.items()}

STUDY_AIDS={
 'hive-security':{
  'overview':'A complete beginner-to-operator curriculum for HIVE SECURITY. Work through the modules in order to learn cybersecurity foundations, safe scanning, STIGs, vulnerability management, threat intelligence, incident response, evidence handling, MITRE ATT&CK, Kill Chain, detection engineering, GRC, Local AI and administration. Finish with the capstone and final assessment to earn the HIVE SECURITY Application Fundamentals Certificate of Completion.',
  'quick_refs':['Asset = a system, host, service or device you protect','Finding = evidence of a weakness that requires triage','IOC = observable indicator such as an IP, domain, URL or hash','CVE = public vulnerability identifier; CWE = weakness class','STIG = secure configuration baseline/checklist','MITRE ATT&CK = behavior-based model of adversary tactics and techniques','Kill Chain = staged view of an intrusion lifecycle','Red finds/exercises; Blue detects/defends; Purple validates both','Evidence should preserve source, time, asset and integrity','Local AI assists analysis; analyst evidence and approval remain authoritative'],
  'labs':['Create a lab asset and document its owner and purpose','Run an authorized Quick pentest scan against a lab target and triage one result','Review a STIG finding, read How to Fix, remediate in a lab and retest','Trace one finding into MITRE ATT&CK Coverage and explain whether it is Exposed, Control Gap, Observed, Suggested or Validated','Create an IOC investigation and record evidence','Walk a mock alert through SOC incident response','Create a Purple Team validation from an ATT&CK technique','Generate an executive report and explain the difference between technical evidence and executive risk','Verify Local AI health and explain what remains local','Create a test user and explain least privilege/RBAC'],
  'flashcards':[['CIA triad','Confidentiality, Integrity and Availability — three core security objectives.'],['Attack surface','The systems, services, identities and interfaces an attacker could potentially reach.'],['Exposure','A condition that creates a plausible path for attack; it does not prove an attack occurred.'],['Control Gap','A missing or ineffective safeguard that reduces prevention, detection or response capability.'],['IOC','An observable artifact that may help identify malicious activity.'],['TTP','Tactic, Technique or Procedure describing adversary behavior.'],['Least privilege','Give identities only the access required for their task.'],['Remediation','A change that removes or reduces a confirmed security weakness.'],['Validation','Retesting to prove a control or remediation works as intended.'],['Chain of custody','A record of who handled evidence, when, why and how integrity was maintained.']]
 },
 'security-plus':{
  'overview':'Use this path to build broad operational security fundamentals before taking timed scenario exams.',
  'quick_refs':['CIA triad + AAA','Common ports and secure protocols','PKI, hashing, encryption and key management','IAM, MFA and least privilege','Network segmentation, Zero Trust and cloud shared responsibility','Incident response, logging, SIEM and vulnerability management','Risk, policy, third-party and compliance concepts'],
  'labs':['Map an incident to the IR lifecycle','Review HTTP security headers','Build a least-privilege access matrix','Write a basic detection rule from a log event','Prioritize a KEV-matched vulnerability'],
  'flashcards':[['Integrity','Protection against unauthorized modification.'],['RTO','Target time to restore a service after disruption.'],['RPO','Maximum tolerable data loss measured in time.'],['SASE','Cloud-delivered networking and security architecture.'],['SCAP','Standards that support automated vulnerability and configuration assessment.']]
 },
 'securityx':{
  'overview':'Advanced architecture and operations study path using scenario-based decision making, not simple memorization.',
  'quick_refs':['Enterprise risk and governance decision patterns','Zero Trust, SASE, microsegmentation and secure architecture','Cloud, container, API, OT/ICS and AI security','Cryptographic architecture and post-quantum planning','Threat modeling and attack-path analysis','Advanced detection, SIEM/XDR, UEBA, threat intelligence and automation','Incident command, forensics, resilience and recovery','Supply-chain, SBOM and secure engineering'],
  'labs':['Design a three-tier microsegmentation policy','Create a Zero Trust access decision flow','Map an attack chain to required telemetry','Draft a cloud guardrail policy-as-code control','Build a purple-team validation for a MITRE technique','Perform a tabletop for ransomware plus identity compromise'],
  'flashcards':[['Microsegmentation','Granular east-west isolation that limits lateral movement.'],['SASE','Converged cloud-delivered networking and security capabilities.'],['SCAP','Security Content Automation Protocol; supports standardized configuration and vulnerability assessment.'],['UEBA','Behavior analytics used to identify anomalous user/entity activity.'],['Data diode','Unidirectional gateway used where one-way data transfer is required.']]
 },
 'cissp':{
  'overview':'Managerial and architectural review across the eight CISSP domains. Focus on risk-based decisions and business alignment.',
  'quick_refs':['Risk: inherent vs residual, treatment, ALE, due care/diligence','Data ownership, classification, lifecycle and retention','Secure design principles and security models','Network architecture and secure protocols','IAM lifecycle, federation, privileged access and access models','Assessment independence, vulnerability testing and penetration testing','IR, BCP/DR, evidence, logging and recovery','Secure SDLC, testing, dependencies and software supply chain'],
  'labs':['Create a BIA for a critical service','Build a data classification matrix','Review an architecture for single points of failure','Design joiner-mover-leaver controls','Create an incident evidence chain-of-custody checklist'],
  'flashcards':[['Residual risk','Risk remaining after controls are applied.'],['Due care','Reasonable protective actions expected from an organization.'],['Due diligence','Ongoing investigation and verification that controls remain appropriate/effective.'],['RTO','Maximum targeted restoration time.'],['RPO','Maximum acceptable data loss expressed as time.']]
 },
 'lfcs':{
  'overview':'Hands-on Linux administration path. Practice commands in a disposable Linux VM and verify every change.',
  'quick_refs':['Files: ls, cd, pwd, find, cp, mv, rm, mkdir, chmod, chown, grep, sed, awk, tar','Systems: systemctl, journalctl, ps, top, kill, nice, cron, systemd timers','Users: useradd, usermod, passwd, groups, sudo, visudo','Networking: ip addr, ip route, ss, dig, hostnamectl, SSH, firewalld/ufw','Services: web servers, SSH, TLS, databases, NFS/Samba and mail basics','Storage: lsblk, fdisk/parted, mkfs, mount, fstab, LVM, RAID, quotas'],
  'labs':['Create and archive a directory tree, then restore it','Create a user/group and safe sudo rule','Create and enable a systemd service','Configure a static route and validate connectivity','Deploy a basic web service and validate TLS/headers','Create an LVM volume, filesystem, mount point and persistent fstab entry','Troubleshoot a failed service using systemctl and journalctl'],
  'flashcards':[['systemctl enable --now','Enable a service at boot and start it immediately.'],['journalctl -u UNIT -f','Follow logs for a systemd unit.'],['usermod -aG GROUP USER','Append a user to a supplementary group.'],['ss -lntp','List listening TCP sockets and process information.'],['lsblk -f','Show block devices and filesystem metadata.'],['visudo','Safely edit and syntax-check sudoers.']]
 },
 'ceh':{
  'overview':'CEH preparation path organized around the current 20-module ethical-hacking curriculum. Use only systems you own or have explicit written authorization to test.',
  'quick_refs':['Rules of engagement, scope, authorization, evidence handling and reporting','Five-phase ethical-hacking workflow: reconnaissance, scanning, gaining access, maintaining access, covering tracks — study as concepts, not unauthorized activity','OSINT and footprinting sources','Host, port, service and OS discovery concepts','Enumeration and vulnerability-analysis workflow','Authentication, password storage, privilege and hardening concepts','Malware behavior and defensive analysis','Packet capture, spoofing and network defense','Social-engineering indicators and user protections','DoS/DDoS concepts and resilience','Session security, tokens and transport protections','IDS/firewall/honeypot roles and detection','Web server and web application attack surfaces','Injection flaws and secure parameterized queries','Wireless security standards and segmentation','Mobile application/platform security','IoT/OT safety, segmentation and monitoring','Cloud shared responsibility, IAM and logging','Cryptography, PKI, hashing and key management','Professional reporting, remediation and retesting'],
  'labs':['Write a rules-of-engagement document for a fictional assessment','Perform passive OSINT on a domain you own and document only public metadata','Run service discovery against an isolated lab VM and compare results with its known configuration','Review a deliberately vulnerable lab application and map findings to CWE categories without attacking public systems','Analyze a packet capture from a lab and identify protocols, endpoints and suspicious patterns','Review password hashes created in the lab using the Password Hash Audit tool and a small approved candidate list','Create a web-server hardening checklist and verify headers on a lab service','Build an incident-style timeline from a simulated phishing scenario','Create a cloud IAM least-privilege review checklist','Write a final pentest-style finding with evidence, risk, remediation and retest steps'],
  'flashcards':[['Rules of Engagement','Written constraints defining scope, allowed techniques, timing, contacts, stop conditions and evidence handling.'],['Footprinting','Collection of information about a target environment, preferably passive first and only within authorization.'],['Enumeration','Active identification of users, services, shares or other details from an authorized target.'],['Vulnerability Analysis','Systematic identification and prioritization of weaknesses before remediation or authorized validation.'],['Least Privilege','Grant only the access necessary for a task and no more.'],['Salt','Unique random value added before password hashing to defeat precomputed rainbow tables.'],['Parameterized Query','SQL statement structure that separates code from user-supplied data to reduce injection risk.'],['WPA3','Modern Wi-Fi security generation providing stronger protections than legacy WPA/WPA2 configurations.'],['Cloud Shared Responsibility','Security duties are split between the cloud provider and customer depending on service model.'],['PKI','Certificates, certificate authorities, keys and policies used to establish trust and secure communications.'],['Honeypot','Decoy system or service designed to attract and observe suspicious activity.'],['CWE','Common Weakness Enumeration: taxonomy for software and hardware weakness types.']]
 }
}


CEH_VIDEOS=[
 {'title':'EC-Council CEH Overview','provider':'YouTube / EC-Council','embed':'https://www.youtube-nocookie.com/embed/V_i3wCtn0qA','note':'Official EC-Council overview. Use alongside the current course outline because older overview videos may reference earlier CEH versions.'},
 {'title':'Current CEH Program & Course Outline','provider':'EC-Council','url':'https://www.eccouncil.org/train-certify/certified-ethical-hacker-ceh-v13-north-america/','note':'Current program outline, exam details and module descriptions.'},
 {'title':'CEH Master / Practical Overview','provider':'EC-Council','url':'https://www.eccouncil.org/train-certify/ceh-master/','note':'Official overview of the optional practical path and lab-oriented assessment.'}
]

STUDY_LESSONS={
 'hive-security':[
  {'title':'Cybersecurity Foundations: What You Are Protecting','objectives':['Explain confidentiality, integrity and availability in practical terms','Differentiate asset, threat, vulnerability, exposure, risk, control, event and incident','Understand why evidence and context matter more than a single severity label'],'topics':['CIA triad','Assets','Threats','Vulnerabilities','Risk','Controls','Evidence','Security events'], 'detail':['Cybersecurity begins with assets: systems, identities, applications, data, network services and business processes that have value. HIVE SECURITY uses the asset record as an anchor so findings and attack paths have business context instead of existing as isolated alerts.','A vulnerability is a weakness. An exposure is a condition that makes a weakness reachable or usable. A threat is something capable of causing harm. Risk combines the likelihood and impact of that harm in the context of a specific asset. An incident is a security event that requires coordinated response.','The CIA triad provides a simple way to reason about impact. Confidentiality asks whether information can be disclosed improperly. Integrity asks whether information or system state can be changed improperly. Availability asks whether a system or service can remain usable when needed.','HIVE SECURITY should not treat every open port, failed STIG control or reputation hit as evidence of compromise. Analysts should identify what was observed, what it means, how confident they are and what additional evidence would confirm or disprove the concern.'], 'practice':['Create three lab assets and identify confidentiality, integrity and availability requirements for each.','Write one example each of a threat, vulnerability, exposure, control gap and confirmed incident.','Take a scanner result and explain why it is or is not proof of compromise.'], 'common_mistakes':['Treating severity as risk without considering asset importance and exposure.','Calling a configuration weakness an attack.','Closing findings without retest evidence.']},
  {'title':'HIVE SECURITY Orientation and Analyst Workflow','objectives':['Navigate every major HIVE SECURITY group','Understand which module owns each record type','Follow a finding from discovery to validation and reporting'],'topics':['Unified Operations','Exposure & Assurance','Threat & Response','Team Workspaces','Academy','Administration'], 'detail':['Unified Operations is the starting point for day-to-day work. It should answer what needs attention, which assets are affected and what the next analyst action should be.','Operations modules discover and inventory. Exposure and Assurance modules evaluate weaknesses, controls and remediation. Threat and Response modules investigate suspicious activity and preserve evidence. Team Workspaces support ATT&CK, Kill Chain, Red, Blue and Purple validation. Administration manages users, integrations, backups and audit history.','A healthy workflow is evidence driven: discover or import evidence, normalize it into a finding, assign ownership, correlate it to ATT&CK when appropriate, remediate, retest and then communicate the result.','Beginners should resist jumping directly to offensive tools. Scope, authorization, asset ownership and expected business impact come first.'], 'practice':['Use the sidebar to locate Assets, Pentest Scanner, STIG, MITRE ATT&CK, Evidence, Incidents and Audit.','Create a sample finding and describe which pages you would use from discovery through closure.'], 'common_mistakes':['Using the wrong module as a data repository.','Scanning before scope and authorization are documented.','Confusing a dashboard summary with source evidence.']},
  {'title':'Asset Inventory, Criticality and Attack Surface','objectives':['Build useful asset records','Understand criticality and ownership','Identify attack surface without overclaiming risk'],'topics':['Asset inventory','Ownership','Criticality','Services','External exposure','Attack surface','Asset context'], 'detail':['Asset inventory is the foundation of useful security analysis. A finding on an unknown host is harder to prioritize than the same finding on a domain controller, payment system or public application.','Record enough context to answer who owns the system, what it does, where it is located, how critical it is and whether it is internet-facing or internally restricted.','Attack surface includes reachable services, applications, identities, trust relationships and interfaces. An open service is not automatically insecure, but it becomes more important when unnecessary, weakly configured or exposed to untrusted networks.','Asset criticality should influence remediation priority. A medium-severity issue on a highly critical exposed system can deserve faster action than a high-severity issue on an isolated disposable lab host.'], 'practice':['Create a lab asset with owner, role, location and criticality.','List its reachable services and classify each as required, optional or unnecessary.','Write an attack-surface summary using only observed evidence.'], 'common_mistakes':['Leaving asset owner blank.','Using hostnames alone without purpose or criticality.','Assuming exposure equals exploitation.']},
  {'title':'Built-In Pentest Scanner: Safe Discovery and Interpretation','objectives':['Choose Quick, Standard or Credentialed scan profiles correctly','Interpret ports, banners, HTTP, TLS and service posture','Move actionable results into remediation workflows'],'topics':['Quick scan','Standard scan','Credentialed scan','Ports','Banners','HTTP headers','TLS','Authorized scope'], 'detail':['The HIVE SECURITY built-in scanner is intentionally bounded and non-exploitative. It is designed to identify reachable services and selected configuration signals without running exploit payloads, password spraying or persistence.','Quick scanning is useful for fast common-port discovery. Standard scanning provides broader service inspection. Credentialed scanning can collect read-only host information when authorized credentials are configured.','Scanner evidence should be interpreted carefully. Reachable RDP may represent a valid administrative service or a significant exposure depending on network location, access controls and business need. Missing HTTP headers may be a hardening issue but do not by themselves prove compromise.','When a result requires ownership and remediation, convert or import it into the tracked finding lifecycle and define a clear validation step for closure.'], 'practice':['Run a Quick scan against a lab host you control.','Compare results with a Standard scan and explain each difference.','Select one result and write evidence, impact, remediation and retest criteria.'], 'common_mistakes':['Scanning unauthorized targets.','Treating a service banner as definitive vulnerability proof.','Using credentials outside approved scope.']},
  {'title':'Scheduled Scanning and Continuous Exposure Management','objectives':['Use recurring scans safely','Understand change over time','Prioritize recurring findings by exposure and criticality'],'topics':['Schedules','Baseline','Drift','Recurring exposure','Trend analysis','Retest'], 'detail':['Scheduled scanning turns a one-time assessment into continuous posture monitoring. The goal is to detect drift, newly exposed services and recurring weaknesses while staying within approved scope.','A baseline gives you something to compare against. New ports, changed certificates, lost security headers or repeated findings should be reviewed in context rather than treated as isolated snapshots.','Repeated findings can indicate failed remediation, configuration drift or an accepted risk that needs formal documentation.','Use remediation and notification workflows so recurring high-risk exposure does not disappear into scan history.'], 'practice':['Create a safe lab scan schedule.','Compare two scan runs and document meaningful changes.','Identify which recurring result should become a tracked remediation item.'], 'common_mistakes':['Scheduling broad ranges without ownership.','Ignoring repeated findings because they are familiar.','Failing to document accepted risk.']},
  {'title':'STIG Compliance: From Checklist to Verified Remediation','objectives':['Understand DISA STIG assessment terminology','Interpret Open, Not a Finding and Not Applicable','Use Fix Text and HIVE remediation guidance safely','Retest and preserve compliance evidence'],'topics':['STIG','CKL','CKLB','XCCDF','Rule ID','Vulnerability ID','CAT I/II/III','Fix Text','Retest'], 'detail':['A STIG is a secure-configuration benchmark. A failed STIG control is a control or configuration gap; it is not evidence that an adversary exploited the system.','Imported checklists may include Rule IDs, Vulnerability IDs, severity/category, finding details and Fix Text. HIVE SECURITY should preserve these values because they are the traceability path back to the applicable benchmark rule.','Use the benchmark Fix Text when available. Before applying a change, verify the system role, organizational policy, dependencies and operational impact. Some secure settings can break legacy applications or management workflows if applied blindly.','After remediation, rerun or re-import the assessment and preserve evidence showing the control is now compliant. Closure without retest creates false assurance.'], 'practice':['Import a sample STIG checklist and inspect one CAT I, II or III finding.','Read How to Fix and identify prerequisites and verification steps.','Remediate one lab setting, rerun the assessment and compare results.'], 'common_mistakes':['Calling every STIG finding a vulnerability exploit.','Applying registry changes without validating applicability.','Deleting old assessment history before evidence is preserved.']},
  {'title':'Findings, CVE, CWE, KEV and Vulnerability Prioritization','objectives':['Write high-quality findings','Understand CVE, CWE, CVSS and CISA KEV','Prioritize by evidence, exploitability, exposure and asset value'],'topics':['Finding lifecycle','CVE','CWE','CVSS','CISA KEV','Severity','Confidence','Ownership'], 'detail':['A useful finding contains a clear title, affected asset, evidence, security impact, severity, confidence, remediation guidance, owner and retest criteria.','CVE identifies a publicly disclosed vulnerability. CWE describes a weakness class. CVSS provides a standardized severity score. CISA KEV adds important context by identifying vulnerabilities known to be exploited in the wild.','Severity is not the same as organizational risk. Prioritization should combine technical severity with exposure, asset criticality, exploitability, compensating controls and business impact.','Confidence should describe how strongly the evidence supports the conclusion. Scanner heuristics or AI suggestions deserve different confidence than a reproduced configuration check or confirmed exploit evidence from an authorized test.'], 'practice':['Take one CVE-based finding and explain CVE, CWE, CVSS and KEV separately.','Build a priority decision for three findings on assets with different criticality.','Write a retest requirement that proves closure.'], 'common_mistakes':['Using CVSS as the only priority factor.','Omitting evidence or asset context.','Marking fixed before validation.']},
  {'title':'Remediation Management and Verified Closure','objectives':['Assign remediation ownership','Track due dates, exceptions and evidence','Verify that fixes actually reduce risk'],'topics':['Owner','Due date','Fix plan','Exception','Compensating control','Retest','Closure evidence'], 'detail':['Remediation is a managed process, not just a recommendation field. A finding should have an accountable owner, target date, implementation plan and validation method.','When the preferred fix cannot be implemented, document the reason, residual risk, compensating controls and approval path. This is different from silently ignoring the issue.','Retesting should repeat the relevant security check and preserve evidence. For a closed port, prove the service is no longer reachable. For a STIG control, rerun the applicable rule. For a web-header issue, capture the corrected response.','Closure should describe what changed, who validated it and when. This creates defensible audit history and reduces repeated debate.'], 'practice':['Create a remediation plan for one scanner result.','Define a compensating control for a hypothetical legacy system.','Perform a retest and write a closure note.'], 'common_mistakes':['Closing based only on an administrator statement.','Using vague fixes such as “patch system.”','Failing to record residual risk.']},
  {'title':'Threat Intelligence and IOC Triage','objectives':['Understand what IOCs can and cannot prove','Use reputation and OSINT sources responsibly','Correlate external context with internal evidence'],'topics':['IP','Domain','URL','Hash','Reputation','OSINT','Confidence','False positives'], 'detail':['Indicators of compromise are observables such as IP addresses, domains, URLs and hashes. They can provide useful context, but reputation alone does not prove that your organization was attacked.','A public IP can be shared, reassigned or used by many services. A domain may change ownership or behavior. Hashes are stronger identifiers for exact file content but still require context about where and when the file was observed.','Use multiple sources when practical and record source, timestamp and confidence. Then look for the indicator in internal logs, endpoints, email, DNS, proxy, firewall or application telemetry.','HIVE SECURITY threat-intelligence pivots should support investigation, not replace analyst judgment.'], 'practice':['Triage a benign test IP or domain using two sources.','Write what evidence would be needed to escalate it to an incident.','Record a confidence statement and expiration/review date.'], 'common_mistakes':['Equating reputation with compromise.','Ignoring timestamp and context.','Blocking indicators without considering shared infrastructure.']},
  {'title':'SOC Triage and Incident Response Lifecycle','objectives':['Differentiate alert, event and incident','Build a timeline','Work through preparation, detection, analysis, containment, eradication, recovery and lessons learned'],'topics':['Alert triage','Incident severity','Timeline','Containment','Eradication','Recovery','Lessons learned'], 'detail':['SOC triage asks whether an alert represents expected activity, a benign anomaly or a security incident. Start by validating the source, affected asset, identity, timestamp and surrounding telemetry.','An incident timeline should preserve what happened, when it happened, who or what was affected, and what actions were taken. Time normalization is essential when logs use different time zones.','Containment limits ongoing harm. Eradication removes the root cause or malicious artifacts. Recovery returns systems to trusted operation. These phases can overlap, but each has a distinct goal.','Lessons learned should create improvements: detection tuning, hardening, documentation, training, architecture changes or new Purple Team validation.'], 'practice':['Create a mock suspicious-login incident.','Build a five-event timeline.','Document containment, eradication and recovery actions separately.'], 'common_mistakes':['Resetting passwords before preserving necessary evidence.','Skipping scope analysis.','Closing before recovery validation.']},
  {'title':'Evidence Locker and Investigation Discipline','objectives':['Preserve evidence integrity','Understand hashing and chain of custody','Organize evidence so another analyst can reconstruct the case'],'topics':['Evidence','SHA-256','Chain of custody','Originals','Metadata','Case notes','Audit trail'], 'detail':['Evidence should answer where it came from, when it was collected, who handled it and why it matters. HIVE SECURITY hashes evidence so later integrity can be checked.','Preserve originals whenever possible. Work from copies for analysis and avoid actions that alter timestamps or metadata unless the change is documented.','A SHA-256 hash does not prove the content is trustworthy; it proves that a specific byte sequence can be identified and compared for change.','Good case notes are factual, timestamped and reproducible. Separate observations from interpretations and clearly identify assumptions.'], 'practice':['Add a harmless evidence file to a test case.','Record source, collection time, purpose and SHA-256.','Write one observation and one interpretation as separate statements.'], 'common_mistakes':['Editing original evidence.','Using screenshots without source context.','Writing conclusions without showing supporting facts.']},
  {'title':'MITRE ATT&CK: Tactics, Techniques, Coverage and Attack Vectors','objectives':['Understand tactics, techniques and sub-techniques','Interpret HIVE mapping states correctly','Use ATT&CK to connect findings, detections and Purple validation'],'topics':['Tactics','Techniques','Sub-techniques','Observed','Exposed','Control Gap','Suggested','Validated','Coverage'], 'detail':['MITRE ATT&CK is a behavior-based knowledge base. A tactic describes an adversary objective, while techniques and sub-techniques describe ways that objective may be achieved.','HIVE SECURITY intentionally distinguishes relationship states. Observed means evidence indicates behavior occurred. Exposed means a weakness creates a plausible attack path. Control Gap means a safeguard is missing or ineffective. Suggested means a candidate mapping needs analyst review. Validated means Purple Team testing confirmed behavior and telemetry.','A failed PowerShell logging STIG can map to T1059.001 as a Control Gap because it reduces visibility, but it should not be labeled Observed PowerShell execution unless telemetry supports that claim.','Attack-vector views help analysts understand how separate exposures can combine into a path. These views are hypotheses grounded in evidence, not automatic proof that an attacker followed the path.'], 'practice':['Map exposed RDP to T1021.001 and explain why it is Exposed.','Map disabled PowerShell logging to T1059.001 as a Control Gap.','Review one Suggested mapping and document approval or dismissal reasoning.'], 'common_mistakes':['Treating every ATT&CK mapping as observed attacker activity.','Ignoring confidence and source evidence.','Using ATT&CK IDs without explaining relevance.']},
  {'title':'Cyber Kill Chain and Safe Red, Blue and Purple Team Operations','objectives':['Understand all seven Kill Chain phases','Distinguish Red, Blue and Purple responsibilities','Turn a hypothesis into a safe validation exercise'],'topics':['Reconnaissance','Weaponization','Delivery','Exploitation','Installation','C2','Actions on Objectives','Detection validation'], 'detail':['The Cyber Kill Chain provides a staged model of intrusion progression. HIVE SECURITY uses it as an educational and defensive planning structure, not as malware or exploit automation.','Red Team activity should operate only under explicit authorization and rules of engagement. Blue Team focuses on prevention, detection, investigation and response. Purple Team connects the two by defining a safe behavior, expected telemetry and measurable outcome.','A good Purple test specifies scope, technique, exact test time, expected sensors, expected detection logic and pass/fail criteria.','Failed Purple tests are valuable: they identify telemetry, logic, process or response gaps that can be remediated and retested.'], 'practice':['Choose one safe Kill Chain command for an isolated lab.','Write expected endpoint, network and SIEM telemetry.','Create a Purple test with measurable pass/fail criteria.'], 'common_mistakes':['Running tests outside written scope.','Calling tool execution a successful detection test without checking telemetry.','Failing to capture timestamps.']},
  {'title':'Detection Engineering and Coverage Validation','objectives':['Write clear detection hypotheses','Understand data-source dependencies','Measure coverage with evidence instead of assumptions'],'topics':['Detection hypothesis','Telemetry','Sigma','Splunk','KQL','Elastic','False positives','Tuning','ATT&CK coverage'], 'detail':['A detection begins with a hypothesis: what suspicious behavior do you want to identify, and which data sources contain the necessary evidence?','A rule cannot detect data that is not collected. Validate endpoint logs, authentication logs, network telemetry and application audit sources before blaming query logic.','Tuning reduces false positives while preserving meaningful behavior. Document exclusions and assumptions because overly broad suppression can create blind spots.','Coverage should be marked validated only after a controlled test demonstrates that expected telemetry reaches the detection and produces the intended analyst-visible result.'], 'practice':['Write a detection hypothesis for suspicious PowerShell use.','List required telemetry fields.','Design a safe Purple test to validate the rule.'], 'common_mistakes':['Copying a rule without understanding its data requirements.','Suppressing noisy results without analysis.','Marking coverage complete based only on rule existence.']},
  {'title':'Risk, GRC and Executive Communication','objectives':['Translate technical findings into business risk','Understand frameworks and control evidence','Write useful executive summaries'],'topics':['Risk statement','Likelihood','Impact','Control evidence','Exceptions','NIST','CIS','ISO 27001','PCI DSS','SOC 2','HIPAA'], 'detail':['Technical findings become business decisions when they are connected to assets, impact, likelihood, ownership and treatment options.','Framework controls should reference evidence. A checkbox without evidence is weak assurance; a tested control with timestamps, artifacts and ownership is stronger.','Executives generally need concise answers: what is at risk, how serious is it, what changed, who owns the response and what decision is required. Engineers need exact technical evidence and remediation detail.','A strong risk statement describes condition, threat or consequence and business impact without unnecessary jargon.'], 'practice':['Rewrite a technical RDP exposure as an executive risk statement.','Map a control to supporting evidence.','Create a one-paragraph executive update with owner and next decision.'], 'common_mistakes':['Dumping raw scan output into executive reports.','Treating framework completion as proof of effectiveness.','Omitting ownership and due dates.']},
  {'title':'Local AI with Ollama and Llama 3.2 3B','objectives':['Understand the local AI architecture','Distinguish AI assistance from authoritative evidence','Verify model health and troubleshoot common failures'],'topics':['Ollama','llama3.2:3b','Loopback','Inference health','Prompt context','AI limitations','Analyst review'], 'detail':['HIVE SECURITY Local AI uses Ollama on the loopback interface and the Meta Llama 3.2 3B model. The full installer should install Ollama when missing, pull the model when missing and perform a real inference health check.','Local AI can summarize imported pentest text, suggest findings and propose ATT&CK candidates. It should never silently replace original evidence or claim certainty that the source material does not support.','A healthy model check verifies the Ollama service, confirms llama3.2:3b is installed and sends a small generation request. Finding ollama.exe alone is not enough.','When AI is unavailable, core HIVE SECURITY functions should remain usable and clearly show Local AI setup or repair status.'], 'practice':['Verify Local AI status.','Run a harmless report-summary prompt and compare the answer to the source text.','Identify one AI statement that requires analyst verification.'], 'common_mistakes':['Treating AI output as source evidence.','Assuming the model is ready because Ollama is installed.','Sending unnecessary sensitive data outside approved workflows.']},
  {'title':'Administration, RBAC, Credentials, Backups and Audit','objectives':['Apply least privilege','Manage user and scan credentials safely','Understand backup and audit responsibilities'],'topics':['Admin','Analyst','Viewer','RBAC','Encrypted secrets','Professional credentials','Backups','Audit'], 'detail':['User roles should match job responsibilities. Administrators manage platform configuration, analysts perform operational work and viewers should have read-oriented access where appropriate.','Scan credentials are operational secrets and should be separated from professional certification records. HIVE SECURITY encrypts supported secret values at rest, but access to the host and backup files still matters.','Backups protect continuity and should be created before major upgrades or configuration changes. Protect backup media because it contains the data required to restore the environment.','Audit logs provide accountability for important actions. User-created operational records can be edited or deleted when appropriate, while audit history should remain append-oriented.'], 'practice':['Create a least-privilege test user.','Review credential storage and explain why secrets should not appear in notes.','Create a backup and locate the corresponding audit event.'], 'common_mistakes':['Giving every user admin rights.','Putting passwords in free-text fields.','Failing to protect backups.']},
  {'title':'Capstone: Run a Security Finding End to End','objectives':['Combine the entire workflow','Demonstrate evidence-based decision making','Prepare for the HIVE SECURITY final assessment'],'topics':['Scope','Discovery','Finding','ATT&CK','Remediation','Retest','Evidence','Reporting'], 'detail':['The capstone combines the platform into one repeatable workflow. Start with an authorized lab asset, collect evidence using a safe scan or imported checklist, create or normalize a finding and document why it matters.','Correlate the finding to ATT&CK only when the relationship is defensible, and select the correct state such as Exposed or Control Gap.','Assign remediation, perform the fix in the lab, retest and preserve evidence showing the result changed.','Finish by writing both a technical closure note and a short executive summary. The goal is not button memorization; it is demonstrating that you understand what the evidence means and can move it through a defensible security lifecycle.'], 'practice':['Complete one end-to-end lab from asset creation through verified closure.','Create an ATT&CK relationship and explain its state and confidence.','Generate or draft a final report summarizing evidence, remediation and validation.'], 'common_mistakes':['Skipping authorization or asset context.','Using ATT&CK labels without evidence.','Completing the workflow without retest proof.']}
 ],
 'security-plus':[
  {'title':'Security Foundations & Architecture','objectives':['Apply CIA, AAA and Zero Trust concepts','Compare secure architecture patterns','Choose compensating controls'],'topics':['Security control categories','Zero Trust','Segmentation','Cloud shared responsibility','Resilience and availability'],'practice':['Sketch trust boundaries for a three-tier app','Explain why a control is preventive, detective, corrective or compensating']},
  {'title':'Threats, Vulnerabilities & Mitigations','objectives':['Recognize common attack paths','Prioritize exposure','Select practical mitigations'],'topics':['Social engineering','Malware','Vulnerability classes','Attack surfaces','Hardening','Patch and configuration management'],'practice':['Take one KEV CVE and create a remediation priority statement','Build a threat-to-control mapping']},
  {'title':'Identity, Cryptography & Data Protection','objectives':['Select authentication methods','Understand certificate trust','Protect data states'],'topics':['MFA','Federation','PAM','PKI','Hashing','Encryption','Key lifecycle','Data classification'],'practice':['Map joiner-mover-leaver controls','Inspect a TLS certificate and identify issuer/validity/SANs']},
  {'title':'Security Operations & Incident Response','objectives':['Triage alerts','Build timelines','Contain and recover'],'topics':['Logging','SIEM','EDR','Threat intel','Vulnerability management','IR lifecycle','Backups'],'practice':['Create an incident timeline from five events','Write a basic IOC hunt for Splunk or KQL']},
  {'title':'Governance, Risk & Program Management','objectives':['Translate technical issues into risk','Apply policy and third-party concepts','Prepare for scenario questions'],'topics':['Risk treatment','Policies/standards/procedures','Vendor risk','Awareness','Audits','BCP/DR'],'practice':['Write a risk statement with likelihood, impact and treatment','Build a one-page third-party security checklist']}
 ],
 'securityx':[
  {'title':'Governance, Risk & Enterprise Security','objectives':['Make risk-based architecture decisions','Select controls for business constraints','Evaluate supply-chain and AI risk'],'topics':['Enterprise risk','GRC','Third-party risk','AI guardrails','SBOM','Policy enforcement','Security automation'],'practice':['Compare two architecture options and defend the lower-risk choice','Create an AI workload guardrail checklist']},
  {'title':'Zero Trust, SASE & Segmentation','objectives':['Design trust decisions','Separate control and data planes','Limit lateral movement'],'topics':['PDP/PEP','SASE','Microsegmentation','ZTNA','Identity context','Network trust boundaries'],'practice':['Design a three-tier microsegmentation matrix','Draw a PDP-to-PEP decision flow']},
  {'title':'Advanced Cloud, API, Container & OT Security','objectives':['Select controls for hybrid environments','Protect APIs and workloads','Recognize OT safety constraints'],'topics':['Cloud IAM','CASB','Workload identity','API gateways','Containers','Kubernetes','OT/ICS','Data diodes'],'practice':['Threat-model a cloud API','Design a one-way OT telemetry pattern']},
  {'title':'Cryptography & Resilient Architecture','objectives':['Choose enterprise cryptographic controls','Plan key management','Reason about post-quantum migration'],'topics':['PKI','HSM','Key splitting','Forward secrecy','Post-quantum planning','Certificate lifecycle','Resilience'],'practice':['Build a certificate lifecycle checklist','Create a crypto-agility migration plan']},
  {'title':'Advanced Security Operations','objectives':['Correlate ambiguous telemetry','Use behavior analytics','Improve detection engineering'],'topics':['SIEM/XDR','UEBA','Threat intelligence','Automation','Central logging','Detection engineering','DFIR'],'practice':['Build a telemetry matrix for one ATT&CK behavior','Investigate a suspicious timeline and identify missing evidence']},
  {'title':'Incident Command, Recovery & Purple Validation','objectives':['Coordinate complex incidents','Protect evidence','Validate controls continuously'],'topics':['Incident command','Forensics','Containment tradeoffs','BCP/DR','Purple teaming','ATT&CK','Retesting'],'practice':['Run a ransomware tabletop','Create a Purple validation with expected telemetry and pass/fail criteria']}
 ],
 'cissp':[
  {'title':'Security & Risk Management','objectives':['Prioritize business risk','Apply governance and ethics','Understand compliance responsibilities'],'topics':['Risk assessment','Policies','Legal/regulatory','Threat modeling','BCP concepts'],'practice':['Create a risk register entry and treatment rationale']},
  {'title':'Asset & Data Security','objectives':['Classify information','Assign ownership','Protect data lifecycle'],'topics':['Classification','Retention','Handling','Privacy','Media sanitization'],'practice':['Build a data classification and handling matrix']},
  {'title':'Architecture, Engineering & Networks','objectives':['Apply secure design principles','Evaluate crypto and physical controls','Design secure communications'],'topics':['Security models','Cryptography','Hardware security','Network segmentation','Secure protocols'],'practice':['Review an architecture for trust boundaries and single points of failure']},
  {'title':'IAM, Assessment & Operations','objectives':['Manage identity lifecycle','Plan assurance activities','Run secure operations'],'topics':['Federation','PAM','Access models','Audit/testing','IR','DR','Logging'],'practice':['Design joiner-mover-leaver controls and an access review']},
  {'title':'Software Development Security','objectives':['Integrate security into SDLC','Manage dependencies','Choose testing methods'],'topics':['Secure SDLC','SAST/DAST','Threat modeling','CI/CD','Supply chain'],'practice':['Build a secure release gate checklist']}
 ],
 'lfcs':[
  {'title':'Essential Commands','objectives':['Navigate and manipulate files','Process text','Archive and redirect I/O'],'topics':['ls/cd/pwd/find','cp/mv/rm','chmod/chown','grep/sed/awk','tar/gzip','pipes/redirection'],'practice':['Create /tmp/exam/data, add files, archive the tree and restore it to /tmp/backup','Use grep/sed/awk to extract fields from a sample log']},
  {'title':'Running Systems','objectives':['Manage services and processes','Read logs','Schedule work'],'topics':['systemctl','journalctl','ps/top','kill/nice','cron','systemd timers','boot targets'],'practice':['Create and enable a systemd service','Troubleshoot a failed service using systemctl status and journalctl']},
  {'title':'Users, Groups & Sudo','objectives':['Manage local identities','Control group membership','Delegate privilege safely'],'topics':['useradd/usermod','groupadd','passwd','id/groups','visudo','sudoers'],'practice':['Create a user/group and add a least-privilege sudo rule']},
  {'title':'Networking','objectives':['Configure addresses and routes','Troubleshoot name resolution','Manage host firewall'],'topics':['ip addr/link/route','ss','DNS','SSH','firewalld','ufw','iptables/nftables'],'practice':['Configure a test address/route in a disposable VM and validate it','Allow an approved service through the firewall and verify listening sockets']},
  {'title':'Service Configuration','objectives':['Deploy common services','Validate service state','Apply TLS basics'],'topics':['Apache/Nginx','SSH','NFS/Samba','Databases','Postfix','TLS certificates'],'practice':['Deploy a basic web virtual host and enable it at boot','Validate logs and listening ports']},
  {'title':'Storage Management','objectives':['Partition and format storage','Configure persistent mounts','Manage LVM/RAID/quotas'],'topics':['fdisk/parted','mkfs/fsck','mount/fstab','LVM','mdadm','quotas'],'practice':['Create a loop-backed test disk, filesystem and persistent mount','Create and extend an LVM logical volume in a lab']}
 ],
 'ceh':[
  {'title': 'Ethical Hacking Foundations', 'objectives': ['Explain authorization, scope and professional ethics', 'Apply risk and threat-intelligence concepts'], 'topics': ['Rules of engagement', 'Risk management', 'Cyber Kill Chain', 'MITRE ATT&CK', 'Legal/compliance boundaries'], 'practice': ['Draft a scoped authorization statement', 'Map a simulated attack chain to defensive controls']},
  {'title': 'Footprinting & Reconnaissance', 'objectives': ['Differentiate passive and active discovery', 'Collect only authorized/public metadata'], 'topics': ['OSINT', 'WHOIS', 'DNS', 'Search engines', 'Social media', 'Email metadata'], 'practice': ['Document passive OSINT for a domain you own', 'Identify what information should be removed from public exposure']},
  {'title': 'Scanning Networks', 'objectives': ['Interpret host and service discovery', 'Select safe scanning approaches'], 'topics': ['Host discovery', 'Port scanning', 'Service/version detection', 'OS detection', 'Scan detection'], 'practice': ['Scan an isolated lab subnet', 'Compare open ports with expected services']},
  {'title': 'Enumeration', 'objectives': ['Recognize enumeration targets and defensive controls', 'Document evidence safely'], 'topics': ['DNS', 'SMB', 'SNMP', 'LDAP', 'NTP', 'Service banners'], 'practice': ['Enumerate only a lab service', 'Recommend one hardening control for each exposed service']},
  {'title': 'Vulnerability Analysis', 'objectives': ['Prioritize vulnerabilities using exploitability and impact', 'Use CVE/CWE/CVSS appropriately'], 'topics': ['CVE', 'CWE', 'CVSS', 'CISA KEV', 'Scanner validation', 'False positives'], 'practice': ['Prioritize five sample findings', 'Write validation steps that do not require exploitation']},
  {'title': 'System Security & Passwords', 'objectives': ['Explain password storage and authentication weaknesses', 'Apply least privilege and hardening'], 'topics': ['Password hashing', 'Salts', 'MFA', 'Privilege', 'Patching', 'Secure configuration'], 'practice': ['Generate strong passwords in the toolbox', 'Audit a lab hash against a small approved candidate list']},
  {'title': 'Malware Threats', 'objectives': ['Classify malware behavior', 'Choose safe analysis and containment approaches'], 'topics': ['Ransomware', 'Trojans', 'Worms', 'Loaders', 'Indicators', 'Sandboxing'], 'practice': ['Classify a simulated malware alert', 'Build a containment checklist']},
  {'title': 'Sniffing & Network Defense', 'objectives': ['Interpret packet-capture evidence', 'Explain spoofing and segmentation defenses'], 'topics': ['Packet capture', 'ARP', 'DNS', 'TLS', 'Switch security', 'Network monitoring'], 'practice': ['Analyze a supplied lab PCAP', 'Identify where encryption prevents content inspection']},
  {'title': 'Social Engineering', 'objectives': ['Recognize manipulation techniques', 'Design layered user and technical defenses'], 'topics': ['Phishing', 'Pretexting', 'Baiting', 'MFA fatigue', 'BEC', 'Awareness'], 'practice': ['Triage a simulated phishing email', 'Write a user-verification procedure']},
  {'title': 'DoS & Availability', 'objectives': ['Differentiate DoS/DDoS patterns', 'Plan resilience and response'], 'topics': ['Volumetric attacks', 'Application exhaustion', 'Rate limiting', 'CDN/WAF', 'Capacity', 'Runbooks'], 'practice': ['Build a DDoS response checklist', 'Identify telemetry needed to distinguish outage from attack']},
  {'title': 'Session Security', 'objectives': ['Explain session/token risk', 'Apply secure cookie and transport controls'], 'topics': ['Cookies', 'Tokens', 'TLS', 'Session fixation', 'Expiration', 'CSRF'], 'practice': ['Inspect a sample JWT without trusting it', 'Review secure session-cookie settings']},
  {'title': 'IDS, Firewalls & Honeypots', 'objectives': ['Explain defensive control roles', 'Interpret alert and evasion concepts defensively'], 'topics': ['IDS/IPS', 'WAF', 'Firewall', 'Honeypot', 'Segmentation', 'Logging'], 'practice': ['Map a safe lab test to expected alerts', 'Document detection gaps and retest criteria']},
  {'title': 'Web Server Security', 'objectives': ['Identify web-server exposure', 'Apply hardening and patching'], 'topics': ['TLS', 'Headers', 'Directory exposure', 'Patching', 'Service accounts', 'Logging'], 'practice': ['Review headers on a lab server', 'Create a web-server hardening checklist']},
  {'title': 'Web Application Security', 'objectives': ['Recognize common application weaknesses', 'Use secure testing methodology'], 'topics': ['OWASP concepts', 'Authentication', 'Access control', 'Input validation', 'File upload', 'Business logic'], 'practice': ['Threat-model a sample web form', 'Map findings to secure coding controls']},
  {'title': 'SQL Injection Defense', 'objectives': ['Explain injection root cause', 'Select prevention and validation controls'], 'topics': ['Parameterized queries', 'ORM safety', 'Input handling', 'DB least privilege', 'Logging'], 'practice': ['Rewrite an unsafe sample query conceptually', 'Create detection indicators for injection attempts']},
  {'title': 'Wireless Security', 'objectives': ['Compare wireless security standards', 'Plan secure enterprise Wi-Fi'], 'topics': ['WPA2/WPA3', '802.1X', 'Guest isolation', 'Rogue AP detection', 'RF monitoring'], 'practice': ['Design a segmented guest/corporate WLAN', 'Review a sample wireless configuration']},
  {'title': 'Mobile Platform Security', 'objectives': ['Identify mobile threats', 'Apply application/device controls'], 'topics': ['Permissions', 'Secure storage', 'MDM', 'App signing', 'API security', 'Jailbreak/root risk'], 'practice': ['Review a mobile-app permission set', 'Build a mobile hardening checklist']},
  {'title': 'IoT & OT Security', 'objectives': ['Recognize safety and availability constraints', 'Plan segmentation and monitoring'], 'topics': ['IoT identity', 'Firmware', 'OT protocols', 'Passive monitoring', 'Safety', 'Change control'], 'practice': ['Design an OT monitoring architecture', 'Prioritize a vulnerable IoT device remediation']},
  {'title': 'Cloud Computing Security', 'objectives': ['Apply shared responsibility', 'Review IAM, logging and exposure'], 'topics': ['IAM', 'Storage exposure', 'Cloud logs', 'Secrets', 'Network controls', 'Containers'], 'practice': ['Review a fictional cloud IAM policy', 'Build a cloud incident evidence checklist']},
  {'title': 'Cryptography', 'objectives': ['Select appropriate cryptographic controls', 'Explain PKI and password hashing'], 'topics': ['Symmetric/asymmetric encryption', 'Hashing', 'Salting', 'PKI', 'Certificates', 'Key lifecycle'], 'practice': ['Compare hashing versus encryption', 'Inspect a certificate chain in a lab']}
 ]
}


# 0.5.4 expanded certification learning paths. These are original study aids and
# practice questions; official provider resources are linked for current objectives.
CERT_VIDEOS={
 'security-plus':[
  {'title':'How to Pass Your SY0-701 Security+ Exam in 2026','provider':'Professor Messer','kind':'Video','url':'https://www.youtube.com/watch?v=KiEptGbnEBc','embed':'https://www.youtube-nocookie.com/embed/KiEptGbnEBc','validated_at':'2026-09-08','validation':'Verified public video','note':'Current SY0-701 exam-preparation overview from Professor Messer. The exact public video ID was validated before this build.'},
  {'title':'Professor Messer SY0-701 Security+ Training Course','provider':'Professor Messer','kind':'Playlist','url':'https://www.youtube.com/playlist?list=PLG49S3nxzAnl4QDVqK-hOnoqcSKEIDDuv','validated_at':'2026-09-08','validation':'Verified playlist','note':'Full SY0-701 playlist organized around the current Security+ objectives.'},
  {'title':'CompTIA Security+ Exam Objectives','provider':'CompTIA','kind':'Official resource','url':'https://www.comptia.org/training/resources/exam-objectives','validated_at':'2026-09-08','validation':'Provider resource','note':'Use CompTIA exam objectives as the authoritative scope checklist; video resources are supplemental.'}
 ],
 'securityx':[
  {'title':'CompTIA SecurityX CAS-005 Video Course','provider':'HowToNetwork','kind':'Video course','url':'https://www.howtonetwork.com/courses/comptia/comptia-securityx-certification/','validated_at':'2026-09-08','validation':'Verified public course page with video player','note':'Current CAS-005-labelled advanced SecurityX video course. Third-party training; verify topics against CompTIA objectives.'},
  {'title':'CompTIA SecurityX Certification Overview','provider':'CompTIA','kind':'Official resource','url':'https://www.comptia.org/certifications/securityx','validated_at':'2026-09-08','validation':'Provider resource','note':'Authoritative certification reference for SecurityX / CAS-005 scope and requirements.'},
  {'title':'CompTIA Exam Objectives','provider':'CompTIA','kind':'Official resource','url':'https://www.comptia.org/training/resources/exam-objectives','validated_at':'2026-09-08','validation':'Provider resource','note':'Use the current CAS-005 objectives to verify every study topic.'}
 ],
 'cissp':[
  {'title':'CISSP: Your Journey Begins Here','provider':'ISC2TV','kind':'Video','url':'https://www.youtube.com/watch?v=s5u14qE2qBs','embed':'https://www.youtube-nocookie.com/embed/s5u14qE2qBs','validated_at':'2026-09-08','validation':'Verified public ISC2 video','note':'Public video published by ISC2TV; validated before this build.'},
  {'title':'CISSP: An Inside Look','provider':'ISC2','kind':'Official video','url':'https://cloud.connect.isc2.org/cissp-an-inside-look','validated_at':'2026-09-08','validation':'Verified official video landing page','note':'ISC2 on-demand CISSP video covering domains, preparation and the certification journey.'},
  {'title':'CISSP Exam Outline','provider':'ISC2','kind':'Official resource','url':'https://www.isc2.org/certifications/cissp/cissp-certification-exam-outline','validated_at':'2026-09-08','validation':'Verified official outline','note':'Current eight-domain outline. Use this as the authoritative content map.'}
 ],
 'lfcs':[
  {'title':'LFCS Certification & Current Domains','provider':'Linux Foundation','kind':'Official resource','url':'https://training.linuxfoundation.org/certification/linux-foundation-certified-sysadmin-lfcs/','validated_at':'2026-09-08','validation':'Verified official LFCS page','note':'Current LFCS domains, competencies and performance-based exam details.'},
  {'title':'Linux System Administration Essentials (LFS207)','provider':'Linux Foundation','kind':'Official e-learning','url':'https://training.linuxfoundation.org/training/linux-system-administration-essentials-lfs207/','validated_at':'2026-09-08','validation':'Verified official training page','note':'Official Linux Foundation system-administration course aligned to skills tested by LFCS. Course access may require enrollment.'},
  {'title':'Linux Foundation Video Channel','provider':'Linux Foundation','kind':'Video channel','url':'https://www.youtube.com/@LinuxfoundationOrg','validated_at':'2026-09-08','validation':'Verified public channel','note':'Official Linux Foundation YouTube channel for Linux, containers and open-source operations. Use current videos as supplemental learning.'}
 ],
 'ceh':[
  {'title':'Get the AI Edge with CEH v13','provider':'EC-Council','kind':'Video','url':'https://www.youtube.com/watch?v=O8jjNj3hGIQ','embed':'https://www.youtube-nocookie.com/embed/O8jjNj3hGIQ','validated_at':'2026-09-08','validation':'Verified public EC-Council video','note':'Official EC-Council CEH v13 overview. This replaces the older v11 video used in previous builds.'},
  {'title':'CEH v13 with the AI Edge','provider':'EC-Council','kind':'Video','url':'https://www.youtube.com/watch?v=pI8EQzABsP4','embed':'https://www.youtube-nocookie.com/embed/pI8EQzABsP4','validated_at':'2026-09-08','validation':'Verified public EC-Council video','note':'Official CEH v13 overview video.'},
  {'title':'Current CEH v13 Program & Course Outline','provider':'EC-Council','kind':'Official resource','url':'https://www.eccouncil.org/train-certify/certified-ethical-hacker-ceh-v13-north-america/','validated_at':'2026-09-08','validation':'Verified official CEH v13 page','note':'Authoritative current program/module reference. EC-Council notes that YouTube is supplemental and not a substitute for official training.'}
 ]
}

RESOURCE_HEALTH_ALLOWED_HOSTS={
 'www.youtube.com','youtube.com','www.youtube-nocookie.com','cloud.connect.isc2.org','www.isc2.org',
 'training.linuxfoundation.org','www.eccouncil.org','www.comptia.org','www.howtonetwork.com'
}


STUDY_AIDS.update({
 'security-plus':{
  'overview':'Expanded CompTIA Security+ SY0-701 preparation path with domain-by-domain lessons, scenario practice, quick references, flashcards, labs, videos and an 80-question original practice bank.',
  'quick_refs':['Security controls: preventive, deterrent, detective, corrective, compensating and directive','CIA, AAA, non-repudiation, least privilege, separation of duties and Zero Trust','Cryptography: symmetric/asymmetric, hashing, salts, digital signatures, certificates, PKI and key lifecycle','Threat actors, attack surfaces, social engineering, malware, supply chain and vulnerability concepts','Architecture: segmentation, VLANs, DMZs, NAC, SASE, SD-WAN, cloud shared responsibility, containers and virtualization','Identity: MFA factors, federation, SSO, RBAC/ABAC, PAM, provisioning and access reviews','Operations: logs, SIEM, EDR/XDR, SOAR, baselines, hardening, patching, backups and change management','Incident response: preparation, detection, analysis, containment, eradication, recovery and lessons learned','Vulnerability management: discovery, validation, prioritization, remediation, retesting, CVE/CVSS and KEV','Governance: policies, standards, procedures, risk register, third parties, privacy, audits, awareness and metrics'],
  'labs':['Build a control matrix for a fictional SaaS application','Inspect TLS and HTTP security headers on a local lab service','Create a least-privilege RBAC matrix for help desk, analyst and administrator roles','Triage a simulated phishing email and document indicators without opening attachments','Build a SIEM hunt from a sample failed-login event','Prioritize a set of vulnerabilities using asset criticality, exposure, CVSS and CISA KEV','Design a backup plan with RTO/RPO and test evidence','Run a tabletop through the six incident-response phases','Create a vendor risk questionnaire and minimum-security requirements','Use Hive Mind Toolbox to parse IOCs and decode a benign sample artifact'],
  'flashcards':[['Zero Trust','Never trust implicitly; continually evaluate identity, device, context and policy before granting least-privilege access.'],['RTO','Target maximum time to restore a service after disruption.'],['RPO','Maximum acceptable data loss measured backward in time.'],['Salting','Adding a unique random value before password hashing to defeat precomputed tables.'],['Digital Signature','Provides integrity, origin authentication and non-repudiation when the private key is protected.'],['PAM','Controls and monitors privileged identities and privileged sessions.'],['SASE','Cloud-delivered convergence of networking and security capabilities.'],['KEV','CISA catalog of vulnerabilities known to be exploited in the wild.'],['DLP','Controls intended to detect or prevent unauthorized movement or exposure of sensitive data.'],['SOAR','Security orchestration, automation and response used to coordinate repeatable workflows.'],['Compensating Control','Alternative control used when the preferred control cannot be implemented.'],['Data Minimization','Collect and retain only data necessary for the stated purpose.']]
 },
 'securityx':{
  'overview':'Expanded CompTIA SecurityX CAS-005 preparation path for senior security architecture and operations decisions, with advanced scenario modules, labs, videos, flashcards and an 80-question original practice bank.',
  'quick_refs':['Risk-driven architecture: business impact, threat modeling, trust boundaries and control trade-offs','Zero Trust: policy decision/enforcement points, identity context, continuous evaluation and microsegmentation','Hybrid and multi-cloud architecture: IAM, secrets, control planes, logging, workload identity and shared responsibility','Secure software and APIs: threat modeling, CI/CD controls, SBOM, signing, secrets, dependency and runtime protection','Cryptographic architecture: PKI, key custody, HSM/KMS, rotation, algorithm agility and post-quantum planning','OT/ICS and IoT: safety, deterministic availability, passive discovery, segmentation, jump hosts and data diodes','Advanced detection: SIEM/XDR, UEBA, threat intelligence, behavioral analytics, detection engineering and SOAR','Resilience: BIA, RTO/RPO, immutable backups, alternate processing, chaos testing and recovery validation','GRC: control inheritance, exceptions, third-party risk, privacy, audit evidence and continuous monitoring','Incident leadership: command structure, evidence strategy, scoping, containment trade-offs, communications and post-incident improvement'],
  'labs':['Design a Zero Trust access flow with PDP/PEP and device posture','Create a multi-account cloud landing-zone security baseline','Threat-model an API-driven application and identify trust boundaries','Design a secrets-management and key-rotation architecture','Build an OT segmentation design that preserves safety and one-way telemetry where appropriate','Create a detection engineering plan for identity compromise using SIEM and UEBA','Run a ransomware plus identity-compromise tabletop with executive communications','Review a fictional software supply chain and build an SBOM/signing control plan','Write a third-party exception with compensating controls and an expiration date','Create a Purple-Team validation plan and define expected telemetry and success criteria'],
  'flashcards':[['PDP','Policy Decision Point evaluates context and decides whether access should be allowed.'],['PEP','Policy Enforcement Point applies the access decision at the resource boundary.'],['Microsegmentation','Granular east-west isolation intended to limit lateral movement.'],['Data Diode','One-way gateway used when information must flow in only one direction.'],['Algorithm Agility','Ability to replace cryptographic algorithms and keys without redesigning the entire system.'],['SBOM','Inventory of software components and dependencies used for supply-chain visibility.'],['UEBA','Behavior analytics for detecting anomalous user or entity activity.'],['Control Inheritance','Reuse of controls provided by a shared platform or service rather than duplicating them per system.'],['Blast Radius','Scope of systems, identities or data affected if a component is compromised.'],['Immutable Backup','Backup protected from modification/deletion for a defined retention period.'],['Threat Model','Structured analysis of assets, trust boundaries, threats and mitigations.'],['Security Debt','Accumulated risk from deferred security work, exceptions and outdated design choices.']]
 },
 'cissp':{
  'overview':'Expanded ISC2 CISSP preparation across all eight domains, emphasizing the manager/architect perspective, risk-based decisions, official-domain alignment, scenario practice, videos and an 80-question original bank.',
  'quick_refs':['Domain 1: ethics, governance, policy, legal/regulatory, risk, BCP, personnel and supply-chain risk','Domain 2: classification, ownership, handling, data lifecycle, retention, remanence and privacy','Domain 3: secure design principles, models, cryptography, physical security and architecture assessment','Domain 4: secure network design, protocols, segmentation, remote access and network attacks/defenses','Domain 5: identity lifecycle, access models, federation, authentication, authorization, PAM and access reviews','Domain 6: assessment strategy, control testing, audits, vulnerability assessment, penetration testing and reporting','Domain 7: investigations, IR, logging, DR, backups, patching, change, evidence and operational resilience','Domain 8: SDLC, secure coding, testing, software supply chain, CI/CD, APIs and acquired software','CISSP decision lens: protect people and business objectives first, follow policy/law, choose risk-based governance, then technical detail','Quantitative risk: SLE × ARO = ALE; compare treatment cost with expected risk reduction while accounting for qualitative factors'],
  'labs':['Perform a BIA and derive RTO/RPO for three services','Create a data-classification and handling matrix','Review an architecture for single points of failure and trust-boundary risks','Design a network segmentation model for users, servers, management and third parties','Create joiner-mover-leaver and privileged-access review workflows','Write an independent security assessment plan with evidence and reporting','Build an incident evidence chain-of-custody and retention checklist','Create a secure SDLC release gate for code, dependencies, secrets and deployment','Compare risk treatment options using ALE plus qualitative impact','Draft a board-level risk statement that separates inherent and residual risk'],
  'flashcards':[['Due Care','Reasonable protective actions expected from an organization.'],['Due Diligence','Ongoing investigation and verification that controls remain appropriate and effective.'],['Residual Risk','Risk remaining after controls are implemented.'],['Data Owner','Business role accountable for classification and protection requirements.'],['Data Custodian','Role that implements and operates controls on behalf of the data owner.'],['Bell-LaPadula','Confidentiality model commonly summarized as no read up and no write down.'],['Biba','Integrity model commonly summarized as no read down and no write up.'],['Defense in Depth','Multiple complementary control layers so one failure does not expose the asset.'],['Federation','Trust relationship allowing identities from one domain to authenticate to another.'],['Chain of Custody','Documented control and transfer history for evidence.'],['BIA','Analysis of business impact used to prioritize continuity and recovery requirements.'],['SDLC','Lifecycle for planning, developing, testing, deploying, operating and retiring software securely.']]
 },
 'lfcs':{
  'overview':'Expanded Linux Foundation Certified System Administrator preparation aligned to the current five LFCS domains. Because LFCS is performance-based, the path emphasizes command-line labs, troubleshooting, videos and an 80-question original review bank.',
  'quick_refs':['Operations & Deployment 25%: kernel parameters, processes/services, scheduled jobs, packages/repos, recovery, VMs, containers and SELinux','Networking 25%: IPv4/IPv6, hostname resolution, time sync, troubleshooting, OpenSSH, filtering/NAT, static routes, bridges/bonds and reverse proxy/load balancing','Storage 20%: LVM, VFS, filesystems, remote filesystems, network block devices, swap, automounters and storage performance','Essential Commands 20%: Git basics, service configuration/troubleshooting, performance, constraints, disk-space troubleshooting and SSL certificates','Users & Groups 10%: local accounts/groups, profiles, resource limits, ACLs and LDAP identities','Core diagnostics: systemctl status, journalctl, ps, top, ss, ip, lsblk, df, du, findmnt and dmesg','Safe persistence: validate configuration before reboot, use systemd enablement, fstab cautiously and test mounts with mount -a','Permissions: mode bits, ownership, ACLs, sticky/setgid/setuid concepts and least privilege','Networking: verify link/address/route/DNS/listener/firewall separately to isolate failures','Storage: identify block device → partition/LVM → filesystem → mount → persistence → permissions → performance'],
  'labs':['Tune a kernel parameter temporarily and persistently, then verify both','Troubleshoot and repair a failed systemd service from logs','Create a scheduled job and prove it executed','Install a package from a configured repository and verify package ownership of a file','Create and run a rootless container in a disposable VM','Apply an SELinux context/boolean change appropriate to a lab service and verify enforcement','Configure IPv4/IPv6 addressing, DNS and a static route in a lab','Configure OpenSSH safely and validate client/server settings','Create a packet-filter rule and verify it with ss plus a local connection test','Create a bridge or bond in a disposable VM/network namespace','Create and extend an LVM logical volume and filesystem','Configure swap and an automounted filesystem','Use Git to clone/init, modify, inspect status and commit a local repository','Diagnose disk-space exhaustion with df/du/find and safely reclaim lab space','Create users/groups, resource limits and ACLs, then verify effective access'],
  'flashcards':[['systemctl enable --now','Enable a unit at boot and start it immediately.'],['journalctl -u UNIT','Show logs for a specific systemd unit.'],['sysctl -w','Change a kernel parameter at runtime; persistence requires a sysctl configuration file.'],['ss -lntp','List listening TCP sockets with process information when permitted.'],['ip route','Display or manage the kernel routing table.'],['findmnt','Show mounted filesystems and their sources/options.'],['lsblk -f','Show block devices with filesystem metadata.'],['mount -a','Attempt mounts defined in fstab; useful for validating changes before reboot.'],['setfacl/getfacl','Set or inspect POSIX ACLs.'],['ulimit','Inspect or set shell resource limits; system-wide policy may use limits.conf/systemd settings.'],['semanage/restorecon','Common SELinux tools for persistent context policy and applying default labels.'],['git status','Show working-tree and staging-area state.']]
 }
})

STUDY_LESSONS.update({
 'security-plus':[
  {'title':'Security Foundations & Control Types','objectives':['Apply CIA/AAA and non-repudiation','Differentiate control categories and functions','Use Zero Trust and least privilege concepts'],'topics':['CIA','AAA','Control types','Zero Trust','Least privilege','Separation of duties'],'practice':['Classify ten sample controls by type and function','Choose controls for a remote-work access scenario']},
  {'title':'Cryptography, PKI & Secrets','objectives':['Select encryption/hash/signature use cases','Explain PKI and certificate trust','Protect keys and secrets'],'topics':['AES','RSA/ECC','Hashing','Salts','HMAC','Digital signatures','PKI','KMS/HSM'],'practice':['Map confidentiality/integrity/authenticity requirements to cryptographic primitives','Inspect a lab certificate chain and identify issuer, subject and expiry']},
  {'title':'Threat Actors, Social Engineering & Malware','objectives':['Recognize threat motivations and techniques','Identify social-engineering indicators','Choose layered mitigations'],'topics':['Threat actors','Phishing','BEC','MFA fatigue','Malware','Ransomware','Supply chain'],'practice':['Triage a simulated phishing message and document indicators','Build preventive/detective/corrective controls for ransomware']},
  {'title':'Vulnerabilities & Secure Configuration','objectives':['Prioritize vulnerabilities','Distinguish scanning from validation','Apply hardening and patching'],'topics':['CVE','CVSS','KEV','Misconfiguration','Patching','Baselines','False positives'],'practice':['Prioritize five findings using exploitation, exposure and asset criticality','Create a remediation validation checklist']},
  {'title':'Network & Infrastructure Security','objectives':['Design segmentation and secure access','Recognize common network defenses','Select secure protocols'],'topics':['VLAN','DMZ','NAC','Firewall','IDS/IPS','VPN','SASE','SD-WAN','Secure protocols'],'practice':['Draw a segmented branch-office design','Replace insecure protocols in a sample architecture']},
  {'title':'Cloud, Virtualization & Application Architecture','objectives':['Apply shared responsibility','Protect workloads and APIs','Recognize container/virtualization risks'],'topics':['IaaS/PaaS/SaaS','Containers','Hypervisors','APIs','Serverless','Secrets','CASB'],'practice':['Assign security responsibilities for IaaS, PaaS and SaaS','Threat-model a simple containerized web application']},
  {'title':'Identity & Access Management','objectives':['Choose authentication factors','Design authorization','Manage identity lifecycle'],'topics':['MFA','SSO','Federation','RBAC','ABAC','PAM','Provisioning','Access review'],'practice':['Create an RBAC matrix','Design joiner-mover-leaver controls with periodic review']},
  {'title':'Security Operations & Monitoring','objectives':['Use logs and telemetry','Explain SIEM/EDR/XDR/SOAR roles','Build repeatable operations'],'topics':['Logging','SIEM','EDR','XDR','SOAR','Baselines','Time sync','Change management'],'practice':['Map a suspicious login to required telemetry','Build a simple detection-to-response workflow']},
  {'title':'Incident Response, Forensics & Recovery','objectives':['Apply IR lifecycle','Preserve evidence appropriately','Plan backup/recovery'],'topics':['IR lifecycle','Evidence','Chain of custody','Backups','RTO','RPO','DR'],'practice':['Run a six-phase tabletop for account takeover','Create backup verification evidence for a critical service']},
  {'title':'Governance, Risk, Privacy & Third Parties','objectives':['Differentiate policy artifacts','Assess risk and vendors','Apply privacy and awareness concepts'],'topics':['Policy','Standard','Procedure','Risk register','Third-party risk','Privacy','Awareness','Metrics'],'practice':['Write a risk statement and treatment','Create a vendor minimum-security checklist']}
 ],
 'securityx':[
  {'title':'Enterprise Governance & Risk Architecture','objectives':['Align architecture to business risk','Evaluate control trade-offs','Manage exceptions and inherited controls'],'topics':['Risk appetite','Control inheritance','Exceptions','Metrics','Third-party risk','Continuous monitoring'],'practice':['Document an architecture exception with compensating controls and expiration']},
  {'title':'Zero Trust & Identity-Centric Architecture','objectives':['Design PDP/PEP flows','Use continuous context','Reduce implicit trust'],'topics':['PDP','PEP','Device posture','Workload identity','Microsegmentation','PAM'],'practice':['Design a Zero Trust access path for an administrative application']},
  {'title':'Hybrid / Multi-Cloud Security','objectives':['Secure cloud control planes','Design identity/logging guardrails','Manage secrets and workload access'],'topics':['Landing zones','Cloud IAM','KMS','Secrets','Cloud logs','Cross-account trust','CSPM'],'practice':['Create a multi-account guardrail checklist and central logging design']},
  {'title':'Secure Software, APIs & Supply Chain','objectives':['Threat-model applications','Secure CI/CD','Assess third-party components'],'topics':['API security','CI/CD','SBOM','Signing','SAST/DAST','Dependency risk','Secrets scanning'],'practice':['Design release gates for a signed containerized application']},
  {'title':'Advanced Network & Service Architecture','objectives':['Design resilient segmentation','Select secure service connectivity','Protect east-west traffic'],'topics':['SASE','SD-WAN','mTLS','Service mesh','WAF','Reverse proxy','DDoS resilience'],'practice':['Compare service-mesh mTLS with perimeter-only TLS for east-west protection']},
  {'title':'Cryptographic Architecture & Algorithm Agility','objectives':['Design key lifecycle','Choose HSM/KMS boundaries','Plan cryptographic migration'],'topics':['PKI','HSM','KMS','Envelope encryption','Rotation','PQC planning'],'practice':['Create an algorithm-agility migration plan for a legacy application']},
  {'title':'OT/ICS, IoT & Safety-Critical Security','objectives':['Protect availability and safety','Use passive monitoring','Design controlled trust boundaries'],'topics':['ICS zones','Jump hosts','Data diode','Passive discovery','Safety','Change control'],'practice':['Design one-way telemetry from an OT zone to enterprise monitoring']},
  {'title':'Detection Engineering, XDR & Threat Intelligence','objectives':['Build high-fidelity detections','Use behavior and intelligence','Measure coverage'],'topics':['SIEM','XDR','UEBA','Threat intel','ATT&CK','Detection-as-code','SOAR'],'practice':['Write a detection hypothesis and expected telemetry for identity compromise']},
  {'title':'Incident Command, Forensics & Resilience','objectives':['Lead complex incidents','Balance containment with business impact','Validate recovery'],'topics':['Incident command','Forensics','Communications','Immutable backup','BIA','Recovery validation'],'practice':['Run a ransomware + identity compromise tabletop with decision points']},
  {'title':'Architecture Assurance & Purple Validation','objectives':['Test architecture assumptions','Design safe validation','Translate gaps into engineering work'],'topics':['Threat modeling','Purple team','Breach simulation','Control testing','Retest','Evidence'],'practice':['Create a Purple-Team test plan with success criteria and telemetry']}
 ],
 'cissp':[
  {'title':'Domain 1A — Ethics, Governance & Policy','objectives':['Apply professional ethics','Align security governance to business','Differentiate policy/standard/procedure/guideline'],'topics':['ISC2 ethics','Governance','Roles','Policy hierarchy','Due care','Due diligence'],'practice':['Choose the best governance response to a policy exception']},
  {'title':'Domain 1B — Risk, BCP & Supply Chain','objectives':['Perform qualitative/quantitative risk analysis','Plan continuity requirements','Manage supplier risk'],'topics':['SLE/ARO/ALE','Risk treatment','BIA','BCP','SCRM','Awareness'],'practice':['Calculate ALE and compare a control investment','Create BIA priorities for three services']},
  {'title':'Domain 2 — Asset Security','objectives':['Classify data/assets','Assign ownership/custody','Manage lifecycle and retention'],'topics':['Classification','Ownership','Handling','Retention','Remanence','Privacy','DLP'],'practice':['Create a classification/handling matrix for customer, HR and public data']},
  {'title':'Domain 3A — Secure Design & Security Models','objectives':['Apply secure design principles','Recognize security models','Assess architecture risk'],'topics':['Defense in depth','Fail secure','Least privilege','Bell-LaPadula','Biba','Zero Trust'],'practice':['Review a design for violations of least privilege and separation of duties']},
  {'title':'Domain 3B — Cryptography & Physical Security','objectives':['Select cryptographic protections','Manage keys/certificates','Apply physical defense layers'],'topics':['Symmetric/asymmetric','Hashing','PKI','Key lifecycle','Site design','Environmental controls'],'practice':['Map data states to encryption and key-custody controls']},
  {'title':'Domain 4 — Communication & Network Security','objectives':['Design secure network architecture','Protect communications','Select segmentation and remote-access controls'],'topics':['OSI/TCP-IP','VLAN','Firewall','VPN','Wireless','TLS','Network attacks'],'practice':['Design user/server/management/third-party network zones']},
  {'title':'Domain 5 — Identity & Access Management','objectives':['Manage identity lifecycle','Choose authentication/authorization','Control privileged access'],'topics':['Federation','MFA','RBAC','ABAC','PAM','Provisioning','Access review'],'practice':['Build joiner-mover-leaver plus quarterly access recertification']},
  {'title':'Domain 6 — Security Assessment & Testing','objectives':['Plan independent assessment','Choose test methods','Analyze and communicate results'],'topics':['Audit','Vulnerability assessment','Penetration test','Code review','BAS','KPIs/KRIs'],'practice':['Create an assessment plan with scope, independence, evidence and reporting']},
  {'title':'Domain 7A — Investigations & Incident Response','objectives':['Preserve evidence','Apply incident lifecycle','Coordinate legal/HR/regulatory needs'],'topics':['Evidence','Chain of custody','IR','Investigations','Logging','Monitoring'],'practice':['Create an evidence-preservation checklist for insider data theft']},
  {'title':'Domain 7B — Resilience, DR & Operations','objectives':['Plan recovery','Operate secure change/patch processes','Validate backups and recovery'],'topics':['DR','RTO/RPO','Backups','Change','Patch','Configuration','Capacity'],'practice':['Build a recovery test plan with measurable success criteria']},
  {'title':'Domain 8A — Secure SDLC & Testing','objectives':['Integrate security throughout SDLC','Choose appropriate testing','Use threat modeling'],'topics':['Requirements','Threat modeling','SAST','DAST','IAST','Code review','Release gates'],'practice':['Create secure acceptance criteria for a new API']},
  {'title':'Domain 8B — Software Supply Chain & DevSecOps','objectives':['Manage dependencies and acquired software','Secure CI/CD','Protect build artifacts and secrets'],'topics':['SBOM','Signing','Dependencies','CI/CD','Secrets','Containers','APIs'],'practice':['Build a software supply-chain release checklist']}
 ],
 'lfcs':[
  {'title':'Operations & Deployment I — Kernel, Processes & Services','objectives':['Configure runtime/persistent kernel settings','Troubleshoot processes/services','Recover failed services'],'topics':['sysctl','ps/top','systemctl','journalctl','signals','resource use'],'practice':['Set a sysctl value temporarily and persistently','Repair a failed unit from logs']},
  {'title':'Operations & Deployment II — Jobs, Packages & Recovery','objectives':['Schedule work','Manage packages/repos','Recover from common failures'],'topics':['cron','systemd timers','apt/dnf','repositories','rescue','boot troubleshooting'],'practice':['Create a scheduled job and verify logs','Identify which package owns a file']},
  {'title':'Operations & Deployment III — VMs, Containers & SELinux','objectives':['Operate libvirt VMs','Manage containers','Apply mandatory access control'],'topics':['virsh','libvirt','podman/docker concepts','images','volumes','SELinux'],'practice':['Run a rootless lab container','Diagnose an SELinux denial without disabling enforcement']},
  {'title':'Networking I — Addressing, DNS & Time','objectives':['Configure IPv4/IPv6','Troubleshoot resolution','Synchronize time'],'topics':['ip addr','ip route','resolv.conf/systemd-resolved','dig','chrony'],'practice':['Configure a lab address and route','Diagnose a DNS failure step by step']},
  {'title':'Networking II — SSH, Filtering, NAT & Routing','objectives':['Secure SSH','Configure packet filtering/NAT','Manage static routing'],'topics':['sshd_config','ssh keys','nftables/firewalld','NAT','routes'],'practice':['Harden a lab SSH service without locking yourself out','Add and validate a firewall rule']},
  {'title':'Networking III — Bridges, Bonds & Proxies','objectives':['Configure link aggregation/bridging','Operate reverse proxy/load balancing','Troubleshoot listeners'],'topics':['bridge','bond','NetworkManager','Nginx/HAProxy concepts','ss','curl'],'practice':['Create a disposable bridge or bond','Proxy a local test service and validate headers']},
  {'title':'Storage I — Filesystems, Swap & Persistence','objectives':['Create/troubleshoot filesystems','Configure persistent mounts','Manage swap'],'topics':['lsblk','mkfs','fsck','mount','fstab','swap'],'practice':['Create a loop-backed filesystem and safe fstab entry','Add and remove lab swap']},
  {'title':'Storage II — LVM, Remote Storage & Automounters','objectives':['Create/extend LVM','Use remote filesystems/block devices','Configure automount'],'topics':['pv/vg/lv','resize2fs/xfs_growfs','NFS','iSCSI concepts','autofs'],'practice':['Extend an LVM volume and filesystem','Configure an automounted lab share']},
  {'title':'Essential Commands I — Git, Services & Certificates','objectives':['Perform basic Git operations','Configure/troubleshoot services','Inspect TLS certificates'],'topics':['git','systemctl','journalctl','openssl','curl'],'practice':['Initialize, commit and inspect a local Git repo','Inspect a certificate with openssl']},
  {'title':'Essential Commands II — Performance & Disk Troubleshooting','objectives':['Diagnose performance','Identify service constraints','Resolve disk-space issues'],'topics':['top','free','vmstat','iostat concepts','df','du','find'],'practice':['Find the largest consumers in a full lab filesystem','Differentiate inode exhaustion from block exhaustion']},
  {'title':'Users & Groups I — Accounts, Profiles & Limits','objectives':['Manage users/groups','Configure environment profiles','Set resource limits'],'topics':['useradd','usermod','groupadd','profiles','ulimit','limits.conf'],'practice':['Create a user/group with a defined shell and supplementary group','Set and verify a lab resource limit']},
  {'title':'Users & Groups II — ACLs & Directory Identity','objectives':['Manage ACLs','Explain LDAP identity integration','Validate effective access'],'topics':['setfacl','getfacl','default ACL','LDAP','NSS/PAM concepts'],'practice':['Grant an ACL without changing base ownership','Explain the identity lookup path for an LDAP-backed user']}
 ]
})

TEAM_GUIDES={
 'red':{
   'purpose':'Plan, execute, and document authorized adversary-simulation activities with explicit scope, safety controls, evidence capture, and remediation tracking.',
   'workflow':['1. Confirm written authorization, scope, exclusions, contacts, time window, and stop conditions.','2. Build the asset and trust-boundary inventory for the engagement.','3. Select ATT&CK-aligned hypotheses and expected defensive telemetry.','4. Perform controlled discovery and validation using approved techniques only.','5. Record evidence, affected controls, detection outcome, impact, and reproduction notes.','6. Stop immediately on safety triggers, production instability, or scope ambiguity.','7. Convert validated weaknesses into findings with owners, remediation, and retest criteria.'],
   'sections':{
     'Engagement Management':['Rules of engagement','Scope and exclusions','Approvals and emergency contacts','Testing windows','Safety and stop conditions','Evidence handling and cleanup'],
     'Recon & Exposure Review':['DNS and certificate review','Service inventory','External attack-surface validation','HTTP/TLS posture','Cloud exposure review','Identity exposure review'],
     'Attack-Path Planning':['Initial-access hypothesis','Privilege boundaries','Trust relationships','Lateral-movement opportunities','Critical asset paths','Expected detections and telemetry'],
     'Web & API Review':['Authentication/session controls','Authorization boundaries','Input validation','API security posture','Secrets handling','Business-logic abuse cases'],
     'Cloud & Identity':['IAM policy review','Privileged paths','Federation trust','Storage exposure','Network controls','Audit/logging coverage'],
     'Evidence & Reporting':['Finding severity','Reproduction notes','Evidence references','Business impact','Root cause','Remediation and retest status']},
   'commands':[
    {'name':'Service discovery - light','cmd':'nmap -sV --version-light <AUTHORIZED_TARGET>','use':'Identify exposed services on an owned or explicitly authorized target.'},
    {'name':'TCP port inventory','cmd':'nmap -sT -Pn --top-ports 100 <AUTHORIZED_TARGET>','use':'Review common TCP exposure without stealth options.'},
    {'name':'HTTP response headers','cmd':'curl -I https://<AUTHORIZED_TARGET>','use':'Review server, cache, HSTS, CSP, cookie, and other HTTP security headers.'},
    {'name':'HTTP verbose transaction','cmd':'curl -vk https://<AUTHORIZED_TARGET>/','use':'Inspect the TLS/HTTP exchange for an authorized service.'},
    {'name':'TLS certificate inspection','cmd':'openssl s_client -connect <AUTHORIZED_TARGET>:443 -servername <AUTHORIZED_TARGET> -showcerts','use':'Inspect certificate chain and negotiated TLS details.'},
    {'name':'Certificate metadata','cmd':'echo | openssl s_client -connect <AUTHORIZED_TARGET>:443 -servername <AUTHORIZED_TARGET> 2>/dev/null | openssl x509 -noout -issuer -subject -dates -fingerprint -sha256','use':'Summarize issuer, subject, validity, and fingerprint.'},
    {'name':'DNS record review','cmd':'nslookup <AUTHORIZED_DOMAIN>','use':'Review basic DNS resolution for an authorized domain.'},
    {'name':'DNS detailed review','cmd':'dig <AUTHORIZED_DOMAIN> A AAAA MX TXT NS +noall +answer','use':'Review common DNS records and security-relevant TXT records.'},
    {'name':'Route path review','cmd':'tracert <AUTHORIZED_TARGET>   # Windows\ntraceroute <AUTHORIZED_TARGET> # Linux/macOS','use':'Understand the network path to an authorized system.'},
    {'name':'Whois ownership review','cmd':'whois <AUTHORIZED_DOMAIN_OR_IP>','use':'Review public registration and network ownership metadata.'},
    {'name':'Local web fingerprint','cmd':'curl -sS https://<AUTHORIZED_TARGET>/robots.txt','use':'Review a publicly exposed robots file without bypassing access controls.'},
    {'name':'Hash engagement artifact','cmd':'certutil -hashfile <FILE> SHA256   # Windows\nsha256sum <FILE>                    # Linux','use':'Create an integrity hash for collected evidence or test artifacts.'}
   ]
 },
 'blue':{
   'purpose':'Investigate, hunt, contain, eradicate, recover, and improve detections using endpoint, identity, network, cloud, and application telemetry.',
   'workflow':['1. Validate alert fidelity, affected asset criticality, and identity context.','2. Scope hosts, users, IPs, processes, files, cloud resources, and the relevant time window.','3. Preserve evidence and build a defensible timeline.','4. Enrich indicators and map observed behavior to ATT&CK.','5. Contain according to confidence, impact, and business continuity requirements.','6. Eradicate root cause, rotate exposed credentials, and recover from a trusted state.','7. Tune detections, document lessons learned, and create Purple-Team retest work.'],
   'sections':{
     'SOC Triage':['Alert validation','Asset criticality','Identity context','IOC enrichment','Timeline building','Severity and escalation decision'],
     'Threat Hunting':['Hypothesis creation','Data-source selection','Baseline comparison','Rare process/network behavior','Persistence indicators','Lateral movement and identity abuse'],
     'Windows DFIR':['Security/System/Application logs','PowerShell logging','Scheduled tasks/services','Network connections','Autoruns/persistence review','Defender/Sysmon telemetry'],
     'Linux DFIR':['journalctl/auth logs','Processes and sockets','systemd services/timers','Cron persistence','File and package review','SSH access and sudo activity'],
     'Detection Engineering':['Sigma concepts','Splunk/KQL/Elastic queries','ATT&CK coverage','False-positive analysis','Rule testing','Detection-as-code lifecycle'],
     'Incident Response':['Containment options','Credential reset planning','Host isolation','Recovery validation','Post-incident review','Executive communication']},
   'commands':[
    {'name':'Windows active TCP sessions','cmd':'Get-NetTCPConnection | Sort-Object State,RemoteAddress | Format-Table -Auto','use':'Triage local and remote TCP sessions.'},
    {'name':'Windows process inventory','cmd':'Get-Process | Sort-Object CPU -Descending | Select-Object -First 30 Name,Id,CPU,Path','use':'Review process activity and high-CPU processes.'},
    {'name':'Windows Security log - recent failures','cmd':'Get-WinEvent -FilterHashtable @{LogName="Security";Id=4625;StartTime=(Get-Date).AddHours(-4)} | Select-Object TimeCreated,Id,Message','use':'Review recent failed logons.'},
    {'name':'Windows Security log - successful logons','cmd':'Get-WinEvent -FilterHashtable @{LogName="Security";Id=4624;StartTime=(Get-Date).AddHours(-4)} | Select-Object TimeCreated,Id,Message','use':'Review recent successful logons during incident scoping.'},
    {'name':'PowerShell operational events','cmd':'Get-WinEvent -LogName "Microsoft-Windows-PowerShell/Operational" -MaxEvents 100','use':'Review recent PowerShell activity when logging is enabled.'},
    {'name':'Defender status','cmd':'Get-MpComputerStatus | Select-Object AntivirusEnabled,RealTimeProtectionEnabled,AntivirusSignatureLastUpdated','use':'Validate Microsoft Defender protection state.'},
    {'name':'Scheduled tasks inventory','cmd':'Get-ScheduledTask | Where-Object {$_.State -ne "Disabled"} | Select-Object TaskName,TaskPath,State','use':'Review enabled scheduled tasks for suspicious persistence.'},
    {'name':'Windows file hash','cmd':'Get-FileHash <FILE> -Algorithm SHA256','use':'Hash evidence or a suspicious file without executing it.'},
    {'name':'Linux listening services','cmd':'ss -lntup','use':'List listening services and owning processes.'},
    {'name':'Linux process tree','cmd':'ps auxf','use':'Review process ancestry and unusual long-running processes.'},
    {'name':'Linux authentication activity','cmd':'journalctl _COMM=sshd --since "-4 hours"','use':'Review SSH daemon activity on systemd-based Linux systems.'},
    {'name':'Systemd unit logs','cmd':'journalctl -u <SERVICE> --since "-4 hours"','use':'Review service-specific events.'},
    {'name':'Linux evidence hash','cmd':'sha256sum <FILE>','use':'Generate an integrity hash before evidence handling.'},
    {'name':'Linux cron inventory','cmd':'crontab -l; ls -la /etc/cron.* /var/spool/cron 2>/dev/null','use':'Review common cron persistence locations.'},
    {'name':'DNS cache - Windows','cmd':'Get-DnsClientCache | Sort-Object Entry','use':'Review cached DNS names during endpoint triage.'}
   ]
 },
 'purple':{
   'purpose':'Run collaborative, safe validation cycles that prove whether expected telemetry, detections, analyst workflows, and response controls work for an agreed ATT&CK behavior.',
   'workflow':['1. Choose a business-relevant threat behavior or ATT&CK technique.','2. Define a safe validation method, success criteria, rollback, and evidence requirements.','3. Document expected endpoint, identity, network, cloud, and application telemetry.','4. Execute only the approved validation action.','5. Compare observed logs, alerts, enrichment, and analyst context with expectations.','6. Record visibility, parser, detection, severity, enrichment, and response gaps.','7. Remediate, rerun the same validation, and close only with evidence.'],
   'sections':{
     'Technique Planning':['Threat scenario','ATT&CK tactic/technique','Business relevance','Preconditions','Safe test method','Rollback and cleanup'],
     'Telemetry Matrix':['EDR events','Windows/Linux logs','Identity-provider logs','DNS/proxy/firewall','Cloud audit logs','Application telemetry'],
     'Detection Validation':['Did a rule fire?','Was severity correct?','Was context sufficient?','Were false positives acceptable?','Did automation behave correctly?','Could an analyst act quickly?'],
     'Gap Management':['Missing sensor','Missing event/field','Parser or normalization issue','Rule logic gap','Response/playbook gap','Owner and due date'],
     'Retest & Coverage':['Repeat same behavior','Compare evidence','Verify control change','Update ATT&CK coverage','Document residual risk','Close with proof']},
   'commands':[
    {'name':'Sigma rule validation','cmd':'sigma check <RULE.yml>','use':'Validate Sigma rule structure before conversion or promotion.'},
    {'name':'Sigma rule conversion - Splunk','cmd':'sigma convert -t splunk <RULE.yml>','use':'Convert an approved Sigma rule into a Splunk-oriented query for validation.'},
    {'name':'Windows event presence check','cmd':'Get-WinEvent -FilterHashtable @{LogName="Security";StartTime=(Get-Date).AddMinutes(-30)} -MaxEvents 200','use':'Confirm expected Windows telemetry exists after a safe validation.'},
    {'name':'PowerShell telemetry check','cmd':'Get-WinEvent -LogName "Microsoft-Windows-PowerShell/Operational" -MaxEvents 100','use':'Verify PowerShell operational telemetry is collected.'},
    {'name':'Linux telemetry check','cmd':'journalctl --since "-30 minutes"','use':'Confirm Linux events were generated during a controlled validation.'},
    {'name':'Sysmon telemetry check','cmd':'Get-WinEvent -LogName "Microsoft-Windows-Sysmon/Operational" -MaxEvents 100','use':'Confirm Sysmon telemetry is present when Sysmon is deployed.'},
    {'name':'Splunk validation pattern','cmd':'index=<INDEX> earliest=-30m <SAFE_TEST_MARKER> | stats count by host, sourcetype','use':'Search for an agreed benign marker generated by the test.'},
    {'name':'Sentinel / KQL validation pattern','cmd':'search "<SAFE_TEST_MARKER>" | summarize count() by $table, Computer','use':'Look for an agreed benign marker across Sentinel tables.'},
    {'name':'Elastic validation pattern','cmd':'Kibana / Discover: search for "<SAFE_TEST_MARKER>" over the validation window','use':'Verify an expected benign marker appears in Elastic telemetry.'},
    {'name':'Validation workflow','cmd':'Technique -> Safe Test -> Expected Telemetry -> Observed Telemetry -> Detection -> Response -> Gap -> Retest','use':'Use this sequence for every Purple-Team validation.'}
   ]
 }
}

# Expanded safe operational command/reference library. Commands are intended for owned systems, authorized labs, or defensive investigation.
TEAM_GUIDES['red']['commands'].extend([
 {'name':'HTTP methods review','cmd':'curl -i -X OPTIONS https://<AUTHORIZED_TARGET>/','use':'Identify HTTP methods the authorized application advertises.'},
 {'name':'Security.txt review','cmd':'curl -sS https://<AUTHORIZED_TARGET>/.well-known/security.txt','use':'Review the published vulnerability-disclosure/security contact file.'},
 {'name':'Certificate SAN inventory','cmd':'echo | openssl s_client -connect <AUTHORIZED_TARGET>:443 -servername <AUTHORIZED_TARGET> 2>/dev/null | openssl x509 -noout -ext subjectAltName','use':'Review certificate subject alternative names for the scoped service.'},
 {'name':'TLS protocol check','cmd':'openssl s_client -tls1_2 -connect <AUTHORIZED_TARGET>:443 -servername <AUTHORIZED_TARGET>','use':'Confirm an approved target can negotiate TLS 1.2.'},
 {'name':'DNS TXT review','cmd':'dig TXT <AUTHORIZED_DOMAIN> +short','use':'Review SPF, verification, and other TXT records without altering anything.'},
 {'name':'DMARC record review','cmd':'dig TXT _dmarc.<AUTHORIZED_DOMAIN> +short','use':'Review published DMARC policy for an authorized domain.'},
 {'name':'SPF record review','cmd':'dig TXT <AUTHORIZED_DOMAIN> +short | grep -i spf','use':'Review the authorized domain SPF policy.'},
 {'name':'Local Windows route inventory','cmd':'Get-NetRoute | Sort-Object DestinationPrefix | Format-Table -Auto','use':'Document routing on an authorized Windows test endpoint.'},
 {'name':'Local Windows listening ports','cmd':'Get-NetTCPConnection -State Listen | Sort-Object LocalPort | Format-Table -Auto','use':'Inventory services listening on an authorized Windows test endpoint.'},
 {'name':'Local Linux listening ports','cmd':'ss -lntup','use':'Inventory listening services on an authorized Linux test endpoint.'},
 {'name':'Local Linux firewall state','cmd':'sudo nft list ruleset   # or: sudo firewall-cmd --list-all','use':'Review local firewall policy on an authorized Linux system.'},
 {'name':'Local Windows firewall profiles','cmd':'Get-NetFirewallProfile | Select-Object Name,Enabled,DefaultInboundAction,DefaultOutboundAction','use':'Review Windows firewall profile posture on an authorized endpoint.'},
 {'name':'Local certificate store','cmd':'Get-ChildItem Cert:\\LocalMachine\\My | Select Subject,Issuer,NotAfter,Thumbprint','use':'Inventory local machine certificates on an authorized Windows endpoint.'},
 {'name':'Linux certificate file metadata','cmd':'openssl x509 -in <CERTIFICATE.pem> -noout -subject -issuer -dates -fingerprint -sha256','use':'Inspect a certificate file supplied for the engagement.'},
 {'name':'File metadata - Windows','cmd':'Get-Item <FILE> | Select FullName,Length,CreationTimeUtc,LastWriteTimeUtc','use':'Document metadata for an authorized engagement artifact.'},
 {'name':'File metadata - Linux','cmd':'stat <FILE>','use':'Document metadata for an authorized engagement artifact.'}
])
TEAM_GUIDES['blue']['commands'].extend([
 {'name':'Windows services inventory','cmd':'Get-CimInstance Win32_Service | Select Name,State,StartMode,StartName,PathName','use':'Review service configuration and unusual executable paths.'},
 {'name':'Windows startup entries','cmd':'Get-CimInstance Win32_StartupCommand | Select Name,Command,Location,User','use':'Review common startup persistence entries.'},
 {'name':'Windows local administrators','cmd':'Get-LocalGroupMember Administrators','use':'Check membership of the local Administrators group.'},
 {'name':'Windows user accounts','cmd':'Get-LocalUser | Select Name,Enabled,LastLogon,PasswordLastSet','use':'Review local account state during triage.'},
 {'name':'Windows Defender detections','cmd':'Get-MpThreatDetection | Select InitialDetectionTime,ThreatName,Resources,ActionSuccess','use':'Review Microsoft Defender detection history.'},
 {'name':'Windows installed hotfixes','cmd':'Get-HotFix | Sort-Object InstalledOn -Descending | Select -First 30','use':'Review recently installed Windows hotfixes.'},
 {'name':'Windows ARP / neighbor cache','cmd':'Get-NetNeighbor | Sort-Object State,IPAddress | Format-Table -Auto','use':'Review recently observed local-network neighbors.'},
 {'name':'Windows DNS configuration','cmd':'Get-DnsClientServerAddress | Format-Table -Auto','use':'Validate configured DNS resolvers during endpoint/network investigation.'},
 {'name':'Linux failed logins','cmd':'lastb -a | head -50','use':'Review recent failed login activity when lastb data is available.'},
 {'name':'Linux successful logins','cmd':'last -a | head -50','use':'Review recent interactive login history.'},
 {'name':'Linux user/group inventory','cmd':'getent passwd; getent group','use':'Review local/directory-resolved accounts and groups.'},
 {'name':'Linux sudo events','cmd':'journalctl _COMM=sudo --since "-24 hours"','use':'Review sudo execution history on systemd systems.'},
 {'name':'Linux systemd enabled units','cmd':'systemctl list-unit-files --state=enabled','use':'Review enabled services/timers for suspicious persistence.'},
 {'name':'Linux recently modified files','cmd':'find /etc /usr/local/bin /tmp -xdev -type f -mtime -2 -printf "%TY-%Tm-%Td %TH:%TM %p\\n" 2>/dev/null | sort -r | head -100','use':'Find recently modified files in common investigation locations.'},
 {'name':'Linux package history - RPM','cmd':'dnf history list | head -30','use':'Review recent package operations on RPM-based systems.'},
 {'name':'Linux package history - Debian','cmd':'grep -E " install | upgrade | remove " /var/log/dpkg.log | tail -50','use':'Review recent package operations on Debian-based systems.'},
 {'name':'Linux firewall review','cmd':'sudo nft list ruleset','use':'Review active nftables rules during network containment analysis.'},
 {'name':'Certificate remote check','cmd':'echo | openssl s_client -connect <HOST>:443 -servername <HOST> 2>/dev/null | openssl x509 -noout -subject -issuer -dates -fingerprint -sha256','use':'Inspect a remote certificate during phishing or service investigations.'},
 {'name':'HTTP header triage','cmd':'curl -sS -D - -o /dev/null https://<HOST>/','use':'Review response headers for an investigated web endpoint.'},
 {'name':'Hash directory files - PowerShell','cmd':'Get-ChildItem <PATH> -File | Get-FileHash -Algorithm SHA256','use':'Create hashes for a small investigation artifact directory.'}
])
TEAM_GUIDES['purple']['commands'].extend([
 {'name':'Windows Security event count','cmd':'Get-WinEvent -FilterHashtable @{LogName="Security";StartTime=(Get-Date).AddMinutes(-30)} | Group-Object Id | Sort Count -Descending | Select -First 25 Count,Name','use':'Confirm which Windows Security event IDs appeared in the validation window.'},
 {'name':'Sysmon event count','cmd':'Get-WinEvent -LogName "Microsoft-Windows-Sysmon/Operational" -ErrorAction SilentlyContinue | Select -First 500 | Group-Object Id | Sort Count -Descending','use':'Check event-type visibility from Sysmon after a safe test.'},
 {'name':'PowerShell 4104 presence','cmd':'Get-WinEvent -FilterHashtable @{LogName="Microsoft-Windows-PowerShell/Operational";Id=4104;StartTime=(Get-Date).AddMinutes(-30)}','use':'Validate script-block logging coverage when enabled.'},
 {'name':'Windows audit policy review','cmd':'auditpol /get /category:*','use':'Document Windows audit policy before or after a detection validation.'},
 {'name':'Linux audit service status','cmd':'systemctl status auditd --no-pager','use':'Confirm Linux audit service collection state where auditd is deployed.'},
 {'name':'Linux audit recent events','cmd':'ausearch -ts recent 2>/dev/null | tail -100','use':'Review recent auditd events generated around the validation window.'},
 {'name':'Linux auth telemetry window','cmd':'journalctl -u ssh --since "-30 minutes" 2>/dev/null || journalctl -u sshd --since "-30 minutes"','use':'Verify authentication telemetry for a benign identity validation.'},
 {'name':'DNS telemetry validation pattern','cmd':'Search DNS telemetry for <SAFE_TEST_DOMAIN> during the agreed validation window','use':'Check that benign test-domain resolution is visible centrally.'},
 {'name':'Proxy telemetry validation pattern','cmd':'Search proxy/SWG telemetry for <SAFE_TEST_URL> during the agreed validation window','use':'Validate URL visibility and user/device enrichment.'},
 {'name':'Firewall telemetry validation pattern','cmd':'Search firewall telemetry for src=<TEST_HOST> dst=<TEST_DESTINATION> during the validation window','use':'Validate expected network connection telemetry.'},
 {'name':'Identity sign-in validation pattern','cmd':'Search identity-provider logs for <TEST_IDENTITY> during the agreed validation window','use':'Validate identity log ingestion and enrichment.'},
 {'name':'Detection QA checklist','cmd':'Trigger? -> Correct severity? -> Entity context? -> ATT&CK tag? -> Owner? -> Response link? -> False positive notes?','use':'Use as the minimum quality gate before promoting a detection.'},
 {'name':'Retest evidence checklist','cmd':'Same test -> Same scope -> Telemetry captured -> Rule fired -> Analyst context adequate -> Response verified -> Evidence attached','use':'Prove remediation with repeatable evidence rather than subjective closure.'}
])


KILL_CHAIN={'framework': 'Cyber Kill Chain', 'source': 'Lockheed Martin', 'purpose': 'Visualize an intrusion from reconnaissance through objectives and connect each phase to safe Red, Blue, and Purple Team actions.', 'phases': [{'id': 'recon', 'number': 1, 'name': 'Reconnaissance', 'summary': 'Research and identify targets, exposed services, identities, domains, and infrastructure.', 'red': [{'name': 'DNS resolution', 'cmd': 'nslookup <AUTHORIZED_DOMAIN>', 'use': 'Review public DNS for an owned or explicitly authorized domain.'}, {'name': 'DNS records', 'cmd': 'dig <AUTHORIZED_DOMAIN> A AAAA MX TXT NS +noall +answer', 'use': 'Review common public DNS records.'}, {'name': 'Service discovery', 'cmd': 'nmap -sV --version-light <AUTHORIZED_TARGET>', 'use': 'Inventory exposed services on an authorized target.'}, {'name': 'WHOIS lookup', 'cmd': 'whois <AUTHORIZED_DOMAIN>', 'use': 'Review public registration data for an authorized domain.'}, {'name': 'Certificate transparency', 'cmd': 'curl "https://crt.sh/?q=%25.<AUTHORIZED_DOMAIN>&output=json"', 'use': 'Query public certificate-transparency records for an authorized domain.'}, {'name': 'HTTP headers', 'cmd': 'curl -I https://<AUTHORIZED_TARGET>', 'use': 'Review public HTTP response headers.'}, {'name': 'TLS certificate', 'cmd': 'openssl s_client -connect <AUTHORIZED_TARGET>:443 -servername <AUTHORIZED_TARGET> </dev/null 2>/dev/null | openssl x509 -noout -subject -issuer -dates', 'use': 'Inspect public TLS certificate metadata.'}, {'name': 'Route trace', 'cmd': 'tracert <AUTHORIZED_TARGET>', 'use': 'Document the network path to an authorized host on Windows.'}], 'blue': [{'name': 'DNS cache review', 'cmd': 'ipconfig /displaydns', 'use': 'Review local Windows DNS cache during triage.'}, {'name': 'Listening services', 'cmd': 'Get-NetTCPConnection -State Listen | Sort-Object LocalPort', 'use': 'Establish expected listening-service exposure on Windows.'}, {'name': 'Established connections', 'cmd': 'Get-NetTCPConnection -State Established | Sort-Object RemoteAddress', 'use': 'Review current established Windows connections.'}, {'name': 'DNS client events', 'cmd': 'Get-WinEvent -LogName "Microsoft-Windows-DNS-Client/Operational" -MaxEvents 100', 'use': 'Review recent Windows DNS client telemetry when the log is enabled.'}, {'name': 'Firewall profiles', 'cmd': 'Get-NetFirewallProfile | Select Name,Enabled,DefaultInboundAction,DefaultOutboundAction', 'use': 'Review Windows firewall profile posture.'}, {'name': 'ARP neighbors', 'cmd': 'Get-NetNeighbor | Sort-Object InterfaceIndex,IPAddress', 'use': 'Review local neighbor-cache entries.'}, {'name': 'Linux listeners', 'cmd': 'ss -lntup', 'use': 'Inventory Linux listening sockets and owning processes.'}], 'purple': [{'name': 'Recon telemetry check', 'cmd': 'Search DNS, proxy, firewall and web telemetry for <TEST_SOURCE> during <TEST_WINDOW>', 'use': 'Confirm reconnaissance activity is visible to defenders.'}, {'name': 'DNS visibility test', 'cmd': 'Resolve-DnsName <AUTHORIZED_DOMAIN>', 'use': 'Generate a benign DNS lookup and confirm it appears in expected telemetry.'}, {'name': 'Web visibility test', 'cmd': 'curl -I https://<AUTHORIZED_TARGET>', 'use': 'Generate a benign HTTP HEAD request for telemetry validation.'}, {'name': 'Telemetry timestamp', 'cmd': 'Get-Date -Format o', 'use': 'Record an exact test timestamp for SIEM correlation.'}, {'name': 'Sensor checklist', 'cmd': 'DNS -> Proxy -> Firewall -> Endpoint -> SIEM -> Alert', 'use': 'Walk the expected telemetry path for the approved recon test.'}, {'name': 'Coverage note', 'cmd': 'Record source, destination, timestamp, sensor, rule and analyst outcome', 'use': 'Capture repeatable evidence for the Purple Team validation.'}]}, {'id': 'weaponization', 'number': 2, 'name': 'Weaponization', 'summary': 'Prepare and analyze the artifacts, infrastructure, and behaviors that could be used in an intrusion. HIVE SECURITY keeps this phase non-destructive.', 'red': [{'name': 'Hash approved test artifact', 'cmd': 'certutil -hashfile <APPROVED_TEST_FILE> SHA256', 'use': 'Create an integrity identifier for a benign engagement artifact.'}, {'name': 'Certificate metadata', 'cmd': 'echo | openssl s_client -connect <AUTHORIZED_TARGET>:443 -servername <AUTHORIZED_TARGET> 2>NUL | openssl x509 -noout -issuer -subject -dates -fingerprint -sha256', 'use': 'Document TLS identity used by an authorized test service.'}, {'name': 'SHA256 PowerShell', 'cmd': 'Get-FileHash <APPROVED_TEST_FILE> -Algorithm SHA256', 'use': 'Hash a benign approved test artifact.'}, {'name': 'File metadata', 'cmd': 'Get-Item <APPROVED_TEST_FILE> | Select Name,Length,CreationTime,LastWriteTime', 'use': 'Document benign test-artifact metadata.'}, {'name': 'Strings review', 'cmd': 'strings <APPROVED_TEST_FILE> | head -n 50', 'use': 'Review printable strings from an approved test artifact without executing it.'}, {'name': 'PE signature check', 'cmd': 'Get-AuthenticodeSignature <APPROVED_TEST_FILE> | Format-List', 'use': 'Inspect Windows code-signing status of an approved artifact.'}, {'name': 'Archive listing', 'cmd': 'tar -tf <APPROVED_ARCHIVE>', 'use': 'List archive contents without extracting or executing them.'}], 'blue': [{'name': 'File hash', 'cmd': 'Get-FileHash <FILE> -Algorithm SHA256', 'use': 'Hash a suspicious or test file without executing it.'}, {'name': 'Defender status', 'cmd': 'Get-MpComputerStatus | Select AntivirusEnabled,RealTimeProtectionEnabled,AntivirusSignatureLastUpdated', 'use': 'Validate endpoint protection before a controlled exercise.'}, {'name': 'Defender preferences', 'cmd': 'Get-MpPreference | Select DisableRealtimeMonitoring,PUAProtection,MAPSReporting', 'use': 'Review selected Microsoft Defender configuration.'}, {'name': 'Signature check', 'cmd': 'Get-AuthenticodeSignature <FILE> | Format-List', 'use': 'Inspect code-signing information for a suspicious file.'}, {'name': 'File zone metadata', 'cmd': 'Get-Item <FILE> -Stream * 2>$null', 'use': 'Review NTFS alternate streams such as Mark-of-the-Web.'}, {'name': 'Recent Defender events', 'cmd': 'Get-WinEvent -LogName "Microsoft-Windows-Windows Defender/Operational" -MaxEvents 100', 'use': 'Review recent Defender operational events.'}, {'name': 'Linux file type', 'cmd': 'file <FILE>; sha256sum <FILE>', 'use': 'Identify and hash a Linux file without executing it.'}], 'purple': [{'name': 'Artifact visibility checklist', 'cmd': 'Hash known? -> File telemetry? -> Email/web telemetry? -> Sandbox verdict? -> Detection mapped?', 'use': 'Validate that benign test artifacts produce the expected defensive context.'}, {'name': 'Known benign artifact', 'cmd': 'Get-FileHash <APPROVED_TEST_FILE> -Algorithm SHA256', 'use': 'Establish the approved artifact hash used for detection QA.'}, {'name': 'AV event check', 'cmd': 'Get-WinEvent -LogName "Microsoft-Windows-Windows Defender/Operational" -MaxEvents 50', 'use': 'Confirm endpoint security telemetry around the approved artifact.'}, {'name': 'MOTW check', 'cmd': 'Get-Item <APPROVED_TEST_FILE> -Stream Zone.Identifier -ErrorAction SilentlyContinue', 'use': 'Validate whether download-origin metadata is available.'}, {'name': 'Artifact evidence', 'cmd': 'Hash -> Signature -> Endpoint event -> SIEM event -> Detection', 'use': 'Document the expected artifact visibility chain.'}, {'name': 'Cleanup proof', 'cmd': 'Test-Path <APPROVED_TEST_FILE>', 'use': 'Verify the benign test artifact was removed when cleanup is required.'}]}, {'id': 'delivery', 'number': 3, 'name': 'Delivery', 'summary': 'Observe and validate how content or links reach users and systems through approved channels.', 'red': [{'name': 'HTTP header review', 'cmd': 'curl -I https://<AUTHORIZED_TARGET>', 'use': 'Inspect an authorized web delivery surface without bypassing access controls.'}, {'name': 'Robots review', 'cmd': 'curl https://<AUTHORIZED_TARGET>/robots.txt', 'use': 'Review a public robots.txt file on an authorized web target.'}, {'name': 'Security.txt review', 'cmd': 'curl https://<AUTHORIZED_TARGET>/.well-known/security.txt', 'use': 'Check for a published security contact policy.'}, {'name': 'Redirect chain', 'cmd': 'curl -I -L https://<AUTHORIZED_TARGET>', 'use': 'Inspect redirects and headers without submitting credentials.'}, {'name': 'TLS protocol check', 'cmd': 'openssl s_client -connect <AUTHORIZED_TARGET>:443 -servername <AUTHORIZED_TARGET> -tls1_2 </dev/null', 'use': 'Validate an authorized endpoint accepts TLS 1.2.'}, {'name': 'Content type', 'cmd': 'curl -sI https://<AUTHORIZED_TARGET> | findstr /I "Content-Type Content-Length"', 'use': 'Inspect basic response metadata on Windows.'}], 'blue': [{'name': 'PowerShell operational events', 'cmd': 'Get-WinEvent -LogName "Microsoft-Windows-PowerShell/Operational" -MaxEvents 100', 'use': 'Review recent PowerShell telemetry when enabled.'}, {'name': 'Recent failed logons', 'cmd': 'Get-WinEvent -FilterHashtable @{LogName="Security";Id=4625;StartTime=(Get-Date).AddHours(-4)}', 'use': 'Review authentication failures around the delivery window.'}, {'name': 'Downloads inventory', 'cmd': 'Get-ChildItem $env:USERPROFILE\\Downloads | Sort LastWriteTime -Descending | Select -First 30 Name,Length,LastWriteTime', 'use': 'Review recent user downloads during triage.'}, {'name': 'PowerShell 4104', 'cmd': 'Get-WinEvent -FilterHashtable @{LogName="Microsoft-Windows-PowerShell/Operational";Id=4104} -MaxEvents 50', 'use': 'Review Script Block Logging events when enabled.'}, {'name': 'Process creation 4688', 'cmd': 'Get-WinEvent -FilterHashtable @{LogName="Security";Id=4688;StartTime=(Get-Date).AddHours(-4)} -MaxEvents 100', 'use': 'Review recent Windows process-creation audit events when enabled.'}, {'name': 'Defender detections', 'cmd': 'Get-MpThreatDetection | Select -First 25', 'use': 'Review recent Microsoft Defender threat detections.'}, {'name': 'Browser DNS cache', 'cmd': 'ipconfig /displaydns', 'use': 'Review cached DNS names that may support delivery triage.'}], 'purple': [{'name': 'Delivery telemetry validation', 'cmd': 'Confirm gateway/proxy/email event -> endpoint event -> SIEM event -> analyst context', 'use': 'Validate end-to-end visibility for an approved delivery simulation.'}, {'name': 'Benign URL request', 'cmd': 'curl -I https://<AUTHORIZED_TARGET>', 'use': 'Generate a controlled web request and verify proxy/endpoint/SIEM visibility.'}, {'name': 'Event-window marker', 'cmd': 'Write-Output "PURPLE-DELIVERY $(Get-Date -Format o)"', 'use': 'Create a console timestamp marker for the validation window.'}, {'name': 'PowerShell telemetry', 'cmd': 'Get-WinEvent -LogName "Microsoft-Windows-PowerShell/Operational" -MaxEvents 20', 'use': 'Confirm expected PowerShell telemetry is present.'}, {'name': 'Delivery chain', 'cmd': 'Gateway -> Proxy -> DNS -> Endpoint -> SIEM -> Case', 'use': 'Validate end-to-end defensive context.'}, {'name': 'Analyst QA', 'cmd': 'Record alert name, severity, evidence, owner and response time', 'use': 'Capture whether the approved simulation produced actionable context.'}]}, {'id': 'exploitation', 'number': 4, 'name': 'Exploitation', 'summary': 'Validate exposure and defensive visibility around vulnerabilities without providing automated exploitation.', 'red': [{'name': 'Version-light service check', 'cmd': 'nmap -sV --version-light <AUTHORIZED_TARGET>', 'use': 'Collect service/version evidence for vulnerability validation.'}, {'name': 'TLS transaction', 'cmd': 'curl -vk https://<AUTHORIZED_TARGET>/', 'use': 'Inspect an authorized TLS/HTTP transaction and configuration.'}, {'name': 'HTTP methods', 'cmd': 'curl -i -X OPTIONS https://<AUTHORIZED_TARGET>/', 'use': 'Inspect advertised HTTP methods on an authorized application.'}, {'name': 'Security headers', 'cmd': 'curl -sI https://<AUTHORIZED_TARGET>/', 'use': 'Collect HTTP response headers for configuration review.'}, {'name': 'TLS versions', 'cmd': 'openssl s_client -connect <AUTHORIZED_TARGET>:443 -servername <AUTHORIZED_TARGET> -tls1_2 </dev/null', 'use': 'Validate supported TLS configuration without exploitation.'}, {'name': 'SMB protocol check', 'cmd': 'Get-SmbConnection | Select ServerName,ShareName,Dialect,Encrypted', 'use': 'Review active SMB dialects from an authorized Windows test host.'}, {'name': 'Installed hotfixes', 'cmd': 'Get-HotFix | Sort-Object InstalledOn -Descending | Select -First 30', 'use': 'Collect patch evidence on an authorized Windows system.'}], 'blue': [{'name': 'Windows event summary', 'cmd': 'Get-WinEvent -FilterHashtable @{LogName="Security";StartTime=(Get-Date).AddMinutes(-30)} | Group-Object Id | Sort Count -Descending | Select -First 25 Count,Name', 'use': 'See which Security event IDs appeared during the validation window.'}, {'name': 'Recent application errors', 'cmd': 'Get-WinEvent -LogName Application -MaxEvents 200 | Where-Object LevelDisplayName -in "Error","Warning"', 'use': 'Review application errors around a validation window.'}, {'name': 'System errors', 'cmd': 'Get-WinEvent -LogName System -MaxEvents 200 | Where-Object LevelDisplayName -in "Critical","Error"', 'use': 'Review system-level errors and critical events.'}, {'name': 'Hotfix inventory', 'cmd': 'Get-HotFix | Sort-Object InstalledOn -Descending', 'use': 'Review installed Windows hotfixes.'}, {'name': 'Defender status', 'cmd': 'Get-MpComputerStatus | Format-List AntivirusEnabled,RealTimeProtectionEnabled,BehaviorMonitorEnabled', 'use': 'Review endpoint protection status.'}, {'name': 'Linux package updates', 'cmd': 'uname -a; cat /etc/os-release', 'use': 'Capture Linux kernel and distribution information for exposure triage.'}], 'purple': [{'name': 'Exploit-detection QA', 'cmd': 'Expected behavior -> Expected data source -> Detection fired? -> Severity correct? -> Evidence attached?', 'use': 'Validate the detection path without embedding exploit code.'}, {'name': 'Controlled request marker', 'cmd': 'curl -I https://<AUTHORIZED_TARGET>/', 'use': 'Generate a benign application request for detection correlation.'}, {'name': 'Event ID baseline', 'cmd': 'Get-WinEvent -FilterHashtable @{LogName="Security";StartTime=(Get-Date).AddMinutes(-15)} | Group Id | Sort Count -Descending', 'use': 'Compare security-event activity during the test window.'}, {'name': 'Detection checklist', 'cmd': 'Behavior -> Data source -> Query -> Rule -> Alert -> Case', 'use': 'Validate the defensive chain for the simulated exposure.'}, {'name': 'Severity QA', 'cmd': 'Record expected severity versus observed severity', 'use': 'Check that detection priority matches the approved scenario.'}, {'name': 'Retest note', 'cmd': 'Record same target, same request, timestamp and observed controls', 'use': 'Make exposure validation repeatable after remediation.'}]}, {'id': 'installation', 'number': 5, 'name': 'Installation', 'summary': 'Inspect persistence and software/service changes; Red/Purple guidance is limited to benign validation and inventory.', 'red': [{'name': 'Windows service inventory', 'cmd': 'Get-Service | Sort-Object Status,Name', 'use': 'Record service state before and after an approved validation.'}, {'name': 'Scheduled task inventory', 'cmd': 'Get-ScheduledTask | Where-Object {$_.State -ne "Disabled"} | Select TaskName,TaskPath,State', 'use': 'Review scheduled tasks without creating persistence.'}, {'name': 'Startup inventory', 'cmd': 'Get-CimInstance Win32_StartupCommand | Select Name,Command,Location,User', 'use': 'Inventory Windows startup entries without creating persistence.'}, {'name': 'Run keys inventory', 'cmd': 'Get-ItemProperty HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run -ErrorAction SilentlyContinue', 'use': 'Review current-user Run entries.'}, {'name': 'Installed software', 'cmd': 'Get-ItemProperty HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* -ErrorAction SilentlyContinue | Select DisplayName,DisplayVersion,Publisher', 'use': 'Inventory installed Windows software.'}, {'name': 'Linux services', 'cmd': 'systemctl list-unit-files --type=service --state=enabled', 'use': 'Review enabled Linux services.'}, {'name': 'Linux timers', 'cmd': 'systemctl list-timers --all', 'use': 'Review systemd timers without modifying them.'}], 'blue': [{'name': 'Scheduled tasks', 'cmd': 'Get-ScheduledTask | Where-Object {$_.State -ne "Disabled"} | Select TaskName,TaskPath,State', 'use': 'Hunt for unexpected scheduled tasks.'}, {'name': 'Linux cron inventory', 'cmd': 'crontab -l; ls -la /etc/cron.* /var/spool/cron 2>/dev/null', 'use': 'Review common Linux scheduled-task locations.'}, {'name': 'Autorun registry', 'cmd': 'Get-ItemProperty HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run,HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run -ErrorAction SilentlyContinue', 'use': 'Review common Windows autorun registry locations.'}, {'name': 'Service creation events', 'cmd': 'Get-WinEvent -FilterHashtable @{LogName="System";Id=7045;StartTime=(Get-Date).AddDays(-7)}', 'use': 'Review recent Windows service-installation events.'}, {'name': 'Task scheduler events', 'cmd': 'Get-WinEvent -LogName "Microsoft-Windows-TaskScheduler/Operational" -MaxEvents 100', 'use': 'Review Task Scheduler operational telemetry.'}, {'name': 'Startup commands', 'cmd': 'Get-CimInstance Win32_StartupCommand | Select Name,Command,Location,User', 'use': 'Review startup commands during persistence triage.'}, {'name': 'Linux enabled units', 'cmd': 'systemctl list-unit-files --state=enabled', 'use': 'Review enabled Linux units for unexpected entries.'}], 'purple': [{'name': 'Persistence telemetry check', 'cmd': 'Approved benign change -> Endpoint telemetry -> SIEM event -> Detection -> Cleanup verified', 'use': 'Validate persistence-oriented telemetry using a benign approved change.'}, {'name': 'Service baseline', 'cmd': 'Get-Service | Sort Name | Select Name,Status,StartType', 'use': 'Capture service state before and after an approved benign change.'}, {'name': 'Task baseline', 'cmd': 'Get-ScheduledTask | Select TaskPath,TaskName,State', 'use': 'Capture scheduled-task state for comparison.'}, {'name': 'Registry baseline', 'cmd': 'Get-ItemProperty HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run -ErrorAction SilentlyContinue', 'use': 'Capture common autorun state for validation.'}, {'name': 'Persistence chain', 'cmd': 'Benign change -> Endpoint event -> SIEM -> Rule -> Alert -> Cleanup', 'use': 'Validate visibility without deploying malicious persistence.'}, {'name': 'Cleanup verification', 'cmd': 'Compare baseline and post-test service/task/startup inventories', 'use': 'Prove the environment returned to its pre-test state.'}]}, {'id': 'c2', 'number': 6, 'name': 'Command & Control', 'summary': 'Identify and validate outbound communications, DNS behavior, proxy visibility, and network detections.', 'red': [{'name': 'Route path', 'cmd': 'tracert <AUTHORIZED_TARGET>', 'use': 'Document the network path to an authorized test endpoint.'}, {'name': 'DNS review', 'cmd': 'nslookup <AUTHORIZED_DOMAIN>', 'use': 'Validate DNS resolution for approved infrastructure.'}, {'name': 'TCP connectivity', 'cmd': 'Test-NetConnection <AUTHORIZED_TARGET> -Port 443', 'use': 'Validate TCP connectivity to an authorized endpoint.'}, {'name': 'TLS handshake', 'cmd': 'openssl s_client -connect <AUTHORIZED_TARGET>:443 -servername <AUTHORIZED_TARGET> </dev/null', 'use': 'Inspect an authorized TLS handshake.'}, {'name': 'DNS timing', 'cmd': 'Resolve-DnsName <AUTHORIZED_DOMAIN>', 'use': 'Generate and document a benign DNS resolution.'}, {'name': 'HTTP timing', 'cmd': 'curl -o NUL -s -w "status=%{http_code} time=%{time_total}\\n" https://<AUTHORIZED_TARGET>/', 'use': 'Measure a benign HTTPS request to an authorized target.'}, {'name': 'Route table', 'cmd': 'route print', 'use': 'Document the Windows routing table on an authorized test host.'}], 'blue': [{'name': 'Active TCP sessions', 'cmd': 'Get-NetTCPConnection | Sort-Object State,RemoteAddress | Format-Table -Auto', 'use': 'Triage active Windows network sessions.'}, {'name': 'Linux sockets', 'cmd': 'ss -lntup', 'use': 'Review listening services and owning processes on Linux.'}, {'name': 'Process network owners', 'cmd': 'Get-NetTCPConnection | Where State -eq Established | Select LocalAddress,LocalPort,RemoteAddress,RemotePort,OwningProcess', 'use': 'Review established sessions and owning process IDs.'}, {'name': 'DNS cache', 'cmd': 'ipconfig /displaydns', 'use': 'Review recently resolved names.'}, {'name': 'Routes', 'cmd': 'Get-NetRoute | Sort DestinationPrefix,RouteMetric', 'use': 'Review Windows routing configuration.'}, {'name': 'Proxy configuration', 'cmd': 'netsh winhttp show proxy', 'use': 'Review WinHTTP proxy configuration.'}, {'name': 'Linux established sockets', 'cmd': 'ss -ntp state established', 'use': 'Review established Linux TCP sessions and processes.'}], 'purple': [{'name': 'Network detection validation', 'cmd': 'Search firewall/proxy/DNS telemetry for src=<TEST_HOST> dst=<TEST_DESTINATION> during <TEST_WINDOW>', 'use': 'Confirm expected network telemetry and alerting.'}, {'name': 'Approved beacon substitute', 'cmd': 'while ($true) { Test-NetConnection <AUTHORIZED_TARGET> -Port 443; Start-Sleep 60 }', 'use': 'Generate a low-rate benign connectivity check only during an explicitly approved test; stop with Ctrl+C.'}, {'name': 'DNS visibility', 'cmd': 'Resolve-DnsName <AUTHORIZED_DOMAIN>', 'use': 'Generate a benign DNS event and confirm resolver/SIEM visibility.'}, {'name': 'Connection evidence', 'cmd': 'Get-NetTCPConnection -State Established | Select RemoteAddress,RemotePort,OwningProcess', 'use': 'Capture endpoint-side connection evidence.'}, {'name': 'Network chain', 'cmd': 'DNS -> Firewall -> Proxy -> Endpoint -> SIEM -> Alert', 'use': 'Validate network telemetry coverage.'}, {'name': 'Stop/cleanup', 'cmd': 'Stop the approved connectivity loop and verify no test process remains', 'use': 'Ensure Purple Team simulations end cleanly.'}]}, {'id': 'objectives', 'number': 7, 'name': 'Actions on Objectives', 'summary': 'Assess business impact, access, collection, and response outcomes using approved simulations and evidence.', 'red': [{'name': 'Evidence hash', 'cmd': 'certutil -hashfile <EVIDENCE_FILE> SHA256', 'use': 'Preserve integrity of authorized assessment evidence.'}, {'name': 'Directory inventory', 'cmd': 'Get-ChildItem <AUTHORIZED_PATH> -File -Recurse -ErrorAction SilentlyContinue | Select -First 100 FullName,Length,LastWriteTime', 'use': 'Inventory files in an explicitly authorized test directory without opening content.'}, {'name': 'ACL review', 'cmd': 'Get-Acl <AUTHORIZED_PATH> | Format-List', 'use': 'Review permissions on an authorized path.'}, {'name': 'Disk usage', 'cmd': 'Get-PSDrive -PSProvider FileSystem', 'use': 'Review filesystem capacity on an authorized Windows host.'}, {'name': 'Linux permissions', 'cmd': 'ls -la <AUTHORIZED_PATH>', 'use': 'Review directory permissions on an authorized Linux path.'}, {'name': 'Evidence manifest', 'cmd': 'Get-ChildItem <EVIDENCE_DIR> -File | Get-FileHash -Algorithm SHA256', 'use': 'Create hashes for collected authorized evidence.'}], 'blue': [{'name': 'Process inventory', 'cmd': 'Get-Process | Sort-Object CPU -Descending | Select -First 30 Name,Id,CPU,Path', 'use': 'Review process activity while scoping impact.'}, {'name': 'Systemd logs', 'cmd': 'journalctl -u <SERVICE> --since "-4 hours"', 'use': 'Review Linux service events during impact assessment.'}, {'name': 'Recent file changes', 'cmd': 'Get-ChildItem <TRIAGE_PATH> -File -Recurse -ErrorAction SilentlyContinue | Sort LastWriteTime -Descending | Select -First 100 FullName,Length,LastWriteTime', 'use': 'Review recent file changes in a scoped triage path.'}, {'name': 'Share inventory', 'cmd': 'Get-SmbShare | Select Name,Path,Description', 'use': 'Review Windows SMB shares.'}, {'name': 'Local admins', 'cmd': 'Get-LocalGroupMember Administrators', 'use': 'Review local administrator membership.'}, {'name': 'Logon summary', 'cmd': 'Get-WinEvent -FilterHashtable @{LogName="Security";Id=4624;StartTime=(Get-Date).AddHours(-8)} | Select -First 100 TimeCreated,Id,Message', 'use': 'Review successful logons during impact scoping.'}, {'name': 'Linux auth events', 'cmd': 'journalctl --since "-4 hours" | grep -Ei "sudo|sshd|authentication"', 'use': 'Review recent Linux authentication-related journal entries.'}], 'purple': [{'name': 'Retest evidence checklist', 'cmd': 'Same test -> Same scope -> Telemetry captured -> Rule fired -> Analyst context adequate -> Response verified -> Evidence attached', 'use': 'Prove remediation and defensive effectiveness with repeatable evidence.'}, {'name': 'Canary-file hash', 'cmd': 'Get-FileHash <APPROVED_CANARY_FILE> -Algorithm SHA256', 'use': 'Identify a benign canary file used for approved access-monitoring validation.'}, {'name': 'Access evidence', 'cmd': 'Get-WinEvent -FilterHashtable @{LogName="Security";Id=4663;StartTime=(Get-Date).AddMinutes(-30)} -ErrorAction SilentlyContinue', 'use': 'Review object-access events when auditing is configured.'}, {'name': 'Impact chain', 'cmd': 'Approved canary access -> File telemetry -> SIEM -> Detection -> Case', 'use': 'Validate objective-stage visibility without accessing sensitive production data.'}, {'name': 'Response timing', 'cmd': 'Record test timestamp, alert timestamp, analyst acknowledgement and closure', 'use': 'Measure detection and response latency.'}, {'name': 'Retest proof', 'cmd': 'Repeat approved canary action after remediation and attach evidence', 'use': 'Confirm controls remain effective after changes.'}]}], 'resources': [{'name': 'OSINT Framework', 'category': 'OSINT Directory', 'url': 'https://osintframework.com/', 'use': 'Directory of open-source intelligence resources.'}, {'name': 'Shodan', 'category': 'Internet Exposure', 'url': 'https://www.shodan.io/', 'use': 'Search Internet-connected devices and exposed service banners.'}, {'name': 'Censys', 'category': 'Internet Exposure', 'url': 'https://search.censys.io/', 'use': 'Search Internet hosts, web properties, and certificates.'}, {'name': 'VirusTotal', 'category': 'IOC Intelligence', 'url': 'https://www.virustotal.com/gui/home/search', 'use': 'Investigate files, hashes, URLs, domains, and IP indicators.'}, {'name': 'AbuseIPDB', 'category': 'IP Reputation', 'url': 'https://www.abuseipdb.com/', 'use': 'Check IP reputation and abuse-report history.'}, {'name': 'GreyNoise', 'category': 'IP Intelligence', 'url': 'https://viz.greynoise.io/', 'use': 'Contextualize Internet scanning and attack traffic.'}, {'name': 'urlscan.io', 'category': 'URL Analysis', 'url': 'https://urlscan.io/', 'use': 'Analyze websites and suspicious URLs in an isolated service.'}, {'name': 'SecurityTrails', 'category': 'DNS / WHOIS', 'url': 'https://securitytrails.com/', 'use': 'Pivot through DNS, WHOIS, IP, and domain intelligence.'}, {'name': 'crt.sh', 'category': 'Certificates', 'url': 'https://crt.sh/', 'use': 'Search public certificate-transparency records.'}, {'name': 'CISA KEV', 'category': 'Vulnerability Intelligence', 'url': 'https://www.cisa.gov/known-exploited-vulnerabilities-catalog', 'use': 'Review vulnerabilities known to be exploited in the wild.'}, {'name': 'MITRE ATT&CK', 'category': 'Adversary Behavior', 'url': 'https://attack.mitre.org/', 'use': 'Map observed behavior and defensive coverage to ATT&CK.'}, {'name': 'OSIRIS AI', 'category': 'Global Intelligence', 'url': 'https://osirisai.live/', 'use': 'Open the OSIRIS global cyber, malware, OSINT, geopolitical, and infrastructure intelligence dashboard.'}, {'name': 'Cyber Kill Chain', 'category': 'Framework', 'url': 'https://www.lockheedmartin.com/en-us/capabilities/cyber/cyber-kill-chain.html', 'use': 'Official Lockheed Martin Cyber Kill Chain overview.'}]}

FRAMEWORKS={
 'NIST CSF 2.0':{'use':'Use for program-level cybersecurity outcomes and executive posture tracking.','areas':['Govern','Identify','Protect','Detect','Respond','Recover'],'controls':['Define cybersecurity roles and risk governance','Maintain asset and data inventory','Prioritize and treat cyber risk','Protect identities and privileged access','Protect data and platforms','Collect security telemetry','Detect and analyze adverse events','Coordinate incident response','Contain and eradicate incidents','Recover services and improve controls']},
 'CIS Controls v8':{'use':'Use for prioritized technical safeguards and implementation tracking.','areas':['IG1','IG2','IG3'],'controls':['Inventory enterprise assets','Inventory software assets','Protect data','Secure configurations','Account management','Access control management','Continuous vulnerability management','Audit log management','Email and browser protections','Malware defenses','Data recovery','Network infrastructure management','Network monitoring and defense','Security awareness','Service provider management','Application software security','Incident response management','Penetration testing']},
 'ISO 27001':{'use':'Use for ISMS governance, risk treatment and evidence-oriented control management.','areas':['Organization','People','Physical','Technology'],'controls':['ISMS scope and context','Leadership and policy','Risk assessment methodology','Risk treatment plan','Statement of Applicability','Competence and awareness','Documented information control','Operational planning','Performance evaluation','Internal audit','Management review','Corrective action']},
 'NIST RMF / 800-53':{'use':'Use for control selection, implementation, assessment, authorization and continuous monitoring.','areas':['Prepare','Categorize','Select','Implement','Assess','Authorize','Monitor'],'controls':['System categorization','Control baseline selection','Control tailoring','Implementation evidence','Assessment procedures','POA&M tracking','Authorization package','Continuous monitoring strategy']},
 'PCI DSS':{'use':'Use when protecting payment-card environments and cardholder-data flows.','areas':['Network','Accounts','Data','Vulnerability','Monitoring','Governance'],'controls':['Define cardholder-data environment','Network security controls','Secure configurations','Protect stored account data','Encrypt transmission','Anti-malware controls','Secure development','Restrict access by need to know','Strong authentication','Physical access controls','Log and monitor access','Test security regularly','Maintain security policy']},
 'HIPAA Security Rule':{'use':'Use for HIPAA Security Rule safeguard tracking for electronic protected health information (ePHI). This is a control-tracking aid, not legal advice or an attestation of compliance.','areas':['Administrative Safeguards','Physical Safeguards','Technical Safeguards','Organizational Requirements'],'controls':['Perform security risk analysis and risk management','Assign security responsibility','Implement workforce security procedures','Manage information access','Security awareness and training','Security incident procedures','Contingency planning and data backup','Periodic security evaluation','Facility access controls','Workstation use and security','Device and media controls','Unique user identification and access control','Emergency access procedures','Automatic logoff where appropriate','Encryption and decryption controls','Audit controls for systems containing ePHI','Integrity controls for ePHI','Person or entity authentication','Transmission security','Business associate and organizational safeguard documentation']},
 'SOC 2':{'use':'Use to organize evidence around Trust Services Criteria and operational control effectiveness.','areas':['Security','Availability','Confidentiality','Processing Integrity','Privacy'],'controls':['Control environment','Risk assessment','Logical access','Change management','System operations','Monitoring','Incident response','Vendor management','Business continuity','Evidence retention']}
}

PLAYBOOKS=[
 {'id':'phishing-bec','title':'Phishing / BEC Investigation','team':'blue','severity':'high','use':'Triage suspicious email, credential-harvest, invoice fraud, or business-email-compromise reports.','trigger':'Reported suspicious message, impossible travel, suspicious mailbox rule, or credential-use alert.','steps':['Preserve the original message and headers.','Identify recipients, sender infrastructure, URLs, attachments and reply-to anomalies.','Search mail telemetry for matching sender, subject, URL and message ID.','Check identity logs for suspicious sign-ins, MFA changes and mailbox rules.','Contain by removing malicious messages and restricting compromised accounts as appropriate.','Reset exposed credentials and revoke sessions when compromise is confirmed.','Block validated malicious indicators at email/web controls.','Document scope, impact, evidence and user notifications.','Tune detections and run a Purple retest.']},
 {'id':'ransomware','title':'Ransomware / Mass Encryption','team':'blue','severity':'critical','use':'Respond to suspected encryption, destructive malware, ransom notes or rapid file modification.','trigger':'EDR ransomware alert, mass file rename, ransom note, backup tampering, or abnormal SMB activity.','steps':['Declare incident and assign commander.','Isolate affected hosts from the network while preserving evidence.','Disable compromised accounts/tokens and restrict lateral-movement paths.','Identify patient zero, encryption scope and affected shares.','Protect backups and verify immutable/recovery copies.','Collect volatile and endpoint evidence before reimaging where feasible.','Eradicate persistence and initial-access vector.','Recover from trusted backups and validate business services.','Rotate exposed secrets and privileged credentials.','Capture lessons learned, detection gaps and Purple retest actions.']},
 {'id':'account-compromise','title':'Compromised Identity / Account Takeover','team':'blue','severity':'high','use':'Investigate suspicious authentication, MFA abuse, token theft or privileged account misuse.','trigger':'Impossible travel, MFA fatigue, unusual token use, anomalous admin action, or user report.','steps':['Validate the alert and business context.','Review sign-ins, device, IP, geolocation, token and MFA events.','Scope mailbox, cloud, VPN and privileged actions.','Revoke active sessions and tokens as appropriate.','Reset credentials and re-register MFA if compromise is confirmed.','Review OAuth grants, forwarding rules and persistence changes.','Hunt for the same indicators across other accounts.','Document impact and tune identity detections.']},
 {'id':'malware-endpoint','title':'Malware / Suspicious Endpoint','team':'blue','severity':'high','use':'Investigate suspicious process, file, persistence or endpoint-detection alerts.','trigger':'EDR alert, malicious hash, suspicious child process or user report.','steps':['Capture alert metadata and endpoint criticality.','Record process tree, network connections, hashes and persistence locations.','Isolate host if risk warrants.','Collect forensic artifacts and timeline evidence.','Enrich indicators using configured threat intelligence.','Identify root cause and initial access.','Remove persistence/malware or rebuild from trusted media.','Validate endpoint health before reconnection.','Create detection and Purple validation follow-up.']},
 {'id':'web-attack','title':'Web Application Attack','team':'blue','severity':'high','use':'Investigate suspicious HTTP behavior, WAF alerts, exploitation attempts or application compromise.','trigger':'WAF/IDS alert, unusual 4xx/5xx burst, webshell indicator, or suspicious application log.','steps':['Preserve WAF, reverse-proxy and application logs.','Identify source IPs, target paths, methods, parameters and user/session context.','Correlate with authentication, host and database events.','Determine exploit success versus blocked attempt.','Contain compromised instances or sessions.','Patch vulnerable component and remove malicious artifacts.','Rotate exposed application secrets.','Add detections and retest safely.']},
 {'id':'cloud-compromise','title':'Cloud Control-Plane Compromise','team':'blue','severity':'critical','use':'Respond to suspicious cloud API activity, exposed keys, privilege escalation or destructive cloud actions.','trigger':'Unusual IAM change, new key, disabled logging, public storage exposure or impossible admin activity.','steps':['Preserve cloud audit logs and affected resource metadata.','Identify principal, source IP, token/key and sequence of API actions.','Disable exposed credentials and revoke sessions.','Review IAM changes, persistence, network and storage exposure.','Restore logging and guardrails if altered.','Scope data access and exfiltration indicators.','Rebuild or remediate affected resources from known-good configuration.','Rotate secrets and review trust policies.','Add detections and Purple validation.']},
 {'id':'data-exfil','title':'Suspected Data Exfiltration','team':'blue','severity':'critical','use':'Investigate unusual outbound transfer, cloud sharing, archive creation or sensitive-data access.','trigger':'DLP alert, unusual egress volume, mass download, archive tooling or suspicious external share.','steps':['Identify data owner, classification and regulatory impact.','Preserve DLP, proxy, network, endpoint and cloud logs.','Scope user, device, destination, volume and time window.','Contain active transfer paths while preserving business continuity.','Validate whether data actually left organizational control.','Revoke malicious shares/tokens and restrict compromised identities.','Engage legal/privacy leadership when required.','Document affected records, evidence and notification decisions.']},
 {'id':'vuln-kev','title':'Known Exploited Vulnerability Emergency Remediation','team':'blue','severity':'critical','use':'Drive rapid response when an internet-facing or critical asset is affected by a known-exploited vulnerability.','trigger':'CISA KEV match or confirmed active exploitation against a vulnerable asset.','steps':['Validate affected product/version and asset exposure.','Determine internet reachability and business criticality.','Search telemetry for exploitation indicators.','Apply vendor mitigation or isolate the service if patching cannot occur immediately.','Patch or upgrade using change controls appropriate to urgency.','Validate remediation with version/configuration evidence.','Hunt for compromise before closing.','Record exception and compensating controls if remediation is deferred.']},
 {'id':'red-external','title':'Authorized External Exposure Review','team':'red','severity':'medium','use':'Structured, low-impact review of externally exposed services during an authorized engagement.','trigger':'Approved external assessment with written scope and stop conditions.','steps':['Confirm scope, authorization, exclusions and testing window.','Inventory authorized domains/IPs and ownership.','Review DNS, certificates and exposed services.','Inspect HTTP/TLS posture and externally visible metadata.','Document only validated findings with evidence.','Stop on instability or scope ambiguity.','Deliver remediation recommendations and explicit retest criteria.']},
 {'id':'purple-identity','title':'Purple Validation — Suspicious Identity Behavior','team':'purple','severity':'medium','use':'Validate identity telemetry, alerting and analyst workflow using an agreed benign test pattern.','trigger':'Planned ATT&CK-aligned identity detection exercise.','steps':['Choose behavior and map it to ATT&CK.','Define safe test, expected telemetry and rollback.','Confirm test identity and maintenance window.','Execute only the agreed benign validation.','Verify identity, endpoint, SIEM and alert telemetry.','Measure alert quality, context and analyst response.','Record gaps with owners and due dates.','Retest after remediation and close with evidence.']},
 {'id':'purple-endpoint','title':'Purple Validation — Endpoint Execution Telemetry','team':'purple','severity':'medium','use':'Validate endpoint process/event collection and detections using safe markers or benign administrative actions.','trigger':'Planned endpoint detection validation.','steps':['Define the expected process/event chain.','Confirm host, sensor health and logging configuration.','Run the approved benign test marker/action.','Verify endpoint and centralized telemetry arrival.','Check detection, severity, enrichment and analyst context.','Record parser, collection or rule gaps.','Tune controls and repeat the identical test.']},
 {'id':'ddos','title':'DDoS / Service Availability','team':'blue','severity':'high','use':'Coordinate response to traffic floods or service exhaustion affecting availability.','trigger':'Availability degradation with anomalous traffic volume or provider DDoS alert.','steps':['Confirm service impact and establish incident command.','Capture traffic characteristics, source distribution and targeted endpoints.','Engage CDN/ISP/DDoS protection provider.','Apply rate limiting or upstream filtering where appropriate.','Protect origin infrastructure and monitor capacity.','Preserve evidence and communications timeline.','Validate service recovery and update resilience controls.']}
]

INTEGRATION_CATALOG={
 'cisa':{'name':'CISA KEV','category':'Free Threat Data','fields':[],'secret':[],'hint':'No key required; live catalog.'},
 'osiris':{'name':'OSIRIS Intelligence','category':'Free Threat Data','fields':[],'secret':[],'hint':'Native keyless OSIRIS cyber, malware, CVE, OSINT, geopolitical and map intelligence feeds.'},
 'feodo':{'name':'abuse.ch Feodo Tracker','category':'Free Threat Data','fields':[],'secret':[],'hint':'No key required; active botnet C2 feed.'},
 'dshield':{'name':'SANS ISC / DShield','category':'Free Threat Data','fields':[],'secret':[],'hint':'Community source telemetry; not a blocklist.'},
 'spamhaus':{'name':'Spamhaus DROP','category':'Free Threat Data','fields':[],'secret':[],'hint':'Free high-confidence malicious netblocks; attribution required.'},
 'threatfox':{'name':'ThreatFox','category':'Threat Intelligence','fields':['auth_key','days'],'secret':['auth_key'],'hint':'Free abuse.ch Auth-Key; recent IOC feed.'},
 'greynoise':{'name':'GreyNoise Community','category':'Threat Intelligence','fields':['api_key','test_ip'],'secret':['api_key'],'hint':'Optional free API key; community IP context.'},
 'otx':{'name':'AlienVault OTX','category':'Threat Intelligence','fields':['api_key'],'secret':['api_key'],'hint':'Community API key.'},
 'abuseipdb':{'name':'AbuseIPDB','category':'Threat Intelligence','fields':['api_key','test_ip'],'secret':['api_key'],'hint':'API key for IP reputation checks.'},
 'virustotal':{'name':'VirusTotal','category':'Threat Intelligence','fields':['api_key','test_ip'],'secret':['api_key'],'hint':'Public/community API key; respect provider terms.'},
 'splunk':{'name':'Splunk','category':'SIEM','fields':['base_url','token'],'secret':['token'],'hint':'https://splunk.example:8089'},
 'sentinel':{'name':'Microsoft Sentinel','category':'SIEM','fields':['tenant_id','client_id','client_secret','subscription_id','resource_group','workspace_name'],'secret':['client_secret'],'hint':'Azure app credentials plus workspace details.'},
 'elastic':{'name':'Elastic Security','category':'SIEM','fields':['base_url','api_key'],'secret':['api_key'],'hint':'Elastic URL + API key.'},
 'defender':{'name':'Microsoft Defender XDR','category':'EDR/XDR','fields':['tenant_id','client_id','client_secret'],'secret':['client_secret'],'hint':'Microsoft security API app credentials.'},
 'crowdstrike':{'name':'CrowdStrike Falcon','category':'EDR/XDR','fields':['base_url','client_id','client_secret'],'secret':['client_secret'],'hint':'Falcon OAuth client.'},
 'misp':{'name':'MISP','category':'Threat Intelligence','fields':['base_url','api_key'],'secret':['api_key'],'hint':'MISP URL + automation key.'},
 'opencti':{'name':'OpenCTI','category':'Threat Intelligence','fields':['base_url','token'],'secret':['token'],'hint':'OpenCTI GraphQL endpoint.'},
 'taxii':{'name':'STIX/TAXII 2.1','category':'Threat Intelligence','fields':['base_url','collection_id','username','password'],'secret':['password'],'hint':'TAXII collection.'},
 'nvd':{'name':'NVD','category':'Vulnerability','fields':['api_key'],'secret':['api_key'],'hint':'Works without a key at lower rate; key improves rate limits.'},
 'jira':{'name':'Jira','category':'Ticketing / ITSM','fields':['base_url','email','api_token','project_key','jql'],'secret':['api_token'],'hint':'Atlassian API token.'},
 'servicenow':{'name':'ServiceNow','category':'Ticketing / ITSM','fields':['base_url','username','password','table'],'secret':['password'],'hint':'Instance credentials and table.'},
 'slack':{'name':'Slack Webhook','category':'Notifications','fields':['webhook_url'],'secret':['webhook_url'],'hint':'Incoming webhook URL.'},
 'teams':{'name':'Microsoft Teams Webhook','category':'Notifications','fields':['webhook_url'],'secret':['webhook_url'],'hint':'Workflow/webhook URL.'},
 'smtp':{'name':'SMTP','category':'Notifications','fields':['host','port','username','password','from_address','to_address','ssl'],'secret':['password'],'hint':'Mail relay settings.'},
 'aws':{'name':'AWS Security Hub','category':'Cloud Security','fields':['region','access_key_id','secret_access_key'],'secret':['access_key_id','secret_access_key'],'hint':'Leave keys blank to use normal AWS credential chain.'},
 'azure':{'name':'Azure Security','category':'Cloud Security','fields':['tenant_id','client_id','client_secret','subscription_id'],'secret':['client_secret'],'hint':'Azure app credentials.'},
 'gcp':{'name':'Google Cloud SCC','category':'Cloud Security','fields':['organization_id','service_account_json'],'secret':['service_account_json'],'hint':'Organization ID + service-account JSON.'},
 'webhook':{'name':'Generic Webhook/API','category':'Automation','fields':['base_url','auth_header'],'secret':['auth_header'],'hint':'HTTP endpoint with optional Authorization value.'}
}
NO_KEY={'cisa','osiris','feodo','dshield','spamhaus'}

COUNTRY_CENTROIDS={'US':[39.8,-98.6],'CA':[56.1,-106.3],'MX':[23.6,-102.5],'BR':[-14.2,-51.9],'AR':[-38.4,-63.6],'CL':[-35.7,-71.5],'CO':[4.6,-74.1],'GB':[55.4,-3.4],'IE':[53.1,-8.2],'FR':[46.2,2.2],'DE':[51.2,10.4],'NL':[52.1,5.3],'BE':[50.5,4.5],'ES':[40.5,-3.7],'PT':[39.4,-8.2],'IT':[41.9,12.6],'PL':[51.9,19.1],'UA':[48.4,31.2],'RU':[61.5,105.3],'SE':[60.1,18.6],'NO':[60.5,8.5],'FI':[61.9,25.7],'DK':[56.3,9.5],'CZ':[49.8,15.5],'RO':[45.9,24.9],'TR':[38.96,35.24],'IL':[31.0,34.9],'SA':[23.9,45.1],'AE':[23.4,53.8],'IN':[20.6,79.0],'PK':[30.4,69.3],'BD':[23.7,90.4],'CN':[35.9,104.2],'JP':[36.2,138.3],'KR':[35.9,127.8],'TW':[23.7,121.0],'HK':[22.3,114.2],'SG':[1.35,103.8],'TH':[15.9,101.0],'VN':[14.1,108.3],'ID':[-0.8,113.9],'MY':[4.2,101.98],'PH':[12.9,121.8],'AU':[-25.3,133.8],'NZ':[-40.9,174.9],'ZA':[-30.6,22.9],'NG':[9.1,8.7],'EG':[26.8,30.8],'KE':[-0.02,37.9],'MA':[31.8,-7.1],'IR':[32.4,53.7],'IQ':[33.2,43.7]}
THREAT_CACHE={'ts':0,'data':None}
CURRENT_USER=ContextVar('hms_current_user',default='system')
CURRENT_IP=ContextVar('hms_current_ip',default='local')
PH=PasswordHasher(time_cost=3,memory_cost=65536,parallelism=2)
SESSION_HOURS=12

def conn():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def _harden_private_file(path:Path):
 try:
  if os.name=='nt':
   user=os.environ.get('USERNAME','')
   if user:subprocess.run(['icacls',str(path),'/inheritance:r','/grant:r',f'{user}:F'],capture_output=True,text=True,timeout=8)
  else: os.chmod(path,0o600)
 except Exception: pass

def key():
 if not KEYFILE.exists():
  KEYFILE.write_bytes(Fernet.generate_key()); _harden_private_file(KEYFILE)
 return KEYFILE.read_bytes()
def enc(v:str)->str:return Fernet(key()).encrypt((v or '').encode()).decode()
def dec(v:str)->str:
 try:return Fernet(key()).decrypt((v or '').encode()).decode()
 except (InvalidToken,ValueError):return ''
def enc_bytes(v:bytes)->bytes:return Fernet(key()).encrypt(v)
def dec_bytes(v:bytes)->bytes:return Fernet(key()).decrypt(v)
def audit(action,detail=''):
 actor=CURRENT_USER.get(); ip=CURRENT_IP.get()
 with conn() as c:c.execute('insert into audit(action,detail,actor,source_ip) values(?,?,?,?)',(action,str(detail)[:4000],actor,ip))

def init_db():
 with conn() as c:c.executescript('''
 CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,owner TEXT DEFAULT '',team TEXT DEFAULT 'blue',status TEXT DEFAULT 'open',priority TEXT DEFAULT 'medium',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS risks(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,likelihood INTEGER DEFAULT 3,impact INTEGER DEFAULT 3,owner TEXT DEFAULT '',treatment TEXT DEFAULT '',status TEXT DEFAULT 'open',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS incidents(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,severity TEXT DEFAULT 'medium',status TEXT DEFAULT 'investigating',commander TEXT DEFAULT '',summary TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS assets(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,kind TEXT DEFAULT 'server',criticality TEXT DEFAULT 'medium',owner TEXT DEFAULT '',location TEXT DEFAULT '',status TEXT DEFAULT 'active',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS integrations(id TEXT PRIMARY KEY,enabled INTEGER DEFAULT 0,config_json TEXT DEFAULT '{}',status TEXT DEFAULT 'not_configured',last_test TEXT DEFAULT '',last_error TEXT DEFAULT '',updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,action TEXT NOT NULL,detail TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS study(id INTEGER PRIMARY KEY AUTOINCREMENT,cert TEXT NOT NULL,score INTEGER,total INTEGER,domain_json TEXT DEFAULT '{}',mode TEXT DEFAULT 'practice',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS academy_certificates(id INTEGER PRIMARY KEY AUTOINCREMENT,certificate_id TEXT UNIQUE NOT NULL,study_id INTEGER NOT NULL,username TEXT NOT NULL,recipient_name TEXT NOT NULL,course TEXT NOT NULL,score INTEGER NOT NULL,total INTEGER NOT NULL,percent INTEGER NOT NULL,issued_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS vulnerabilities(id INTEGER PRIMARY KEY AUTOINCREMENT,cve TEXT DEFAULT '',title TEXT NOT NULL,severity TEXT DEFAULT 'medium',asset TEXT DEFAULT '',owner TEXT DEFAULT '',status TEXT DEFAULT 'open',due_date TEXT DEFAULT '',source TEXT DEFAULT 'manual',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS engagements(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,scope TEXT DEFAULT '',owner TEXT DEFAULT '',status TEXT DEFAULT 'planning',roe TEXT DEFAULT '',stop_conditions TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS team_findings(id INTEGER PRIMARY KEY AUTOINCREMENT,team TEXT NOT NULL,title TEXT NOT NULL,severity TEXT DEFAULT 'medium',status TEXT DEFAULT 'open',asset TEXT DEFAULT '',attack_id TEXT DEFAULT '',evidence TEXT DEFAULT '',remediation TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS purple_tests(id INTEGER PRIMARY KEY AUTOINCREMENT,technique TEXT NOT NULL,hypothesis TEXT DEFAULT '',expected_telemetry TEXT DEFAULT '',observed TEXT DEFAULT '',detection TEXT DEFAULT '',gap TEXT DEFAULT '',owner TEXT DEFAULT '',status TEXT DEFAULT 'planned',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS investigations(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,status TEXT DEFAULT 'open',severity TEXT DEFAULT 'medium',summary TEXT DEFAULT '',iocs TEXT DEFAULT '',timeline TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS toolbox_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,tool TEXT NOT NULL,input_summary TEXT DEFAULT '',output TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS incident_lifecycle(id INTEGER PRIMARY KEY AUTOINCREMENT,incident_id INTEGER NOT NULL,phase TEXT NOT NULL,status TEXT DEFAULT 'pending',notes TEXT DEFAULT '',owner TEXT DEFAULT '',updated_at TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(incident_id,phase));
 CREATE TABLE IF NOT EXISTS framework_checks(id INTEGER PRIMARY KEY AUTOINCREMENT,framework TEXT NOT NULL,control TEXT NOT NULL,status TEXT DEFAULT 'not_started',owner TEXT DEFAULT '',evidence TEXT DEFAULT '',updated_at TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(framework,control));
 CREATE TABLE IF NOT EXISTS playbook_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,playbook_id TEXT NOT NULL,title TEXT NOT NULL,team TEXT DEFAULT 'blue',status TEXT DEFAULT 'open',owner TEXT DEFAULT '',notes TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS incident_plans(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,customer TEXT DEFAULT '',prepared_by TEXT DEFAULT '',version TEXT DEFAULT '1.0',status TEXT DEFAULT 'draft',organization_profile TEXT DEFAULT '',contacts TEXT DEFAULT '',scope TEXT DEFAULT '',roles TEXT DEFAULT '',severity TEXT DEFAULT '',response TEXT DEFAULT '',communications TEXT DEFAULT '',evidence TEXT DEFAULT '',recovery TEXT DEFAULT '',lessons TEXT DEFAULT '',approvals TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS incident_plan_sources(id INTEGER PRIMARY KEY AUTOINCREMENT,plan_id INTEGER NOT NULL,name TEXT NOT NULL,sha256 TEXT NOT NULL,text_enc TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS stig_findings(id INTEGER PRIMARY KEY AUTOINCREMENT,scan_id TEXT DEFAULT '',benchmark TEXT DEFAULT '',rule_id TEXT DEFAULT '',vuln_id TEXT DEFAULT '',title TEXT NOT NULL,category TEXT DEFAULT 'CAT II',severity TEXT DEFAULT 'medium',status TEXT DEFAULT 'Open',asset TEXT DEFAULT '',source TEXT DEFAULT '',finding_details TEXT DEFAULT '',remediation TEXT DEFAULT '',comments TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS stig_scans(id INTEGER PRIMARY KEY AUTOINCREMENT,scan_id TEXT UNIQUE,asset TEXT DEFAULT '',profile TEXT DEFAULT '',source TEXT DEFAULT '',summary TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT DEFAULT 'admin',enabled INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP,last_login TEXT DEFAULT '');
 CREATE TABLE IF NOT EXISTS sessions(id INTEGER PRIMARY KEY AUTOINCREMENT,token_hash TEXT UNIQUE NOT NULL,username TEXT NOT NULL,csrf_token TEXT NOT NULL,expires_at INTEGER NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS auth_failures(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT DEFAULT '',source_ip TEXT DEFAULT '',attempted_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS pentest_reports(id TEXT PRIMARY KEY,name TEXT NOT NULL,client TEXT DEFAULT '',original_filename TEXT NOT NULL,sha256 TEXT NOT NULL,encrypted_path TEXT NOT NULL,extracted_text_enc TEXT DEFAULT '',parser TEXT DEFAULT '',ai_status TEXT DEFAULT '',finding_count INTEGER DEFAULT 0,uploaded_by TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS tracked_findings(id INTEGER PRIMARY KEY AUTOINCREMENT,report_id TEXT DEFAULT '',source TEXT DEFAULT 'manual',title TEXT NOT NULL,severity TEXT DEFAULT 'medium',status TEXT DEFAULT 'open',asset TEXT DEFAULT '',cve TEXT DEFAULT '',cwe TEXT DEFAULT '',cvss TEXT DEFAULT '',category TEXT DEFAULT '',description_enc TEXT DEFAULT '',evidence_enc TEXT DEFAULT '',remediation_enc TEXT DEFAULT '',owner TEXT DEFAULT '',due_date TEXT DEFAULT '',fixed_at TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS remediation_reports(id TEXT PRIMARY KEY,finding_id INTEGER NOT NULL,encrypted_path TEXT NOT NULL,sha256 TEXT NOT NULL,created_by TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS pentest_scans(id TEXT PRIMARY KEY,name TEXT NOT NULL,target TEXT NOT NULL,profile TEXT DEFAULT 'standard',credential_user TEXT DEFAULT '',status TEXT DEFAULT 'queued',summary_json TEXT DEFAULT '{}',result_enc TEXT DEFAULT '',finding_count INTEGER DEFAULT 0,report_path TEXT DEFAULT '',created_by TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,finished_at TEXT DEFAULT '');
 CREATE TABLE IF NOT EXISTS scan_credentials(username TEXT PRIMARY KEY,cred_type TEXT DEFAULT '',target_username TEXT DEFAULT '',secret_enc TEXT DEFAULT '',domain TEXT DEFAULT '',key_enc TEXT DEFAULT '',updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS watchlists(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT DEFAULT 'ioc',value TEXT NOT NULL,label TEXT DEFAULT '',severity TEXT DEFAULT 'medium',status TEXT DEFAULT 'active',notes TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS scheduled_scans(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,target TEXT NOT NULL,profile TEXT DEFAULT 'quick',credential_user TEXT DEFAULT '',interval_hours INTEGER DEFAULT 168,enabled INTEGER DEFAULT 1,last_run TEXT DEFAULT '',next_run TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS evidence_items(id INTEGER PRIMARY KEY AUTOINCREMENT,investigation_id INTEGER DEFAULT 0,name TEXT NOT NULL,kind TEXT DEFAULT 'note',sha256 TEXT DEFAULT '',encrypted_path TEXT DEFAULT '',notes_enc TEXT DEFAULT '',created_by TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS detections(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,kind TEXT DEFAULT 'sigma',attack_id TEXT DEFAULT '',status TEXT DEFAULT 'draft',content TEXT DEFAULT '',notes TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS notification_rules(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,event_type TEXT DEFAULT 'critical_finding',severity TEXT DEFAULT 'high',enabled INTEGER DEFAULT 1,channel TEXT DEFAULT 'in_app',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS notification_events(id INTEGER PRIMARY KEY AUTOINCREMENT,rule_id INTEGER DEFAULT 0,event_type TEXT DEFAULT '',title TEXT NOT NULL,detail TEXT DEFAULT '',status TEXT DEFAULT 'new',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS asset_notes(id INTEGER PRIMARY KEY AUTOINCREMENT,asset_id INTEGER NOT NULL,note TEXT NOT NULL,created_by TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS user_certifications(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT NOT NULL,certification TEXT NOT NULL,credential_id TEXT DEFAULT '',issued_date TEXT DEFAULT '',expires_date TEXT DEFAULT '',verification_url TEXT DEFAULT '',notes TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS attack_mappings(id INTEGER PRIMARY KEY AUTOINCREMENT,record_type TEXT NOT NULL,record_id TEXT NOT NULL,source TEXT DEFAULT '',asset TEXT DEFAULT '',technique_id TEXT NOT NULL,technique_name TEXT DEFAULT '',tactic TEXT DEFAULT '',relation TEXT DEFAULT 'exposed',confidence TEXT DEFAULT 'medium',reason TEXT DEFAULT '',evidence TEXT DEFAULT '',status TEXT DEFAULT 'active',analyst_note TEXT DEFAULT '',auto_generated INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(record_type,record_id,technique_id,relation));
 CREATE TABLE IF NOT EXISTS osiris_events(id INTEGER PRIMARY KEY AUTOINCREMENT,event_key TEXT UNIQUE NOT NULL,feed TEXT NOT NULL,kind TEXT DEFAULT '',title TEXT DEFAULT '',indicator TEXT DEFAULT '',lat REAL,lon REAL,country TEXT DEFAULT '',summary TEXT DEFAULT '',raw_json TEXT DEFAULT '{}',first_seen TEXT DEFAULT CURRENT_TIMESTAMP,last_seen TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS pentest_report_projects(id TEXT PRIMARY KEY,name TEXT NOT NULL,client TEXT DEFAULT '',assessment_type TEXT DEFAULT 'penetration test',status TEXT DEFAULT 'draft',author TEXT DEFAULT '',classification TEXT DEFAULT 'Confidential',sections_enc TEXT DEFAULT '',ai_status TEXT DEFAULT '',created_by TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS pentest_report_sources(id TEXT PRIMARY KEY,project_id TEXT NOT NULL,kind TEXT DEFAULT 'document',label TEXT DEFAULT '',caption TEXT DEFAULT '',original_filename TEXT DEFAULT '',mime TEXT DEFAULT '',sha256 TEXT DEFAULT '',encrypted_path TEXT DEFAULT '',text_enc TEXT DEFAULT '',reference_id TEXT DEFAULT '',created_by TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS pentest_report_project_findings(project_id TEXT NOT NULL,finding_id INTEGER NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(project_id,finding_id));

 ''')
 cols={r[1] for r in c.execute('pragma table_info(audit)').fetchall()}
 if 'actor' not in cols:c.execute("alter table audit add column actor TEXT DEFAULT ''")
 if 'source_ip' not in cols:c.execute("alter table audit add column source_ip TEXT DEFAULT ''")
 study_cols={r[1] for r in c.execute('pragma table_info(study)').fetchall()}
 if 'domain_json' not in study_cols:c.execute("alter table study add column domain_json TEXT DEFAULT '{}'")
 if 'mode' not in study_cols:c.execute("alter table study add column mode TEXT DEFAULT 'practice'")
 stig_cols={r[1] for r in c.execute('pragma table_info(stig_findings)').fetchall()}
 if 'remediation' not in stig_cols:c.execute("alter table stig_findings add column remediation TEXT DEFAULT ''")
init_db()

class Task(BaseModel): title:str; owner:str=''; team:str='blue'; status:str='open'; priority:str='medium'
class Risk(BaseModel): title:str; likelihood:int=Field(3,ge=1,le=5); impact:int=Field(3,ge=1,le=5); owner:str=''; treatment:str=''; status:str='open'
class Incident(BaseModel): title:str; severity:str='medium'; status:str='investigating'; commander:str=''; summary:str=''
class IncidentPhase(BaseModel): phase:str; status:str='pending'; notes:str=''; owner:str=''
class VulnerabilityUpdate(BaseModel): status:str='open'; owner:str=''; due_date:str=''
class Asset(BaseModel): name:str; kind:str='server'; criticality:str='medium'; owner:str=''; location:str=''; status:str='active'
class IntegrationConfig(BaseModel): enabled:bool=True; config:dict[str,Any]={}
class Grade(BaseModel): answers:list[str]; mode:str='practice'; certificate_name:str='' 
class CheckAnswer(BaseModel): question_id:str; answer:str
class Vulnerability(BaseModel): cve:str=''; title:str; severity:str='medium'; asset:str=''; owner:str=''; status:str='open'; due_date:str=''; source:str='manual'
class Engagement(BaseModel): name:str; scope:str=''; owner:str=''; status:str='planning'; roe:str=''; stop_conditions:str=''
class TeamFinding(BaseModel): team:str; title:str; severity:str='medium'; status:str='open'; asset:str=''; attack_id:str=''; evidence:str=''; remediation:str=''
class PurpleTest(BaseModel): technique:str; hypothesis:str=''; expected_telemetry:str=''; observed:str=''; detection:str=''; gap:str=''; owner:str=''; status:str='planned'
class Investigation(BaseModel): title:str; status:str='open'; severity:str='medium'; summary:str=''; iocs:str=''; timeline:str=''
class ToolboxInput(BaseModel): value:str=''; operation:str=''; extra:str=''
class FrameworkCheck(BaseModel): framework:str; control:str; status:str='not_started'; owner:str=''; evidence:str=''
class PlaybookRun(BaseModel): playbook_id:str; title:str; team:str='blue'; status:str='open'; owner:str=''; notes:str=''
class IncidentPlan(BaseModel):
 name:str; customer:str=''; prepared_by:str=''; version:str='1.0'; status:str='draft'; organization_profile:str=''; contacts:str=''; scope:str=''; roles:str=''; severity:str=''; response:str=''; communications:str=''; evidence:str=''; recovery:str=''; lessons:str=''; approvals:str=''
class AuthSetup(BaseModel): username:str='admin'; password:str
class AuthLogin(BaseModel): username:str; password:str
class UserCreate(BaseModel): username:str; password:str; role:str='analyst'; enabled:bool=True
class UserUpdate(BaseModel): role:str=''; enabled:bool|None=None; password:str=''
class ScanCredentialUpdate(BaseModel): cred_type:str=''; target_username:str=''; secret:str=''; domain:str=''; private_key:str=''; clear:bool=False
class UserCertification(BaseModel): certification:str; credential_id:str=''; issued_date:str=''; expires_date:str=''; verification_url:str=''; notes:str=''
class PentestScanRequest(BaseModel): name:str=''; target:str; profile:str='standard'; credential_user:str=''; authorized:bool=False; import_findings:bool=True
class TrackedFinding(BaseModel):
 title:str; severity:str='medium'; status:str='open'; asset:str=''; cve:str=''; cwe:str=''; cvss:str=''; category:str=''; description:str=''; evidence:str=''; remediation:str=''; owner:str=''; due_date:str=''; report_id:str=''; source:str='manual'
class FindingUpdate(BaseModel):
 title:str=''; severity:str=''; status:str=''; asset:str=''; cve:str=''; cwe:str=''; cvss:str=''; category:str=''; description:str=''; evidence:str=''; remediation:str=''; owner:str=''; due_date:str=''
class NotificationTest(BaseModel): message:str='Hive Mind Security integration test: connectivity verified.'
class WatchItem(BaseModel): kind:str='ioc'; value:str; label:str=''; severity:str='medium'; status:str='active'; notes:str=''
class ScheduledScan(BaseModel): name:str; target:str; profile:str='quick'; credential_user:str=''; interval_hours:int=Field(168,ge=1,le=8760); enabled:bool=True
class DetectionRule(BaseModel): name:str; kind:str='sigma'; attack_id:str=''; status:str='draft'; content:str=''; notes:str=''
class NotificationRule(BaseModel): name:str; event_type:str='critical_finding'; severity:str='high'; enabled:bool=True; channel:str='in_app'
class AssetNote(BaseModel): note:str
class EvidenceNote(BaseModel): investigation_id:int=0; name:str; notes:str=''
class PentestReportProject(BaseModel): name:str; client:str=''; assessment_type:str='penetration test'; status:str='draft'; author:str=''; classification:str='Confidential'
class PentestReportProjectUpdate(BaseModel): name:str=''; client:str=''; assessment_type:str=''; status:str=''; author:str=''; classification:str=''; sections:dict[str,Any]={}
class PentestReportFindingLink(BaseModel): finding_ids:list[int]=[]


def _token_hash(token:str)->str:return hashlib.sha256(token.encode()).hexdigest()
def _session_from_request(request:Request):
 token=request.cookies.get('hms_session','')
 if not token:return None
 now=int(time.time())
 with conn() as c:
  row=c.execute('select username,csrf_token,expires_at from sessions where token_hash=?',(_token_hash(token),)).fetchone()
  if not row:return None
  if int(row['expires_at'])<now:
   c.execute('delete from sessions where token_hash=?',(_token_hash(token),));return None
  u=c.execute('select username,role,enabled from users where username=?',(row['username'],)).fetchone()
  if not u or not u['enabled']:return None
  return {'username':u['username'],'role':u['role'],'csrf_token':row['csrf_token'],'expires_at':row['expires_at']}

def _auth_required_count()->int:
 with conn() as c:return c.execute('select count(*) from users where enabled=1').fetchone()[0]

@app.middleware('http')
async def secure_portal(request:Request,call_next):
 path=request.url.path
 host=(request.headers.get('host') or '').split(':')[0].lower()
 if host not in ('127.0.0.1','localhost','::1'):return JSONResponse({'detail':'Invalid host'},status_code=400)
 public=path=='/login' or path.startswith('/static/') or path in ('/api/auth/status','/api/auth/setup','/api/auth/login')
 sess=None if public else _session_from_request(request)
 if not public and not sess:
  if path.startswith('/api/'):return JSONResponse({'detail':'Authentication required'},status_code=401)
  return RedirectResponse('/login',status_code=303)
 if sess:
  request.state.user=sess['username'];request.state.role=sess['role'];request.state.csrf=sess['csrf_token']
  tok1=CURRENT_USER.set(sess['username']);tok2=CURRENT_IP.set(request.client.host if request.client else 'local')
  if sess['role']=='viewer' and request.method in ('POST','PUT','PATCH','DELETE') and path!='/api/auth/logout':
   CURRENT_USER.reset(tok1);CURRENT_IP.reset(tok2);return JSONResponse({'detail':'Viewer role is read-only.'},status_code=403)
  if request.method in ('POST','PUT','PATCH','DELETE') and request.headers.get('X-CSRF-Token','')!=sess['csrf_token']:
   CURRENT_USER.reset(tok1);CURRENT_IP.reset(tok2);return JSONResponse({'detail':'CSRF validation failed'},status_code=403)
 else:tok1=tok2=None
 try:resp=await call_next(request)
 finally:
  if sess:CURRENT_USER.reset(tok1);CURRENT_IP.reset(tok2)
 resp.headers['X-Content-Type-Options']='nosniff';resp.headers['X-Frame-Options']='DENY';resp.headers['Referrer-Policy']='no-referrer';resp.headers['Permissions-Policy']='camera=(), microphone=(), geolocation=()';resp.headers['Cache-Control']='no-store'
 resp.headers['Content-Security-Policy']="default-src 'self' https://unpkg.com; script-src 'self' 'unsafe-inline' https://unpkg.com; style-src 'self' 'unsafe-inline' https://unpkg.com; img-src 'self' data: https:; connect-src 'self' https:; frame-src https://cybermap.kaspersky.com https://www.youtube-nocookie.com"
 return resp

@app.get('/login',response_class=HTMLResponse)
def login_page():return (STATIC/'login.html').read_text(encoding='utf-8')
@app.get('/api/auth/status')
def auth_status(request:Request):
 sess=_session_from_request(request)
 return {'needs_setup':_auth_required_count()==0,'authenticated':bool(sess),'user':sess['username'] if sess else '','csrf_token':sess['csrf_token'] if sess else ''}
@app.post('/api/auth/setup')
def auth_setup(x:AuthSetup,response:Response):
 if _auth_required_count()!=0:raise HTTPException(409,'Administrator account is already configured.')
 username=re.sub(r'[^A-Za-z0-9_.-]','',x.username.strip())[:64] or 'admin'
 if len(x.password)<12:raise HTTPException(400,'Password must be at least 12 characters.')
 with conn() as c:c.execute('insert into users(username,password_hash,role) values(?,?,?)',(username,PH.hash(x.password),'admin'))
 CURRENT_USER.set(username);audit('auth.admin.setup',username)
 token=secrets.token_urlsafe(32);csrf=secrets.token_urlsafe(24);exp=int(time.time())+SESSION_HOURS*3600
 with conn() as c:c.execute('insert into sessions(token_hash,username,csrf_token,expires_at) values(?,?,?,?)',(_token_hash(token),username,csrf,exp))
 response.set_cookie('hms_session',token,httponly=True,samesite='strict',secure=False,max_age=SESSION_HOURS*3600,path='/')
 return {'ok':True,'user':username,'csrf_token':csrf}
@app.post('/api/auth/login')
def auth_login(x:AuthLogin,response:Response,request:Request):
 ip=request.client.host if request.client else 'local';now=int(time.time());user=x.username.strip()
 with conn() as c:
  c.execute('delete from auth_failures where attempted_at<?',(now-86400,));fails=c.execute('select count(*) from auth_failures where source_ip=? and attempted_at>?',(ip,now-900)).fetchone()[0]
  u=c.execute('select * from users where username=? and enabled=1',(user,)).fetchone()
 if fails>=5:
  CURRENT_IP.set(ip);audit('auth.login.blocked',f'{user}:rate-limit');raise HTTPException(429,'Too many failed login attempts. Try again later.')
 try:
  if not u:raise VerifyMismatchError
  PH.verify(u['password_hash'],x.password)
 except VerifyMismatchError:
  with conn() as c:c.execute('insert into auth_failures(username,source_ip,attempted_at) values(?,?,?)',(user,ip,now))
  CURRENT_IP.set(ip);audit('auth.login.failed',user);raise HTTPException(401,'Invalid username or password.')
 with conn() as c:c.execute('delete from auth_failures where source_ip=?',(ip,))
 with conn() as c:
  c.execute('delete from sessions where expires_at<?',(int(time.time()),));c.execute('update users set last_login=CURRENT_TIMESTAMP where username=?',(u['username'],))
 token=secrets.token_urlsafe(32);csrf=secrets.token_urlsafe(24);exp=int(time.time())+SESSION_HOURS*3600
 with conn() as c:c.execute('insert into sessions(token_hash,username,csrf_token,expires_at) values(?,?,?,?)',(_token_hash(token),u['username'],csrf,exp))
 CURRENT_USER.set(u['username']);audit('auth.login',u['username'])
 response.set_cookie('hms_session',token,httponly=True,samesite='strict',secure=False,max_age=SESSION_HOURS*3600,path='/')
 return {'ok':True,'user':u['username'],'csrf_token':csrf}
@app.post('/api/auth/logout')
def auth_logout(request:Request,response:Response):
 token=request.cookies.get('hms_session','')
 if token:
  with conn() as c:c.execute('delete from sessions where token_hash=?',(_token_hash(token),))
 audit('auth.logout',getattr(request.state,'user',''))
 response.delete_cookie('hms_session',path='/');return {'ok':True}
@app.get('/api/auth/me')
def auth_me(request:Request):return {'user':request.state.user,'role':request.state.role,'csrf_token':request.state.csrf}


def _require_admin(request:Request):
 if getattr(request.state,'role','')!='admin': raise HTTPException(403,'Administrator role required.')

@app.get('/api/users')
def users_list(request:Request):
 _require_admin(request)
 with conn() as c:
  rows=[dict(r) for r in c.execute("select u.id,u.username,u.role,u.enabled,u.created_at,u.last_login,coalesce(sc.cred_type,'') scan_credential_type,coalesce(sc.target_username,'') scan_username,coalesce(sc.domain,'') scan_domain,case when sc.secret_enc!='' or sc.key_enc!='' then 1 else 0 end scan_credential_configured from users u left join scan_credentials sc on sc.username=u.username order by u.username").fetchall()]
 return rows

@app.post('/api/users')
def users_create(x:UserCreate,request:Request):
 _require_admin(request);username=re.sub(r'[^A-Za-z0-9_.-]','',x.username.strip())[:64]
 if not username:raise HTTPException(400,'Username is required.')
 if len(x.password)<12:raise HTTPException(400,'Password must be at least 12 characters.')
 role=x.role.lower().strip()
 if role not in ('admin','analyst','viewer'):raise HTTPException(400,'Role must be admin, analyst, or viewer.')
 try:
  with conn() as c:c.execute('insert into users(username,password_hash,role,enabled) values(?,?,?,?)',(username,PH.hash(x.password),role,1 if x.enabled else 0))
 except sqlite3.IntegrityError:raise HTTPException(409,'Username already exists.')
 audit('auth.user.create',f'{username}:{role}');return {'ok':True,'username':username}

@app.patch('/api/users/{username}')
def users_update(username:str,x:UserUpdate,request:Request):
 _require_admin(request)
 with conn() as c:
  row=c.execute('select * from users where username=?',(username,)).fetchone()
  if not row:raise HTTPException(404,'User not found.')
  role=(x.role or row['role']).lower()
  if role not in ('admin','analyst','viewer'):raise HTTPException(400,'Invalid role.')
  enabled=row['enabled'] if x.enabled is None else (1 if x.enabled else 0)
  if username==request.state.user and not enabled:raise HTTPException(400,'You cannot disable your own active account.')
  if row['role']=='admin' and (role!='admin' or not enabled):
   admins=c.execute("select count(*) from users where role='admin' and enabled=1").fetchone()[0]
   if admins<=1:raise HTTPException(400,'At least one enabled administrator is required.')
  if x.password:
   if len(x.password)<12:raise HTTPException(400,'Password must be at least 12 characters.')
   c.execute('update users set role=?,enabled=?,password_hash=? where username=?',(role,enabled,PH.hash(x.password),username));c.execute('delete from sessions where username=?',(username,))
  else:c.execute('update users set role=?,enabled=? where username=?',(role,enabled,username))
 audit('auth.user.update',f'{username}:{role}:enabled={enabled}');return {'ok':True}

@app.delete('/api/users/{username}')
def users_delete(username:str,request:Request):
 _require_admin(request)
 if username==request.state.user:raise HTTPException(400,'You cannot delete the account currently signed in.')
 with conn() as c:
  row=c.execute('select role,enabled from users where username=?',(username,)).fetchone()
  if not row:raise HTTPException(404,'User not found.')
  if row['role']=='admin' and row['enabled']:
   admins=c.execute("select count(*) from users where role='admin' and enabled=1").fetchone()[0]
   if admins<=1:raise HTTPException(400,'At least one enabled administrator is required.')
  c.execute('delete from sessions where username=?',(username,));c.execute('delete from scan_credentials where username=?',(username,));c.execute('delete from user_certifications where username=?',(username,));c.execute('delete from users where username=?',(username,))
 audit('auth.user.delete',username);return {'ok':True}

@app.get('/api/users/{username}/certifications')
def user_certifications_list(username:str,request:Request):
 _require_admin(request)
 with conn() as c:
  if not c.execute('select 1 from users where username=?',(username,)).fetchone():raise HTTPException(404,'User not found.')
  return [dict(r) for r in c.execute('select * from user_certifications where username=? order by certification,issued_date desc,id desc',(username,)).fetchall()]

@app.post('/api/users/{username}/certifications')
def user_certifications_create(username:str,x:UserCertification,request:Request):
 _require_admin(request); cert=x.certification.strip()[:200]
 if not cert:raise HTTPException(400,'Certification is required.')
 url=x.verification_url.strip()[:1000]
 if url and not re.match(r'^https?://',url,re.I):raise HTTPException(400,'Verification URL must use http:// or https://.')
 with conn() as c:
  if not c.execute('select 1 from users where username=?',(username,)).fetchone():raise HTTPException(404,'User not found.')
  cur=c.execute('insert into user_certifications(username,certification,credential_id,issued_date,expires_date,verification_url,notes) values(?,?,?,?,?,?,?)',(username,cert,x.credential_id.strip()[:200],x.issued_date.strip()[:20],x.expires_date.strip()[:20],url,x.notes.strip()[:4000]))
 audit('auth.user.certification.create',f'{username}:{cert}');return {'ok':True,'id':cur.lastrowid}

@app.patch('/api/users/{username}/certifications/{cert_id}')
def user_certifications_update(username:str,cert_id:int,x:UserCertification,request:Request):
 _require_admin(request); cert=x.certification.strip()[:200]
 if not cert:raise HTTPException(400,'Certification is required.')
 url=x.verification_url.strip()[:1000]
 if url and not re.match(r'^https?://',url,re.I):raise HTTPException(400,'Verification URL must use http:// or https://.')
 with conn() as c:
  if not c.execute('select 1 from user_certifications where id=? and username=?',(cert_id,username)).fetchone():raise HTTPException(404,'Certification record not found.')
  c.execute('update user_certifications set certification=?,credential_id=?,issued_date=?,expires_date=?,verification_url=?,notes=?,updated_at=CURRENT_TIMESTAMP where id=? and username=?',(cert,x.credential_id.strip()[:200],x.issued_date.strip()[:20],x.expires_date.strip()[:20],url,x.notes.strip()[:4000],cert_id,username))
 audit('auth.user.certification.update',f'{username}:{cert_id}:{cert}');return {'ok':True}

@app.delete('/api/users/{username}/certifications/{cert_id}')
def user_certifications_delete(username:str,cert_id:int,request:Request):
 _require_admin(request)
 with conn() as c:
  cur=c.execute('delete from user_certifications where id=? and username=?',(cert_id,username))
  if not cur.rowcount:raise HTTPException(404,'Certification record not found.')
 audit('auth.user.certification.delete',f'{username}:{cert_id}');return {'ok':True}

@app.patch('/api/users/{username}/scan-credentials')
def user_scan_credentials(username:str,x:ScanCredentialUpdate,request:Request):
 _require_admin(request)
 with conn() as c:
  u=c.execute('select username from users where username=?',(username,)).fetchone()
  if not u:raise HTTPException(404,'User not found.')
  if x.clear:
   c.execute('delete from scan_credentials where username=?',(username,));audit('scan.credentials.clear',username);return {'ok':True,'configured':False}
  ctype=x.cred_type.strip().lower()
  if ctype not in ('ssh','winrm'):raise HTTPException(400,'Credential type must be SSH or WinRM.')
  target_user=x.target_username.strip()[:200]
  if not target_user:raise HTTPException(400,'Target username is required.')
  old=c.execute('select * from scan_credentials where username=?',(username,)).fetchone()
  secret_enc=enc(x.secret) if x.secret else (old['secret_enc'] if old else '')
  key_enc=enc(x.private_key) if x.private_key else (old['key_enc'] if old else '')
  if not secret_enc and not key_enc:raise HTTPException(400,'Provide a password or private key.')
  c.execute('insert into scan_credentials(username,cred_type,target_username,secret_enc,domain,key_enc,updated_at) values(?,?,?,?,?,?,CURRENT_TIMESTAMP) on conflict(username) do update set cred_type=excluded.cred_type,target_username=excluded.target_username,secret_enc=excluded.secret_enc,domain=excluded.domain,key_enc=excluded.key_enc,updated_at=CURRENT_TIMESTAMP',(username,ctype,target_user,secret_enc,x.domain.strip()[:200],key_enc))
 audit('scan.credentials.update',f'{username}:{ctype}:{target_user}')
 return {'ok':True,'configured':True,'cred_type':ctype,'target_username':target_user,'domain':x.domain.strip()[:200]}

def _get_scan_credential(username:str)->dict:
 if not username:return {}
 with conn() as c:r=c.execute('select * from scan_credentials where username=?',(username,)).fetchone()
 if not r:return {}
 d=dict(r);d['secret']=dec(d.pop('secret_enc',''));d['private_key']=dec(d.pop('key_enc',''));return d

@app.get('/',response_class=HTMLResponse)
def home():return (STATIC/'index.html').read_text(encoding='utf-8')
@app.get('/api/health')
def health():return {'status':'ok','product':'HIVE SECURITY','version':VERSION,'data_dir':str(DATA)}
@app.get('/api/system')
def system():return {'version':VERSION,'data_dir':str(DATA),'database':str(DB),'backups':str(BACKUPS),'python':os.sys.version.split()[0]}

@app.get('/api/dashboard')
def dashboard():
 with conn() as c:
  q=lambda s:c.execute(s).fetchone()[0]
  total=q("select count(*) from integrations where enabled=1")+len(NO_KEY); healthy=q("select count(*) from integrations where enabled=1 and status='healthy'")
  study=q('select count(*) from study')
  return {'open_tasks':q("select count(*) from tasks where status!='done'"),'open_risks':q("select count(*) from risks where status='open'"),'active_incidents':q("select count(*) from incidents where status!='closed'"),'assets':q("select count(*) from assets where status='active'"),'open_vulns':q("select count(*) from vulnerabilities where status!='closed'"),'investigations':q("select count(*) from investigations where status!='closed'"),'integrations':total,'healthy_integrations':healthy,'academy_attempts':study,'tracked_findings':q("select count(*) from tracked_findings where lower(status) not in ('fixed','remediated','closed')")}

@app.get('/api/news')
async def news(limit:int=45):
 items=[]; sources=[]
 async with httpx.AsyncClient(timeout=12,follow_redirects=True,headers={'User-Agent':f'HiveMindSecurity/{VERSION}'}) as client:
  for source,url,category,home in NEWS_FEEDS:
   status={'name':source,'category':category,'home':home,'feed':url,'ok':False,'count':0,'error':''}
   try:
    r=await client.get(url);r.raise_for_status();root=ET.fromstring(r.content); found=[]
    for e in root.findall('.//item')[:10]:
     title=(e.findtext('title') or 'Untitled').strip(); link=(e.findtext('link') or '').strip(); published=(e.findtext('pubDate') or e.findtext('date') or '').strip()
     if link.startswith('https://') or link.startswith('http://'):found.append({'source':source,'category':category,'title':title,'link':link,'published':published})
    # Atom fallback
    if not found:
     ns={'a':'http://www.w3.org/2005/Atom'}
     for e in root.findall('.//a:entry',ns)[:10]:
      title=(e.findtext('a:title',default='Untitled',namespaces=ns) or 'Untitled').strip(); le=e.find('a:link',ns); link=(le.get('href') if le is not None else '') or ''; published=(e.findtext('a:updated',default='',namespaces=ns) or '').strip()
      if link.startswith('https://') or link.startswith('http://'):found.append({'source':source,'category':category,'title':title,'link':link,'published':published})
    items.extend(found); status['ok']=True; status['count']=len(found)
   except Exception as e:status['error']=str(e)[:180]
   sources.append(status)
 return {'generated_at':datetime.now(timezone.utc).isoformat(),'items':items[:max(1,min(limit,90))],'sources':sources}

@app.get('/api/kev')
async def kev(limit:int=30):
 try:
  async with httpx.AsyncClient(timeout=15,follow_redirects=True) as c:r=await c.get('https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json');r.raise_for_status();d=r.json()
  return sorted(d.get('vulnerabilities',[]),key=lambda x:x.get('dateAdded',''),reverse=True)[:limit]
 except Exception as e:return {'error':str(e),'vulnerabilities':[]}

async def geo_ip(client,ip):
 try:
  r=await client.get(f'https://ipwho.is/{ip}'); d=r.json();
  if d.get('success') is False:return None
  return {'lat':d.get('latitude'),'lon':d.get('longitude'),'country':d.get('country_code'),'city':d.get('city'),'asn':(d.get('connection') or {}).get('asn'),'org':(d.get('connection') or {}).get('org')}
 except Exception:return None

def extract_dshield(d):
 if isinstance(d,list):return d
 if isinstance(d,dict):
  for k in ('sources','data','source'):
   v=d.get(k)
   if isinstance(v,list):return v
   if isinstance(v,dict):
    for vv in v.values():
     if isinstance(vv,list):return vv
 return []

@app.get('/api/threat-map')
async def threat_map(refresh:bool=False):
 now=time.time()
 if THREAT_CACHE['data'] and not refresh and now-THREAT_CACHE['ts']<300:return THREAT_CACHE['data']
 events=[]; errors=[]
 async with httpx.AsyncClient(timeout=18,follow_redirects=True,headers={'User-Agent':f'HiveMindSecurity/{VERSION}'}) as c:
  try:
   r=await c.get('https://feodotracker.abuse.ch/downloads/ipblocklist_recommended.json');r.raise_for_status()
   for x in r.json()[:120]:
    cc=x.get('country'); pos=COUNTRY_CENTROIDS.get(cc)
    if pos:events.append({'source':'Feodo Tracker','kind':'Botnet C2','ip':x.get('ip_address'),'port':x.get('port'),'malware':x.get('malware'),'country':cc,'lat':pos[0],'lon':pos[1],'first_seen':x.get('first_seen'),'last_seen':x.get('last_online'),'confidence':'high','note':'Active/recent botnet command-and-control infrastructure.'})
  except Exception as e:errors.append('Feodo: '+str(e)[:120])
  try:
   r=await c.get('https://isc.sans.edu/api/sources/attacks/25?json');r.raise_for_status(); src=extract_dshield(r.json())[:18]
   geos=await asyncio.gather(*[geo_ip(c,str(x.get('ip') or x.get('source') or '').strip()) for x in src])
   for x,g in zip(src,geos):
    ip=str(x.get('ip') or x.get('source') or '').strip()
    if g and g.get('lat') is not None:events.append({'source':'SANS ISC / DShield','kind':'Reported source activity','ip':ip,'country':g.get('country'),'city':g.get('city'),'lat':g.get('lat'),'lon':g.get('lon'),'reports':x.get('count') or x.get('reports'),'targets':x.get('attacks') or x.get('targets'),'first_seen':x.get('firstseen'),'last_seen':x.get('lastseen'),'confidence':'community','note':'Community-reported source activity; this feed is not a blocklist.'})
  except Exception as e:errors.append('DShield: '+str(e)[:120])
 data={'generated_at':datetime.now(timezone.utc).isoformat(),'events':events,'sources':['abuse.ch Feodo Tracker','SANS ISC / DShield'],'errors':errors,'meaning':'Markers represent real malicious infrastructure or reported source activity from the named feed. Hive Mind does not invent attack paths. Source-to-destination arcs are only shown when an attached organizational telemetry source supplies both endpoints.'}
 THREAT_CACHE.update(ts=now,data=data); return data

# CRUD helpers
@app.get('/api/tasks')
def tasks():
 with conn() as c:return [dict(x) for x in c.execute('select * from tasks order by id desc').fetchall()]
@app.post('/api/tasks')
def add_task(x:Task):
 with conn() as c:c.execute('insert into tasks(title,owner,team,status,priority) values(?,?,?,?,?)',(x.title,x.owner,x.team,x.status,x.priority))
 audit('task.create',x.title);return {'ok':True}
@app.put('/api/tasks/{record_id}')
def task_update(record_id:int,x:Task):
 with conn() as c:
  if not c.execute('select 1 from tasks where id=?',(record_id,)).fetchone():raise HTTPException(404,'Task not found')
  c.execute('update tasks set title=?,owner=?,team=?,status=?,priority=? where id=?',(x.title,x.owner,x.team,x.status,x.priority,record_id))
 audit('task.update',f'{record_id}:{x.title}');return {'ok':True}
@app.delete('/api/tasks/{record_id}')
def task_delete(record_id:int):
 with conn() as c:
  r=c.execute('select title from tasks where id=?',(record_id,)).fetchone()
  if not r:raise HTTPException(404,'Task not found')
  c.execute('delete from tasks where id=?',(record_id,))
 audit('task.delete',f'{record_id}:{r["title"]}');return {'ok':True}
@app.get('/api/risks')
def risks():
 with conn() as c:a=[dict(x) for x in c.execute('select * from risks order by id desc').fetchall()]
 for r in a:r['score']=r['likelihood']*r['impact']
 return a
@app.post('/api/risks')
def add_risk(x:Risk):
 with conn() as c:c.execute('insert into risks(title,likelihood,impact,owner,treatment,status) values(?,?,?,?,?,?)',(x.title,x.likelihood,x.impact,x.owner,x.treatment,x.status))
 audit('risk.create',x.title);return {'ok':True}
@app.get('/api/incidents')
def incidents():
 with conn() as c:return [dict(x) for x in c.execute('select * from incidents order by id desc').fetchall()]
@app.post('/api/incidents')
def add_incident(x:Incident):
 phases=['Detect & Validate','Scope & Preserve','Contain','Eradicate','Recover','Lessons Learned']
 with conn() as c:
  c.execute('insert into incidents(title,severity,status,commander,summary) values(?,?,?,?,?)',(x.title,x.severity,x.status,x.commander,x.summary));iid=c.execute('select last_insert_rowid()').fetchone()[0]
  for i,p in enumerate(phases):c.execute('insert or ignore into incident_lifecycle(incident_id,phase,status) values(?,?,?)',(iid,p,'active' if i==0 else 'pending'))
 audit('incident.declare',f'{iid}:{x.title}');return {'ok':True,'id':iid}
@app.get('/api/incidents/{incident_id}/lifecycle')
def incident_lifecycle(incident_id:int):
 with conn() as c:
  if not c.execute('select 1 from incidents where id=?',(incident_id,)).fetchone():raise HTTPException(404,'Incident not found')
  return [dict(x) for x in c.execute('select * from incident_lifecycle where incident_id=? order by id',(incident_id,)).fetchall()]
@app.put('/api/incidents/{incident_id}/lifecycle')
def incident_lifecycle_update(incident_id:int,x:IncidentPhase):
 allowed=['Detect & Validate','Scope & Preserve','Contain','Eradicate','Recover','Lessons Learned'];statuses=['pending','active','complete','blocked']
 if x.phase not in allowed or x.status not in statuses:raise HTTPException(400,'Invalid lifecycle phase or status')
 with conn() as c:
  if not c.execute('select 1 from incidents where id=?',(incident_id,)).fetchone():raise HTTPException(404,'Incident not found')
  c.execute('insert into incident_lifecycle(incident_id,phase,status,notes,owner,updated_at) values(?,?,?,?,?,CURRENT_TIMESTAMP) on conflict(incident_id,phase) do update set status=excluded.status,notes=excluded.notes,owner=excluded.owner,updated_at=CURRENT_TIMESTAMP',(incident_id,x.phase,x.status,x.notes,x.owner))
 audit('incident.lifecycle.update',f'{incident_id}:{x.phase}:{x.status}');return {'ok':True}
@app.delete('/api/incidents/{incident_id}')
def incident_delete(incident_id:int):
 with conn() as c:
  r=c.execute('select title from incidents where id=?',(incident_id,)).fetchone()
  if not r:raise HTTPException(404,'Incident not found')
  c.execute('delete from incident_lifecycle where incident_id=?',(incident_id,));c.execute('delete from incidents where id=?',(incident_id,))
 audit('incident.delete',f'{incident_id}:{r["title"]}');return {'ok':True}
@app.get('/api/assets')
def assets():
 with conn() as c:return [dict(x) for x in c.execute('select * from assets order by id desc').fetchall()]
@app.post('/api/assets')
def add_asset(x:Asset):
 with conn() as c:c.execute('insert into assets(name,kind,criticality,owner,location,status) values(?,?,?,?,?,?)',(x.name,x.kind,x.criticality,x.owner,x.location,x.status))
 audit('asset.create',x.name);return {'ok':True}
@app.get('/api/vulnerabilities')
def vulns():
 with conn() as c:return [dict(x) for x in c.execute('select * from vulnerabilities order by id desc').fetchall()]
@app.post('/api/vulnerabilities')
def add_vuln(x:Vulnerability):
 with conn() as c:c.execute('insert into vulnerabilities(cve,title,severity,asset,owner,status,due_date,source) values(?,?,?,?,?,?,?,?)',(x.cve,x.title,x.severity,x.asset,x.owner,x.status,x.due_date,x.source))
 audit('vulnerability.create',x.cve or x.title);return {'ok':True}
@app.put('/api/vulnerabilities/{finding_id}')
def update_vulnerability(finding_id:int,x:VulnerabilityUpdate):
 if x.status not in ('open','in_progress','risk_accepted','remediated','closed'):raise HTTPException(400,'Invalid vulnerability status')
 with conn() as c:
  r=c.execute('select * from vulnerabilities where id=?',(finding_id,)).fetchone()
  if not r:raise HTTPException(404,'Vulnerability finding not found')
  c.execute('update vulnerabilities set status=?,owner=?,due_date=? where id=?',(x.status,x.owner[:200],x.due_date[:32],finding_id))
 audit('vulnerability.update',f'{finding_id}:{x.status}:{x.owner}');return {'ok':True}
@app.delete('/api/vulnerabilities/{finding_id}')
def delete_vulnerability(finding_id:int):
 with conn() as c:
  r=c.execute('select * from vulnerabilities where id=?',(finding_id,)).fetchone()
  if not r:raise HTTPException(404,'Tracked finding not found')
  c.execute('delete from vulnerabilities where id=?',(finding_id,))
 audit('vulnerability.delete',f'{finding_id}:{r["cve"] or r["title"]}');return {'ok':True}


@app.get('/api/killchain')
def killchain():
 # Return the static safe workflow plus live ATT&CK-backed work from STIG, pentest,
 # imported reports and team sources. This keeps Kill Chain operational rather than decorative.
 _cleanup_orphan_attack_mappings() if '_cleanup_orphan_attack_mappings' in globals() else None
 data=json.loads(json.dumps(KILL_CHAIN))
 tactic_phase={
  'Reconnaissance':'recon','Resource Development':'weaponization','Initial Access':'delivery',
  'Execution':'exploitation','Persistence':'installation','Privilege Escalation':'installation',
  'Defense Evasion':'installation','Command and Control':'c2','Credential Access':'actions',
  'Discovery':'actions','Lateral Movement':'actions','Collection':'actions','Exfiltration':'actions','Impact':'actions'
 }
 live=[]
 try:
  live=_rows("select * from attack_mappings where status!='dismissed' order by id desc limit 500")
 except Exception:
  live=[]
 for phase in data.get('phases',[]):
  phase['correlations']=[]
 for m in live:
  tactics=[x.strip() for x in str(m.get('tactic','') or '').split('/') if x.strip()]
  phase_ids={tactic_phase.get(t) for t in tactics}; phase_ids.discard(None)
  for phase in data.get('phases',[]):
   if phase.get('id') in phase_ids:
    phase['correlations'].append({k:m.get(k) for k in ('id','record_type','record_id','source','asset','technique_id','technique_name','tactic','relation','confidence','reason')})
 data['correlation_count']=sum(len(p.get('correlations',[])) for p in data.get('phases',[]))
 return data
@app.get('/api/team/{team}')
def team_guide(team:str):
 if team not in TEAM_GUIDES:raise HTTPException(404,'Unknown team')
 return TEAM_GUIDES[team]
@app.get('/api/engagements')
def engagements():
 with conn() as c:return [dict(x) for x in c.execute('select * from engagements order by id desc').fetchall()]
@app.post('/api/engagements')
def add_engagement(x:Engagement):
 with conn() as c:c.execute('insert into engagements(name,scope,owner,status,roe,stop_conditions) values(?,?,?,?,?,?)',(x.name,x.scope,x.owner,x.status,x.roe,x.stop_conditions))
 audit('red.engagement.create',x.name);return {'ok':True}
@app.get('/api/team-findings')
def team_findings(team:str=''):
 with conn() as c:
  if team:return [dict(x) for x in c.execute('select * from team_findings where team=? order by id desc',(team,)).fetchall()]
  return [dict(x) for x in c.execute('select * from team_findings order by id desc').fetchall()]
@app.post('/api/team-findings')
def add_team_finding(x:TeamFinding):
 with conn() as c:c.execute('insert into team_findings(team,title,severity,status,asset,attack_id,evidence,remediation) values(?,?,?,?,?,?,?,?)',(x.team,x.title,x.severity,x.status,x.asset,x.attack_id,x.evidence,x.remediation))
 audit(f'{x.team}.finding.create',x.title);return {'ok':True}
@app.get('/api/purple-tests')
def purple_tests():
 with conn() as c:return [dict(x) for x in c.execute('select * from purple_tests order by id desc').fetchall()]
@app.post('/api/purple-tests')
def add_purple(x:PurpleTest):
 with conn() as c:c.execute('insert into purple_tests(technique,hypothesis,expected_telemetry,observed,detection,gap,owner,status) values(?,?,?,?,?,?,?,?)',(x.technique,x.hypothesis,x.expected_telemetry,x.observed,x.detection,x.gap,x.owner,x.status))
 audit('purple.test.create',x.technique);return {'ok':True}
@app.get('/api/investigations')
def investigations():
 with conn() as c:return [dict(x) for x in c.execute('select * from investigations order by id desc').fetchall()]
@app.post('/api/investigations')
def add_investigation(x:Investigation):
 with conn() as c:c.execute('insert into investigations(title,status,severity,summary,iocs,timeline) values(?,?,?,?,?,?)',(x.title,x.status,x.severity,x.summary,x.iocs,x.timeline))
 audit('blue.investigation.create',x.title);return {'ok':True}


# User-entered operational records: full edit/delete support -----------------
def _must_row(c,table:str,rid:int,label:str):
 r=c.execute(f'select * from {table} where id=?',(rid,)).fetchone()
 if not r: raise HTTPException(404,f'{label} not found')
 return r

@app.put('/api/investigations/{record_id}')
def investigation_update(record_id:int,x:Investigation):
 with conn() as c:
  _must_row(c,'investigations',record_id,'Investigation')
  c.execute('update investigations set title=?,status=?,severity=?,summary=?,iocs=?,timeline=? where id=?',(x.title,x.status,x.severity,x.summary,x.iocs,x.timeline,record_id))
 audit('blue.investigation.update',f'{record_id}:{x.title}');return {'ok':True}
@app.delete('/api/investigations/{record_id}')
def investigation_delete(record_id:int):
 with conn() as c:
  r=_must_row(c,'investigations',record_id,'Investigation');c.execute('delete from investigations where id=?',(record_id,))
 audit('blue.investigation.delete',f'{record_id}:{r["title"]}');return {'ok':True}

@app.put('/api/incidents/{record_id}')
def incident_update(record_id:int,x:Incident):
 with conn() as c:
  _must_row(c,'incidents',record_id,'Incident');c.execute('update incidents set title=?,severity=?,status=?,commander=?,summary=? where id=?',(x.title,x.severity,x.status,x.commander,x.summary,record_id))
 audit('incident.update',f'{record_id}:{x.title}:{x.status}');return {'ok':True}

@app.put('/api/assets/{record_id}')
def asset_update(record_id:int,x:Asset):
 with conn() as c:_must_row(c,'assets',record_id,'Asset');c.execute('update assets set name=?,kind=?,criticality=?,owner=?,location=?,status=? where id=?',(x.name,x.kind,x.criticality,x.owner,x.location,x.status,record_id))
 audit('asset.update',f'{record_id}:{x.name}');return {'ok':True}
@app.delete('/api/assets/{record_id}')
def asset_delete(record_id:int):
 with conn() as c:r=_must_row(c,'assets',record_id,'Asset');c.execute('delete from assets where id=?',(record_id,))
 audit('asset.delete',f'{record_id}:{r["name"]}');return {'ok':True}

@app.put('/api/risks/{record_id}')
def risk_update(record_id:int,x:Risk):
 with conn() as c:_must_row(c,'risks',record_id,'Risk');c.execute('update risks set title=?,likelihood=?,impact=?,owner=?,treatment=?,status=? where id=?',(x.title,x.likelihood,x.impact,x.owner,x.treatment,x.status,record_id))
 audit('risk.update',f'{record_id}:{x.title}');return {'ok':True}
@app.delete('/api/risks/{record_id}')
def risk_delete(record_id:int):
 with conn() as c:r=_must_row(c,'risks',record_id,'Risk');c.execute('delete from risks where id=?',(record_id,))
 audit('risk.delete',f'{record_id}:{r["title"]}');return {'ok':True}

@app.put('/api/engagements/{record_id}')
def engagement_update(record_id:int,x:Engagement):
 with conn() as c:_must_row(c,'engagements',record_id,'Engagement');c.execute('update engagements set name=?,scope=?,owner=?,status=?,roe=?,stop_conditions=? where id=?',(x.name,x.scope,x.owner,x.status,x.roe,x.stop_conditions,record_id))
 audit('red.engagement.update',f'{record_id}:{x.name}');return {'ok':True}
@app.delete('/api/engagements/{record_id}')
def engagement_delete(record_id:int):
 with conn() as c:r=_must_row(c,'engagements',record_id,'Engagement');c.execute('delete from engagements where id=?',(record_id,))
 audit('red.engagement.delete',f'{record_id}:{r["name"]}');return {'ok':True}

@app.put('/api/team-findings/{record_id}')
def team_finding_update(record_id:int,x:TeamFinding):
 with conn() as c:_must_row(c,'team_findings',record_id,'Team finding');c.execute('update team_findings set team=?,title=?,severity=?,status=?,asset=?,attack_id=?,evidence=?,remediation=? where id=?',(x.team,x.title,x.severity,x.status,x.asset,x.attack_id,x.evidence,x.remediation,record_id))
 audit(f'{x.team}.finding.update',f'{record_id}:{x.title}');return {'ok':True}
@app.delete('/api/team-findings/{record_id}')
def team_finding_delete(record_id:int):
 with conn() as c:r=_must_row(c,'team_findings',record_id,'Team finding');c.execute('delete from team_findings where id=?',(record_id,))
 audit(f'{r["team"]}.finding.delete',f'{record_id}:{r["title"]}');return {'ok':True}

@app.put('/api/purple-tests/{record_id}')
def purple_update(record_id:int,x:PurpleTest):
 with conn() as c:_must_row(c,'purple_tests',record_id,'Purple validation');c.execute('update purple_tests set technique=?,hypothesis=?,expected_telemetry=?,observed=?,detection=?,gap=?,owner=?,status=? where id=?',(x.technique,x.hypothesis,x.expected_telemetry,x.observed,x.detection,x.gap,x.owner,x.status,record_id))
 audit('purple.test.update',f'{record_id}:{x.technique}');return {'ok':True}
@app.delete('/api/purple-tests/{record_id}')
def purple_delete(record_id:int):
 with conn() as c:r=_must_row(c,'purple_tests',record_id,'Purple validation');c.execute('delete from purple_tests where id=?',(record_id,))
 audit('purple.test.delete',f'{record_id}:{r["technique"]}');return {'ok':True}

@app.put('/api/playbook-runs/{record_id}')
def playbook_run_update(record_id:int,x:PlaybookRun):
 with conn() as c:_must_row(c,'playbook_runs',record_id,'Playbook run');c.execute('update playbook_runs set playbook_id=?,title=?,team=?,status=?,owner=?,notes=? where id=?',(x.playbook_id,x.title,x.team,x.status,x.owner,x.notes,record_id))
 audit('playbook.run.update',f'{record_id}:{x.title}:{x.status}');return {'ok':True}
@app.delete('/api/playbook-runs/{record_id}')
def playbook_run_delete(record_id:int):
 with conn() as c:r=_must_row(c,'playbook_runs',record_id,'Playbook run');c.execute('delete from playbook_runs where id=?',(record_id,))
 audit('playbook.run.delete',f'{record_id}:{r["title"]}');return {'ok':True}

@app.delete('/api/study-history/{record_id}')
def study_history_delete(record_id:int):
 with conn() as c:r=_must_row(c,'study',record_id,'Study attempt');c.execute('delete from study where id=?',(record_id,))
 audit('academy.history.delete',f'{record_id}:{r["cert"]}');return {'ok':True}

@app.delete('/api/framework-check')
def framework_check_delete(framework:str,control:str):
 with conn() as c:c.execute('delete from framework_checks where framework=? and control=?',(framework,control))
 audit('framework.check.reset',f'{framework}:{control}');return {'ok':True}

@app.delete('/api/integrations/{iid}')
def integration_reset(iid:str):
 with conn() as c:
  if not c.execute('select 1 from integrations where id=?',(iid,)).fetchone(): raise HTTPException(404,'Integration configuration not found')
  c.execute("update integrations set enabled=0,config_json='{}',status='not_configured',last_error='',updated_at=CURRENT_TIMESTAMP where id=?",(iid,))
 audit('integration.reset',iid);return {'ok':True}

# Third-party pentest reports and tracked findings ----------------------------
def _safe_name(name:str)->str:return re.sub(r'[^A-Za-z0-9._-]','_',Path(name or 'report').name)[:180]
def _cleanup_report_text(txt:str)->str:
 # Normalize tab-heavy/table-derived PDF text while preserving paragraph boundaries.
 txt=(txt or '').replace('\r\n','\n').replace('\r','\n').replace('\xa0',' ')
 txt=re.sub(r'[\t\f\v]+',' ',txt)
 txt=re.sub(r' {2,}',' ',txt)
 txt=re.sub(r' *\n *','\n',txt)
 txt=re.sub(r'\n{4,}','\n\n\n',txt)
 return txt.strip()

def _pdf_variant_score(txt:str)->int:
 if not txt:return -1
 labels=len(re.findall(r'(?im)^\s*(?:vulnerability|finding|id|plugin id|plugin name|synopsis|description|solution|risk factor|severity|evidence|recommendation|remediation)\s*[:#-]?',txt))
 words=len(re.findall(r'\b[A-Za-z]{3,}\b',txt))
 long_lines=sum(1 for x in txt.splitlines() if len(x.strip())>=60)
 return labels*40 + min(words,20000) + long_lines*3

def _extract_report_text(name:str,data:bytes)->tuple[str,str]:
 ext=Path(name).suffix.lower()
 if ext=='.pdf':
  reader=PdfReader(BytesIO(data));pages=[];used_layout=0
  for page in reader.pages:
   plain='';layout=''
   try:plain=page.extract_text() or ''
   except Exception:pass
   try:layout=page.extract_text(extraction_mode='layout') or ''
   except Exception:pass
   plain=_cleanup_report_text(plain);layout=_cleanup_report_text(layout)
   if _pdf_variant_score(layout)>_pdf_variant_score(plain)+20:
    pages.append(layout);used_layout+=1
   else:pages.append(plain or layout)
  mode='PDF text extraction (hybrid layout/plain)' if used_layout else 'PDF text extraction'
  return _cleanup_report_text('\n\n'.join(pages)),mode
 if ext=='.docx':
  d=Document(BytesIO(data));return _cleanup_report_text('\n'.join(p.text for p in d.paragraphs)),'DOCX text extraction'
 if ext in ('.txt','.md','.csv','.json','.xml','.html','.htm'):
  txt=data.decode('utf-8','replace')
  if ext in ('.html','.htm'):txt=re.sub(r'<[^>]+>',' ',txt)
  return _cleanup_report_text(txt),'Text extraction'
 raise ValueError('Supported pentest report formats: PDF, DOCX, TXT, MD, CSV, JSON, XML, HTML.')
def _defender_scan_bytes(name:str,data:bytes)->str:
 if os.name!='nt':return 'not_available'
 mpcmd=None
 candidates=[]
 for base in (os.environ.get('ProgramFiles',''),os.environ.get('ProgramData','')):
  if base:candidates+=list(Path(base).glob('Windows Defender/MpCmdRun.exe'))+list(Path(base).glob('Microsoft/Windows Defender/Platform/*/MpCmdRun.exe'))
 if candidates:mpcmd=str(sorted(candidates)[-1])
 if not mpcmd:return 'not_available'
 tmp=Path(tempfile.gettempdir())/('hms_'+secrets.token_hex(8)+'_'+_safe_name(name));tmp.write_bytes(data)
 try:
  r=subprocess.run([mpcmd,'-Scan','-ScanType','3','-File',str(tmp),'-DisableRemediation'],capture_output=True,text=True,timeout=120)
  if r.returncode==2:raise ValueError('Microsoft Defender reported a threat in the uploaded report. Upload rejected.')
  return 'clean' if r.returncode==0 else 'scan_unknown'
 finally:
  try:tmp.unlink()
  except Exception:pass
def _norm_severity(value:str)->str:
 v=(value or '').strip().lower()
 if v in ('critical','high','medium','low'):return v
 if v in ('moderate','med'):return 'medium'
 if v in ('informational','information','info'):return 'info'
 return 'medium'

def _first_group(pattern:str,text:str,flags=re.I|re.S)->str:
 m=re.search(pattern,text,flags)
 return (m.group(1).strip() if m else '')

def _section_slice(block:str,names:list[str],next_names:list[str])->str:
 if not block:return ''
 n='|'.join(re.escape(x) for x in names); nxt='|'.join(re.escape(x) for x in next_names)
 pat=rf'(?ims)^\s*(?:\d+(?:\.\d+)*\s+)?(?:{n})\s*[:\-]?\s*$\n?(.*?)(?=^\s*(?:\d+(?:\.\d+)*\s+)?(?:{nxt})\s*[:\-]?\s*$|\Z)' if nxt else rf'(?ims)^\s*(?:\d+(?:\.\d+)*\s+)?(?:{n})\s*[:\-]?\s*$\n?(.*?)(?=\Z)'
 m=re.search(pat,block)
 return re.sub(r'\n{3,}','\n\n',m.group(1)).strip()[:12000] if m else ''

def _finding_from_block(title:str,block:str)->dict:
 sev=''
 for pat in [r'(?i)CVSS(?:\s*v?3(?:\.1)?)?[^\n]{0,60}?\b(Critical|High|Medium|Moderate|Low|Informational|Info)\b',r'(?i)Severity\s*[:\-]?\s*(Critical|High|Medium|Moderate|Low|Informational|Info)',r'(?im)^\s*(Critical|High|Medium|Moderate|Low|Informational|Info)\s*$']:
  m=re.search(pat,block)
  if m:sev=_norm_severity(m.group(1));break
 score=_first_group(r'(?i)CVSS(?:\s*(?:v|version)?\s*3(?:\.1)?)?\s*(?:Score)?\s*[:\-/ ]\s*(10(?:\.0)?|[0-9](?:\.[0-9])?)',block)
 vector=_first_group(r'(CVSS:3\.[01]/[A-Z0-9:/.-]+)',block)
 cvss='; '.join(x for x in [score,vector] if x)
 cves=[]
 for x in re.findall(r'(?i)CVE-\d{4}-\d{4,7}',block):
  x=x.upper()
  if x not in cves:cves.append(x)
 cwes=[]
 for x in re.findall(r'(?i)CWE-\d+',block):
  x=x.upper()
  if x not in cwes:cwes.append(x)
 background=_section_slice(block,['Background','Description','Discussion','Overview','Finding Details','Finding Description'],['Details','Technical Details','Risk Analysis','Risk','Impact','Recommendation','Recommendations','Remediation','Affected Item(s)','Affected Items','Affected Asset(s)','Affected Assets'])
 details=_section_slice(block,['Details','Technical Details','Evidence','Observation','Result','Check Text'],['Risk Analysis','Risk','Impact','Recommendation','Recommendations','Remediation','Affected Item(s)','Affected Items','Affected Asset(s)','Affected Assets'])
 risk=_section_slice(block,['Risk Analysis','Risk','Impact'],['Recommendation','Recommendations','Remediation','Affected Item(s)','Affected Items','Affected Asset(s)','Affected Assets'])
 remediation=_section_slice(block,['Recommendation','Recommendations','Remediation','Remediation Guidance','Fix','Fix Text','Solution','Mitigation'],['Affected Item(s)','Affected Items','Affected Asset(s)','Affected Assets','References','Reference'])
 affected=_section_slice(block,['Affected Item(s)','Affected Items','Affected Asset(s)','Affected Assets','Affected Systems','Affected Hosts'],['References','Reference'])
 # Preserve the complete source narrative for the finding. Structured fields are
 # extracted in addition to this text, never instead of it. This prevents labels
 # such as "Vulnerability: ...", "ID: I10-20", Discussion/Description text,
 # and paragraphs that do not fit a CVE/CVSS template from disappearing.
 source_narrative=re.sub(r'\n{3,}','\n\n',block).strip()
 desc=source_narrative[:12000]
 urls=[]
 for x in re.findall(r'https?://[^\s<>\])}]+',affected or block):
  x=x.rstrip('.,;')
  if x not in urls:urls.append(x)
 hosts=[]
 for x in re.findall(r'(?<![\w.-])(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}(?![\w.-])',affected):
  if x not in hosts:hosts.append(x)
 asset=', '.join((urls+hosts)[:6])
 return {'title':re.sub(r'\s+',' ',title).strip()[:300],'severity':sev or 'medium','asset':asset[:500],'cve':', '.join(cves)[:500],'cwe':', '.join(cwes)[:250],'cvss':cvss[:250],'category':'third-party pentest','description':desc[:12000],'evidence':(details or affected or block[:3000])[:6000],'remediation':remediation[:8000]}

def _finding_id_from_block(block:str)->str:
 for pat in [r'(?im)^\s*ID\s*[:#-]\s*([A-Za-z0-9._/-]{2,40})\s*$',r'(?im)^\s*(?:Plugin\s+ID|PluginID)\s*[:#-]?\s*(\d{2,12})\s*$']:
  m=re.search(pat,block or '')
  if m:return m.group(1).strip()
 return ''

def _dedupe_block_lines(parts:list[str])->str:
 seen=set();out=[]
 for part in parts:
  for raw in (part or '').splitlines():
   line=raw.rstrip();key=re.sub(r'\s+',' ',line).strip().lower()
   if not key:
    if out and out[-1] != '':out.append('')
    continue
   if key in seen and (len(key)<90 or re.match(r'^(vulnerability|id|description|synopsis|solution|risk factor|plugin)',key)):
    continue
   seen.add(key);out.append(line)
 return re.sub(r'\n{3,}','\n\n','\n'.join(out)).strip()

def _id_context_blocks(lines:list[str])->dict[str,list[str]]:
 # Build contexts around each ID, bounded by the nearest explicit finding title.
 # This handles PDFs that repeat an ID in both a summary table and a detailed section
 # without accidentally borrowing text from the neighboring finding.
 by={};id_re=re.compile(r'^\s*ID\s*[:#-]\s*([A-Za-z0-9._/-]{2,40})\s*$',re.I)
 vuln_re=re.compile(r'^\s*(?:Vulnerability|Finding|Issue|Observation|Risk)\s*(?:#|ID|No\.?|Number)?\s*[:\-–]',re.I)
 hits=[(i,id_re.match(line).group(1).strip()) for i,line in enumerate(lines) if id_re.match(line)]
 vuln_positions=[i for i,line in enumerate(lines) if vuln_re.match(line)]
 for i,fid in hits:
  prev=[v for v in vuln_positions if v<=i]
  lo=prev[-1] if prev and i-prev[-1]<=12 else max(0,i-2)
  nxt=[v for v in vuln_positions if v>i]
  hi=nxt[0] if nxt else min(len(lines),i+220)
  block='\n'.join(lines[lo:hi]).strip()
  # Reject a context if its nearest title actually carries a different explicit ID.
  local_id=_finding_id_from_block(block)
  if local_id and local_id.lower()!=fid.lower():
   block='\n'.join(lines[max(0,i-1):hi]).strip()
  by.setdefault(fid.lower(),[]).append(block)
 return by

def _nessus_findings(text:str)->list[dict]:
 raw=_cleanup_report_text(text);lines=raw.splitlines();starts=[]
 pid_re=re.compile(r'^\s*Plugin\s+ID\s*[:#-]?\s*(\d{2,12})\s*$',re.I)
 pname_re=re.compile(r'^\s*Plugin\s+Name\s*[:#-]?\s*(.{3,240})\s*$',re.I)
 for i,line in enumerate(lines):
  m=pid_re.match(line)
  if m:starts.append((i,'plugin-id',m.group(1)))
 if not starts:
  for i,line in enumerate(lines):
   m=pname_re.match(line)
   if m:starts.append((i,'plugin-name',m.group(1)))
 out=[]
 for n,(i,kind,val) in enumerate(starts):
  j=starts[n+1][0] if n+1<len(starts) else min(len(lines),i+260)
  block='\n'.join(lines[i:j]).strip()
  title=_first_group(r'(?im)^\s*Plugin\s+Name\s*[:#-]?\s*(.+?)\s*$',block,flags=re.I|re.M)
  if not title:title=_first_group(r'(?im)^\s*(?:Name|Finding|Vulnerability)\s*[:#-]\s*(.+?)\s*$',block,flags=re.I|re.M)
  if not title:title=f'Nessus Plugin {val}' if kind=='plugin-id' else val
  f=_finding_from_block(title,block)
  risk=_first_group(r'(?im)^\s*Risk\s+Factor\s*[:#-]?\s*(Critical|High|Medium|Low|None|Informational|Info)\s*$',block,flags=re.I|re.M)
  if risk:f['severity']=_norm_severity(risk)
  synopsis=_section_slice(block,['Synopsis'],['Description','Solution','See Also','Plugin Information','Plugin Output','Risk Factor'])
  description=_section_slice(block,['Description'],['Solution','See Also','Plugin Information','Plugin Output','Risk Factor','References'])
  solution=_section_slice(block,['Solution'],['See Also','Plugin Information','Plugin Output','Risk Factor','References'])
  output=_section_slice(block,['Plugin Output','Output'],['See Also','Plugin Information','Risk Factor','References'])
  host=_first_group(r'(?im)^\s*Host\s*[:#-]?\s*(.+?)\s*$',block,flags=re.I|re.M)
  port=_first_group(r'(?im)^\s*Port\s*[:#-]?\s*(.+?)\s*$',block,flags=re.I|re.M)
  f['description']=_dedupe_block_lines([block,synopsis,description])[:12000]
  if output:f['evidence']=output[:6000]
  if solution:f['remediation']=solution[:8000]
  if host:f['asset']=(host+((':'+port) if port and port.isdigit() else '')).strip()[:500]
  f['category']='Nessus / third-party pentest';out.append(f)
 return out[:100]

def _structured_findings(text:str)->list[dict]:
 raw=_cleanup_report_text(text); lines=raw.split('\n'); starts=[]; id_context=_id_context_blocks(lines)
 # Numbered top-level finding headings such as "5.1 Vulnerabilities in Outdated Dependencies Detected".
 for i,line in enumerate(lines):
  m=re.match(r'^\s*(\d+)\.(\d+)\s+(.{4,220}?)\s*$',line)
  if not m:continue
  title=m.group(3).strip()
  if re.match(r'(?i)^(background|details|risk analysis|risk|impact|recommendation|recommendations|remediation|affected item|affected items|references?)\b',title):continue
  look='\n'.join(lines[i:min(len(lines),i+45)])
  signals=sum(bool(re.search(p,look,re.I|re.M)) for p in [r'CVSS',r'\bSeverity\b',r'^\s*\d+\.\d+\.\d+\s+(?:Background|Details|Risk Analysis|Recommendation|Affected)',r'\bCVE-\d{4}-\d+'])
  if signals>=2:starts.append((i,m.group(1),m.group(2),title))
 out=[]
 for idx,(i,a,b,title) in enumerate(starts):
  j=len(lines)
  for ni,na,nb,nt in starts[idx+1:]:
   if ni>i:j=ni;break
  block='\n'.join(lines[i:j]).strip()
  out.append(_finding_from_block(title,block))
 # Conventional/flat report headings. Support both "Vulnerability: Name" and
 # common Finding/Issue/Observation forms while keeping the heading and nearby ID
 # lines inside the source narrative.
 title_re=re.compile(r'^\s*(?:finding|vulnerability|issue|observation|risk)\s*(?:#|id|no\.?|number)?\s*[A-Za-z0-9._-]{0,20}\s*[:\-–]\s*(.{3,220})\s*$',re.I)
 explicit=[]
 for i,line in enumerate(lines):
  m=title_re.match(line)
  if m:explicit.append((i,m.group(1).strip()))
 for idx,(i,title) in enumerate(explicit):
  j=explicit[idx+1][0] if idx+1<len(explicit) else min(len(lines),i+220)
  # Stop at a strong numbered top-level finding heading if it arrives first.
  for k in range(i+1,j):
   nm=re.match(r'^\s*\d+\.\d+\s+(.{4,220}?)\s*$',lines[k])
   if nm and not re.match(r'(?i)^(background|details|discussion|description|risk analysis|risk|impact|recommendation|recommendations|remediation|affected item|affected items|references?)\b',nm.group(1).strip()):
    j=k;break
  block='\n'.join(lines[i:j]).strip()
  fid=_finding_id_from_block(block)
  if fid and fid.lower() in id_context:
   block=_dedupe_block_lines([block]+id_context[fid.lower()])
  out.append(_finding_from_block(title,block))
 out.extend(_nessus_findings(raw))
 # Deduplicate deterministic output. Prefer the candidate with the richer source narrative.
 dedup=[];by_key={}
 for x in out:
  key=re.sub(r'[^a-z0-9]+','',x.get('title','').lower())
  if not key:continue
  if key not in by_key:
   by_key[key]=x;dedup.append(x)
  else:
   cur=by_key[key]
   def richness(z):
    d=(z.get('description') or '')
    sections=len(re.findall(r'(?im)^\s*(?:description|discussion|details|evidence|recommendation|remediation|solution|synopsis|risk|impact)\s*[:\-]?\s*$',d))
    return len(d)+sections*250
   if richness(x)>richness(cur):
    idx=dedup.index(cur);dedup[idx]=x;by_key[key]=x
   else:
    # If both are truly the same finding, preserve any unique longer source text.
    fid_cur=_finding_id_from_block(cur.get('description',''));fid_x=_finding_id_from_block(x.get('description',''))
    if fid_cur and fid_x and fid_cur.lower()==fid_x.lower():
     cur['description']=_dedupe_block_lines([cur.get('description',''),x.get('description','')])[:12000]
  if len(dedup)>=100:break
 return dedup

def _heuristic_findings(text:str)->list[dict]:
 # Legacy broad fallback retained for unusual flat reports.
 lines=[re.sub(r'\s+',' ',x).strip() for x in text.replace('\r','\n').split('\n') if x.strip()];out=[]
 sev_re=re.compile(r'\b(critical|high|medium|moderate|low|informational|info)\b',re.I);title_re=re.compile(r'^(?:finding|vulnerability|issue|observation|risk)\s*(?:#|id|no\.?|:)?.{0,12}[:\-–]\s*(.+)$',re.I)
 for i,line in enumerate(lines):
  m=title_re.match(line)
  if not m:continue
  title=m.group(1).strip()[:240];window=' '.join(lines[i:min(i+20,len(lines))])[:7000];sm=sev_re.search(window);sev=_norm_severity(sm.group(1) if sm else 'medium')
  cm=re.findall(r'CVE-\d{4}-\d{4,7}',window,re.I);wm=re.findall(r'CWE-\d+',window,re.I)
  out.append({'title':title,'severity':sev,'description':window[:4000],'evidence':window[:2500],'remediation':'','cve':', '.join(dict.fromkeys(x.upper() for x in cm)),'cwe':', '.join(dict.fromkeys(x.upper() for x in wm)),'category':'third-party pentest'})
  if len(out)>=100:break
 return out

def _match_findings(a:dict,b:dict)->bool:
 ac={x.strip().upper() for x in (a.get('cve') or '').split(',') if x.strip()};bc={x.strip().upper() for x in (b.get('cve') or '').split(',') if x.strip()}
 if ac and bc and ac & bc:return True
 ta=set(re.findall(r'[a-z0-9]{3,}',(a.get('title') or '').lower()));tb=set(re.findall(r'[a-z0-9]{3,}',(b.get('title') or '').lower()))
 return bool(ta and tb and len(ta&tb)/max(1,min(len(ta),len(tb)))>=0.65)

def _merge_hybrid_findings(deterministic:list[dict],ai:list[dict])->list[dict]:
 merged=[dict(x) for x in deterministic]
 for ax in ai:
  if not isinstance(ax,dict) or not ax.get('title'):continue
  ax=dict(ax);ax['severity']=_norm_severity(ax.get('severity','medium'))
  hit=next((x for x in merged if _match_findings(x,ax)),None)
  if hit:
   # AI may enrich missing metadata, but deterministic report-grounded extraction wins when already populated.
   for k in ('asset','cve','cwe','cvss','category','evidence','remediation'):
    if not hit.get(k) and ax.get(k):hit[k]=ax[k]
   if ax.get('description') and len((hit.get('description') or '').strip())<220:
    hit['description']=_dedupe_block_lines([hit.get('description',''),ax.get('description','')])[:12000]
  else:merged.append(ax)
 seen=[]
 for x in merged:
  if not any(_match_findings(x,y) for y in seen):seen.append(x)
 return seen[:100]

async def _ollama_findings(text:str)->tuple[list[dict],str]:
 url='http://127.0.0.1:11434/api/chat';model='llama3.2:3b'
 prompt=("You are a local cybersecurity report extraction assistant. Extract only findings explicitly supported by the supplied third-party penetration-test report. Do not invent vulnerabilities. Treat numbered Technical Findings, CVSS severity labels, Background, Details, Risk Analysis, Recommendation, and Affected Items as strong structure. Return strict JSON with key findings containing objects with: title, severity (critical/high/medium/low/info), asset, cve, cwe, cvss, category, description, evidence, remediation. Keep evidence grounded in the report and remediation concise. Report text follows:\n\n"+text[:90000])
 try:
  async with httpx.AsyncClient(timeout=90) as c:
   r=await c.post(url,json={'model':model,'stream':False,'messages':[{'role':'user','content':prompt}],'format':'json'});r.raise_for_status();d=r.json();content=((d.get('message') or {}).get('content') or '{}');obj=json.loads(content);rows=obj.get('findings',[]) if isinstance(obj,dict) else []
  return [x for x in rows[:100] if isinstance(x,dict) and x.get('title')],f'{model} local'
 except Exception as e:return [],f'unavailable: {str(e)[:160]}'

async def _hybrid_findings(text:str)->tuple[list[dict],str]:
 structured=_structured_findings(text);fallback=_heuristic_findings(text) if not structured else []
 deterministic=structured or fallback
 ai,ai_state=await _ollama_findings(text)
 merged=_merge_hybrid_findings(deterministic,ai)
 mode=f'hybrid: structured={len(structured)}, fallback={len(fallback)}, ai={len(ai)}, merged={len(merged)}; {ai_state}'
 return merged,mode

def _finding_row(r)->dict:
 d=dict(r);d['description']=dec(d.pop('description_enc',''));d['evidence']=dec(d.pop('evidence_enc',''));d['remediation']=dec(d.pop('remediation_enc',''));return d
def _insert_tracked_finding(c,x:dict,report_id='',source='manual'):
 c.execute('insert into tracked_findings(report_id,source,title,severity,status,asset,cve,cwe,cvss,category,description_enc,evidence_enc,remediation_enc,owner,due_date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(report_id,source,x.get('title','Tracked finding')[:300],(x.get('severity') or 'medium').lower(),x.get('status','open'),x.get('asset',''),x.get('cve',''),x.get('cwe',''),str(x.get('cvss','')),x.get('category',''),enc(x.get('description','')),enc(x.get('evidence','')),enc(x.get('remediation','')),x.get('owner',''),x.get('due_date','')))
 return c.execute('select last_insert_rowid()').fetchone()[0]
def _pdf_for_finding(f:dict)->bytes:
 buf=BytesIO();doc=SimpleDocTemplate(buf,pagesize=letter,rightMargin=.65*inch,leftMargin=.65*inch,topMargin=.65*inch,bottomMargin=.65*inch,title='Hive Mind Security Remediation Report');styles=getSampleStyleSheet();styles.add(ParagraphStyle(name='SmallGray',parent=styles['BodyText'],fontSize=8,textColor=colors.grey,leading=10));story=[]
 story += [Paragraph('HIVE MIND SECURITY - REMEDIATION REPORT',styles['Title']),Paragraph(f"Finding #{f['id']} - {f['title']}",styles['Heading2']),Spacer(1,8)]
 meta=[['Severity',f.get('severity','')],['Status',f.get('status','')],['Asset',f.get('asset','')],['CVE',f.get('cve','')],['CWE',f.get('cwe','')],['CVSS',f.get('cvss','')],['Owner',f.get('owner','')],['Fixed At',f.get('fixed_at','')],['Source',f.get('source','')]];tbl=Table(meta,colWidths=[1.25*inch,5.6*inch]);tbl.setStyle(TableStyle([('BACKGROUND',(0,0),(0,-1),colors.HexColor('#e6e6e6')),('GRID',(0,0),(-1,-1),.25,colors.grey),('VALIGN',(0,0),(-1,-1),'TOP'),('FONTNAME',(0,0),(0,-1),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),9)]));story+=[tbl,Spacer(1,12)]
 for h,k in [('Original Finding','description'),('Evidence','evidence'),('Remediation Performed / Recommendation','remediation')]:story += [Paragraph(h,styles['Heading3']),Paragraph((f.get(k) or 'Not documented.').replace('\n','<br/>'),styles['BodyText']),Spacer(1,9)]
 story += [Spacer(1,8),Paragraph('Generated by Hive Mind Security. This report records the application finding state and supporting evidence; independent validation may still be required.',styles['SmallGray'])];doc.build(story);return buf.getvalue()
def _create_remediation_pdf(finding_id:int)->str:
 with conn() as c:r=c.execute('select * from tracked_findings where id=?',(finding_id,)).fetchone()
 if not r:raise HTTPException(404,'Finding not found')
 f=_finding_row(r);pdf=_pdf_for_finding(f);rid=secrets.token_hex(12);raw_hash=hashlib.sha256(pdf).hexdigest();path=REMEDIATION_STORE/f'{rid}.pdf.hmsenc';path.write_bytes(enc_bytes(pdf));_harden_private_file(path)
 with conn() as c:c.execute('insert into remediation_reports(id,finding_id,encrypted_path,sha256,created_by) values(?,?,?,?,?)',(rid,finding_id,str(path),raw_hash,CURRENT_USER.get()))
 audit('finding.remediation_report.create',f'{finding_id}:{rid}');return rid
@app.get('/api/ai/status')
async def ai_status():
 try:
  async with httpx.AsyncClient(timeout=3) as c:r=await c.get('http://127.0.0.1:11434/api/tags');r.raise_for_status();names=[x.get('name','') for x in r.json().get('models',[])]
  return {'available':True,'endpoint':'loopback only','model':'llama3.2:3b','installed_models':names,'privacy':'Report content is sent only to the local loopback Ollama service.'}
 except Exception as e:return {'available':False,'endpoint':'loopback only','model':'llama3.2:3b','detail':str(e)[:180]}
@app.get('/api/pentest-reports')
def pentest_reports():
 with conn() as c:return [dict(x) for x in c.execute('select id,name,client,original_filename,sha256,parser,ai_status,finding_count,uploaded_by,created_at from pentest_reports order by created_at desc').fetchall()]
@app.post('/api/pentest-reports/import')
async def pentest_import(file:UploadFile=File(...),name:str='',client:str=''):
 data=await file.read()
 if not data:raise HTTPException(400,'The uploaded report is empty.')
 if len(data)>40*1024*1024:raise HTTPException(413,'Pentest report exceeds the 40 MB secure upload limit.')
 fname=_safe_name(file.filename or 'pentest-report')
 try:scan=_defender_scan_bytes(fname,data);text,parser=_extract_report_text(fname,data)
 except Exception as e:raise HTTPException(400,f'Report rejected or could not be parsed: {e}')
 if len(text.strip())<40:raise HTTPException(400,'Very little extractable text was found. A scanned-image report may require OCR before import.')
 rid=secrets.token_hex(12);path=REPORT_STORE/f'{rid}.report.hmsenc';path.write_bytes(enc_bytes(data));_harden_private_file(path);sha=hashlib.sha256(data).hexdigest();proposals,ai_state=await _hybrid_findings(text);source='hybrid-parser'
 with conn() as c:
  c.execute('insert into pentest_reports(id,name,client,original_filename,sha256,encrypted_path,extracted_text_enc,parser,ai_status,finding_count,uploaded_by) values(?,?,?,?,?,?,?,?,?,?,?)',(rid,(name or Path(fname).stem)[:240],client[:240],fname,sha,str(path),enc(text[:500000]),parser+'; Defender='+scan,ai_state,len(proposals),CURRENT_USER.get()))
  for x in proposals:_insert_tracked_finding(c,x,rid,source)
 _rebuild_attack_correlations()
 audit('pentest.report.import',f'{rid}:{fname}:{len(proposals)} findings:{source}');return {'ok':True,'report_id':rid,'findings_created':len(proposals),'parser':parser,'defender':scan,'ai':ai_state}
@app.post('/api/pentest-reports/{report_id}/ai-parse')
async def pentest_ai_parse(report_id:str):
 with conn() as c:r=c.execute('select * from pentest_reports where id=?',(report_id,)).fetchone()
 if not r:raise HTTPException(404,'Pentest report not found')
 text=dec(r['extracted_text_enc']);ai,state=await _hybrid_findings(text)
 if not ai:raise HTTPException(422,'No supported findings could be extracted from this report. Review the report text/format or OCR scanned pages.')
 with conn() as c:
  old_ids=[str(x[0]) for x in c.execute("select id from tracked_findings where report_id=? and source in ('local-ai','report-parser','hybrid-parser')",(report_id,)).fetchall()]
  if old_ids:
   q=','.join('?' for _ in old_ids);c.execute(f"delete from attack_mappings where record_type='tracked_finding' and record_id in ({q})",old_ids)
  c.execute("delete from tracked_findings where report_id=? and source in ('local-ai','report-parser','hybrid-parser')",(report_id,))
  for x in ai:_insert_tracked_finding(c,x,report_id,'hybrid-parser')
  c.execute('update pentest_reports set ai_status=?,finding_count=? where id=?',(state,len(ai),report_id))
 _rebuild_attack_correlations()
 audit('pentest.report.ai_parse',f'{report_id}:{len(ai)} findings');return {'ok':True,'findings_created':len(ai),'ai':state}
@app.delete('/api/pentest-reports/{report_id}')
def pentest_delete(report_id:str):
 with conn() as c:
  r=c.execute('select * from pentest_reports where id=?',(report_id,)).fetchone()
  if not r:raise HTTPException(404,'Pentest report not found')
  n=c.execute('select count(*) from tracked_findings where report_id=?',(report_id,)).fetchone()[0];ids=[x[0] for x in c.execute('select id from tracked_findings where report_id=?',(report_id,)).fetchall()]
  if ids:
   q=','.join('?' for _ in ids);c.execute(f"delete from attack_mappings where record_type='tracked_finding' and record_id in ({q})",[str(x) for x in ids])
  for fid in ids:
   for rr in c.execute('select encrypted_path from remediation_reports where finding_id=?',(fid,)).fetchall():
    try:Path(rr[0]).unlink(missing_ok=True)
    except Exception:pass
   c.execute('delete from remediation_reports where finding_id=?',(fid,))
  c.execute('delete from tracked_findings where report_id=?',(report_id,));c.execute('delete from pentest_reports where id=?',(report_id,))
 try:Path(r['encrypted_path']).unlink(missing_ok=True)
 except Exception:pass
 _cleanup_orphan_imported_findings(); _cleanup_orphan_attack_mappings()
 audit('pentest.report.delete',f'{report_id}:{r["original_filename"]}:{n} associated findings deleted');return {'ok':True,'deleted_findings':n}
def _cleanup_orphan_imported_findings():
 # Repair legacy rows left by older builds: parser-generated findings must have a live parent report.
 removed=[]
 with conn() as c:
  rows=c.execute("select id,report_id from tracked_findings where report_id<>'' and source in ('local-ai','report-parser','hybrid-parser')").fetchall()
  for r in rows:
   if not c.execute('select 1 from pentest_reports where id=?',(r['report_id'],)).fetchone(): removed.append(r['id'])
  if removed:
   q=','.join('?' for _ in removed)
   c.execute(f"delete from attack_mappings where record_type='tracked_finding' and record_id in ({q})",[str(x) for x in removed])
   c.execute(f"delete from remediation_reports where finding_id in ({q})",removed)
   c.execute(f"delete from tracked_findings where id in ({q})",removed)
 return len(removed)

@app.get('/api/tracked-findings')
def tracked_findings():
 _cleanup_orphan_imported_findings()
 with conn() as c:return [_finding_row(x) for x in c.execute('select * from tracked_findings order by case severity when "critical" then 1 when "high" then 2 when "medium" then 3 when "low" then 4 else 5 end,id desc').fetchall()]
@app.post('/api/tracked-findings')
def tracked_finding_create(x:TrackedFinding):
 with conn() as c:fid=_insert_tracked_finding(c,x.model_dump(),x.report_id,x.source)
 audit('finding.create',f'{fid}:{x.title}');return {'ok':True,'id':fid}
@app.put('/api/tracked-findings/{finding_id}')
def tracked_finding_update(finding_id:int,x:FindingUpdate):
 with conn() as c:r=c.execute('select * from tracked_findings where id=?',(finding_id,)).fetchone()
 if not r:raise HTTPException(404,'Finding not found')
 old=_finding_row(r);d=x.model_dump();new={k:(d[k] if d[k] != '' else old.get(k,'')) for k in d};status=(new.get('status') or old['status']).lower();fixed_at=old.get('fixed_at','')
 if status in ('fixed','remediated','closed') and old['status'].lower() not in ('fixed','remediated','closed'):fixed_at=datetime.now(timezone.utc).isoformat()
 with conn() as c:c.execute('update tracked_findings set title=?,severity=?,status=?,asset=?,cve=?,cwe=?,cvss=?,category=?,description_enc=?,evidence_enc=?,remediation_enc=?,owner=?,due_date=?,fixed_at=?,updated_at=CURRENT_TIMESTAMP where id=?',(new['title'],new['severity'].lower(),status,new['asset'],new['cve'],new['cwe'],new['cvss'],new['category'],enc(new['description']),enc(new['evidence']),enc(new['remediation']),new['owner'],new['due_date'],fixed_at,finding_id))
 audit('finding.update',f'{finding_id}:{old["status"]}->{status}:{new["title"]}');report_id=''
 if status in ('fixed','remediated','closed') and old['status'].lower() not in ('fixed','remediated','closed'):report_id=_create_remediation_pdf(finding_id)
 return {'ok':True,'remediation_report_id':report_id}
@app.delete('/api/tracked-findings/{finding_id}')
def tracked_finding_delete(finding_id:int):
 with conn() as c:
  r=c.execute('select * from tracked_findings where id=?',(finding_id,)).fetchone()
  if not r:raise HTTPException(404,'Finding not found')
  reports=c.execute('select encrypted_path from remediation_reports where finding_id=?',(finding_id,)).fetchall();c.execute('delete from remediation_reports where finding_id=?',(finding_id,));c.execute("delete from attack_mappings where record_type='tracked_finding' and record_id=?",(str(finding_id),));c.execute('delete from tracked_findings where id=?',(finding_id,))
 for rr in reports:
  try:Path(rr[0]).unlink(missing_ok=True)
  except Exception:pass
 audit('finding.delete',f'{finding_id}:{r["title"]}');return {'ok':True}
@app.get('/api/tracked-findings/{finding_id}/remediation-reports')
def finding_reports(finding_id:int):
 with conn() as c:return [dict(x) for x in c.execute('select id,finding_id,sha256,created_by,created_at from remediation_reports where finding_id=? order by created_at desc',(finding_id,)).fetchall()]
@app.get('/api/remediation-reports/{report_id}.pdf')
def remediation_pdf(report_id:str,download:int=0):
 with conn() as c:r=c.execute('select * from remediation_reports where id=?',(report_id,)).fetchone()
 if not r:raise HTTPException(404,'Remediation report not found')
 try:data=dec_bytes(Path(r['encrypted_path']).read_bytes())
 except Exception:raise HTTPException(500,'Remediation report could not be decrypted.')
 audit('finding.remediation_report.export',report_id);disp='attachment' if download else 'inline';return StreamingResponse(BytesIO(data),media_type='application/pdf',headers={'Content-Disposition':f'{disp}; filename="HiveMind-Remediation-{r["finding_id"]}.pdf"'})

@app.get('/api/frameworks')
def frameworks():
 with conn() as c: rows=[dict(x) for x in c.execute('select * from framework_checks').fetchall()]
 saved={(r['framework'],r['control']):r for r in rows}
 out={}
 for name,meta in FRAMEWORKS.items():
  controls=[]
  for control in meta['controls']:
   r=saved.get((name,control),{})
   controls.append({'control':control,'status':r.get('status','not_started'),'owner':r.get('owner',''),'evidence':r.get('evidence','')})
  out[name]={**meta,'controls':controls}
 return out
@app.post('/api/framework-check')
def framework_check(x:FrameworkCheck):
 if x.framework not in FRAMEWORKS or x.control not in FRAMEWORKS[x.framework]['controls']:raise HTTPException(400,'Unknown framework/control')
 with conn() as c:c.execute('insert into framework_checks(framework,control,status,owner,evidence,updated_at) values(?,?,?,?,?,CURRENT_TIMESTAMP) on conflict(framework,control) do update set status=excluded.status,owner=excluded.owner,evidence=excluded.evidence,updated_at=CURRENT_TIMESTAMP',(x.framework,x.control,x.status,x.owner,x.evidence))
 audit('framework.update',f'{x.framework}:{x.control}:{x.status}');return {'ok':True}

@app.get('/api/playbooks')
def playbooks(team:str=''):
 return [x for x in PLAYBOOKS if not team or x['team']==team]
@app.get('/api/playbook-runs')
def playbook_runs():
 with conn() as c:return [dict(x) for x in c.execute('select * from playbook_runs order by id desc limit 100').fetchall()]
@app.post('/api/playbook-runs')
def add_playbook_run(x:PlaybookRun):
 pb=next((p for p in PLAYBOOKS if p['id']==x.playbook_id),None)
 if not pb:raise HTTPException(404,'Unknown playbook')
 with conn() as c:c.execute('insert into playbook_runs(playbook_id,title,team,status,owner,notes) values(?,?,?,?,?,?)',(x.playbook_id,x.title or pb['title'],x.team or pb['team'],x.status,x.owner,x.notes))
 audit('playbook.start',x.playbook_id);return {'ok':True}



# STIG Compliance -------------------------------------------------------------
def _stig_cat_from_severity(v:str)->str:
 v=(v or '').strip().lower()
 if v in ('high','cat i','category i','1'): return 'CAT I'
 if v in ('low','cat iii','category iii','3'): return 'CAT III'
 return 'CAT II'

def _stig_norm_status(v:str)->str:
 t=(v or '').strip().lower().replace('_',' ').replace('-',' ')
 if t in ('not a finding','notafinding','pass','passed','fixed','compliant'): return 'Not a Finding'
 if t in ('not applicable','notapplicable','na','n/a'): return 'Not Applicable'
 if t in ('not reviewed','notreviewed','not checked','unknown','informational'): return 'Not Reviewed'
 return 'Open'

def _save_stig_scan(asset:str, profile:str, source:str, findings:list[dict]):
 scan_id=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+hashlib.sha1(f'{asset}|{profile}|{time.time_ns()}'.encode()).hexdigest()[:8]
 counts={'CAT I':0,'CAT II':0,'CAT III':0,'Open':0,'Not a Finding':0,'Not Applicable':0,'Not Reviewed':0}
 with conn() as c:
  for f in findings:
   cat=f.get('category') or _stig_cat_from_severity(f.get('severity',''))
   st=_stig_norm_status(f.get('status',''))
   counts[cat]=counts.get(cat,0)+(1 if st=='Open' else 0); counts[st]=counts.get(st,0)+1
   c.execute('insert into stig_findings(scan_id,benchmark,rule_id,vuln_id,title,category,severity,status,asset,source,finding_details,remediation,comments) values(?,?,?,?,?,?,?,?,?,?,?,?,?)',(
    scan_id,f.get('benchmark',''),f.get('rule_id',''),f.get('vuln_id',''),f.get('title') or f.get('rule_id') or 'STIG finding',cat,f.get('severity',''),st,asset,source,f.get('finding_details',''),f.get('remediation',''),f.get('comments','')))
  c.execute('insert into stig_scans(scan_id,asset,profile,source,summary) values(?,?,?,?,?)',(scan_id,asset,profile,source,json.dumps(counts)))
 audit('stig.scan',f'{source}:{asset}:{profile}:{scan_id}')
 if '_rebuild_attack_correlations' in globals(): _rebuild_attack_correlations()
 return {'scan_id':scan_id,'asset':asset,'profile':profile,'source':source,'counts':counts,'findings':findings}

def _ps(command:str)->tuple[int,str]:
 if os.name!='nt': return (127,'Native Windows STIG quick scan is available only on Windows.')
 try:
  r=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-Command',command],capture_output=True,text=True,timeout=20)
  return r.returncode,(r.stdout or r.stderr or '').strip()
 except Exception as e:return (1,str(e))

def _native_windows_stig_quick_scan()->list[dict]:
 # Local defensive checks only. They are intentionally labeled baseline checks because a complete
 # official STIG assessment requires the applicable DISA benchmark plus manual checks/SCC results.
 checks=[
  ('HMS-WIN-001','Guest account must be disabled','CAT I','high',"(Get-LocalUser -Name 'Guest' -ErrorAction SilentlyContinue).Enabled",lambda x:x.strip().lower()=='false','Guest account should be disabled.',"Run PowerShell as Administrator: Disable-LocalUser -Name 'Guest'. Then verify with: Get-LocalUser -Name 'Guest' | Select Name,Enabled. In a domain, enforce the equivalent account policy through approved Group Policy."),
  ('HMS-WIN-002','Windows Firewall Domain profile must be enabled','CAT I','high',"(Get-NetFirewallProfile -Profile Domain).Enabled",lambda x:x.strip().lower()=='true','Domain firewall profile should be enabled.',"Run PowerShell as Administrator: Set-NetFirewallProfile -Profile Domain -Enabled True. Prefer enforcing this with your approved Group Policy/MDM baseline, then verify with Get-NetFirewallProfile -Profile Domain."),
  ('HMS-WIN-003','Windows Firewall Private profile must be enabled','CAT II','medium',"(Get-NetFirewallProfile -Profile Private).Enabled",lambda x:x.strip().lower()=='true','Private firewall profile should be enabled.',"Run PowerShell as Administrator: Set-NetFirewallProfile -Profile Private -Enabled True. Verify with Get-NetFirewallProfile -Profile Private."),
  ('HMS-WIN-004','Windows Firewall Public profile must be enabled','CAT II','medium',"(Get-NetFirewallProfile -Profile Public).Enabled",lambda x:x.strip().lower()=='true','Public firewall profile should be enabled.',"Run PowerShell as Administrator: Set-NetFirewallProfile -Profile Public -Enabled True. Verify with Get-NetFirewallProfile -Profile Public."),
  ('HMS-WIN-005','SMBv1 server protocol must be disabled','CAT I','high',"(Get-SmbServerConfiguration).EnableSMB1Protocol",lambda x:x.strip().lower()=='false','SMBv1 should be disabled.',"After confirming no approved legacy dependency requires SMBv1, run PowerShell as Administrator: Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force. Also remove the SMB 1.0/CIFS feature where policy requires it, then retest."),
  ('HMS-WIN-006','PowerShell Script Block Logging should be enabled','CAT II','medium',"(Get-ItemProperty -Path 'HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\PowerShell\\ScriptBlockLogging' -Name EnableScriptBlockLogging -ErrorAction SilentlyContinue).EnableScriptBlockLogging",lambda x:x.strip()=='1','Enable Script Block Logging where required by policy.',"Enable through Group Policy: Computer Configuration > Administrative Templates > Windows Components > Windows PowerShell > Turn on PowerShell Script Block Logging = Enabled. Apply policy and verify the registry value is 1."),
  ('HMS-WIN-007','Remote Desktop NLA should be required','CAT II','medium',"(Get-ItemProperty 'HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Terminal Server\\WinStations\\RDP-Tcp' -Name UserAuthentication -ErrorAction SilentlyContinue).UserAuthentication",lambda x:x.strip()=='1','Require Network Level Authentication for RDP.',"Enable Network Level Authentication through the approved Remote Desktop Services Group Policy. For a local administrative fix, set UserAuthentication to 1 under the RDP-Tcp registry key, then verify and retest RDP access."),
  ('HMS-WIN-008','LM hash storage should be disabled','CAT I','high',"(Get-ItemProperty 'HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Lsa' -Name NoLMHash -ErrorAction SilentlyContinue).NoLMHash",lambda x:x.strip()=='1','Do not store LAN Manager hash values.',"Enable Security Options policy 'Network security: Do not store LAN Manager hash value on next password change'. After policy applies, users must change passwords before old LM hashes are eliminated. Verify NoLMHash=1."),
  ('HMS-WIN-009','Anonymous SAM enumeration should be restricted','CAT II','medium',"(Get-ItemProperty 'HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Lsa' -Name RestrictAnonymousSAM -ErrorAction SilentlyContinue).RestrictAnonymousSAM",lambda x:x.strip()=='1','Restrict anonymous enumeration of SAM accounts.',"Enable Security Options policy 'Network access: Do not allow anonymous enumeration of SAM accounts'. Apply policy, then verify RestrictAnonymousSAM=1."),
  ('HMS-WIN-010','AutoRun should be disabled by policy','CAT II','medium',"(Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer' -Name NoDriveTypeAutoRun -ErrorAction SilentlyContinue).NoDriveTypeAutoRun",lambda x:x.strip() in ('255','0xFF'),'Disable AutoRun through policy.',"Use Group Policy under AutoPlay Policies to disable AutoPlay/AutoRun for all drives according to your benchmark. Apply policy and verify NoDriveTypeAutoRun is 255 (0xFF)."),
  ('HMS-WIN-011','Windows Defender real-time protection should be enabled','CAT I','high',"(Get-MpComputerStatus -ErrorAction SilentlyContinue).RealTimeProtectionEnabled",lambda x:x.strip().lower()=='true','Real-time antimalware protection should be enabled.',"If Microsoft Defender is the approved antimalware provider, enable real-time monitoring through your security policy/management platform or run PowerShell as Administrator: Set-MpPreference -DisableRealtimeMonitoring $false. Verify with Get-MpComputerStatus."),
  ('HMS-WIN-012','Secure Boot should be enabled where supported','CAT III','low',"try { Confirm-SecureBootUEFI } catch { 'UNKNOWN' }",lambda x:x.strip().lower()=='true','Verify Secure Boot where applicable to the platform and benchmark.',"Confirm the device supports UEFI Secure Boot and that enabling it will not disrupt approved boot components or encryption recovery. Enable Secure Boot in system UEFI/firmware, then verify in Windows with Confirm-SecureBootUEFI.")
 ]
 out=[]
 for rid,title,cat,sev,cmd,ok,note,fix in checks:
  rc,val=_ps(cmd); passed=(rc==0 and ok(val)); status='Not a Finding' if passed else ('Not Reviewed' if val in ('','UNKNOWN') or rc!=0 else 'Open')
  out.append({'benchmark':'Hive Mind Windows STIG Baseline Helper','rule_id':rid,'vuln_id':'','title':title,'category':cat,'severity':sev,'status':status,'finding_details':f'Observed: {val or "no value returned"}. {note}','remediation':fix,'comments':'This native helper is not a substitute for an official DISA STIG/SCC assessment.'})
 return out

def _stig_local_remediation(title:str='', rule_id:str='', vuln_id:str='', details:str='')->str:
 """Provide conservative, actionable local guidance when an imported result omits DISA Fix Text.
 This is explicitly supplemental guidance, not a claim to be the authoritative benchmark fix text.
 """
 text=' '.join([title or '',rule_id or '',vuln_id or '',details or '']).lower()
 guides=[
  (('password','minimum password','password length'), "Review the applicable Account Policies > Password Policy requirement in the benchmark, then configure it through your approved domain/local Group Policy. On Windows, open secpol.msc or the governing GPO and set the required password policy value. Run gpupdate /force where appropriate, verify with 'net accounts' / Resultant Set of Policy, and rerun the STIG check."),
  (('account lockout','lockout threshold','lockout duration'), "Configure the required Account Lockout Policy through the governing Group Policy: Computer Configuration > Windows Settings > Security Settings > Account Policies > Account Lockout Policy. Apply the benchmark-required threshold/duration/reset values, update policy, verify Resultant Set of Policy, and rerun the check."),
  (('audit policy','auditpol','auditing'), "Configure the benchmark-required Advanced Audit Policy subcategory through Group Policy under Computer Configuration > Windows Settings > Security Settings > Advanced Audit Policy Configuration. Verify the effective setting with 'auditpol /get /category:*', then rerun the STIG check."),
  (('firewall','windows defender firewall'), "Configure the required Windows Defender Firewall profile through the governing GPO/MDM policy. Verify effective settings with 'Get-NetFirewallProfile | Format-Table Name,Enabled,DefaultInboundAction,DefaultOutboundAction'. Apply the benchmark-required profile state and rerun the check."),
  (('smbv1','smb 1.0','smb1'), "After confirming no approved legacy dependency requires SMBv1, disable the SMBv1 server/client components through approved policy or Windows Features. Verify with 'Get-SmbServerConfiguration | Select EnableSMB1Protocol' and 'Get-WindowsOptionalFeature -Online -FeatureName SMB1Protocol', then rerun the check."),
  (('rdp','remote desktop','network level authentication','nla'), "Configure the applicable Remote Desktop Services security setting through Group Policy. If the rule concerns NLA, require user authentication for remote connections by using Network Level Authentication. Verify the effective RDP policy/registry setting and rerun the STIG check."),
  (('powershell','script block logging'), "Configure the applicable Windows PowerShell policy through Group Policy under Computer Configuration > Administrative Templates > Windows Components > Windows PowerShell. For Script Block Logging findings, enable 'Turn on PowerShell Script Block Logging', apply policy, verify the effective registry/policy state, and rerun the check."),
  (('defender','antivirus','real-time protection','realtime protection'), "If Microsoft Defender is the approved antimalware provider, configure the benchmark-required Defender setting through your security management platform, GPO, or MDM. Verify effective status with 'Get-MpComputerStatus' and applicable 'Get-MpPreference' values, then rerun the check."),
  (('guest account','guest'), "Disable the built-in Guest account through the governing security policy/GPO. For a standalone Windows host, an administrator can verify with 'Get-LocalUser -Name Guest' and disable it with 'Disable-LocalUser -Name Guest'. Apply domain policy where applicable and rerun the check."),
  (('anonymous','restrictanonymous','sam enumeration'), "Configure the applicable Security Options policy under Computer Configuration > Windows Settings > Security Settings > Local Policies > Security Options to restrict anonymous enumeration/access as required by the benchmark. Apply policy, verify the effective LSA setting, and rerun the check."),
  (('autorun','autoplay'), "Configure AutoPlay/AutoRun through Group Policy under Computer Configuration > Administrative Templates > Windows Components > AutoPlay Policies according to the benchmark. Apply policy, verify the effective policy/registry value, and rerun the check."),
  (('secure boot','secureboot'), "Confirm the platform supports UEFI Secure Boot and coordinate any BitLocker/recovery-key requirements before changing firmware settings. Enable Secure Boot in UEFI/firmware as required, boot Windows, verify with 'Confirm-SecureBootUEFI', and rerun the check."),
  (('bitlocker','drive encryption'), "Use the organization's approved BitLocker policy to configure the benchmark-required encryption and recovery settings. Before changes, ensure recovery material is escrowed as required. Verify effective protection with 'manage-bde -status' or 'Get-BitLockerVolume', then rerun the check."),
  (('tls','ssl','schannel'), "Identify the exact protocol/cipher requirement from the Rule/Vulnerability ID before changing SCHANNEL. Configure the required protocol/cipher state through approved GPO/registry management, account for application compatibility, reboot if required, verify the effective TLS configuration, and rerun the check."),
  (('registry','regedit','registry value'), "Use the Rule/Vulnerability ID to confirm the required registry path, value name, type, and benchmark value. Apply it through the governing GPO/MDM/configuration-management policy rather than an ad-hoc local change where possible. Run policy refresh if needed, verify the effective value with Get-ItemProperty/reg query, and rerun the check."),
  (('service','must be disabled','must not be running'), "Confirm the named service is not required by an approved application or mission dependency. Configure its startup state through approved policy/configuration management, stop it if the benchmark requires that state, verify with Get-Service/sc.exe, and rerun the check."),
 ]
 for keys,guide in guides:
  if any(k in text for k in keys): return guide
 return ("The imported result did not contain the benchmark's Fix Text. Use the Rule ID/Vulnerability ID shown above to confirm the exact required value in the matching DISA STIG benchmark version. "
         "Then apply that requirement through your approved GPO, MDM, local security policy, registry, or configuration-management method; verify the effective setting on the endpoint; and rerun/re-import the assessment. "
         "HIVE SECURITY is not inventing a specific registry value or command when the imported result does not provide enough rule detail.")

def _xccdf_rule_fix_map(root)->dict:
 """Extract Rule metadata/fixtext when an XCCDF benchmark and results are in the same XML."""
 out={}
 for rule in root.iter():
  if str(rule.tag).split('}')[-1] != 'Rule': continue
  rid=rule.attrib.get('id','')
  if not rid: continue
  title=''; fix=''; desc=''
  for ch in rule.iter():
   local=str(ch.tag).split('}')[-1]
   txt=' '.join(''.join(ch.itertext()).split())
   if local=='title' and txt and not title: title=txt
   elif local in ('fixtext','fix') and txt and not fix: fix=txt
   elif local=='description' and txt and not desc: desc=txt
  out[rid]={'title':title,'fix':fix,'description':desc}
 return out

def _parse_stig_upload(name:str,data:bytes)->tuple[str,list[dict]]:
 lower=name.lower(); findings=[]; benchmark='Imported STIG Results'
 if lower.endswith('.cklb') or lower.endswith('.json'):
  obj=json.loads(data.decode('utf-8-sig',errors='replace')); benchmark=obj.get('title') or obj.get('stigs',[{}])[0].get('display_name','Imported CKLB') if isinstance(obj,dict) else 'Imported CKLB'
  stigs=obj.get('stigs',[]) if isinstance(obj,dict) else []
  for st in stigs:
   benchmark=st.get('display_name') or st.get('title') or benchmark
   for r in st.get('rules',[]) or []:
    findings.append({'benchmark':benchmark,'rule_id':r.get('rule_id',''),'vuln_id':r.get('group_id') or r.get('vuln_id',''),'title':r.get('rule_title') or r.get('title') or r.get('rule_id',''),'severity':r.get('severity',''),'category':_stig_cat_from_severity(r.get('severity','')),'status':r.get('status','Not Reviewed'),'finding_details':r.get('finding_details',''),'remediation':r.get('fix_text') or r.get('fix') or r.get('remediation') or _stig_local_remediation(r.get('rule_title') or r.get('title',''),r.get('rule_id',''),r.get('group_id') or r.get('vuln_id',''),r.get('finding_details','')), 'comments':r.get('comments','')})
 elif lower.endswith('.ckl') or lower.endswith('.xml'):
  root=ET.fromstring(data)
  # Supports classic CKL and common XCCDF result shapes.
  benchmark=root.findtext('.//STIG_INFO/SI_DATA[SID_NAME="title"]/SID_DATA') or root.attrib.get('id') or 'Imported CKL/XCCDF'
  vulns=root.findall('.//VULN')
  if vulns:
   for v in vulns:
    attrs={}
    for sd in v.findall('.//STIG_DATA'):
     k=sd.findtext('VULN_ATTRIBUTE') or ''; attrs[k]=sd.findtext('ATTRIBUTE_DATA') or ''
    sev=attrs.get('Severity','')
    findings.append({'benchmark':benchmark,'rule_id':attrs.get('Rule_ID',''),'vuln_id':attrs.get('Vuln_Num',''),'title':attrs.get('Rule_Title') or attrs.get('Vuln_Num',''),'severity':sev,'category':_stig_cat_from_severity(sev),'status':v.findtext('STATUS') or 'Not Reviewed','finding_details':v.findtext('FINDING_DETAILS') or '','remediation':attrs.get('Fix_Text') or attrs.get('FixText') or _stig_local_remediation(attrs.get('Rule_Title',''),attrs.get('Rule_ID',''),attrs.get('Vuln_Num',''),v.findtext('FINDING_DETAILS') or ''), 'comments':v.findtext('COMMENTS') or ''})
  else:
   ns={'x':'http://checklists.nist.gov/xccdf/1.2'}; rule_map=_xccdf_rule_fix_map(root)
   for rr in root.findall('.//x:rule-result',ns)+root.findall('.//rule-result'):
    sev=rr.attrib.get('severity',''); result=(rr.findtext('x:result',namespaces=ns) or rr.findtext('result') or ''); rid=rr.attrib.get('idref',''); meta=rule_map.get(rid,{})
    status='Not a Finding' if result.lower() in ('pass','fixed') else ('Not Applicable' if result.lower() in ('notapplicable','notselected') else ('Not Reviewed' if result.lower() in ('unknown','notchecked','informational') else 'Open'))
    title=meta.get('title') or rid; details=f'XCCDF result: {result}' + (f". Rule context: {meta.get('description')}" if meta.get('description') else '')
    remediation=meta.get('fix') or _stig_local_remediation(title,rid,'',details)
    findings.append({'benchmark':benchmark,'rule_id':rid,'vuln_id':'','title':title,'severity':sev,'category':_stig_cat_from_severity(sev),'status':status,'finding_details':details,'remediation':remediation, 'comments':''})
 else: raise ValueError('Supported result files: .ckl, .cklb, .xml or .json')
 return benchmark,findings

@app.get('/api/stig/summary')
def stig_summary():
 with conn() as c:
  rows=[dict(x) for x in c.execute('select * from stig_findings order by id desc').fetchall()]
  scans=[dict(x) for x in c.execute('select * from stig_scans order by id desc limit 25').fetchall()]
 open_rows=[r for r in rows if r['status']=='Open']
 return {'open':len(open_rows),'cat1':sum(r['category']=='CAT I' for r in open_rows),'cat2':sum(r['category']=='CAT II' for r in open_rows),'cat3':sum(r['category']=='CAT III' for r in open_rows),'not_a_finding':sum(r['status']=='Not a Finding' for r in rows),'not_reviewed':sum(r['status']=='Not Reviewed' for r in rows),'not_applicable':sum(r['status']=='Not Applicable' for r in rows),'findings':rows[:500],'scans':scans}


@app.get('/api/stig/scans/{scan_id}')
def stig_scan_detail(scan_id:str):
 with conn() as c:
  scan=c.execute('select * from stig_scans where scan_id=?',(scan_id,)).fetchone()
  if not scan: raise HTTPException(404,'STIG scan not found')
  findings=[dict(x) for x in c.execute('select * from stig_findings where scan_id=? order by category,id',(scan_id,)).fetchall()]
 sr=dict(scan)
 try: sr['counts']=json.loads(sr.get('summary') or '{}')
 except Exception: sr['counts']={}
 return {'scan':sr,'findings':findings}

@app.delete('/api/stig/scans/{scan_id}')
def stig_delete_scan(scan_id:str):
 with conn() as c:
  scan=c.execute('select * from stig_scans where scan_id=?',(scan_id,)).fetchone()
  if not scan: raise HTTPException(404,'STIG scan not found')
  count=c.execute('select count(*) from stig_findings where scan_id=?',(scan_id,)).fetchone()[0]
  finding_ids=[str(x[0]) for x in c.execute('select id from stig_findings where scan_id=?',(scan_id,)).fetchall()]
  if finding_ids:
   q=','.join('?' for _ in finding_ids);c.execute(f"delete from attack_mappings where record_type='stig' and record_id in ({q})",finding_ids)
  c.execute('delete from stig_findings where scan_id=?',(scan_id,))
  c.execute('delete from stig_scans where scan_id=?',(scan_id,))
 _cleanup_orphan_attack_mappings()
 audit('stig.scan.delete',f'{scan_id}:{count} findings')
 return {'ok':True,'deleted_scan':scan_id,'deleted_findings':count}

@app.delete('/api/stig/scans')
def stig_clear_history():
 with conn() as c:
  scans=c.execute('select count(*) from stig_scans').fetchone()[0]
  findings=c.execute('select count(*) from stig_findings').fetchone()[0]
  c.execute("delete from attack_mappings where record_type='stig'")
  c.execute('delete from stig_findings')
  c.execute('delete from stig_scans')
 audit('stig.history.clear',f'{scans} scans:{findings} findings')
 return {'ok':True,'deleted_scans':scans,'deleted_findings':findings}

@app.post('/api/stig/scan-local')
def stig_scan_local():
 if os.name!='nt': raise HTTPException(400,'Native STIG quick scan currently supports the local Windows host only.')
 asset=os.environ.get('COMPUTERNAME',socket.gethostname()); findings=_native_windows_stig_quick_scan()
 return _save_stig_scan(asset,'Windows Local Baseline Helper','native',findings)

@app.post('/api/stig/import')
async def stig_import(file:UploadFile=File(...), asset:str=''):
 data=await file.read()
 if len(data)>25*1024*1024: raise HTTPException(413,'STIG result file exceeds 25 MB import limit.')
 try: benchmark,findings=_parse_stig_upload(file.filename or 'stig-results',data)
 except Exception as e: raise HTTPException(400,f'Could not parse STIG result file: {e}')
 if not findings: raise HTTPException(400,'No STIG rule results were found in the uploaded file.')
 return _save_stig_scan(asset or socket.gethostname(),benchmark,'import',findings)

@app.post('/api/stig/{finding_id}/status')
def stig_update_status(finding_id:int,x:ToolboxInput):
 status=_stig_norm_status(x.value)
 with conn() as c:
  if not c.execute('select 1 from stig_findings where id=?',(finding_id,)).fetchone(): raise HTTPException(404,'Finding not found')
  c.execute('update stig_findings set status=?,comments=?,updated_at=CURRENT_TIMESTAMP where id=?',(status,x.extra or '',finding_id))
 audit('stig.finding.update',f'{finding_id}:{status}'); return {'ok':True,'status':status}

@app.get('/api/certs')
def certs():return CERTS
@app.get('/api/study-aids/{cert}')
def study_aids(cert:str):
 if cert not in STUDY_AIDS:raise HTTPException(404,'Unknown certification')
 return {'cert':CERTS[cert],**STUDY_AIDS[cert],'lessons':STUDY_LESSONS.get(cert,[]),'videos':CERT_VIDEOS.get(cert,[]),'question_count':len(BANKS.get(cert,[]))}
@app.get('/api/study-aids/{cert}/resource-health')
async def study_resource_health(cert:str):
 if cert not in CERT_VIDEOS: raise HTTPException(404,'Unknown certification')
 out=[]
 async with httpx.AsyncClient(follow_redirects=True,timeout=httpx.Timeout(7.0),headers={'User-Agent':'Hive-Mind-Security/0.5.5'}) as client:
  for r in CERT_VIDEOS.get(cert,[]):
   url=r.get('url','')
   try:
    parsed=urllib.parse.urlparse(url)
    if parsed.scheme!='https' or (parsed.hostname or '').lower() not in RESOURCE_HEALTH_ALLOWED_HOSTS:
     out.append({'title':r.get('title','Resource'),'url':url,'ok':False,'status':'blocked','detail':'Resource host is not on the approved study-resource allowlist.'}); continue
    resp=await client.get(url)
    ok=200 <= resp.status_code < 400
    out.append({'title':r.get('title','Resource'),'url':url,'ok':ok,'status':resp.status_code,'final_url':str(resp.url)})
   except Exception as e:
    out.append({'title':r.get('title','Resource'),'url':url,'ok':False,'status':'unreachable','detail':str(e)[:180]})
 return {'cert':cert,'checked_at':datetime.now(timezone.utc).isoformat(),'resources':out}

@app.get('/api/quiz/{cert}')
def quiz(cert:str,length:int=10,domain:str=''):
 if cert not in BANKS:raise HTTPException(404,'Unknown certification')
 bank=BANKS[cert];
 if domain: bank=[q for q in bank if q.get('domain')==domain]
 import random; bank=bank.copy(); random.shuffle(bank); chosen=bank[:max(1,min(length,len(bank)))]
 return [{k:v for k,v in q.items() if k not in ('correct','answer','explanation')} for q in chosen]
@app.post('/api/quiz/{cert}/check')
def check_quiz_answer(cert:str,x:CheckAnswer):
 if cert not in BANKS: raise HTTPException(404,'Unknown certification')
 q=next((q for q in BANKS[cert] if str(q.get('id'))==str(x.question_id)),None)
 if not q: raise HTTPException(404,'Question not found')
 answer=str(q.get('correct',q.get('answer',''))).upper(); chosen=str(x.answer or '').upper(); ok=chosen==answer
 return {'id':q['id'],'correct':ok,'answer':answer,'answer_text':q.get(answer,''),'explanation':q.get('explanation',''),'domain':q.get('domain','Other')}

def _certificate_pdf(row:dict)->bytes:
 buf=BytesIO(); w,h=landscape(letter); c=canvas.Canvas(buf,pagesize=(w,h))
 # dark professional field
 c.setFillColor(colors.HexColor('#08090b')); c.rect(0,0,w,h,fill=1,stroke=0)
 c.setFillColor(colors.HexColor('#111318')); c.rect(22,22,w-44,h-44,fill=1,stroke=0)
 c.setStrokeColor(colors.HexColor('#c20d1b')); c.setLineWidth(4); c.rect(30,30,w-60,h-60,fill=0,stroke=1)
 c.setStrokeColor(colors.HexColor('#5a1118')); c.setLineWidth(1); c.rect(40,40,w-80,h-80,fill=0,stroke=1)
 # logo and brand
 logo=STATIC/'icon-512.png'
 if logo.exists():
  try:c.drawImage(ImageReader(str(logo)),w/2-34,h-105,68,68,mask='auto',preserveAspectRatio=True)
  except Exception:pass
 c.setFillColor(colors.HexColor('#f5f6f7')); c.setFont('Helvetica-Bold',18); c.drawCentredString(w/2,h-130,'HIVE SECURITY')
 c.setFillColor(colors.HexColor('#d71920')); c.setFont('Helvetica-Bold',28); c.drawCentredString(w/2,h-175,'CERTIFICATE OF COMPLETION')
 c.setFillColor(colors.HexColor('#b9bec5')); c.setFont('Helvetica',12); c.drawCentredString(w/2,h-205,'This certificate recognizes successful completion of')
 c.setFillColor(colors.white); c.setFont('Helvetica-Bold',20); c.drawCentredString(w/2,h-238,row['course'])
 c.setFillColor(colors.HexColor('#b9bec5')); c.setFont('Helvetica',12); c.drawCentredString(w/2,h-270,'Awarded to')
 name=(row.get('recipient_name') or row.get('username') or 'HIVE SECURITY Learner')[:70]
 c.setFillColor(colors.white); c.setFont('Helvetica-Bold',26); c.drawCentredString(w/2,h-307,name)
 c.setStrokeColor(colors.HexColor('#d71920')); c.setLineWidth(1); c.line(w/2-190,h-316,w/2+190,h-316)
 c.setFillColor(colors.HexColor('#c8ccd1')); c.setFont('Helvetica',11)
 c.drawCentredString(w/2,h-345,f"Final assessment score: {row['score']}/{row['total']} ({row['percent']}%)")
 issued=str(row.get('issued_at','')).split('.')[0].replace('T',' ')
 c.drawCentredString(w/2,h-367,f"Issued: {issued} UTC")
 c.setFont('Helvetica',9); c.setFillColor(colors.HexColor('#8e949c'))
 c.drawString(55,58,f"Certificate ID: {row['certificate_id']}")
 c.drawRightString(w-55,58,'HIVE SECURITY Academy • Application Fundamentals')
 c.setFillColor(colors.HexColor('#d71920')); c.rect(0,0,w,8,fill=1,stroke=0); c.rect(0,h-8,w,8,fill=1,stroke=0)
 c.showPage(); c.save(); return buf.getvalue()

@app.post('/api/quiz/{cert}/grade')
def grade(cert:str,x:Grade,request:Request):
 if cert not in BANKS:raise HTTPException(404,'Unknown certification')
 bank={str(q['id']):q for q in BANKS[cert]}; score=0; results=[]; domains={}
 for token in x.answers:
  try:qid,ans=token.split(':',1)
  except ValueError:continue
  q=bank.get(qid)
  if not q:continue
  correct=str(q.get('correct',q.get('answer',''))).upper(); ok=ans.upper()==correct;score+=int(ok); d=q.get('domain','Other');domains.setdefault(d,[0,0]);domains[d][1]+=1;domains[d][0]+=int(ok)
  results.append({'id':q['id'],'correct':ok,'answer':correct,'explanation':q['explanation'],'domain':d})
 total=len(results); dstat={k:{'correct':v[0],'total':v[1],'percent':round(100*v[0]/v[1]) if v[1] else 0} for k,v in domains.items()}
 percent=round(score*100/total) if total else 0
 req=EXAM_REQUIREMENTS.get(cert,{}); threshold=int(req.get('practice_pass_percent',70)); passed=percent>=threshold
 cert_record=None
 with conn() as c:
  cur=c.execute('insert into study(cert,score,total,domain_json,mode) values(?,?,?,?,?)',(cert,score,total,json.dumps(dstat),x.mode)); study_id=cur.lastrowid
  if cert=='hive-security' and x.mode=='exam' and passed and total==40 and len(BANKS['hive-security'])==40:
   username=getattr(request.state,'user','learner'); display=re.sub(r"[^A-Za-z0-9 .,_'\-]",'',x.certificate_name or '').strip()[:80] or username
   cid=f"HIVE-{datetime.now(timezone.utc).strftime('%Y%m%d')}-{secrets.token_hex(4).upper()}"
   c.execute('insert into academy_certificates(certificate_id,study_id,username,recipient_name,course,score,total,percent) values(?,?,?,?,?,?,?,?)',(cid,study_id,username,display,'HIVE SECURITY Application Fundamentals',score,total,percent))
   cert_record={'certificate_id':cid,'recipient_name':display,'download_url':f'/api/academy/certificates/{cid}.pdf'}
  
 if cert_record:audit('academy.certificate.issue',cert_record['certificate_id'])
 return {'score':score,'total':total,'percent':percent,'domains':dstat,'results':results,'passed':passed,'practice_pass_percent':threshold,'official_pass':req.get('official_pass',''),'official_format':req.get('official_format',''),'practice_note':req.get('practice_note',''),'certificate':cert_record}

@app.get('/api/academy/certificates')
def academy_certificates(request:Request):
 with conn() as c:
  rows=c.execute('select certificate_id,recipient_name,course,score,total,percent,issued_at from academy_certificates where username=? order by id desc',(request.state.user,)).fetchall()
 return [dict(r) for r in rows]

@app.get('/api/academy/certificates/{certificate_id}.pdf')
def academy_certificate_pdf(certificate_id:str,request:Request):
 with conn() as c:
  row=c.execute('select * from academy_certificates where certificate_id=?',(certificate_id,)).fetchone()
 if not row:raise HTTPException(404,'Certificate not found')
 if request.state.role!='admin' and row['username']!=request.state.user:raise HTTPException(403,'Certificate belongs to another user')
 pdf=_certificate_pdf(dict(row)); headers={'Content-Disposition':f'inline; filename="HIVE_SECURITY_Certificate_{certificate_id}.pdf"'}
 return StreamingResponse(BytesIO(pdf),media_type='application/pdf',headers=headers)
@app.get('/api/study-history')
def study_history(cert:str=''):
 with conn() as c:
  rows=c.execute('select * from study where cert=? order by id desc limit 30',(cert,)).fetchall() if cert else c.execute('select * from study order by id desc limit 50').fetchall()
 return [dict(x) for x in rows]

@app.get('/api/integrations/catalog')
def integration_catalog():return INTEGRATION_CATALOG
@app.get('/api/integrations')
def integrations():
 with conn() as c:rows={r['id']:dict(r) for r in c.execute('select * from integrations').fetchall()}
 out=[]
 for iid,meta in INTEGRATION_CATALOG.items():
  if iid in NO_KEY:
   out.append({'id':iid,**meta,'enabled':True,'status':'built_in','last_test':'','last_error':'','config':{}});continue
  r=rows.get(iid,{});cfg=json.loads(r.get('config_json') or '{}');safe={k:('••••••••' if k in meta.get('secret',[]) and cfg.get(k) else cfg.get(k,'')) for k in meta['fields']}
  out.append({'id':iid,**meta,'enabled':bool(r.get('enabled',0)),'status':r.get('status','not_configured'),'last_test':r.get('last_test',''),'last_error':r.get('last_error',''),'config':safe})
 return out
@app.put('/api/integrations/{iid}')
def save_integration(iid:str,x:IntegrationConfig):
 if iid not in INTEGRATION_CATALOG:raise HTTPException(404,'Unknown integration')
 if iid in NO_KEY:return {'ok':True,'built_in':True}
 meta=INTEGRATION_CATALOG[iid]
 with conn() as c:
  old=c.execute('select config_json from integrations where id=?',(iid,)).fetchone();oldcfg=json.loads(old[0]) if old else {};cfg={}
  for f in meta['fields']:
   v=str(x.config.get(f,'')).strip()
   if f in meta.get('secret',[]):
    if v in ('','••••••••') and oldcfg.get(f):cfg[f]=oldcfg[f]
    elif v:cfg[f]=enc(v)
   else:cfg[f]=v
  c.execute('insert into integrations(id,enabled,config_json,status,updated_at) values(?,?,?,?,CURRENT_TIMESTAMP) on conflict(id) do update set enabled=excluded.enabled,config_json=excluded.config_json,status=excluded.status,updated_at=CURRENT_TIMESTAMP',(iid,int(x.enabled),json.dumps(cfg),'configured'))
 audit('integration.save',iid);return {'ok':True}
def get_cfg(iid):
 with conn() as c:r=c.execute('select config_json from integrations where id=?',(iid,)).fetchone()
 if not r:return {}
 cfg=json.loads(r[0]);meta=INTEGRATION_CATALOG[iid]
 for s in meta.get('secret',[]):
  if cfg.get(s):cfg[s]=dec(cfg[s])
 return cfg
@app.post('/api/integrations/{iid}/test')
async def test_integration(iid:str):
 if iid not in INTEGRATION_CATALOG:raise HTTPException(404,'Unknown integration')
 if iid in NO_KEY:
  if iid=='osiris':
   try:
    d=await _osiris_get('/api/health',ttl=10);ok=True
   except Exception:ok=False
  elif iid=='cisa':d=await kev(1);ok=not isinstance(d,dict)
  elif iid in ('feodo','dshield'):d=await threat_map(True);ok=bool(d.get('events'))
  elif iid=='spamhaus':
   try:
    async with httpx.AsyncClient(timeout=12) as c:r=await c.get('https://www.spamhaus.org/drop/drop_v4.json');r.raise_for_status();ok=True
   except Exception:ok=False
  else:
   try:
    async with httpx.AsyncClient(timeout=12) as c:r=await c.get('https://services.nvd.nist.gov/rest/json/cves/2.0',params={'resultsPerPage':1});r.raise_for_status();ok=True
   except Exception:ok=False
  return {'ok':ok,'status':'healthy' if ok else 'error','detail':'Built-in public feed query '+('succeeded' if ok else 'failed')}
 cfg=get_cfg(iid);ok,detail=await test_provider(iid,cfg);status='healthy' if ok else 'error';now=datetime.now(timezone.utc).isoformat()
 with conn() as c:c.execute('update integrations set status=?,last_test=?,last_error=? where id=?',(status,now,'' if ok else detail,iid))
 audit('integration.test',f'{iid}:{status}');return {'ok':ok,'status':status,'detail':detail,'tested_at':now}
@app.get('/api/integrations/{iid}/data')
async def integration_data(iid:str,limit:int=50):
 if iid=='osiris':return await osiris_feed('cyber-attacks',min(limit,200),False)
 if iid=='cisa':return {'kind':'kev','items':await kev(limit)}
 if iid in ('feodo','dshield'):return await threat_map()
 if iid=='spamhaus':
  async with httpx.AsyncClient(timeout=15) as c:r=await c.get('https://www.spamhaus.org/drop/drop_v4.json');r.raise_for_status();return {'kind':'netblocks','items':r.json()[:limit] if isinstance(r.json(),list) else r.json()}
 if iid=='nvd':
  cfg=get_cfg('nvd') if 'nvd' in INTEGRATION_CATALOG else {};headers={'apiKey':cfg.get('api_key')} if cfg.get('api_key') else {}
  async with httpx.AsyncClient(timeout=15) as c:r=await c.get('https://services.nvd.nist.gov/rest/json/cves/2.0',params={'resultsPerPage':min(limit,100)},headers=headers);r.raise_for_status();return {'kind':'cves','items':r.json().get('vulnerabilities',[])}
 if iid not in INTEGRATION_CATALOG:raise HTTPException(404,'Unknown integration')
 cfg=get_cfg(iid)
 if not cfg:raise HTTPException(400,'Integration is not configured')
 try:return await fetch_provider(iid,cfg,limit)
 except Exception as e:raise HTTPException(502,str(e)[:800])
@app.post('/api/integrations/{iid}/send-test')
async def send_notification_test(iid:str,x:NotificationTest):
 cfg=get_cfg(iid)
 try:detail=await send_test(iid,cfg,x.message);audit('integration.send_test',iid);return {'ok':True,'detail':detail}
 except Exception as e:raise HTTPException(502,str(e)[:800])


# OSIRIS Intelligence integration -------------------------------------------
OSIRIS_BASE='https://osirisai.live'
OSIRIS_FEEDS={
 'cyber-attacks':'/api/cyber-attacks','malware':'/api/malware','cyber-threats':'/api/cyber-threats',
 'conflicts':'/api/conflicts','frontlines':'/api/frontlines','gdelt':'/api/gdelt','country-risk':'/api/country-risk',
 'infrastructure':'/api/infrastructure','maritime':'/api/maritime','earthquakes':'/api/earthquakes','fires':'/api/fires',
 'weather':'/api/weather','air-quality':'/api/air-quality','radar':'/api/radar','news':'/api/news'
}
OSIRIS_MAP_FEEDS={'cyber-attacks','malware','conflicts','gdelt','infrastructure','maritime','earthquakes','fires','weather'}
OSIRIS_CACHE={}

def _osiris_cache_key(path,params):
 return path+'?'+json.dumps(params or {},sort_keys=True,separators=(',',':'))

async def _osiris_get(path,params=None,ttl=55):
 key=_osiris_cache_key(path,params); now=time.time(); hit=OSIRIS_CACHE.get(key)
 if hit and now-hit[0] < ttl:return hit[1]
 async with httpx.AsyncClient(timeout=20,follow_redirects=True,headers={'User-Agent':f'HIVE-SECURITY/{VERSION}'}) as c:
  r=await c.get(OSIRIS_BASE+path,params=params or {});r.raise_for_status();d=r.json()
 OSIRIS_CACHE[key]=(now,d);return d

def _num(v):
 try:return float(v)
 except Exception:return None

def _coords_from_obj(o):
 if not isinstance(o,dict):return (None,None)
 # GeoJSON geometry
 g=o.get('geometry')
 if isinstance(g,dict):
  co=g.get('coordinates')
  if isinstance(co,(list,tuple)) and len(co)>=2 and not isinstance(co[0],(list,tuple)):
   lon,lat=_num(co[0]),_num(co[1])
   if lat is not None and lon is not None and -90<=lat<=90 and -180<=lon<=180:return lat,lon
 candidates=[
  (o.get('lat'),o.get('lon')),(o.get('lat'),o.get('lng')),(o.get('latitude'),o.get('longitude')),
  (o.get('Latitude'),o.get('Longitude')),(o.get('LATITUDE'),o.get('LONGITUDE'))
 ]
 loc=o.get('location')
 if isinstance(loc,dict):candidates.extend([(loc.get('lat'),loc.get('lon')),(loc.get('lat'),loc.get('lng')),(loc.get('latitude'),loc.get('longitude'))])
 for a,b in candidates:
  lat,lon=_num(a),_num(b)
  if lat is not None and lon is not None and -90<=lat<=90 and -180<=lon<=180:return lat,lon
 return None,None

def _flatten_osiris(data,limit=500):
 out=[]
 def walk(v,depth=0):
  if len(out)>=limit or depth>6:return
  if isinstance(v,list):
   for x in v:walk(x,depth+1)
  elif isinstance(v,dict):
   lat,lon=_coords_from_obj(v)
   if lat is not None and lon is not None:out.append(v)
   else:
    for k,x in v.items():
     if isinstance(x,(list,dict)):walk(x,depth+1)
 walk(data)
 return out

def _pick(o,*keys):
 p=o.get('properties') if isinstance(o,dict) and isinstance(o.get('properties'),dict) else {}
 for k in keys:
  v=(o or {}).get(k) if isinstance(o,dict) else None
  if v not in (None,'',[],{}):return v
  v=p.get(k)
  if v not in (None,'',[],{}):return v
 return ''

def _osiris_normalize(feed,data,limit=350):
 rows=[]
 # GeoJSON and generic geolocated objects
 for i,o in enumerate(_flatten_osiris(data,limit)):
  lat,lon=_coords_from_obj(o)
  props=o.get('properties') if isinstance(o.get('properties'),dict) else {}
  merged={**props,**{k:v for k,v in o.items() if k not in ('properties','geometry')}}
  title=str(_pick(o,'title','name','event','attack_type','malware','type','category','label') or feed.replace('-',' ').title())
  indicator=str(_pick(o,'ip','host','domain','url','indicator','src_ip','source_ip','address') or '')
  country=str(_pick(o,'country','country_code','countryCode','iso2') or '')
  ts=str(_pick(o,'timestamp','time','date','created_at','last_seen','first_seen','publishedAt') or '')
  summary=str(_pick(o,'summary','description','detail','details','message','note','headline') or '')
  keysrc=f'{feed}|{indicator}|{title}|{lat}|{lon}|{ts}'
  ek=hashlib.sha256(keysrc.encode()).hexdigest()[:32]
  rows.append({'event_key':ek,'feed':feed,'kind':str(_pick(o,'kind','type','category') or feed),'title':title[:300],'indicator':indicator[:500],'lat':lat,'lon':lon,'country':country[:80],'timestamp':ts[:80],'summary':summary[:1200],'raw':merged})
 return rows[:limit]

def _store_osiris(rows):
 if not rows:return
 with conn() as c:
  for x in rows:
   c.execute("""insert into osiris_events(event_key,feed,kind,title,indicator,lat,lon,country,summary,raw_json)
    values(?,?,?,?,?,?,?,?,?,?) on conflict(event_key) do update set last_seen=CURRENT_TIMESTAMP,title=excluded.title,summary=excluded.summary,raw_json=excluded.raw_json""",
    (x['event_key'],x['feed'],x['kind'],x['title'],x['indicator'],x['lat'],x['lon'],x['country'],x['summary'],json.dumps(x.get('raw',{}),default=str)[:12000]))

@app.get('/api/osiris/status')
async def osiris_status():
 try:
  h=await _osiris_get('/api/health',ttl=30);s=await _osiris_get('/api/stats',ttl=45)
  return {'ok':True,'provider':'OSIRIS','base_url':OSIRIS_BASE,'health':h,'stats':s,'timestamp':datetime.now(timezone.utc).isoformat()}
 except Exception as e:return {'ok':False,'provider':'OSIRIS','base_url':OSIRIS_BASE,'error':str(e)[:500],'timestamp':datetime.now(timezone.utc).isoformat()}

@app.get('/api/osiris/feed')
async def osiris_feed(feed:str='cyber-attacks',limit:int=100,refresh:bool=False):
 if feed not in OSIRIS_FEEDS:raise HTTPException(400,'Unsupported OSIRIS feed')
 if refresh:OSIRIS_CACHE.pop(_osiris_cache_key(OSIRIS_FEEDS[feed],{}),None)
 try:
  d=await _osiris_get(OSIRIS_FEEDS[feed],ttl=55);rows=_osiris_normalize(feed,d,min(max(limit,1),500));_store_osiris(rows)
  return {'ok':True,'feed':feed,'items':rows,'count':len(rows),'generated_at':datetime.now(timezone.utc).isoformat()}
 except Exception as e:raise HTTPException(502,'OSIRIS feed unavailable: '+str(e)[:700])

@app.get('/api/osiris/map')
async def osiris_map(layers:str='cyber-attacks,malware,conflicts,gdelt,infrastructure',limit:int=120):
 chosen=[]
 for f in [x.strip() for x in layers.split(',') if x.strip()]:
  if f in OSIRIS_MAP_FEEDS and f not in chosen:chosen.append(f)
 if not chosen:raise HTTPException(400,'Select at least one supported OSIRIS map layer')
 events=[];errors=[];per=max(20,min(250,limit))
 for f in chosen:
  try:
   d=await _osiris_get(OSIRIS_FEEDS[f],ttl=55);r=_osiris_normalize(f,d,per);events.extend(r);_store_osiris(r)
  except Exception as e:errors.append(f'{f}: {str(e)[:180]}')
 return {'ok':bool(events) or not errors,'provider':'OSIRIS','layers':chosen,'events':events[:1600],'errors':errors,'generated_at':datetime.now(timezone.utc).isoformat()}

@app.get('/api/osiris/region-dossier')
async def osiris_region_dossier(lat:float,lon:float):
 if not (-90<=lat<=90 and -180<=lon<=180):raise HTTPException(400,'Invalid coordinates')
 # OSIRIS versions have used lon/lng naming; try the documented location request and a compatible fallback.
 for params in ({'lat':lat,'lon':lon},{'lat':lat,'lng':lon}):
  try:return {'ok':True,'lat':lat,'lon':lon,'dossier':await _osiris_get('/api/region-dossier',params,ttl=90)}
  except Exception as e:last=e
 raise HTTPException(502,'OSIRIS region dossier unavailable: '+str(last)[:700])

@app.get('/api/osiris/history')
def osiris_history(limit:int=100):
 with conn() as c:rows=c.execute('select id,event_key,feed,kind,title,indicator,lat,lon,country,summary,first_seen,last_seen from osiris_events order by last_seen desc limit ?',(min(max(limit,1),500),)).fetchall()
 return [dict(x) for x in rows]


# Built-in authorized pentest scanner ----------------------------------------
SCAN_PORTS={20:'ftp-data',21:'ftp',22:'ssh',23:'telnet',25:'smtp',53:'dns',80:'http',110:'pop3',111:'rpcbind',135:'msrpc',139:'netbios',143:'imap',389:'ldap',443:'https',445:'smb',465:'smtps',587:'submission',636:'ldaps',993:'imaps',995:'pop3s',1433:'mssql',1521:'oracle',2049:'nfs',3306:'mysql',3389:'rdp',5432:'postgres',5900:'vnc',6379:'redis',8080:'http-alt',8443:'https-alt',9200:'elasticsearch',27017:'mongodb'}
QUICK_PORTS=[22,23,25,53,80,110,135,139,143,389,443,445,465,587,636,993,995,1433,1521,2049,3306,3389,5432,5900,6379,8080,8443,9200,27017]
STANDARD_PORTS=sorted(set(list(range(1,1025))+[1433,1521,2049,3306,3389,5432,5900,6379,8080,8443,9200,27017]))

def _scan_targets(raw:str,profile:str='standard',credentialed:bool=False)->list[str]:
 raw=raw.strip()
 try:
  if '/' in raw:
   net=ipaddress.ip_network(raw,strict=False)
   max_hosts=256 if (profile=='standard' or credentialed) else 1024
   hosts=[str(x) for x in net.hosts()]
   if len(hosts)>max_hosts:raise ValueError(f'{profile.title()} scans are limited to {max_hosts} usable hosts. Quick supports up to /22; Standard and credentialed scans support up to /24.')
   return hosts
  try:ipaddress.ip_address(raw);return [raw]
  except ValueError:
   infos=socket.getaddrinfo(raw,None,type=socket.SOCK_STREAM);ips=[]
   for i in infos:
    ip=i[4][0]
    if ip not in ips:ips.append(ip)
   return ips[:8] or [raw]
 except Exception as e:raise HTTPException(400,str(e))

def _tcp_probe(host:str,port:int,timeout=.35)->dict|None:
 try:
  with socket.create_connection((host,port),timeout=timeout) as sock:
   sock.settimeout(.5);banner=''
   if port in (80,8080,8443,443):
    try:
     if port in (443,8443):
      ctx=ssl.create_default_context();ctx.check_hostname=False;ctx.verify_mode=ssl.CERT_NONE
      with ctx.wrap_socket(sock,server_hostname=host) as ss:
       ss.sendall(b'HEAD / HTTP/1.0\r\nHost: '+host.encode(errors='ignore')+b'\r\nUser-Agent: HiveMindSecurity/0.6.1\r\n\r\n');banner=ss.recv(2048).decode(errors='replace')
       return {'port':port,'service':SCAN_PORTS.get(port,'tcp'),'banner':banner[:800]}
     sock.sendall(b'HEAD / HTTP/1.0\r\nHost: '+host.encode(errors='ignore')+b'\r\nUser-Agent: HiveMindSecurity/0.6.1\r\n\r\n');banner=sock.recv(2048).decode(errors='replace')
    except Exception:pass
   else:
    try:banner=sock.recv(512).decode(errors='replace')
    except Exception:pass
   return {'port':port,'service':SCAN_PORTS.get(port,'tcp'),'banner':banner[:800]}
 except Exception:return None

def _tls_info(host:str,port:int)->dict:
 try:
  ctx=ssl.create_default_context();ctx.check_hostname=False;ctx.verify_mode=ssl.CERT_NONE
  with socket.create_connection((host,port),timeout=2) as raw:
   with ctx.wrap_socket(raw,server_hostname=host) as s:
    cert=s.getpeercert();return {'protocol':s.version(),'cipher':s.cipher()[0] if s.cipher() else '', 'subject':str(cert.get('subject',''))[:500],'notAfter':cert.get('notAfter','')}
 except Exception as e:return {'error':str(e)[:300]}

def _http_assess(host:str,port:int,tls:bool)->tuple[dict,list[dict]]:
 url=f"{'https' if tls else 'http'}://{host}:{port}/";out={'url':url};find=[]
 try:
  r=httpx.get(url,timeout=3,follow_redirects=True,verify=False,headers={'User-Agent':f'HiveMindSecurity/{VERSION}'})
  out.update({'status':r.status_code,'server':r.headers.get('server',''),'headers':dict(r.headers)})
  h={k.lower():v for k,v in r.headers.items()}
  missing=[]
  for key,label in [('content-security-policy','Content-Security-Policy'),('x-content-type-options','X-Content-Type-Options'),('x-frame-options','X-Frame-Options')]:
   if key not in h:missing.append(label)
  if tls and 'strict-transport-security' not in h:missing.append('Strict-Transport-Security')
  if missing:find.append({'title':'HTTP security headers missing','severity':'low','asset':host,'category':'Web Configuration','description':'The service did not return these recommended browser security headers: '+', '.join(missing)+'.','evidence':url+' returned HTTP '+str(r.status_code),'remediation':'Configure appropriate HTTP security headers after compatibility testing.'})
  if not tls:find.append({'title':'Unencrypted HTTP service exposed','severity':'medium','asset':host,'category':'Transport Security','description':'An HTTP service is reachable without TLS.','evidence':url,'remediation':'Use HTTPS/TLS for authenticated or sensitive web services and redirect cleartext HTTP where appropriate.'})
 except Exception as e:out['error']=str(e)[:300]
 return out,find

def _service_findings(host:str,opens:list[dict])->list[dict]:
 f=[];ports={x['port'] for x in opens}
 risky={23:('Telnet service exposed','high','Replace Telnet with SSH and restrict management access.'),21:('FTP service exposed','medium','Prefer SFTP/FTPS and disable plaintext authentication.'),445:('SMB service reachable','medium','Restrict SMB to trusted networks, require signing where appropriate, and disable SMBv1.'),3389:('RDP service reachable','medium','Restrict RDP exposure, require NLA/MFA through a secured access path, and monitor logons.'),5900:('VNC service reachable','medium','Restrict VNC to trusted management networks and use authenticated encrypted access.'),6379:('Redis service reachable','high','Bind Redis to trusted interfaces only and require authentication/TLS where supported.'),9200:('Elasticsearch service reachable','high','Restrict Elasticsearch to trusted networks and require authentication/TLS.'),27017:('MongoDB service reachable','high','Restrict MongoDB exposure and require authentication/TLS.')}
 for port,(title,sev,rem) in risky.items():
  if port in ports:f.append({'title':title,'severity':sev,'asset':host,'category':'Exposed Service','description':f'TCP/{port} is reachable from the scanner host. Reachability alone does not prove compromise.','evidence':f'{host}:{port} accepted a TCP connection.','remediation':rem})
 for x in opens:
  b=(x.get('banner') or '').lower()
  if 'server: apache/2.2' in b:f.append({'title':'Legacy Apache 2.2 banner detected','severity':'high','asset':host,'category':'Software Lifecycle','description':'The web server banner identifies Apache 2.2, an end-of-life branch.','evidence':x.get('banner','')[:500],'remediation':'Upgrade to a vendor-supported web server release and verify application compatibility.'})
  if 'openssh_5.' in b or 'openssh_6.' in b:f.append({'title':'Legacy OpenSSH banner detected','severity':'medium','asset':host,'category':'Software Lifecycle','description':'The SSH banner indicates an old OpenSSH major release.','evidence':x.get('banner','')[:500],'remediation':'Upgrade using the operating-system vendor supported packages and review SSH hardening.'})
 return f

def _credentialed_scan(host:str,cred:dict)->tuple[dict,list[dict]]:
 if not cred:return ({'status':'not_configured'},[])
 ctype=cred.get('cred_type','');user=cred.get('target_username','');secret=cred.get('secret','');key=cred.get('private_key','');find=[]
 if ctype=='ssh':
  try:
   import paramiko, io
   cli=paramiko.SSHClient();cli.set_missing_host_key_policy(paramiko.AutoAddPolicy())
   kw={'hostname':host,'username':user,'timeout':5,'banner_timeout':5,'auth_timeout':5,'look_for_keys':False,'allow_agent':False}
   if key:kw['pkey']=paramiko.RSAKey.from_private_key(io.StringIO(key),password=secret or None)
   else:kw['password']=secret
   cli.connect(**kw)
   cmds=['uname -a','cat /etc/os-release 2>/dev/null | head -20','id','uptime','ss -lnt 2>/dev/null | head -80']
   data={}
   for cmd in cmds:
    _i,o,e=cli.exec_command(cmd,timeout=7);data[cmd]=(o.read().decode(errors='replace')+e.read().decode(errors='replace'))[:8000]
   cli.close()
   osrel=data.get(cmds[1],'')
   if re.search(r'(?im)^ID=(ubuntu|debian)',osrel):
    # no sudo, no package changes: read-only package status
    pass
   return ({'status':'ok','type':'ssh','username':user,'inventory':data},find)
  except Exception as e:return ({'status':'failed','type':'ssh','error':str(e)[:500]},[])
 if ctype=='winrm':
  try:
   import winrm
   endpoint=f'http://{host}:5985/wsman';uname=(cred.get('domain','')+'\\' if cred.get('domain') else '')+user
   ses=winrm.Session(endpoint,auth=(uname,secret),transport='ntlm',server_cert_validation='ignore')
   ps="$ErrorActionPreference='SilentlyContinue'; Get-CimInstance Win32_OperatingSystem | Select Caption,Version,BuildNumber,LastBootUpTime | ConvertTo-Json; Get-HotFix | Sort InstalledOn -Descending | Select -First 20 HotFixID,InstalledOn | ConvertTo-Json; Get-NetFirewallProfile | Select Name,Enabled | ConvertTo-Json; Get-SmbServerConfiguration | Select EnableSMB1Protocol,RequireSecuritySignature | ConvertTo-Json"
   r=ses.run_ps(ps);text=(r.std_out+r.std_err).decode(errors='replace')[:20000]
   if '"EnableSMB1Protocol":  true' in text.lower().replace('true','true'):pass
   return ({'status':'ok' if r.status_code==0 else 'partial','type':'winrm','username':uname,'inventory':text},find)
  except Exception as e:return ({'status':'failed','type':'winrm','error':str(e)[:500]},[])
 return ({'status':'unsupported'},[])

def _scan_report_pdf(scan:dict,result:dict)->bytes:
 buf=BytesIO();styles=getSampleStyleSheet();styles.add(ParagraphStyle(name='Tiny',parent=styles['BodyText'],fontSize=7,leading=9,textColor=colors.grey));doc=SimpleDocTemplate(buf,pagesize=letter,rightMargin=.55*inch,leftMargin=.55*inch,topMargin=.55*inch,bottomMargin=.55*inch,title='Hive Mind Security Pentest Scan Report');story=[]
 story += [Paragraph('HIVE MIND SECURITY - AUTHORIZED PENTEST SCAN REPORT',styles['Title']),Paragraph(scan.get('name') or scan.get('target','Assessment'),styles['Heading2']),Spacer(1,6)]
 meta=[['Scan ID',scan.get('id','')],['Target',scan.get('target','')],['Profile',scan.get('profile','')],['Credential Profile',scan.get('credential_user','') or 'None'],['Started By',scan.get('created_by','')],['Created',scan.get('created_at','')],['Status',scan.get('status','')]]
 t=Table(meta,colWidths=[1.35*inch,5.35*inch]);t.setStyle(TableStyle([('GRID',(0,0),(-1,-1),.25,colors.grey),('BACKGROUND',(0,0),(0,-1),colors.HexColor('#e6e6e6')),('VALIGN',(0,0),(-1,-1),'TOP'),('FONTNAME',(0,0),(0,-1),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),8)]));story += [t,Spacer(1,10)]
 summary=result.get('summary',{});story += [Paragraph('Executive Summary',styles['Heading2']),Paragraph(f"Hosts assessed: {summary.get('hosts',0)} &nbsp;&nbsp; Open services: {summary.get('open_ports',0)} &nbsp;&nbsp; Findings: {summary.get('findings',0)}",styles['BodyText']),Paragraph('Hive Mind performs non-exploit validation and configuration review. A clean result does not prove the target is vulnerability-free.',styles['Tiny']),Spacer(1,10)]
 for h in result.get('hosts',[]):
  story += [Paragraph('Host: '+str(h.get('host','')),styles['Heading2']),Paragraph('Open TCP services: '+(', '.join(str(x.get('port'))+'/'+x.get('service','tcp') for x in h.get('open_ports',[])) or 'None observed'),styles['BodyText'])]
  cred=h.get('credentialed',{});story += [Paragraph('Credentialed assessment: '+str(cred.get('status','not used')),styles['BodyText']),Spacer(1,5)]
  hf=h.get('findings',[])
  if not hf:story += [Paragraph('No findings generated by the enabled checks.',styles['BodyText'])]
  for i,f in enumerate(hf,1):
   story += [Paragraph(f"{i}. {f.get('title','Finding')} [{str(f.get('severity','')).upper()}]",styles['Heading3']),Paragraph((f.get('description') or '').replace('&','&amp;').replace('<','&lt;').replace('>','&gt;'),styles['BodyText']),Paragraph('<b>Evidence:</b> '+(f.get('evidence') or 'Not recorded').replace('&','&amp;').replace('<','&lt;').replace('>','&gt;'),styles['BodyText']),Paragraph('<b>Remediation:</b> '+(f.get('remediation') or '').replace('&','&amp;').replace('<','&lt;').replace('>','&gt;'),styles['BodyText']),Spacer(1,7)]
  story += [Spacer(1,10)]
 doc.build(story);return buf.getvalue()

def _run_builtin_scan(scan_id:str,x:PentestScanRequest,actor:str)->dict:
 profile=x.profile if x.profile in ('quick','standard') else 'standard';cred=_get_scan_credential(x.credential_user);targets=_scan_targets(x.target,profile,bool(cred));ports=QUICK_PORTS if profile=='quick' else STANDARD_PORTS;hosts=[];all_find=[];open_count=0
 for host in targets:
  opens=[]
  # bounded concurrency for local workstation safety
  import concurrent.futures
  with concurrent.futures.ThreadPoolExecutor(max_workers=80) as ex:
   futs=[ex.submit(_tcp_probe,host,p,.25 if profile=='standard' else .4) for p in ports]
   for f in concurrent.futures.as_completed(futs):
    r=f.result()
    if r:opens.append(r)
  opens.sort(key=lambda z:z['port']);open_count+=len(opens);find=_service_findings(host,opens);http=[];tls=[]
  for o in opens:
   if o['port'] in (80,8080):
    h,ff=_http_assess(host,o['port'],False);http.append(h);find+=ff
   if o['port'] in (443,8443):
    tls.append({'port':o['port'],**_tls_info(host,o['port'])});h,ff=_http_assess(host,o['port'],True);http.append(h);find+=ff
  cdata,cf=_credentialed_scan(host,cred);find+=cf
  # dedupe by title/evidence
  uniq=[];seen=set()
  for f in find:
   k=(f.get('title'),f.get('evidence'))
   if k not in seen:seen.add(k);uniq.append(f);all_find.append(f)
  hosts.append({'host':host,'open_ports':opens,'http':http,'tls':tls,'credentialed':cdata,'findings':uniq})
 result={'summary':{'hosts':len(hosts),'open_ports':open_count,'findings':len(all_find)},'hosts':hosts}
 with conn() as c:
  if x.import_findings:
   for f in all_find:_insert_tracked_finding(c,f,source='built-in scan')
  row=c.execute('select * from pentest_scans where id=?',(scan_id,)).fetchone();scan=dict(row) if row else {'id':scan_id,'name':x.name,'target':x.target,'profile':profile,'credential_user':x.credential_user,'created_by':actor,'created_at':''}
  scan['status']='complete';pdf=_scan_report_pdf(scan,result);rp=SCAN_REPORT_STORE/f'{scan_id}.pdf.hmsenc';rp.write_bytes(enc_bytes(pdf));_harden_private_file(rp)
  c.execute("update pentest_scans set status='complete',summary_json=?,result_enc=?,finding_count=?,report_path=?,finished_at=CURRENT_TIMESTAMP where id=?",(json.dumps(result['summary']),enc(json.dumps(result)),len(all_find),str(rp),scan_id))
 audit('pentest.scan.complete',f'{scan_id}:{x.target}:hosts={len(hosts)}:findings={len(all_find)}')
 return result

@app.get('/api/pentest-scans/credential-profiles')
def pentest_scan_credential_profiles(request:Request):
 with conn() as c:
  if getattr(request.state,'role','')=='admin':
   rows=c.execute("select u.username,sc.cred_type,sc.target_username,sc.domain from users u join scan_credentials sc on sc.username=u.username where u.enabled=1 order by u.username").fetchall()
  else:
   rows=c.execute("select u.username,sc.cred_type,sc.target_username,sc.domain from users u join scan_credentials sc on sc.username=u.username where u.enabled=1 and u.username=?",(request.state.user,)).fetchall()
 return [dict(r) for r in rows]

@app.get('/api/pentest-scans')
def pentest_scans():
 with conn() as c:return [dict(r) for r in c.execute("select id,name,target,profile,credential_user,status,summary_json,finding_count,created_by,created_at,finished_at from pentest_scans order by created_at desc limit 50").fetchall()]

@app.post('/api/pentest-scans')
def pentest_scan_start(x:PentestScanRequest,request:Request):
 if not x.authorized:raise HTTPException(400,'You must confirm that you are authorized to assess the target.')
 if x.credential_user:
  if getattr(request.state,'role','')!='admin' and x.credential_user!=request.state.user:raise HTTPException(403,'Analysts may use only their own configured scan credential profile.')
  with conn() as c:u=c.execute('select username from users where username=?',(x.credential_user,)).fetchone()
  if not u:raise HTTPException(400,'Selected credential user does not exist.')
  if not _get_scan_credential(x.credential_user):raise HTTPException(400,'Selected user does not have scan credentials configured.')
 # validate and bound scope before writing
 profile=x.profile if x.profile in ('quick','standard') else 'standard';_scan_targets(x.target,profile,bool(x.credential_user));sid=uuid.uuid4().hex[:24];name=(x.name.strip() or f'Assessment {x.target}')[:240]
 with conn() as c:c.execute('insert into pentest_scans(id,name,target,profile,credential_user,status,created_by) values(?,?,?,?,?,?,?)',(sid,name,x.target.strip(),profile,x.credential_user,'running',request.state.user))
 audit('pentest.scan.start',f'{sid}:{x.target}:{profile}:credential={x.credential_user or "none"}')
 try:r=_run_builtin_scan(sid,x,request.state.user)
 except Exception as e:
  with conn() as c:c.execute("update pentest_scans set status='failed',summary_json=?,finished_at=CURRENT_TIMESTAMP where id=?",(json.dumps({'error':str(e)[:1000]}),sid))
  audit('pentest.scan.failed',f'{sid}:{str(e)[:300]}');raise HTTPException(500,'Scan failed: '+str(e)[:500])
 return {'ok':True,'scan_id':sid,'summary':r['summary']}

@app.get('/api/pentest-scans/{scan_id}')
def pentest_scan_detail(scan_id:str):
 with conn() as c:r=c.execute('select * from pentest_scans where id=?',(scan_id,)).fetchone()
 if not r:raise HTTPException(404,'Scan not found.')
 d=dict(r);d['result']=json.loads(dec(d.pop('result_enc','')) or '{}');return d

@app.get('/api/pentest-scans/{scan_id}/report')
def pentest_scan_report(scan_id:str):
 with conn() as c:r=c.execute('select report_path,name from pentest_scans where id=?',(scan_id,)).fetchone()
 if not r or not r['report_path']:raise HTTPException(404,'Scan report not available.')
 path=Path(r['report_path'])
 if not path.exists():raise HTTPException(404,'Encrypted scan report file is missing.')
 raw=dec_bytes(path.read_bytes());fname=re.sub(r'[^A-Za-z0-9_.-]+','_',r['name'])[:80]+'_pentest_report.pdf'
 return StreamingResponse(BytesIO(raw),media_type='application/pdf',headers={'Content-Disposition':f'inline; filename="{fname}"'})

@app.delete('/api/pentest-scans/{scan_id}')
def pentest_scan_delete(scan_id:str):
 with conn() as c:
  r=c.execute('select report_path,target from pentest_scans where id=?',(scan_id,)).fetchone()
  if not r:raise HTTPException(404,'Scan not found.')
  if r['report_path']:
   try:Path(r['report_path']).unlink(missing_ok=True)
   except Exception:pass
  c.execute("delete from attack_mappings where record_type in ('pentest_scan','pentest_service') and (record_id=? or record_id like ?)",(str(scan_id),str(scan_id)+':%'))
  c.execute('delete from pentest_scans where id=?',(scan_id,))
 audit('pentest.scan.delete',f'{scan_id}:{r["target"]}:ATT&CK correlations cleaned');return {'ok':True}


# ---- Connected Security Operations / Exposure Management 0.7.0 ----
def _rows(sql,args=()):
 with conn() as c:return [dict(r) for r in c.execute(sql,args).fetchall()]
def _one(sql,args=()):
 with conn() as c:
  r=c.execute(sql,args).fetchone();return dict(r) if r else None

def _asset_matches(name:str):
 q=(name or '').strip().lower()
 if not q:return []
 return _rows("select * from assets where lower(name)=? or lower(location)=? order by id desc",(q,q))

@app.get('/api/exposure/summary')
async def exposure_summary():
 assets=_rows('select * from assets order by id desc'); vulns=_rows("select * from vulnerabilities where status not in ('closed','remediated') order by id desc"); tracked=_rows("select id,title,severity,status,asset,cve,owner,due_date,source,created_at from tracked_findings where status not in ('closed','remediated','fixed') order by id desc")
 kev_rows=await kev(250); kev_list=kev_rows if isinstance(kev_rows,list) else kev_rows.get('vulnerabilities',[]); kev_ids={str(x.get('cveID','')).upper():x for x in kev_list}
 exposures=[]
 for v in vulns+tracked:
  cve=str(v.get('cve') or '').upper(); asset=v.get('asset') or ''; sev=(v.get('severity') or 'medium').lower(); k=kev_ids.get(cve)
  score={'critical':4,'high':3,'medium':2,'low':1}.get(sev,1)+(4 if k else 0)
  exposures.append({**v,'cisa_kev':bool(k),'kev':k,'priority_score':score,'asset_records':_asset_matches(asset)})
 exposures.sort(key=lambda x:x['priority_score'],reverse=True)
 return {'assets':len(assets),'open_exposures':len(exposures),'kev_matches':sum(1 for x in exposures if x['cisa_kev']),'critical':sum(1 for x in exposures if str(x.get('severity')).lower()=='critical'),'items':exposures[:250]}

@app.get('/api/assets/{asset_id}/intelligence')
def asset_intelligence(asset_id:int):
 a=_one('select * from assets where id=?',(asset_id,))
 if not a:raise HTTPException(404,'Asset not found')
 names={str(a.get('name','')).lower(),str(a.get('location','')).lower()}; names.discard('')
 scans=[]
 for r in _rows("select id,name,target,profile,status,summary_json,finding_count,created_at,finished_at from pentest_scans order by created_at desc limit 100"):
  if str(r.get('target','')).lower() in names: scans.append(r)
 v=[]
 for r in _rows('select * from vulnerabilities order by id desc'):
  if str(r.get('asset','')).lower() in names:v.append(r)
 f=[]
 for r in _rows("select id,title,severity,status,asset,cve,owner,due_date,source,created_at from tracked_findings order by id desc"):
  if str(r.get('asset','')).lower() in names:f.append(r)
 inv=[]
 for r in _rows('select * from investigations order by id desc'):
  text=' '.join(str(r.get(k,'') or '') for k in ('title','summary','iocs','timeline')).lower()
  if any(n in text for n in names):inv.append(r)
 notes=_rows('select * from asset_notes where asset_id=? order by id desc',(asset_id,))
 return {'asset':a,'scans':scans,'vulnerabilities':v,'findings':f,'investigations':inv,'notes':notes}

@app.post('/api/assets/{asset_id}/notes')
def add_asset_note(asset_id:int,x:AssetNote):
 if not _one('select id from assets where id=?',(asset_id,)):raise HTTPException(404,'Asset not found')
 with conn() as c:c.execute('insert into asset_notes(asset_id,note,created_by) values(?,?,?)',(asset_id,x.note[:8000],CURRENT_USER.get()))
 audit('asset.note.create',f'{asset_id}:{x.note[:120]}');return {'ok':True}
@app.delete('/api/assets/{asset_id}/notes/{note_id}')
def delete_asset_note(asset_id:int,note_id:int):
 with conn() as c:c.execute('delete from asset_notes where id=? and asset_id=?',(note_id,asset_id))
 audit('asset.note.delete',f'{asset_id}:{note_id}');return {'ok':True}

@app.get('/api/watchlists')
def get_watchlists():return _rows('select * from watchlists order by id desc')
@app.post('/api/watchlists')
def add_watchlist(x:WatchItem):
 with conn() as c:c.execute('insert into watchlists(kind,value,label,severity,status,notes) values(?,?,?,?,?,?)',(x.kind,x.value.strip(),x.label,x.severity,x.status,x.notes))
 audit('watchlist.create',x.value);return {'ok':True}
@app.put('/api/watchlists/{rid}')
def edit_watchlist(rid:int,x:WatchItem):
 with conn() as c:c.execute('update watchlists set kind=?,value=?,label=?,severity=?,status=?,notes=?,updated_at=CURRENT_TIMESTAMP where id=?',(x.kind,x.value.strip(),x.label,x.severity,x.status,x.notes,rid))
 audit('watchlist.update',rid);return {'ok':True}
@app.delete('/api/watchlists/{rid}')
def del_watchlist(rid:int):
 with conn() as c:c.execute('delete from watchlists where id=?',(rid,))
 audit('watchlist.delete',rid);return {'ok':True}
@app.get('/api/watchlists/matches')
async def watch_matches():
 ws=_rows("select * from watchlists where status='active'"); matches=[]
 threat=await threat_map(False); newsd=await news(90); kevdata=await kev(250); kevlist=kevdata if isinstance(kevdata,list) else kevdata.get('vulnerabilities',[])
 corpus=[('Threat Activity',json.dumps(x),x) for x in threat.get('events',[])]+[('Cyber News',json.dumps(x),x) for x in newsd.get('items',[])]+[('CISA KEV',json.dumps(x),x) for x in kevlist]
 for w in ws:
  val=w['value'].lower()
  for src,text,obj in corpus:
   if val and val in text.lower():matches.append({'watch_id':w['id'],'value':w['value'],'source':src,'match':obj})
 return {'matches':matches[:200],'checked':len(ws)}

@app.get('/api/scheduled-scans')
def scheduled_scans():return _rows('select * from scheduled_scans order by id desc')
@app.post('/api/scheduled-scans')
def scheduled_add(x:ScheduledScan):
 profile=x.profile if x.profile in ('quick','standard') else 'quick';_scan_targets(x.target,profile,bool(x.credential_user)); nxt=datetime.now(timezone.utc).isoformat()
 with conn() as c:c.execute('insert into scheduled_scans(name,target,profile,credential_user,interval_hours,enabled,next_run) values(?,?,?,?,?,?,?)',(x.name,x.target,profile,x.credential_user,x.interval_hours,1 if x.enabled else 0,nxt))
 audit('scheduled_scan.create',f'{x.name}:{x.target}');return {'ok':True}
@app.put('/api/scheduled-scans/{rid}')
def scheduled_edit(rid:int,x:ScheduledScan):
 profile=x.profile if x.profile in ('quick','standard') else 'quick';_scan_targets(x.target,profile,bool(x.credential_user))
 with conn() as c:c.execute('update scheduled_scans set name=?,target=?,profile=?,credential_user=?,interval_hours=?,enabled=? where id=?',(x.name,x.target,profile,x.credential_user,x.interval_hours,1 if x.enabled else 0,rid))
 audit('scheduled_scan.update',rid);return {'ok':True}
@app.delete('/api/scheduled-scans/{rid}')
def scheduled_delete(rid:int):
 with conn() as c:c.execute('delete from scheduled_scans where id=?',(rid,))
 audit('scheduled_scan.delete',rid);return {'ok':True}
@app.post('/api/scheduled-scans/{rid}/run')
def scheduled_run(rid:int,request:Request):
 row=_one('select * from scheduled_scans where id=?',(rid,));
 if not row:raise HTTPException(404,'Schedule not found')
 req=PentestScanRequest(name=row['name'],target=row['target'],profile=row['profile'],credential_user=row['credential_user'],authorized=True,import_findings=True)
 result=pentest_scan_start(req,request)
 now=datetime.now(timezone.utc); nxt=datetime.fromtimestamp(now.timestamp()+int(row['interval_hours'])*3600,timezone.utc).isoformat()
 with conn() as c:c.execute('update scheduled_scans set last_run=?,next_run=? where id=?',(now.isoformat(),nxt,rid))
 return result

@app.get('/api/evidence')
def evidence(investigation_id:int=0):
 sql='select id,investigation_id,name,kind,sha256,created_by,created_at from evidence_items';args=()
 if investigation_id:sql+=' where investigation_id=?';args=(investigation_id,)
 return _rows(sql+' order by id desc',args)
@app.post('/api/evidence/note')
def evidence_note(x:EvidenceNote):
 raw=x.notes.encode();sha=hashlib.sha256(raw).hexdigest()
 with conn() as c:c.execute("insert into evidence_items(investigation_id,name,kind,sha256,notes_enc,created_by) values(?,?,?,?,?,?)",(x.investigation_id,x.name,'note',sha,enc(x.notes),CURRENT_USER.get()))
 audit('evidence.note.create',f'{x.investigation_id}:{x.name}:{sha}');return {'ok':True,'sha256':sha}
@app.post('/api/evidence/upload')
async def evidence_upload(file:UploadFile=File(...),investigation_id:int=0):
 raw=await file.read();
 if len(raw)>40*1024*1024:raise HTTPException(413,'Evidence file exceeds 40 MB limit')
 eid=uuid.uuid4().hex;sha=hashlib.sha256(raw).hexdigest();path=DATA/'evidence';path.mkdir(exist_ok=True);fp=path/f'{eid}.hmsenc';fp.write_bytes(enc_bytes(raw));_harden_private_file(fp)
 with conn() as c:c.execute('insert into evidence_items(investigation_id,name,kind,sha256,encrypted_path,created_by) values(?,?,?,?,?,?)',(investigation_id,(file.filename or 'evidence')[:240],'file',sha,str(fp),CURRENT_USER.get()))
 audit('evidence.file.create',f'{investigation_id}:{file.filename}:{sha}');return {'ok':True,'sha256':sha}
@app.put('/api/evidence/{rid}')
def evidence_edit(rid:int,x:EvidenceNote):
 row=_one('select * from evidence_items where id=?',(rid,))
 if not row:raise HTTPException(404,'Evidence not found')
 if row.get('kind')!='note':raise HTTPException(400,'Uploaded evidence files are immutable; replace the file instead of editing its bytes.')
 raw=x.notes.encode();sha=hashlib.sha256(raw).hexdigest()
 with conn() as c:c.execute('update evidence_items set investigation_id=?,name=?,sha256=?,notes_enc=? where id=?',(x.investigation_id,x.name,sha,enc(x.notes),rid))
 audit('evidence.note.update',f'{rid}:{x.name}:{sha}');return {'ok':True,'sha256':sha}

@app.delete('/api/evidence/{rid}')
def evidence_delete(rid:int):
 row=_one('select * from evidence_items where id=?',(rid,));
 if not row:raise HTTPException(404,'Evidence not found')
 if row.get('encrypted_path'):
  try:Path(row['encrypted_path']).unlink(missing_ok=True)
  except Exception:pass
 with conn() as c:c.execute('delete from evidence_items where id=?',(rid,))
 audit('evidence.delete',f'{rid}:{row["name"]}:{row["sha256"]}');return {'ok':True}

@app.get('/api/detections')
def detections():return _rows('select * from detections order by id desc')
@app.post('/api/detections')
def detection_add(x:DetectionRule):
 with conn() as c:c.execute('insert into detections(name,kind,attack_id,status,content,notes) values(?,?,?,?,?,?)',(x.name,x.kind,x.attack_id,x.status,x.content,x.notes))
 audit('detection.create',x.name);return {'ok':True}
@app.put('/api/detections/{rid}')
def detection_edit(rid:int,x:DetectionRule):
 with conn() as c:c.execute('update detections set name=?,kind=?,attack_id=?,status=?,content=?,notes=?,updated_at=CURRENT_TIMESTAMP where id=?',(x.name,x.kind,x.attack_id,x.status,x.content,x.notes,rid))
 audit('detection.update',rid);return {'ok':True}
@app.delete('/api/detections/{rid}')
def detection_delete(rid:int):
 with conn() as c:c.execute('delete from detections where id=?',(rid,))
 audit('detection.delete',rid);return {'ok':True}
ATTACK_CATALOG={
 'T1190':('Exploit Public-Facing Application','Initial Access'),
 'T1133':('External Remote Services','Persistence / Initial Access'),
 'T1078':('Valid Accounts','Defense Evasion / Persistence / Privilege Escalation / Initial Access'),
 'T1110':('Brute Force','Credential Access'),
 'T1021.001':('Remote Services: Remote Desktop Protocol','Lateral Movement'),
 'T1021.002':('Remote Services: SMB/Windows Admin Shares','Lateral Movement'),
 'T1021.004':('Remote Services: SSH','Lateral Movement'),
 'T1021.006':('Remote Services: Windows Remote Management','Lateral Movement'),
 'T1219':('Remote Access Software','Command and Control'),
 'T1059.001':('Command and Scripting Interpreter: PowerShell','Execution'),
 'T1059.003':('Command and Scripting Interpreter: Windows Command Shell','Execution'),
 'T1053.005':('Scheduled Task/Job: Scheduled Task','Execution / Persistence / Privilege Escalation'),
 'T1543.003':('Create or Modify System Process: Windows Service','Persistence / Privilege Escalation'),
 'T1547.001':('Boot or Logon Autostart Execution: Registry Run Keys / Startup Folder','Persistence / Privilege Escalation'),
 'T1562.001':('Impair Defenses: Disable or Modify Tools','Defense Evasion'),
 'T1562.002':('Impair Defenses: Disable Windows Event Logging','Defense Evasion'),
 'T1562.004':('Impair Defenses: Disable or Modify System Firewall','Defense Evasion'),
 'T1087.001':('Account Discovery: Local Account','Discovery'),
 'T1040':('Network Sniffing','Credential Access / Discovery'),
 'T1552.001':('Unsecured Credentials: Credentials In Files','Credential Access'),
 'T1003':('OS Credential Dumping','Credential Access'),
 'T1046':('Network Service Discovery','Discovery'),
 'T1082':('System Information Discovery','Discovery'),
 'T1083':('File and Directory Discovery','Discovery'),
 'T1018':('Remote System Discovery','Discovery'),
 'T1057':('Process Discovery','Discovery'),
 'T1518.001':('Software Discovery: Security Software Discovery','Discovery'),
 'T1112':('Modify Registry','Defense Evasion / Persistence'),
 'T1098':('Account Manipulation','Persistence / Privilege Escalation'),
 'T1531':('Account Access Removal','Impact'),
 'T1486':('Data Encrypted for Impact','Impact'),
 'T1567':('Exfiltration Over Web Service','Exfiltration'),
}

def _attack_add(out,record_type,record_id,source,asset,tid,relation,confidence,reason,evidence=''):
 if tid not in ATTACK_CATALOG:return
 name,tactic=ATTACK_CATALOG[tid]
 out.append({'record_type':str(record_type),'record_id':str(record_id),'source':str(source or ''),'asset':str(asset or ''),'technique_id':tid,'technique_name':name,'tactic':tactic,'relation':relation,'confidence':confidence,'reason':str(reason or '')[:1200],'evidence':str(evidence or '')[:1600]})

def _attack_candidates(record_type,record_id,source,asset,text,relation='exposed'):
 """Deterministic ATT&CK candidate mapper. Exposure/control relationships are not proof of compromise."""
 t=(text or '').lower(); out=[]
 def add(tid,confidence,reason):_attack_add(out,record_type,record_id,source,asset,tid,relation,confidence,reason,text)
 if re.search(r'\brdp\b|remote desktop|3389',t):add('T1021.001','high','RDP exposure or configuration is directly relevant to Remote Desktop Protocol lateral movement.')
 if re.search(r'\bsmb\b|windows admin shares|445|cifs',t):add('T1021.002','high','SMB exposure/configuration is directly relevant to SMB/Windows Admin Shares lateral movement.')
 if re.search(r'\bssh\b|tcp/22|port 22',t):add('T1021.004','high','SSH exposure or configuration is directly relevant to SSH remote services.')
 if re.search(r'\bwinrm\b|windows remote management|5985|5986',t):add('T1021.006','high','WinRM exposure/configuration is directly relevant to Windows Remote Management.')
 if re.search(r'\bvnc\b|5900|remote access software',t):add('T1219','medium','Remote access software exposure can provide interactive remote control capability.')
 if re.search(r'vpn|external remote service|remote access gateway|citrix|rd gateway',t):add('T1133','medium','External remote-access services can form an initial-access or persistence path.')
 if re.search(r'public[- ]facing|web application|web server|http service|https service|apache|nginx|iis|tomcat|wordpress|cve-\d{4}-\d+',t):add('T1190','medium','A vulnerable or exposed public-facing application can provide an initial-access path.')
 if re.search(r'open port|service reachable|service exposed|tcp/\d+|network service',t):add('T1046','medium','Reachable services expose network-service information useful to service discovery.')
 if re.search(r'password policy|account lockout|lockout threshold|weak password|brute force|password guessing',t):add('T1110','high','Weak password or lockout controls can increase susceptibility to brute-force activity.')
 if re.search(r'guest account|default account|valid account|shared account|stale account|inactive account',t):add('T1078','medium','Account-control weakness may make valid-account abuse easier.')
 if re.search(r'anonymous sam|enumerat.*account|sam account|local account enumeration',t):add('T1087.001','high','Anonymous/local account enumeration is directly relevant to Local Account Discovery.')
 if re.search(r'credential.*file|password.*file|plaintext credential|clear text credential|hardcoded credential',t):add('T1552.001','high','Credentials stored in files can enable Unsecured Credentials discovery.')
 if re.search(r'credential dump|lsass|sam database|ntds',t):add('T1003','medium','The finding references credential-dumping targets or controls.')
 if re.search(r'windows event log|event logging|audit log|audit policy|logging disabled|logon audit',t):add('T1562.002','high','Insufficient Windows event logging creates a defense-evasion visibility gap.')
 if re.search(r'firewall.*disabled|windows firewall|firewall profile|system firewall',t):add('T1562.004','high','A disabled or weakened system firewall creates a control gap relevant to firewall impairment.')
 if re.search(r'defender.*disabled|antivirus.*disabled|endpoint protection.*disabled|security tool.*disabled|tamper protection',t):add('T1562.001','high','Disabled or weakened endpoint security creates a control gap relevant to impairing defenses.')
 if re.search(r'powershell|script block logging|4104',t):add('T1059.001','high','PowerShell configuration/telemetry directly affects visibility for PowerShell execution.')
 if re.search(r'scheduled task|task scheduler',t):add('T1053.005','high','Scheduled Task configuration or evidence is directly relevant to Scheduled Task execution/persistence.')
 if re.search(r'windows service|service creation|service control manager|sc.exe',t):add('T1543.003','medium','Windows service configuration/evidence is relevant to service-based persistence or privilege escalation.')
 if re.search(r'run key|startup folder|autorun|auto run|autostart',t):add('T1547.001','high','Run-key/startup configuration is relevant to logon autostart persistence.')
 if re.search(r'registry modification|registry key|regedit|reg add',t):add('T1112','medium','Registry-related control/evidence can be relevant to registry modification activity.')
 if re.search(r'system information|hostname|os version|operating system discovery',t):add('T1082','medium','The finding references system-information discovery.')
 if re.search(r'file and directory discovery|directory listing|sensitive file enumeration',t):add('T1083','medium','The finding references file/directory discovery.')
 if re.search(r'process discovery|process enumeration|running processes',t):add('T1057','medium','The finding references process discovery.')
 if re.search(r'security software discovery|antivirus discovery|edr discovery',t):add('T1518.001','medium','The finding references discovery of defensive software.')
 if re.search(r'ransomware|encrypted for impact|file encryption',t):add('T1486','high','The finding/report references encryption of data for impact.')
 if re.search(r'exfiltrat|data transfer to web service|cloud upload',t):add('T1567','medium','The finding/report references exfiltration over web-accessible services.')
 if re.search(r'telnet|plaintext protocol|cleartext protocol|unencrypted http|\bftp\b',t):add('T1040','medium','Cleartext network protocols can expose traffic to network sniffing.')
 return out

def _attack_source_exists(c,record_type,record_id):
 """Return True only when a derived ATT&CK mapping still has a live source record."""
 rt=str(record_type or ''); rid=str(record_id or '')
 try:
  if rt=='stig': return bool(c.execute('select 1 from stig_findings where id=?',(int(rid),)).fetchone())
  if rt=='tracked_finding': return bool(c.execute('select 1 from tracked_findings where id=?',(int(rid),)).fetchone())
  if rt in ('pentest_scan','pentest_service'):
   sid=rid.split(':',1)[0]; return bool(c.execute('select 1 from pentest_scans where id=?',(sid,)).fetchone())
  if rt=='team_finding': return bool(c.execute('select 1 from team_findings where id=?',(int(rid),)).fetchone())
  if rt=='purple_test': return bool(c.execute('select 1 from purple_tests where id=?',(int(rid),)).fetchone())
  if rt=='osiris_event': return bool(c.execute('select 1 from osiris_events where id=?',(rid,)).fetchone())
  # Unknown/future record types are preserved instead of being guessed orphaned.
  return True
 except Exception:
  return False

ATTACK_DERIVED_SOURCE_TYPES=('stig','tracked_finding','pentest_scan','pentest_service','team_finding','purple_test','osiris_event')

def _cleanup_orphan_attack_mappings(detail=False):
 """Remove ATT&CK mappings whose real source record has been deleted.

 This intentionally checks both automatic and analyst-reviewed mappings. A reviewed mapping
 stays only while its source record still exists. Unknown/future record types are preserved.
 """
 removed=[]; by_source={}
 with conn() as c:
  ph=','.join('?' for _ in ATTACK_DERIVED_SOURCE_TYPES)
  rows=c.execute(f"select id,record_type,record_id,auto_generated from attack_mappings where record_type in ({ph})",ATTACK_DERIVED_SOURCE_TYPES).fetchall()
  for r in rows:
   if not _attack_source_exists(c,r['record_type'],r['record_id']):
    removed.append(r['id']);by_source[r['record_type']]=by_source.get(r['record_type'],0)+1
  if removed:
   q=','.join('?' for _ in removed);c.execute(f'delete from attack_mappings where id in ({q})',removed)
 result={'removed':len(removed),'by_source':by_source,'ids':removed}
 return result if detail else result['removed']

def _attack_cleanup_orphans():
 """Remove only mappings whose source record no longer exists.

 Coverage reads never rebuild mappings. This prevents a page refresh from silently
 recreating correlations after an analyst intentionally cleared generated coverage.
 """
 with conn() as c:
  before=c.execute('select count(*) from attack_mappings').fetchone()[0]
 result=_cleanup_orphan_attack_mappings(detail=True)
 with conn() as c:
  after=c.execute('select count(*) from attack_mappings').fetchone()[0]
 return {'ok':True,'before':before,'after':after,'removed_orphans':result['removed'],'orphan_sources':result['by_source']}

def _attack_clear_auto():
 """Clear auto-generated ATT&CK correlations without rebuilding them.
 Analyst-reviewed/manual mappings are retained. Rebuild Correlation is an explicit action.
 """
 with conn() as c:
  before=c.execute('select count(*) from attack_mappings').fetchone()[0]
  auto=c.execute('select count(*) from attack_mappings where auto_generated=1').fetchone()[0]
  c.execute('delete from attack_mappings where auto_generated=1')
  after=c.execute('select count(*) from attack_mappings').fetchone()[0]
 return {'ok':True,'before':before,'after':after,'removed_auto':auto}

def _persist_attack_mappings(items,replace_auto=False):
 with conn() as c:
  if replace_auto:c.execute('delete from attack_mappings where auto_generated=1')
  for m in items:
   c.execute("""insert into attack_mappings(record_type,record_id,source,asset,technique_id,technique_name,tactic,relation,confidence,reason,evidence,status,auto_generated)
    values(?,?,?,?,?,?,?,?,?,?,?,?,1)
    on conflict(record_type,record_id,technique_id,relation) do update set source=excluded.source,asset=excluded.asset,technique_name=excluded.technique_name,tactic=excluded.tactic,confidence=excluded.confidence,reason=excluded.reason,evidence=excluded.evidence,updated_at=CURRENT_TIMESTAMP""",
    (m['record_type'],m['record_id'],m['source'],m['asset'],m['technique_id'],m['technique_name'],m['tactic'],m['relation'],m['confidence'],m['reason'],m['evidence'],'active'))

def _rebuild_attack_correlations():
 _cleanup_orphan_attack_mappings()
 items=[]
 for r in _rows("select * from osiris_events where feed in ('cyber-attacks','malware') order by last_seen desc limit 500"):
  text=' '.join(str(r.get(k,'') or '') for k in ('kind','title','indicator','summary','raw_json'))
  items += _attack_candidates('osiris_event',r['id'],'OSIRIS '+r.get('feed',''),r.get('indicator',''),text,'observed' if r.get('feed')=='cyber-attacks' else 'suggested')
 for r in _rows("select * from stig_findings where lower(status) not in ('not a finding','not_applicable','not applicable','closed','fixed','remediated')"):
  text=' '.join(str(r.get(k,'') or '') for k in ('title','rule_id','vuln_id','finding_details','remediation','comments','benchmark'))
  items += _attack_candidates('stig',r['id'],r.get('source') or 'STIG',r.get('asset',''),text,'control_gap')
 with conn() as c: tf=[_finding_row(x) for x in c.execute("select * from tracked_findings where lower(status) not in ('closed','fixed','remediated')").fetchall()]
 for r in tf:
  text=' '.join(str(r.get(k,'') or '') for k in ('title','category','cve','cwe','description','evidence','remediation'))
  rel='suggested' if str(r.get('source','')).lower()=='local-ai' else 'exposed'
  items += _attack_candidates('tracked_finding',r['id'],r.get('source') or 'finding',r.get('asset',''),text,rel)
 with conn() as c: scans=c.execute("select * from pentest_scans where status='complete' and result_enc<>''").fetchall()
 for row in scans:
  d=dict(row)
  try: result=json.loads(dec(d.get('result_enc','')) or '{}')
  except Exception: result={}
  for hi,h in enumerate(result.get('hosts',[]) or []):
   host=h.get('host') or d.get('target','')
   for fi,f in enumerate(h.get('findings',[]) or []):
    text=' '.join(str(f.get(k,'') or '') for k in ('title','category','description','evidence','remediation'))
    items += _attack_candidates('pentest_scan',f"{d['id']}:{hi}:{fi}",'built-in scan',host,text,'exposed')
   for op in h.get('open_ports',[]) or []:
    text=f"open port tcp/{op.get('port')} {op.get('service','')} service reachable"
    items += _attack_candidates('pentest_service',f"{d['id']}:{host}:{op.get('port')}",'built-in scan',host,text,'exposed')
 for r in _rows("select * from team_findings where attack_id<>''"):
  for tid in re.findall(r'T\d{4}(?:\.\d{3})?',str(r.get('attack_id','')).upper()):
   _attack_add(items,'team_finding',r['id'],r.get('team','team'),r.get('asset',''),tid,'observed','high','Explicit ATT&CK mapping recorded on a team finding.',r.get('evidence',''))
 for r in _rows("select * from purple_tests where technique<>''"):
  for tid in re.findall(r'T\d{4}(?:\.\d{3})?',str(r.get('technique','')).upper()):
   _attack_add(items,'purple_test',r['id'],'purple','',tid,'validated','high','Explicit Purple Team validation mapping.',r.get('observed',''))
 _persist_attack_mappings(items,replace_auto=True)
 return len(items)

def _attack_detection_counts():
 out={}
 for r in _rows("select * from detections where attack_id<>''"):
  for tid in re.findall(r'T\d{4}(?:\.\d{3})?',str(r.get('attack_id','')).upper()):out[tid]=out.get(tid,0)+1
 return out

@app.post('/api/attack/correlate')
def attack_correlate():
 n=_rebuild_attack_correlations();audit('attack.correlate',n);return {'ok':True,'mapped_candidates':n}

@app.post('/api/attack/cleanup')
def attack_cleanup():
 result=_attack_cleanup_orphans()
 audit('attack.cleanup',f"before={result['before']}; orphans={result['removed_orphans']}; after={result['after']}")
 return result

@app.post('/api/attack/clear-auto')
def attack_clear_auto():
 result=_attack_clear_auto()
 audit('attack.clear_auto',f"before={result['before']}; removed_auto={result['removed_auto']}; after={result['after']}")
 return result

@app.get('/api/attack/coverage')
def attack_coverage():
 _cleanup_orphan_attack_mappings()
 mappings=_rows("select * from attack_mappings where status!='dismissed' order by technique_id,confidence desc,id desc")
 det=_attack_detection_counts(); by={}
 for m in mappings:by.setdefault(m['technique_id'],[]).append(m)
 techniques=[]
 for tid,v in sorted(by.items()):
  name,tactic=ATTACK_CATALOG.get(tid,(v[0].get('technique_name',''),v[0].get('tactic','')))
  techniques.append({'technique':tid,'name':name,'tactic':tactic,'mappings':len(v),'observed':sum(x['relation']=='observed' for x in v),'exposed':sum(x['relation']=='exposed' for x in v),'control_gaps':sum(x['relation']=='control_gap' for x in v),'suggested':sum(x['relation']=='suggested' for x in v),'validated':sum(x['relation']=='validated' for x in v),'detections':det.get(tid,0),'items':v})
 assets={}
 for m in mappings:
  a=m.get('asset') or '(unassigned asset)';assets.setdefault(a,[]).append(m)
 vectors=[]
 for asset,v in assets.items():
  relations={k:sum(x['relation']==k for x in v) for k in ('observed','exposed','control_gap','suggested','validated')}
  vectors.append({'asset':asset,'risk_score':sum({'high':3,'medium':2,'low':1}.get(str(x.get('confidence','')).lower(),1) for x in v),'relations':relations,'techniques':sorted(set(x['technique_id'] for x in v)),'items':v})
 vectors.sort(key=lambda x:x['risk_score'],reverse=True)
 source_counts={}
 for m in mappings:
  key=str(m.get('record_type') or 'unknown')
  source_counts[key]=source_counts.get(key,0)+1
 return {'techniques':techniques,'vectors':vectors,'mappings':mappings,'source_counts':source_counts,'summary':{'techniques':len(techniques),'mappings':len(mappings),'assets':len(vectors),'detections':sum(det.values()),'control_gaps':sum(x['relation']=='control_gap' for x in mappings),'exposures':sum(x['relation']=='exposed' for x in mappings),'validated':sum(x['relation']=='validated' for x in mappings),'suggested':sum(x['relation']=='suggested' for x in mappings)}}


@app.on_event('startup')
def _startup_attack_reconcile():
 # One repair/sync pass on every launch upgrades existing 0.7.x data without requiring a button click.
 try:
  _cleanup_orphan_imported_findings()
  _rebuild_attack_correlations()
 except Exception as e:
  print('ATT&CK startup reconciliation warning:',str(e)[:240])

@app.patch('/api/attack/mappings/{rid}')
def attack_mapping_edit(rid:int,x:dict):
 allowed_relation={'observed','exposed','control_gap','suggested','validated'}; allowed_status={'active','approved','dismissed'}
 relation=str(x.get('relation','')).strip().lower();status=str(x.get('status','')).strip().lower();note=str(x.get('analyst_note',''))[:2000]
 with conn() as c:
  r=c.execute('select * from attack_mappings where id=?',(rid,)).fetchone()
  if not r:raise HTTPException(404,'Mapping not found')
  c.execute('update attack_mappings set relation=?,status=?,analyst_note=?,auto_generated=0,updated_at=CURRENT_TIMESTAMP where id=?',(relation if relation in allowed_relation else r['relation'],status if status in allowed_status else r['status'],note,rid))
 audit('attack.mapping.update',rid);return {'ok':True}

@app.delete('/api/attack/mappings/{rid}')
def attack_mapping_delete(rid:int):
 with conn() as c:c.execute('delete from attack_mappings where id=?',(rid,))
 audit('attack.mapping.delete',rid);return {'ok':True}

@app.get('/api/notifications')
def notification_data():return {'rules':_rows('select * from notification_rules order by id desc'),'events':_rows('select * from notification_events order by id desc limit 100')}
@app.post('/api/notifications/rules')
def notification_add(x:NotificationRule):
 with conn() as c:c.execute('insert into notification_rules(name,event_type,severity,enabled,channel) values(?,?,?,?,?)',(x.name,x.event_type,x.severity,1 if x.enabled else 0,x.channel))
 audit('notification_rule.create',x.name);return {'ok':True}
@app.put('/api/notifications/rules/{rid}')
def notification_edit(rid:int,x:NotificationRule):
 with conn() as c:c.execute('update notification_rules set name=?,event_type=?,severity=?,enabled=?,channel=? where id=?',(x.name,x.event_type,x.severity,1 if x.enabled else 0,x.channel,rid))
 audit('notification_rule.update',rid);return {'ok':True}
@app.delete('/api/notifications/rules/{rid}')
def notification_delete(rid:int):
 with conn() as c:c.execute('delete from notification_rules where id=?',(rid,))
 audit('notification_rule.delete',rid);return {'ok':True}
@app.post('/api/notifications/evaluate')
async def notification_evaluate():
 rules=_rows('select * from notification_rules where enabled=1');created=0
 exp=await exposure_summary()
 for rule in rules:
  candidates=[]
  if rule['event_type']=='critical_finding':candidates=[x for x in exp['items'] if str(x.get('severity')).lower()=='critical']
  elif rule['event_type']=='kev_match':candidates=[x for x in exp['items'] if x.get('cisa_kev')]
  for x in candidates[:20]:
   title=f"{rule['event_type']}: {x.get('cve') or x.get('title')}"
   with conn() as c:
    exists=c.execute('select id from notification_events where rule_id=? and title=?',(rule['id'],title)).fetchone()
    if not exists:c.execute('insert into notification_events(rule_id,event_type,title,detail) values(?,?,?,?)',(rule['id'],rule['event_type'],title,json.dumps({'asset':x.get('asset'),'severity':x.get('severity')})));created+=1
 audit('notifications.evaluate',created);return {'ok':True,'created':created}
@app.delete('/api/notifications/events/{rid}')
def notification_event_delete(rid:int):
 with conn() as c:c.execute('delete from notification_events where id=?',(rid,))
 audit('notification_event.delete',rid);return {'ok':True}

# Pentest Report Studio -------------------------------------------------------
PENTEST_REPORT_SECTIONS=['executive_summary','scope','objectives','methodology','attack_surface','risk_summary','findings_narrative','remediation_roadmap','conclusion','limitations']
def _studio_sections(raw='')->dict:
 try:d=json.loads(dec(raw) if raw else '{}')
 except Exception:d={}
 return {k:str(d.get(k,'')) for k in PENTEST_REPORT_SECTIONS}
def _studio_project_row(r)->dict:
 d=dict(r);d['sections']=_studio_sections(d.pop('sections_enc',''));return d
def _project_get(project_id:str):
 with conn() as c:r=c.execute('select * from pentest_report_projects where id=?',(project_id,)).fetchone()
 if not r:raise HTTPException(404,'Pentest report project not found')
 return _studio_project_row(r)
def _studio_source_row(r)->dict:
 d=dict(r);d['has_text']=bool(d.get('text_enc'));d.pop('text_enc',None);d.pop('encrypted_path',None);return d

def _project_findings(project_id:str)->list[dict]:
 q="select f.* from tracked_findings f join pentest_report_project_findings pf on pf.finding_id=f.id where pf.project_id=? order by case lower(f.severity) when 'critical' then 1 when 'high' then 2 when 'medium' then 3 when 'low' then 4 else 5 end,f.id"
 with conn() as c:rows=c.execute(q,(project_id,)).fetchall()
 return [_finding_row(x) for x in rows]

def _studio_context(project_id:str)->str:
 p=_project_get(project_id);findings=_project_findings(project_id)
 with conn() as c:src=c.execute('select * from pentest_report_sources where project_id=? order by created_at',(project_id,)).fetchall()
 parts=[f"PROJECT: {p['name']}\nCLIENT: {p['client']}\nASSESSMENT TYPE: {p['assessment_type']}"]
 for r in src:
  txt=dec(r['text_enc']) if r['text_enc'] else ''
  if txt:parts.append(f"SOURCE {r['label'] or r['original_filename']}:\n{txt[:24000]}")
 if findings:
  parts.append('TRACKED FINDINGS:\n'+json.dumps([{k:f.get(k,'') for k in ('id','title','severity','asset','cve','cwe','cvss','category','description','evidence','remediation','status')} for f in findings],ensure_ascii=False)[:50000])
 return '\n\n'.join(parts)[:90000]

async def _ollama_report_draft(project_id:str)->tuple[dict,str]:
 context=_studio_context(project_id)
 prompt=("You are the local HIVE SECURITY penetration-test report writing assistant. Build a professional report draft ONLY from the supplied project sources and tracked findings. Do not invent vulnerabilities, hosts, credentials, exploit success, CVEs, business impacts, dates, or evidence. If information is absent, say it was not provided. Return strict JSON with exactly these string keys: executive_summary, scope, objectives, methodology, attack_surface, risk_summary, findings_narrative, remediation_roadmap, conclusion, limitations. Write detailed, evidence-grounded prose for an authorized professional penetration-test report. Clearly distinguish observed evidence from risk inference. Context follows:\n\n"+context)
 try:
  async with httpx.AsyncClient(timeout=180) as c:
   r=await c.post('http://127.0.0.1:11434/api/chat',json={'model':'llama3.2:3b','stream':False,'messages':[{'role':'user','content':prompt}],'format':'json'});r.raise_for_status();obj=json.loads(((r.json().get('message') or {}).get('content') or '{}'))
  return {k:str(obj.get(k,'')) for k in PENTEST_REPORT_SECTIONS},'llama3.2:3b local - grounded draft'
 except Exception as e:return {},f'unavailable: {str(e)[:180]}'

def _severity_counts(findings):
 out={k:0 for k in ['critical','high','medium','low','info']}
 for f in findings:
  k=(f.get('severity') or 'info').lower();out[k if k in out else 'info']+=1
 return out

def _studio_pdf(project_id:str)->bytes:
 p=_project_get(project_id);findings=_project_findings(project_id)
 with conn() as c:sources=c.execute('select * from pentest_report_sources where project_id=? order by created_at',(project_id,)).fetchall()
 buf=BytesIO();doc=SimpleDocTemplate(buf,pagesize=letter,rightMargin=.62*inch,leftMargin=.62*inch,topMargin=.62*inch,bottomMargin=.66*inch,title=f"{p['name']} - Penetration Test Report",author=p.get('author') or 'HIVE SECURITY')
 styles=getSampleStyleSheet();red=colors.HexColor('#d71920');dark=colors.HexColor('#111111');gray=colors.HexColor('#5d5d5d');light=colors.HexColor('#f2f2f2')
 styles.add(ParagraphStyle(name='HiveTitle',parent=styles['Title'],fontSize=26,leading=30,textColor=dark,spaceAfter=10))
 styles.add(ParagraphStyle(name='HiveH1',parent=styles['Heading1'],fontSize=16,leading=20,textColor=red,spaceBefore=10,spaceAfter=8))
 styles.add(ParagraphStyle(name='HiveH2',parent=styles['Heading2'],fontSize=12,leading=15,textColor=dark,spaceBefore=8,spaceAfter=5))
 styles.add(ParagraphStyle(name='HiveBody',parent=styles['BodyText'],fontSize=9.2,leading=13.2,textColor=dark,spaceAfter=6))
 styles.add(ParagraphStyle(name='HiveSmall',parent=styles['BodyText'],fontSize=7.5,leading=10,textColor=gray))
 def para(x,style='HiveBody'):return Paragraph(html.escape(str(x or 'Not provided.')).replace('\n','<br/>'),styles[style])
 def footer(canv,docobj):
  canv.saveState();canv.setStrokeColor(red);canv.setLineWidth(1);canv.line(.62*inch,.48*inch,7.88*inch,.48*inch);canv.setFont('Helvetica',7);canv.setFillColor(gray);canv.drawString(.62*inch,.31*inch,f"HIVE SECURITY | {p.get('classification') or 'Confidential'}");canv.drawRightString(7.88*inch,.31*inch,f"Page {docobj.page}");canv.restoreState()
 story=[];logo=STATIC/'icon-256.png'
 if logo.exists():story += [Image(str(logo),width=.78*inch,height=.78*inch),Spacer(1,4)]
 story += [Paragraph('HIVE SECURITY',styles['HiveH1']),Paragraph('PENETRATION TEST REPORT',styles['HiveTitle']),Spacer(1,4),para(p['name'],'HiveH2'),para(p['client'] or 'Client not specified','HiveH2'),Spacer(1,14)]
 meta=[['Assessment Type',p['assessment_type']],['Status',p['status']],['Author',p['author'] or p['created_by']],['Classification',p['classification']],['Generated',datetime.now().strftime('%Y-%m-%d %H:%M')]]
 t=Table([[Paragraph(f'<b>{html.escape(a)}</b>',styles['HiveSmall']),para(b,'HiveSmall')] for a,b in meta],colWidths=[1.45*inch,5.75*inch]);t.setStyle(TableStyle([('BACKGROUND',(0,0),(0,-1),light),('GRID',(0,0),(-1,-1),.35,colors.HexColor('#c7c7c7')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]));story += [t,Spacer(1,16),para('Authorized security assessment report. Findings and conclusions are limited to the evidence and scope documented in this project.','HiveSmall'),PageBreak()]
 counts=_severity_counts(findings);story += [Paragraph('Report Overview',styles['HiveH1'])]
 ct=Table([['Critical','High','Medium','Low','Info'],[counts['critical'],counts['high'],counts['medium'],counts['low'],counts['info']]],colWidths=[1.44*inch]*5);ct.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),dark),('TEXTCOLOR',(0,0),(-1,0),colors.white),('BACKGROUND',(0,1),(-1,1),light),('ALIGN',(0,0),(-1,-1),'CENTER'),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('GRID',(0,0),(-1,-1),.4,colors.HexColor('#bbbbbb')),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]));story += [ct,Spacer(1,12)]
 for label,key in [('Executive Summary','executive_summary'),('Scope','scope'),('Objectives','objectives'),('Methodology','methodology'),('Attack Surface & Attack Vectors','attack_surface'),('Risk Summary','risk_summary')]:story += [Paragraph(label,styles['HiveH1']),para(p['sections'].get(key,''))]
 story += [PageBreak(),Paragraph('Detailed Findings',styles['HiveH1'])]
 if not findings:story += [para('No tracked findings are linked to this report project.')]
 for i,f in enumerate(findings,1):
  meta2=[[para('Severity','HiveSmall'),para((f.get('severity') or 'info').upper(),'HiveSmall')],[para('Asset','HiveSmall'),para(f.get('asset') or 'Not specified','HiveSmall')],[para('CVE / CWE','HiveSmall'),para(' / '.join(x for x in [f.get('cve'),f.get('cwe')] if x) or 'Not specified','HiveSmall')],[para('CVSS','HiveSmall'),para(f.get('cvss') or 'Not specified','HiveSmall')]]
  mt=Table(meta2,colWidths=[1.15*inch,6.05*inch]);mt.setStyle(TableStyle([('BACKGROUND',(0,0),(0,-1),light),('GRID',(0,0),(-1,-1),.3,colors.HexColor('#cccccc')),('VALIGN',(0,0),(-1,-1),'TOP')]))
  story += [Paragraph(f"{i}. {html.escape(f.get('title') or 'Finding')}",styles['HiveH2']),mt,Spacer(1,5),Paragraph('Description',styles['HiveH2']),para(f.get('description')),Paragraph('Evidence',styles['HiveH2']),para(f.get('evidence')),Paragraph('Remediation',styles['HiveH2']),para(f.get('remediation')),Spacer(1,10)]
 story += [Paragraph('Findings Narrative',styles['HiveH1']),para(p['sections'].get('findings_narrative','')),Paragraph('Remediation Roadmap',styles['HiveH1']),para(p['sections'].get('remediation_roadmap','')),Paragraph('Conclusion',styles['HiveH1']),para(p['sections'].get('conclusion','')),Paragraph('Limitations',styles['HiveH1']),para(p['sections'].get('limitations',''))]
 imgs=[r for r in sources if (r['kind']=='image' or (r['mime'] or '').startswith('image/')) and r['encrypted_path']]
 if imgs:
  story += [PageBreak(),Paragraph('Evidence Images',styles['HiveH1']),para('Images are reproduced from project evidence sources. Captions are analyst-provided and are not automatically interpreted by the text-only local Llama 3.2 3B model.','HiveSmall')]
  for idx,r in enumerate(imgs,1):
   try:
    raw=dec_bytes(Path(r['encrypted_path']).read_bytes());im=Image(BytesIO(raw));scale=min((7.0*inch)/im.imageWidth,(5.0*inch)/im.imageHeight,1.0);im.drawWidth=im.imageWidth*scale;im.drawHeight=im.imageHeight*scale
    story += [Paragraph(f"Figure {idx}: {html.escape(r['label'] or r['original_filename'])}",styles['HiveH2']),im,Spacer(1,4),para(r['caption'] or 'No caption provided.','HiveSmall'),Spacer(1,12)]
   except Exception:story += [para(f"Image {r['original_filename']} could not be rendered.",'HiveSmall')]
 if sources:
  story += [PageBreak(),Paragraph('Source Appendix',styles['HiveH1'])]
  rows=[['Source','Type','SHA-256']]+[[r['label'] or r['original_filename'],r['kind'],r['sha256'][:24]+'...' if r['sha256'] else 'reference'] for r in sources]
  st=Table([[para(c,'HiveSmall') for c in row] for row in rows],colWidths=[3.0*inch,1.2*inch,3.0*inch],repeatRows=1);st.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),dark),('TEXTCOLOR',(0,0),(-1,0),colors.white),('GRID',(0,0),(-1,-1),.3,colors.HexColor('#cccccc')),('VALIGN',(0,0),(-1,-1),'TOP')]))
  story += [st]
 doc.build(story,onFirstPage=footer,onLaterPages=footer);return buf.getvalue()

@app.get('/api/pentest-report-studio/projects')
def studio_projects():
 with conn() as c:return [_studio_project_row(x) for x in c.execute('select * from pentest_report_projects order by updated_at desc,created_at desc').fetchall()]
@app.post('/api/pentest-report-studio/projects')
def studio_project_create(x:PentestReportProject):
 pid=secrets.token_hex(12);sections={k:'' for k in PENTEST_REPORT_SECTIONS}
 with conn() as c:c.execute('insert into pentest_report_projects(id,name,client,assessment_type,status,author,classification,sections_enc,created_by) values(?,?,?,?,?,?,?,?,?)',(pid,x.name[:240],x.client[:240],x.assessment_type[:120],x.status[:40],x.author[:160],x.classification[:80],enc(json.dumps(sections)),CURRENT_USER.get()))
 audit('pentest.studio.project.create',f'{pid}:{x.name}');return {'ok':True,'id':pid}
@app.get('/api/pentest-report-studio/projects/{project_id}')
def studio_project_detail(project_id:str):
 p=_project_get(project_id)
 with conn() as c:p['sources']=[_studio_source_row(x) for x in c.execute('select * from pentest_report_sources where project_id=? order by created_at',(project_id,)).fetchall()]
 p['findings']=_project_findings(project_id);return p
@app.put('/api/pentest-report-studio/projects/{project_id}')
def studio_project_update(project_id:str,x:PentestReportProjectUpdate):
 old=_project_get(project_id);sections=old['sections'];sections.update({k:str(v) for k,v in (x.sections or {}).items() if k in PENTEST_REPORT_SECTIONS})
 vals=[x.name or old['name'],x.client if x.client!='' else old['client'],x.assessment_type or old['assessment_type'],x.status or old['status'],x.author if x.author!='' else old['author'],x.classification or old['classification'],enc(json.dumps(sections)),project_id]
 with conn() as c:c.execute('update pentest_report_projects set name=?,client=?,assessment_type=?,status=?,author=?,classification=?,sections_enc=?,updated_at=CURRENT_TIMESTAMP where id=?',vals)
 audit('pentest.studio.project.update',project_id);return {'ok':True}
@app.delete('/api/pentest-report-studio/projects/{project_id}')
def studio_project_delete(project_id:str):
 _project_get(project_id)
 with conn() as c:
  paths=[x[0] for x in c.execute('select encrypted_path from pentest_report_sources where project_id=?',(project_id,)).fetchall() if x[0]];c.execute('delete from pentest_report_project_findings where project_id=?',(project_id,));c.execute('delete from pentest_report_sources where project_id=?',(project_id,));c.execute('delete from pentest_report_projects where id=?',(project_id,))
 for x in paths:
  try:Path(x).unlink(missing_ok=True)
  except Exception:pass
 audit('pentest.studio.project.delete',project_id);return {'ok':True}
@app.post('/api/pentest-report-studio/projects/{project_id}/source')
async def studio_source_upload(project_id:str,file:UploadFile=File(...),label:str='',caption:str=''):
 _project_get(project_id);data=await file.read();await file.close()
 if not data:raise HTTPException(400,'Uploaded source is empty.')
 if len(data)>40*1024*1024:raise HTTPException(413,'Source exceeds the 40 MB secure upload limit.')
 fname=_safe_name(file.filename or 'source');ext=Path(fname).suffix.lower();is_image=ext in ('.png','.jpg','.jpeg')
 text='';parser='image'
 if not is_image:
  try:text,parser=_extract_report_text(fname,data)
  except ValueError as e:raise HTTPException(400,str(e))
 sid=secrets.token_hex(12);path=PENTEST_STUDIO_STORE/f'{sid}.hmsenc';path.write_bytes(enc_bytes(data));_harden_private_file(path);sha=hashlib.sha256(data).hexdigest();mime=mimetypes.guess_type(fname)[0] or ('image/png' if ext=='.png' else 'application/octet-stream')
 with conn() as c:c.execute('insert into pentest_report_sources(id,project_id,kind,label,caption,original_filename,mime,sha256,encrypted_path,text_enc,created_by) values(?,?,?,?,?,?,?,?,?,?,?)',(sid,project_id,'image' if is_image else 'document',(label or Path(fname).stem)[:240],caption[:2000],fname,mime,sha,str(path),enc(text[:500000]) if text else '',CURRENT_USER.get()));c.execute('update pentest_report_projects set updated_at=CURRENT_TIMESTAMP where id=?',(project_id,))
 audit('pentest.studio.source.upload',f'{project_id}:{fname}:{parser}');return {'ok':True,'id':sid,'parser':parser,'text_chars':len(text),'image':is_image}
@app.post('/api/pentest-report-studio/projects/{project_id}/existing-report/{report_id}')
def studio_link_existing_report(project_id:str,report_id:str):
 _project_get(project_id)
 with conn() as c:r=c.execute('select * from pentest_reports where id=?',(report_id,)).fetchone()
 if not r:raise HTTPException(404,'Existing pentest report not found')
 sid=secrets.token_hex(12)
 with conn() as c:c.execute('insert into pentest_report_sources(id,project_id,kind,label,original_filename,mime,sha256,text_enc,reference_id,created_by) values(?,?,?,?,?,?,?,?,?,?)',(sid,project_id,'existing-report',r['name'],r['original_filename'],'application/octet-stream',r['sha256'],r['extracted_text_enc'],report_id,CURRENT_USER.get()));c.execute('update pentest_report_projects set updated_at=CURRENT_TIMESTAMP where id=?',(project_id,))
 audit('pentest.studio.source.link',f'{project_id}:{report_id}');return {'ok':True,'id':sid}
@app.delete('/api/pentest-report-studio/projects/{project_id}/source/{source_id}')
def studio_source_delete(project_id:str,source_id:str):
 with conn() as c:r=c.execute('select * from pentest_report_sources where id=? and project_id=?',(source_id,project_id)).fetchone()
 if not r:raise HTTPException(404,'Source not found')
 with conn() as c:c.execute('delete from pentest_report_sources where id=?',(source_id,));c.execute('update pentest_report_projects set updated_at=CURRENT_TIMESTAMP where id=?',(project_id,))
 if r['encrypted_path']:
  try:Path(r['encrypted_path']).unlink(missing_ok=True)
  except Exception:pass
 audit('pentest.studio.source.delete',f'{project_id}:{source_id}');return {'ok':True}
@app.put('/api/pentest-report-studio/projects/{project_id}/findings')
def studio_findings_link(project_id:str,x:PentestReportFindingLink):
 _project_get(project_id);ids=sorted(set(int(i) for i in x.finding_ids if int(i)>0))
 with conn() as c:
  c.execute('delete from pentest_report_project_findings where project_id=?',(project_id,))
  for fid in ids:
   if c.execute('select 1 from tracked_findings where id=?',(fid,)).fetchone():c.execute('insert into pentest_report_project_findings(project_id,finding_id) values(?,?)',(project_id,fid))
  c.execute('update pentest_report_projects set updated_at=CURRENT_TIMESTAMP where id=?',(project_id,))
 audit('pentest.studio.findings.link',f'{project_id}:{len(ids)}');return {'ok':True,'count':len(_project_findings(project_id))}
@app.post('/api/pentest-report-studio/projects/{project_id}/generate')
async def studio_generate(project_id:str):
 _project_get(project_id);draft,state=await _ollama_report_draft(project_id)
 if not draft:
  with conn() as c:c.execute('update pentest_report_projects set ai_status=?,updated_at=CURRENT_TIMESTAMP where id=?',(state,project_id))
  raise HTTPException(503,f'Local AI report generation failed: {state}')
 with conn() as c:c.execute('update pentest_report_projects set sections_enc=?,ai_status=?,updated_at=CURRENT_TIMESTAMP where id=?',(enc(json.dumps(draft)),state,project_id))
 audit('pentest.studio.ai.generate',f'{project_id}:{state}');return {'ok':True,'ai_status':state,'sections':draft}
@app.get('/api/pentest-report-studio/projects/{project_id}/report.pdf')
def studio_report_pdf(project_id:str,download:int=0):
 data=_studio_pdf(project_id);p=_project_get(project_id);name=re.sub(r'[^A-Za-z0-9_.-]+','_',p['name'])[:80]+'_pentest_report.pdf';audit('pentest.studio.report.export',project_id);disp='attachment' if download else 'inline';return StreamingResponse(BytesIO(data),media_type='application/pdf',headers={'Content-Disposition':f'{disp}; filename="{name}"'})

@app.get('/api/reports/executive.pdf')
async def executive_report():
 exp=await exposure_summary(); inc=_rows("select * from incidents where status!='closed'"); risks=_rows("select *,likelihood*impact score from risks where status!='closed'"); st=stig_summary()
 bio=BytesIO();doc=SimpleDocTemplate(bio,pagesize=letter,rightMargin=.55*inch,leftMargin=.55*inch,topMargin=.55*inch,bottomMargin=.55*inch);styles=getSampleStyleSheet();story=[Paragraph('Hive Mind Security — Executive Security Report',styles['Title']),Paragraph(datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),styles['Normal']),Spacer(1,12)]
 data=[['Metric','Value'],['Assets',str(exp['assets'])],['Open exposures',str(exp['open_exposures'])],['Critical exposures',str(exp['critical'])],['CISA KEV matches',str(exp['kev_matches'])],['Active incidents',str(len(inc))],['Open risks',str(len(risks))],['Open STIG findings',str(st.get('open',0))]];t=Table(data,colWidths=[3.5*inch,2*inch]);t.setStyle(TableStyle([('GRID',(0,0),(-1,-1),.4,colors.grey),('BACKGROUND',(0,0),(-1,0),colors.lightgrey),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('PADDING',(0,0),(-1,-1),6)]));story+=[t,Spacer(1,14),Paragraph('Top Exposure Priorities',styles['Heading2'])]
 for x in exp['items'][:15]:story.append(Paragraph(f"{x.get('severity','').upper()} — {x.get('cve') or x.get('title')} — {x.get('asset') or 'Unassigned'}{' — CISA KEV' if x.get('cisa_kev') else ''}",styles['BodyText']))
 doc.build(story);bio.seek(0);audit('report.executive.generate',f"exposures={exp['open_exposures']}");return StreamingResponse(bio,media_type='application/pdf',headers={'Content-Disposition':'inline; filename="hive_mind_executive_report.pdf"'})



@app.get('/api/remediation/queue')
def remediation_queue():
 out=[]
 for x in _rows('select id,cve,title,severity,asset,owner,status,due_date,source,created_at from vulnerabilities order by id desc'):
  out.append({**x,'record_type':'vulnerability','record_id':x['id']})
 for x in _rows('select id,cve,title,severity,asset,owner,status,due_date,source,created_at from tracked_findings order by id desc'):
  out.append({**x,'record_type':'tracked_finding','record_id':x['id']})
 for x in _rows('select id,vuln_id cve,title,severity,asset,\'\' owner,status,\'\' due_date,source,created_at from stig_findings order by id desc'):
  out.append({**x,'record_type':'stig','record_id':x['id']})
 rank={'critical':4,'high':3,'medium':2,'low':1};out.sort(key=lambda x:(str(x.get('status','')).lower() in ('closed','remediated','fixed'),-rank.get(str(x.get('severity','')).lower(),0),str(x.get('due_date',''))))
 return out[:500]

def _run_schedule_row(row:dict,actor='scheduler'):
 req=PentestScanRequest(name=row['name'],target=row['target'],profile=row['profile'],credential_user=row['credential_user'],authorized=True,import_findings=True)
 profile=req.profile if req.profile in ('quick','standard') else 'quick';_scan_targets(req.target,profile,bool(req.credential_user));sid=uuid.uuid4().hex[:24]
 with conn() as c:c.execute('insert into pentest_scans(id,name,target,profile,credential_user,status,created_by) values(?,?,?,?,?,?,?)',(sid,row['name'],row['target'],profile,row['credential_user'],'running',actor))
 tok=CURRENT_USER.set(actor)
 try:
  _run_builtin_scan(sid,req,actor);now=datetime.now(timezone.utc);nxt=datetime.fromtimestamp(now.timestamp()+int(row['interval_hours'])*3600,timezone.utc).isoformat()
  with conn() as c:c.execute('update scheduled_scans set last_run=?,next_run=? where id=?',(now.isoformat(),nxt,row['id']))
 except Exception as e:
  with conn() as c:c.execute("update pentest_scans set status='failed',summary_json=?,finished_at=CURRENT_TIMESTAMP where id=?",(json.dumps({'error':str(e)[:1000]}),sid))
  audit('scheduled_scan.failed',f"{row['id']}:{str(e)[:300]}")
 finally:CURRENT_USER.reset(tok)

async def _scheduled_scan_loop():
 while True:
  try:
   now=datetime.now(timezone.utc)
   for row in _rows('select * from scheduled_scans where enabled=1'):
    try:due=not row.get('next_run') or datetime.fromisoformat(row['next_run'].replace('Z','+00:00'))<=now
    except Exception:due=True
    if due:await asyncio.to_thread(_run_schedule_row,row,'scheduler')
  except Exception:pass
  await asyncio.sleep(60)

@app.on_event('startup')
async def _start_schedule_worker():
 asyncio.create_task(_scheduled_scan_loop())

# Functional toolbox
PRIVATE_NETS=[ipaddress.ip_network('10.0.0.0/8'),ipaddress.ip_network('172.16.0.0/12'),ipaddress.ip_network('192.168.0.0/16'),ipaddress.ip_network('127.0.0.0/8'),ipaddress.ip_network('169.254.0.0/16')]
def save_tool(tool,inp,out):
 with conn() as c:c.execute('insert into toolbox_runs(tool,input_summary,output) values(?,?,?)',(tool,inp[:500],json.dumps(out)[:6000]))
 return out
@app.post('/api/toolbox/hash')
def tb_hash(x:ToolboxInput):return save_tool('hash',x.value,{'md5':hashlib.md5(x.value.encode()).hexdigest(),'sha1':hashlib.sha1(x.value.encode()).hexdigest(),'sha256':hashlib.sha256(x.value.encode()).hexdigest(),'sha512':hashlib.sha512(x.value.encode()).hexdigest()})
@app.post('/api/toolbox/encode')
def tb_encode(x:ToolboxInput):
 op=x.operation.lower();v=x.value
 try:
  if op=='base64-encode':o=base64.b64encode(v.encode()).decode()
  elif op=='base64-decode':o=base64.b64decode(v).decode(errors='replace')
  elif op=='url-encode':o=urllib.parse.quote(v,safe='')
  elif op=='url-decode':o=urllib.parse.unquote(v)
  elif op=='hex-encode':o=v.encode().hex()
  elif op=='hex-decode':o=bytes.fromhex(v).decode(errors='replace')
  else:raise ValueError('Unknown operation')
  return save_tool('encode',v,{'operation':op,'result':o})
 except Exception as e:raise HTTPException(400,str(e))
@app.post('/api/toolbox/ioc-parse')
def tb_ioc(x:ToolboxInput):
 text=x.value;ips=sorted(set(re.findall(r'\b(?:\d{1,3}\.){3}\d{1,3}\b',text)));urls=sorted(set(re.findall(r'https?://[^\s<>()"\']+',text)));emails=sorted(set(re.findall(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b',text)));hashes=sorted(set(re.findall(r'\b(?:[A-Fa-f0-9]{64}|[A-Fa-f0-9]{40}|[A-Fa-f0-9]{32})\b',text)))
 return save_tool('ioc-parse',text,{'ips':ips,'urls':urls,'emails':emails,'hashes':hashes,'count':len(ips)+len(urls)+len(emails)+len(hashes)})
@app.post('/api/toolbox/subnet')
def tb_subnet(x:ToolboxInput):
 try:n=ipaddress.ip_network(x.value.strip(),strict=False);o={'network':str(n.network_address),'broadcast':str(n.broadcast_address) if n.version==4 else 'n/a','prefix':n.prefixlen,'netmask':str(n.netmask),'addresses':n.num_addresses,'first':str(next(n.hosts(),n.network_address)),'last':str(list(n.hosts())[-1]) if n.num_addresses<65538 else str(n[-2])}
 except Exception as e:raise HTTPException(400,str(e))
 return save_tool('subnet',x.value,o)
@app.post('/api/toolbox/jwt')
def tb_jwt(x:ToolboxInput):
 try:
  p=x.value.split('.');
  if len(p)<2:raise ValueError('JWT must contain at least header.payload')
  de=lambda s:json.loads(base64.urlsafe_b64decode(s+'='*((4-len(s)%4)%4)).decode())
  o={'header':de(p[0]),'payload':de(p[1]),'warning':'Decoded for inspection only; signature is NOT verified.'}
 except Exception as e:raise HTTPException(400,str(e))
 return save_tool('jwt',x.value[:80],o)
@app.post('/api/toolbox/regex')
def tb_regex(x:ToolboxInput):
 try:r=re.compile(x.operation);matches=[m.group(0) for m in r.finditer(x.value)][:200]
 except Exception as e:raise HTTPException(400,str(e))
 return save_tool('regex',x.operation,{'matches':matches,'count':len(matches)})
@app.post('/api/toolbox/query-builder')
def tb_query(x:ToolboxInput):
 v=x.value.strip();kind=x.operation.lower();safe=v.replace('"','\\"')
 q={'splunk':f'index=* (src_ip="{safe}" OR dest_ip="{safe}" OR url="{safe}") | stats count min(_time) as firstSeen max(_time) as lastSeen by host,source', 'kql':f'Search * | where tostring(*) contains "{safe}" | take 100', 'elastic':json.dumps({'query':{'query_string':{'query':f'"{safe}"'}}},indent=2), 'sigma':f'title: IOC Hunt - {safe}\nstatus: experimental\nlogsource:\n  category: network_connection\ndetection:\n  selection:\n    DestinationIp: {safe}\n  condition: selection\nlevel: medium'}
 if kind not in q:raise HTTPException(400,'Choose splunk, kql, elastic, or sigma')
 return save_tool('query-builder',v,{'platform':kind,'query':q[kind]})

@app.post('/api/toolbox/password-generate')
def toolbox_password_generate(x:ToolboxInput):
 try:length=max(12,min(128,int(x.value or '20')))
 except:length=20
 count=max(1,min(20,int(x.extra or '5') if str(x.extra or '').isdigit() else 5))
 import string
 alphabet=string.ascii_letters+string.digits+'!@#$%^&*()-_=+[]{}:,.?'
 def one():
  while True:
   p=''.join(secrets.choice(alphabet) for _ in range(length))
   if any(c.islower() for c in p) and any(c.isupper() for c in p) and any(c.isdigit() for c in p) and any(c in '!@#$%^&*()-_=+[]{}:,.?' for c in p):return p
 vals=[one() for _ in range(count)]
 audit('toolbox.password.generate',f'length={length}:count={count}')
 return {'length':length,'count':count,'passwords':vals,'note':'Generated locally with Python secrets; passwords are not stored in toolbox history.'}

@app.post('/api/toolbox/password-hash-audit')
def toolbox_password_hash_audit(x:ToolboxInput):
 target=(x.value or '').strip(); candidates=[v for v in (x.extra or '').splitlines() if v][:5000]; op=(x.operation or 'auto').lower()
 if not target:raise HTTPException(400,'Password hash is required.')
 if not candidates:raise HTTPException(400,'Provide one or more authorized candidate passwords, one per line.')
 if len(candidates)>5000:raise HTTPException(400,'Candidate list is limited to 5,000 entries per local audit.')
 found=None;alg=op
 if target.startswith('$argon2') or op=='argon2':
  alg='argon2'
  for cand in candidates:
   try:
    if PH.verify(target,cand):found=cand;break
   except Exception:pass
 else:
  if op=='auto':
   alg={32:'md5',40:'sha1',64:'sha256',128:'sha512'}.get(len(target),'')
  if alg not in ('md5','sha1','sha256','sha512'):raise HTTPException(400,'Choose MD5, SHA1, SHA256, SHA512, or Argon2; auto-detection uses hash length for common hex digests.')
  for cand in candidates:
   if hashlib.new(alg,cand.encode()).hexdigest().lower()==target.lower():found=cand;break
 audit('toolbox.password.hash_audit',f'algorithm={alg}:candidates={len(candidates)}:matched={bool(found)}')
 return {'algorithm':alg,'tested':len(candidates),'matched':bool(found),'match':found if found else None,'note':'Local authorized candidate-list audit only. No brute-force, remote cracking, or credential spraying is performed.'}

@app.delete('/api/toolbox/history/{run_id}')
def toolbox_history_delete(run_id:int):
 with conn() as c:
  r=c.execute('select tool from toolbox_runs where id=?',(run_id,)).fetchone()
  if not r:raise HTTPException(404,'Tool run not found')
  c.execute('delete from toolbox_runs where id=?',(run_id,))
 audit('toolbox.history.delete',f'{run_id}:{r["tool"]}');return {'ok':True}
@app.get('/api/toolbox/history')
def tb_history():
 with conn() as c:return [dict(x) for x in c.execute('select * from toolbox_runs order by id desc limit 30').fetchall()]

@app.get('/api/audit')
def get_audit():
 with conn() as c:return [dict(x) for x in c.execute('select * from audit order by id desc limit 200').fetchall()]
BACKUP_MAX_BYTES=1024*1024*1024
RESTORE_UPLOAD_MAX_BYTES=1024*1024*1024
BACKUP_DATA_DIRS=('pentest_reports','remediation_reports','scan_reports','pentest_studio','evidence')
AUTO_BACKUP_PREFIX='auto_daily'
AUTO_BACKUP_KEEP=7
AUTO_BACKUP_INTERVAL_SECONDS=24*60*60

def _backup_name_ok(name:str)->bool:
 return bool(name==Path(name).name and re.fullmatch(r'[A-Za-z0-9_.-]+\.zip',name))

def _prune_auto_backups(keep:int=AUTO_BACKUP_KEEP):
 files=sorted(BACKUPS.glob(f'{AUTO_BACKUP_PREFIX}_*.zip'),key=lambda x:x.stat().st_mtime,reverse=True)
 deleted=[]
 for fp in files[max(1,int(keep)):]:
  try:
   fp.unlink();deleted.append(fp.name)
  except Exception:pass
 return deleted

def _auto_backup_due()->bool:
 files=list(BACKUPS.glob(f'{AUTO_BACKUP_PREFIX}_*.zip'))
 if not files:return True
 latest=max(files,key=lambda x:x.stat().st_mtime)
 return (time.time()-latest.stat().st_mtime)>=AUTO_BACKUP_INTERVAL_SECONDS

def _backup_archive(prefix='hive_mind_security'):
 key()  # Every restorable backup must carry the encryption key, even on a fresh install.
 stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
 path=BACKUPS/f'{prefix}_{stamp}_{secrets.token_hex(2)}.zip'
 manifest={'product':'HIVE SECURITY','format':2,'app_version':VERSION,'created_at':datetime.now(timezone.utc).isoformat(),'includes':['database','encryption_key','managed_data']}
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,allowZip64=True) as z:
  z.writestr('hive_backup_manifest.json',json.dumps(manifest,indent=2))
  if DB.exists():z.write(DB,DB.name)
  if KEYFILE.exists():z.write(KEYFILE,KEYFILE.name)
  for dirname in BACKUP_DATA_DIRS:
   base=DATA/dirname
   if not base.exists():continue
   for fp in base.rglob('*'):
    if fp.is_file():z.write(fp,fp.relative_to(DATA).as_posix())
 return path

def _validate_restore_zip(path:Path):
 if not path.exists() or not zipfile.is_zipfile(path):raise HTTPException(400,'Selected file is not a valid ZIP backup.')
 stage=Path(tempfile.mkdtemp(prefix='hive_restore_'))
 try:
  total=0; seen=set(); allowed_roots=set(BACKUP_DATA_DIRS)
  with zipfile.ZipFile(path,'r') as z:
   infos=z.infolist()
   for info in infos:
    name=info.filename.replace('\\','/').lstrip('/')
    parts=Path(name).parts
    if not name or '..' in parts or Path(name).is_absolute():raise HTTPException(400,'Backup contains an unsafe archive path.')
    root=parts[0] if parts else ''
    if name not in ('hive_mind_security.db','.hms.key','hive_backup_manifest.json') and root not in allowed_roots:
     raise HTTPException(400,f'Backup contains an unexpected file: {name}')
    total+=max(0,info.file_size)
    if total>BACKUP_MAX_BYTES:raise HTTPException(413,'Backup expands beyond the 1 GB restore safety limit.')
    if not info.is_dir():
     out=stage/name;out.parent.mkdir(parents=True,exist_ok=True)
     with z.open(info) as src,open(out,'wb') as dst:
      while True:
       chunk=src.read(1024*1024)
       if not chunk:break
       dst.write(chunk)
     seen.add(name)
  if 'hive_mind_security.db' not in seen or '.hms.key' not in seen:raise HTTPException(400,'HIVE backup must contain both hive_mind_security.db and .hms.key.')
  keydata=(stage/'.hms.key').read_bytes().strip()
  try:Fernet(keydata)
  except Exception:raise HTTPException(400,'Backup encryption key is invalid.')
  testdb=stage/'hive_mind_security.db'
  try:
   tc=sqlite3.connect(f'file:{testdb.as_posix()}?mode=ro',uri=True)
   integrity=tc.execute('pragma integrity_check').fetchone()[0]
   tables={r[0] for r in tc.execute("select name from sqlite_master where type='table'").fetchall()};tc.close()
  except Exception as e:raise HTTPException(400,f'Backup database could not be opened: {e}')
  if str(integrity).lower()!='ok':raise HTTPException(400,f'Backup database integrity check failed: {integrity}')
  if not {'users','audit'}.issubset(tables):raise HTTPException(400,'Backup database is missing required HIVE SECURITY tables.')
  manifest={}
  mf=stage/'hive_backup_manifest.json'
  if mf.exists():
   try:manifest=json.loads(mf.read_text(encoding='utf-8'))
   except Exception:raise HTTPException(400,'Backup manifest is malformed.')
   if manifest.get('product') not in ('HIVE SECURITY',None):raise HTTPException(400,'Backup manifest is not for HIVE SECURITY.')
  return stage,manifest
 except Exception:
  import shutil;shutil.rmtree(stage,ignore_errors=True);raise

def _apply_restore(path:Path,request:Request):
 _require_admin(request)
 stage,manifest=_validate_restore_zip(path)
 import shutil
 safety=None
 try:
  # Always protect the currently running system before changing any persistent state.
  safety=_backup_archive('pre_restore_safety')
  dbtmp=DATA/(DB.name+'.restoretmp');keytmp=DATA/(KEYFILE.name+'.restoretmp')
  shutil.copy2(stage/DB.name,dbtmp);shutil.copy2(stage/KEYFILE.name,keytmp)
  _harden_private_file(dbtmp);_harden_private_file(keytmp)
  os.replace(dbtmp,DB);os.replace(keytmp,KEYFILE)
  # Format 2 backups contain managed encrypted artifacts. Legacy DB+key backups remain supported.
  if manifest.get('format')==2:
   for dirname in BACKUP_DATA_DIRS:
    target=DATA/dirname;incoming=stage/dirname
    old=DATA/(dirname+'.restore_old')
    if old.exists():shutil.rmtree(old,ignore_errors=True)
    if target.exists():os.replace(target,old)
    target.mkdir(parents=True,exist_ok=True)
    if incoming.exists():
     shutil.rmtree(target,ignore_errors=True);shutil.copytree(incoming,target)
    shutil.rmtree(old,ignore_errors=True)
  init_db()  # Migrate older valid backups forward to the currently installed schema.
  with conn() as c:c.execute('delete from sessions')
  audit('backup.restore',f'{path.name}; safety={safety.name if safety else ""}')
  return {'ok':True,'restored':path.name,'safety_backup':safety.name if safety else '','requires_login':True,'format':manifest.get('format',1)}
 except HTTPException:raise
 except Exception as e:
  raise HTTPException(500,f'Restore failed after validation. A pre-restore safety backup was created at {safety.name if safety else "unknown"}. Error: {e}')
 finally:shutil.rmtree(stage,ignore_errors=True)


INCIDENT_PLAN_DEFAULTS={
 'scope':'PURPOSE\nThis plan establishes a coordinated, repeatable process for preparing for, detecting, analyzing, containing, eradicating, recovering from, and learning from cybersecurity incidents.\n\nSCOPE\nApplies to approved business systems, endpoints, servers, networks, cloud services, applications, identities, data, facilities, third-party services, contractors, and personnel that could affect the organization’s operations or information security.\n\nOBJECTIVES\n• Protect people, information, systems, and business operations.\n• Establish clear authority and escalation paths.\n• Contain incidents quickly while preserving evidence.\n• Restore critical services safely and in priority order.\n• Meet applicable contractual, legal, regulatory, insurance, and customer obligations.\n• Capture lessons learned and track corrective actions.\n\nOUT OF SCOPE / EXCEPTIONS\nDocument any systems, subsidiaries, vendors, or environments that are excluded, and identify who approved each exclusion.',
 'roles':'INCIDENT RESPONSE LEAD / COORDINATOR\nOwns the incident, assigns severity, coordinates the response team, maintains the incident record, manages escalation, and coordinates executive decisions.\n\nTECHNICAL / SECURITY LEAD\nValidates technical evidence, identifies affected assets and accounts, directs approved containment and eradication, preserves technical artifacts, and validates recovery.\n\nIT / INFRASTRUCTURE LEAD\nSupports endpoint, server, network, identity, cloud, backup, and restoration actions and documents operational changes.\n\nBUSINESS / SERVICE OWNER\nDefines business impact, service priorities, acceptable downtime, and return-to-service approval.\n\nCOMMUNICATIONS LEAD\nCoordinates approved employee, customer, vendor, public, and media communications and maintains a notification record.\n\nLEGAL / PRIVACY / COMPLIANCE CONTACT\nEvaluates notification, preservation, privacy, contractual, regulatory, and law-enforcement considerations when applicable.\n\nEVIDENCE CUSTODIAN\nControls evidence identifiers, collection records, hashes where practical, secure storage, transfers, and chain of custody.\n\nEXECUTIVE / MANAGEMENT CONTACT\nApproves major business decisions, extraordinary containment, external notifications, risk acceptance, and recovery priorities.\n\nTHIRD-PARTY SUPPORT\nDocument MSP/MSSP, cyber-insurance breach counsel, forensic provider, cloud/vendor, and other retained response contacts.',
 'severity':'SEVERITY 1 — CRITICAL\nWidespread or destructive compromise; major outage; confirmed material data exposure; active ransomware; safety or major business impact; or an event requiring immediate executive coordination.\nTarget: immediate escalation and continuous coordination until stabilized.\n\nSEVERITY 2 — HIGH\nConfirmed compromise, privileged-account misuse, significant malware, material service degradation, or credible exposure with substantial potential impact.\nTarget: urgent response and management notification.\n\nSEVERITY 3 — MEDIUM\nContained compromise or suspicious activity requiring investigation and remediation but with limited current business impact.\nTarget: same-business-day triage or organization-defined target.\n\nSEVERITY 4 — LOW\nMinor security event, policy issue, blocked attempt, or low-impact suspicious activity requiring tracking or review.\nTarget: normal security operations queue.\n\nESCALATION FACTORS\nIncrease severity for critical assets, privileged identities, sensitive information, multiple sites, active exfiltration, destructive behavior, legal/contractual deadlines, public impact, or rapidly expanding scope. Severity must be based on verified evidence and may change as facts develop.',
 'response':'1. PREPARATION\nMaintain current contacts, asset inventory, logging, endpoint/network visibility, secure administrative access, backups, recovery procedures, vendor contacts, evidence tools, communications alternatives, and staff awareness. Review this plan at least annually and after significant incidents.\n\n2. IDENTIFICATION & INITIAL TRIAGE\nRecord who reported the event, detection source, date/time, affected users/assets, initial indicators, symptoms, and business impact. Open an incident record, assign an owner, validate the event, preserve volatile or short-lived evidence where appropriate, and assign an initial severity.\n\n3. ANALYSIS & SCOPING\nDevelop a timeline; identify affected systems, accounts, data, services, indicators, entry vector, persistence indicators, lateral movement, and external dependencies. Distinguish confirmed facts from assumptions. Identify what is known, unknown, and still being investigated.\n\n4. CONTAINMENT\nSelect short-term containment that reduces harm while considering business continuity and evidence preservation. Examples may include approved host isolation, account restriction, token/session revocation, domain/IP blocking, segmentation, or temporary service controls. Record every action, owner, time, reason, and result.\n\n5. ERADICATION\nRemove confirmed malicious artifacts and unauthorized access; remediate root causes; patch or reconfigure affected systems; rotate affected credentials when authorized; remove unauthorized accounts or access paths; and validate that identified compromise mechanisms are no longer present.\n\n6. RECOVERY\nRestore from known-good sources, validate system integrity, restore business services in approved priority order, confirm identity/access controls, verify logging/monitoring, increase monitoring for recurrence, and obtain business/service-owner acceptance.\n\n7. POST-INCIDENT\nComplete the incident timeline, impact assessment, root-cause statement, evidence index, response metrics, lessons learned, and corrective-action plan. Assign owners and due dates and verify remediation through follow-up testing.\n\n8. DECISION LOG\nFor significant decisions, record date/time, decision, decision maker, supporting facts, alternatives considered, business impact, and follow-up action.',
 'communications':'COMMUNICATION PRINCIPLES\nUse approved channels and a designated source of truth. Share verified facts on a need-to-know basis. Do not speculate about attribution, impact, data exposure, or recovery time. Preserve copies of material communications.\n\nINTERNAL NOTIFICATIONS\nDefine who must be notified for each severity: security/IT, management, service owners, legal/privacy/compliance, communications, HR, physical security, and other relevant functions.\n\nEXTERNAL NOTIFICATIONS\nIdentify who is authorized to contact cyber insurance, breach counsel, forensic providers, law enforcement, regulators, customers, vendors, partners, or the public. Notification requirements and deadlines must be evaluated by authorized organizational personnel.\n\nSTATUS UPDATE FORMAT\nIncident ID; severity; current status; confirmed scope; business impact; containment status; decisions needed; actions underway; next update time.\n\nALTERNATE COMMUNICATIONS\nDocument an out-of-band method to use if normal email, chat, identity, or network services are unavailable or untrusted.',
 'evidence':'EVIDENCE HANDLING PRINCIPLES\nPreserve evidence appropriate to the event and organizational requirements. Minimize unnecessary modification of original evidence. Record acquisition method and cryptographic hashes of digital evidence where practical. Store evidence in access-controlled locations and document every transfer.\n\nMINIMUM EVIDENCE RECORD\n• Case / Incident Number\n• Evidence Number\n• Date and Time Collected (including time zone)\n• Collected By\n• Collected From / Source\n• Location / System / Account\n• Description of Evidence\n• Acquisition Method\n• Cryptographic Hash, when applicable\n• Storage Location\n• Notes / Handling Restrictions\n\nCHAIN OF CUSTODY\nEach transfer should record date/time, evidence number, released by, received by, purpose, destination/location, and signatures or equivalent acknowledgement.\n\nCHAIN-OF-CUSTODY WORKSHEET\nCase/Incident Number: __________    Evidence Number: __________\nDate Collected: __________    Time Collected / TZ: __________\nCollected By: __________    Collected From: __________\nLocation / System: __________________________________________\nDescription of Evidence: ____________________________________\nAcquisition Method: _________________________________________\nHash / Algorithm: ___________________________________________\nStorage Location: ___________________________________________\nTransfer Log: Date/Time | Released By | Received By | Purpose/Location | Acknowledgement\nComments: __________________________________________________',
 'recovery':'RECOVERY PRIORITIES\nRank services using business impact, dependencies, recovery objectives, customer commitments, and safety/operational needs. Identify minimum viable service levels and dependencies required before each service can return.\n\nRECOVERY VALIDATION\nBefore return to service, verify the threat/root cause has been addressed; required patches/configuration changes are applied; credentials/tokens are handled appropriately; restored data is trusted; security controls are active; logging reaches monitoring systems; backups are functioning; and heightened monitoring is enabled.\n\nRETURN-TO-SERVICE APPROVAL\nDocument the technical validator, business/service owner, date/time, residual risk, temporary controls, and any follow-up actions.\n\nMONITORING PERIOD\nDefine the heightened-monitoring period and the indicators, alerts, accounts, systems, or traffic that will be watched for recurrence.',
 'lessons':'POST-INCIDENT REVIEW\nHold a structured review after stabilization. Include incident responders, affected service owners, and appropriate management or support functions.\n\nREVIEW QUESTIONS\n• What happened and what was the verified root cause?\n• When did the activity begin, when was it detected, and when was it contained?\n• Which systems, accounts, data, vendors, and business services were affected?\n• Which controls detected or prevented activity, and which controls failed or were absent?\n• What slowed detection, decisions, containment, eradication, or recovery?\n• Were communications, escalation, evidence handling, and vendor support effective?\n• What should be changed in architecture, configuration, detections, playbooks, training, contracts, backups, or this plan?\n\nCORRECTIVE ACTION TRACKING\nFor every improvement, record action, priority, owner, target date, validation method, status, and residual risk. Close actions only after evidence of completion or approved risk acceptance.',
 'approvals':'PLAN REVIEW\nReview Frequency: At least annually and after material organizational, technology, regulatory, vendor, or incident-response changes.\nNext Review Date: ____________________\n\nAPPROVALS\nPlan Owner: ______________________________  Title: __________________  Date: __________\nPrepared By: _____________________________  Date: __________\nManagement Approval: _____________________  Title: __________________  Date: __________\nCustomer / Organization Approval: __________  Title: __________________  Date: __________\n\nDOCUMENT CONTROL\nApproved Version: __________    Effective Date: __________    Classification: __________\nChange Summary / Notes: __________________________________________________________'
}

def _plan_row(r):
 d=dict(r); return d

@app.get('/api/incident-plans')
def incident_plans_list():
 with conn() as c:return [dict(r) for r in c.execute("select id,name,customer,prepared_by,version,status,created_at,updated_at from incident_plans order by updated_at desc,id desc").fetchall()]

@app.post('/api/incident-plans')
def incident_plan_create(x:IncidentPlan):
 vals=x.model_dump()
 for k,v in INCIDENT_PLAN_DEFAULTS.items():
  if not vals.get(k): vals[k]=v
 if not vals.get('organization_profile'): vals['organization_profile']='Organization: '+(vals.get('customer') or 'Customer / Organization')+'\nIndustry / Business Function: ____________________\nPrimary Locations / Environments: ____________________\nApproximate Users / Endpoints: ____________________\nCritical Business Services: ____________________\nCritical Data / Information Types: ____________________\nKey Technology / Cloud Dependencies: ____________________\nKey Vendors / MSP / MSSP: ____________________\nNormal Business Hours / 24x7 Requirements: ____________________\nMaximum Acceptable Service Disruption: ____________________'
 if not vals.get('contacts'): vals['contacts']='Primary Incident Contact / Phone / Email: ____________________\nBackup Incident Contact / Phone / Email: ____________________\nTechnical / IT Contact: ____________________\nManagement / Executive Contact: ____________________\nBusiness Continuity Contact: ____________________\nLegal / Privacy / Compliance Contact (if applicable): ____________________\nCommunications / Public Relations Contact: ____________________\nCyber Insurance / Breach Counsel Contact (if applicable): ____________________\nForensics / IR Provider (if applicable): ____________________\nCritical Vendor / MSP / MSSP Contact: ____________________\nLaw Enforcement / Government Contact (if organization-approved): ____________________\nOut-of-Band Communication Method: ____________________'
 cols=list(vals); q=','.join('?' for _ in cols)
 with conn() as c:
  cur=c.execute(f"insert into incident_plans({','.join(cols)}) values({q})",tuple(vals[k] for k in cols));pid=cur.lastrowid
 audit('incident.plan.create',f'{pid}:{x.name}');return {'ok':True,'id':pid}

@app.get('/api/incident-plans/{plan_id}')
def incident_plan_get(plan_id:int):
 with conn() as c:
  r=c.execute('select * from incident_plans where id=?',(plan_id,)).fetchone()
  if not r:raise HTTPException(404,'Incident plan not found.')
  d=dict(r);d['sources']=[dict(z) for z in c.execute('select id,name,sha256,created_at from incident_plan_sources where plan_id=? order by id',(plan_id,)).fetchall()]
 return d

@app.put('/api/incident-plans/{plan_id}')
def incident_plan_update(plan_id:int,x:IncidentPlan):
 vals=x.model_dump(); cols=list(vals)
 with conn() as c:
  if not c.execute('select 1 from incident_plans where id=?',(plan_id,)).fetchone():raise HTTPException(404,'Incident plan not found.')
  c.execute('update incident_plans set '+','.join(f'{k}=?' for k in cols)+',updated_at=CURRENT_TIMESTAMP where id=?',tuple(vals[k] for k in cols)+(plan_id,))
 audit('incident.plan.update',plan_id);return {'ok':True}

@app.delete('/api/incident-plans/{plan_id}')
def incident_plan_delete(plan_id:int):
 with conn() as c:
  c.execute('delete from incident_plan_sources where plan_id=?',(plan_id,));c.execute('delete from incident_plans where id=?',(plan_id,))
 audit('incident.plan.delete',plan_id);return {'ok':True}

@app.post('/api/incident-plans/{plan_id}/source')
async def incident_plan_source(plan_id:int,file:UploadFile=File(...)):
 data=await file.read();name=Path(file.filename or 'source').name
 if len(data)>20*1024*1024:raise HTTPException(413,'Source document exceeds 20 MB.')
 ext=Path(name).suffix.lower()
 if ext not in ('.pdf','.docx','.txt','.md'):raise HTTPException(400,'Supported source documents: PDF, DOCX, TXT, MD.')
 try:text,_=_extract_report_text(name,data)
 except Exception as e:raise HTTPException(400,'Could not extract source document text.') from e
 text=text[:250000]
 with conn() as c:
  if not c.execute('select 1 from incident_plans where id=?',(plan_id,)).fetchone():raise HTTPException(404,'Incident plan not found.')
  cur=c.execute('insert into incident_plan_sources(plan_id,name,sha256,text_enc) values(?,?,?,?)',(plan_id,name,hashlib.sha256(data).hexdigest(),enc(text)))
 audit('incident.plan.source.add',f'{plan_id}:{name}');return {'ok':True,'id':cur.lastrowid,'characters':len(text)}

@app.delete('/api/incident-plans/{plan_id}/source/{source_id}')
def incident_plan_source_delete(plan_id:int,source_id:int):
 with conn() as c:c.execute('delete from incident_plan_sources where id=? and plan_id=?',(source_id,plan_id))
 audit('incident.plan.source.delete',f'{plan_id}:{source_id}');return {'ok':True}

@app.post('/api/incident-plans/{plan_id}/apply-sources')
def incident_plan_apply_sources(plan_id:int):
 # Source-grounded deterministic application: preserve user content and strengthen evidence handling when source material supports it.
 with conn() as c:
  p=c.execute('select * from incident_plans where id=?',(plan_id,)).fetchone();src=c.execute('select * from incident_plan_sources where plan_id=?',(plan_id,)).fetchall()
  if not p:raise HTTPException(404,'Incident plan not found.')
 texts='\n'.join(dec(r['text_enc']) for r in src)
 if not texts.strip():raise HTTPException(400,'Upload at least one source document first.')
 evidence=p['evidence'] or INCIDENT_PLAN_DEFAULTS['evidence']
 low=texts.lower()
 if 'chain of custody' in low:
  evidence=INCIDENT_PLAN_DEFAULTS['evidence']+'\n\nChain-of-Custody Worksheet\nCase/Incident Number: __________  Evidence Number: __________\nDate Collected: __________  Time Collected: __________\nCollected By: __________  Collected From: __________\nLocation: __________\nDescription of Evidence: ________________________________________\nTransfer Log: Date/Time | Released By | Received By | Purpose/Location | Signature\nComments: ______________________________________________________'
 with conn() as c:c.execute('update incident_plans set evidence=?,updated_at=CURRENT_TIMESTAMP where id=?',(evidence,plan_id))
 audit('incident.plan.sources.apply',f'{plan_id}:{len(src)} source(s)');return {'ok':True,'sources':len(src),'applied':['chain_of_custody'] if 'chain of custody' in low else []}

def _incident_plan_pdf(plan_id:int):
 with conn() as c:p=c.execute('select * from incident_plans where id=?',(plan_id,)).fetchone()
 if not p:raise HTTPException(404,'Incident plan not found.')
 p=dict(p);buf=BytesIO();styles=getSampleStyleSheet();
 title_style=ParagraphStyle('HIVEPlanTitle',parent=styles['Title'],fontSize=24,leading=28,textColor=colors.HexColor('#b31217'),spaceAfter=14)
 h=ParagraphStyle('HIVEPlanH',parent=styles['Heading2'],fontSize=14,textColor=colors.HexColor('#b31217'),spaceBefore=10,spaceAfter=6)
 body=ParagraphStyle('HIVEPlanBody',parent=styles['BodyText'],fontSize=9.5,leading=13,spaceAfter=7)
 doc=SimpleDocTemplate(buf,pagesize=letter,rightMargin=.65*inch,leftMargin=.65*inch,topMargin=.7*inch,bottomMargin=.65*inch,title=p['name'])
 story=[Paragraph('HIVE SECURITY',title_style),Paragraph('Cybersecurity Incident Response Plan',styles['Heading1']),Spacer(1,8),Table([['Customer / Organization',p['customer'] or '____________________'],['Plan Name',p['name']],['Prepared By',p['prepared_by'] or '____________________'],['Version',p['version']],['Status',p['status']],['Date',datetime.now().strftime('%Y-%m-%d')]],colWidths=[1.7*inch,5.2*inch],style=[('BACKGROUND',(0,0),(0,-1),colors.HexColor('#171717')),('TEXTCOLOR',(0,0),(0,-1),colors.white),('GRID',(0,0),(-1,-1),.35,colors.grey),('VALIGN',(0,0),(-1,-1),'TOP'),('PADDING',(0,0),(-1,-1),6)]),Spacer(1,18),Paragraph('CUSTOMER-READY INCIDENT RESPONSE PLAN',styles['Heading2']),Paragraph('This plan is intentionally organization-neutral and should be reviewed against the customer’s contractual, legal, regulatory, insurance, and operational requirements before approval.',body),PageBreak()]
 sections=[('1. Organization Profile','organization_profile'),('2. Incident Contacts','contacts'),('3. Purpose & Scope','scope'),('4. Roles & Responsibilities','roles'),('5. Incident Severity','severity'),('6. Incident Response Lifecycle','response'),('7. Communications & Notifications','communications'),('8. Evidence Handling & Chain of Custody','evidence'),('9. Recovery & Return to Service','recovery'),('10. Post-Incident Review & Lessons Learned','lessons'),('11. Approval','approvals')]
 for heading,keyname in sections:
  story.append(Paragraph(heading,h))
  for para in (p.get(keyname) or '').split('\n'):
   story.append(Paragraph(html.escape(para) if para else '&nbsp;',body))
 def footer(canv,doc):
  canv.saveState();canv.setFont('Helvetica',7);canv.setFillColor(colors.grey);canv.drawString(.65*inch,.35*inch,'HIVE SECURITY • Cybersecurity Incident Response Plan');canv.drawRightString(7.85*inch,.35*inch,f'Page {doc.page}');canv.restoreState()
 doc.build(story,onFirstPage=footer,onLaterPages=footer);buf.seek(0);return buf

@app.get('/api/incident-plans/{plan_id}/report.pdf')
def incident_plan_pdf(plan_id:int):
 buf=_incident_plan_pdf(plan_id);return StreamingResponse(buf,media_type='application/pdf',headers={'Content-Disposition':f'inline; filename="incident-response-plan-{plan_id}.pdf"'})

@app.get('/api/backups')
def backups_list(request:Request):
 _require_admin(request)
 rows=[]
 for p in sorted(BACKUPS.glob('*.zip'),key=lambda x:x.stat().st_mtime,reverse=True):
  rows.append({'name':p.name,'size_bytes':p.stat().st_size,'modified_at':datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec='seconds')})
 return rows[:100]

@app.post('/api/backup')
def backup(request:Request):
 _require_admin(request);path=_backup_archive()
 audit('backup.create',path.name);return {'ok':True,'file':str(path),'name':path.name}


async def _automatic_backup_loop():
 # Check shortly after startup, then hourly. A backup is created when the newest
 # automatic backup is at least 24 hours old. This avoids depending on one exact
 # wall-clock time and catches up after the portal was offline.
 await asyncio.sleep(20)
 while True:
  try:
   if _auto_backup_due():
    path=await asyncio.to_thread(_backup_archive,AUTO_BACKUP_PREFIX)
    deleted=await asyncio.to_thread(_prune_auto_backups,AUTO_BACKUP_KEEP)
    audit('backup.auto',f'{path.name}; retained={AUTO_BACKUP_KEEP}; pruned={len(deleted)}')
   else:
    await asyncio.to_thread(_prune_auto_backups,AUTO_BACKUP_KEEP)
  except Exception as e:
   try:audit('backup.auto.failed',str(e)[:500])
   except Exception:pass
  await asyncio.sleep(60*60)

@app.on_event('startup')
async def _start_automatic_backup_worker():
 asyncio.create_task(_automatic_backup_loop())

@app.delete('/api/backups/{backup_name}')
def backup_delete(backup_name:str,request:Request):
 _require_admin(request)
 if not _backup_name_ok(backup_name):raise HTTPException(400,'Invalid backup name.')
 path=BACKUPS/backup_name
 if not path.exists():raise HTTPException(404,'Backup not found.')
 try:
  size=path.stat().st_size
  path.unlink()
 except Exception as e:raise HTTPException(500,f'Could not delete backup: {e}')
 audit('backup.delete',f'{backup_name}; bytes={size}')
 return {'ok':True,'deleted':backup_name}

@app.post('/api/restore/{backup_name}')
def restore_existing(backup_name:str,request:Request):
 _require_admin(request)
 if not _backup_name_ok(backup_name):raise HTTPException(400,'Invalid backup name.')
 path=BACKUPS/backup_name
 if not path.exists():raise HTTPException(404,'Backup not found.')
 return _apply_restore(path,request)

@app.post('/api/restore-upload')
async def restore_upload(request:Request,file:UploadFile=File(...)):
 _require_admin(request)
 name=Path(file.filename or 'restore.zip').name
 if not name.lower().endswith('.zip'):raise HTTPException(400,'Select a HIVE SECURITY .zip backup.')
 tmp=BACKUPS/f'uploaded_restore_{datetime.now().strftime("%Y%m%d_%H%M%S")}_{secrets.token_hex(2)}.zip'
 total=0
 try:
  with open(tmp,'wb') as out:
   while True:
    chunk=await file.read(1024*1024)
    if not chunk:break
    total+=len(chunk)
    if total>RESTORE_UPLOAD_MAX_BYTES:raise HTTPException(413,'Uploaded backup exceeds the 1 GB limit.')
    out.write(chunk)
  return _apply_restore(tmp,request)
 finally:
  try:tmp.unlink(missing_ok=True)
  except Exception:pass
