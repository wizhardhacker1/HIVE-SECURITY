from __future__ import annotations
import json, smtplib, ssl
from email.message import EmailMessage
from typing import Any
import httpx

UA='HiveMindSecurity/0.4.0'

def _items(data:Any, *keys):
    cur=data
    for k in keys:
        if not isinstance(cur,dict): return []
        cur=cur.get(k,[])
    return cur if isinstance(cur,list) else []

async def ms_token(cfg:dict, scope:str)->str:
    tenant=cfg.get('tenant_id',''); cid=cfg.get('client_id',''); secret=cfg.get('client_secret','')
    if not all((tenant,cid,secret)): raise ValueError('tenant_id, client_id and client_secret are required')
    url=f'https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token'
    async with httpx.AsyncClient(timeout=15) as c:
        r=await c.post(url,data={'client_id':cid,'client_secret':secret,'grant_type':'client_credentials','scope':scope},headers={'User-Agent':UA}); r.raise_for_status(); return r.json()['access_token']

async def fetch_provider(iid:str,cfg:dict,limit:int=50)->dict:
    limit=max(1,min(limit,200))
    async with httpx.AsyncClient(timeout=25,follow_redirects=True,headers={'User-Agent':UA}) as c:
        if iid=='splunk':
            base=cfg['base_url'].rstrip('/'); tok=cfg['token']
            r=await c.get(base+'/services/search/jobs',params={'output_mode':'json','count':limit},headers={'Authorization':'Bearer '+tok}); r.raise_for_status()
            return {'kind':'jobs','items':r.json().get('entry',[])[:limit]}
        if iid=='elastic':
            base=cfg['base_url'].rstrip('/'); key=cfg['api_key']; body={'size':limit,'sort':[{'@timestamp':'desc'}],'query':{'match_all':{}}}
            r=await c.post(base+'/.alerts-security.alerts-*/_search',headers={'Authorization':'ApiKey '+key},json=body); r.raise_for_status()
            return {'kind':'alerts','items':[x.get('_source',{}) for x in _items(r.json(),'hits','hits')]}
        if iid=='defender':
            tok=await ms_token(cfg,'https://api.security.microsoft.com/.default')
            r=await c.get('https://api.security.microsoft.com/api/incidents',params={'$top':limit},headers={'Authorization':'Bearer '+tok}); r.raise_for_status()
            return {'kind':'incidents','items':r.json().get('value',[])[:limit]}
        if iid=='sentinel':
            tok=await ms_token(cfg,'https://management.azure.com/.default'); sub=cfg['subscription_id']; rg=cfg['resource_group']; ws=cfg['workspace_name']
            url=f'https://management.azure.com/subscriptions/{sub}/resourceGroups/{rg}/providers/Microsoft.OperationalInsights/workspaces/{ws}/providers/Microsoft.SecurityInsights/incidents'
            r=await c.get(url,params={'api-version':'2024-09-01'},headers={'Authorization':'Bearer '+tok}); r.raise_for_status()
            return {'kind':'incidents','items':r.json().get('value',[])[:limit]}
        if iid=='crowdstrike':
            base=(cfg.get('base_url') or 'https://api.crowdstrike.com').rstrip('/')
            tr=await c.post(base+'/oauth2/token',data={'client_id':cfg['client_id'],'client_secret':cfg['client_secret']}); tr.raise_for_status(); tok=tr.json()['access_token']
            r=await c.get(base+'/alerts/queries/alerts/v2',params={'limit':limit,'sort':'created_timestamp.desc'},headers={'Authorization':'Bearer '+tok}); r.raise_for_status()
            ids=r.json().get('resources',[])
            if not ids:return {'kind':'alerts','items':[]}
            d=await c.post(base+'/alerts/entities/alerts/v2',json={'composite_ids':ids},headers={'Authorization':'Bearer '+tok}); d.raise_for_status()
            return {'kind':'alerts','items':d.json().get('resources',[])[:limit]}
        if iid=='misp':
            r=await c.post(cfg['base_url'].rstrip('/')+'/events/restSearch',headers={'Authorization':cfg['api_key'],'Accept':'application/json','Content-Type':'application/json'},json={'returnFormat':'json','limit':limit,'published':1}); r.raise_for_status()
            data=r.json(); return {'kind':'events','items':data.get('response',data if isinstance(data,list) else [])[:limit]}
        if iid=='opencti':
            q='query Indicators($first:Int!){indicators(first:$first,orderBy:created_at,orderMode:desc){edges{node{id name pattern confidence created_at}}}}'
            r=await c.post(cfg['base_url'].rstrip('/')+'/graphql',headers={'Authorization':'Bearer '+cfg['token']},json={'query':q,'variables':{'first':limit}}); r.raise_for_status()
            edges=((r.json().get('data') or {}).get('indicators') or {}).get('edges',[]); return {'kind':'indicators','items':[e.get('node',{}) for e in edges]}
        if iid=='taxii':
            base=cfg['base_url'].rstrip('/'); col=cfg.get('collection_id',''); url=f'{base}/collections/{col}/objects/' if col else base
            auth=(cfg.get('username',''),cfg.get('password','')) if cfg.get('username') else None
            r=await c.get(url,headers={'Accept':'application/taxii+json;version=2.1'},auth=auth); r.raise_for_status(); data=r.json()
            return {'kind':'stix','items':data.get('objects',[])[:limit]}
        if iid=='nvd':
            headers={'apiKey':cfg['api_key']} if cfg.get('api_key') else {}; r=await c.get('https://services.nvd.nist.gov/rest/json/cves/2.0',params={'resultsPerPage':limit},headers=headers); r.raise_for_status()
            return {'kind':'cves','items':r.json().get('vulnerabilities',[])[:limit]}
        if iid=='jira':
            base=cfg['base_url'].rstrip('/'); jql=cfg.get('jql') or (f'project={cfg.get("project_key")}' if cfg.get('project_key') else 'order by updated desc')
            r=await c.get(base+'/rest/api/3/search/jql',params={'jql':jql,'maxResults':limit,'fields':'summary,status,priority,assignee,updated,issuetype'},auth=(cfg['email'],cfg['api_token']),headers={'Accept':'application/json'}); r.raise_for_status()
            return {'kind':'issues','items':r.json().get('issues',[])[:limit]}
        if iid=='servicenow':
            base=cfg['base_url'].rstrip('/'); table=cfg.get('table') or 'incident'
            r=await c.get(base+f'/api/now/table/{table}',params={'sysparm_limit':limit,'sysparm_display_value':'true','sysparm_query':'ORDERBYDESCsys_updated_on'},auth=(cfg['username'],cfg['password']),headers={'Accept':'application/json'}); r.raise_for_status()
            return {'kind':table,'items':r.json().get('result',[])[:limit]}
        if iid=='azure':
            tok=await ms_token(cfg,'https://management.azure.com/.default'); sub=cfg['subscription_id']
            url=f'https://management.azure.com/subscriptions/{sub}/providers/Microsoft.Security/assessments'
            r=await c.get(url,params={'api-version':'2021-06-01'},headers={'Authorization':'Bearer '+tok}); r.raise_for_status()
            return {'kind':'assessments','items':r.json().get('value',[])[:limit]}
        if iid=='threatfox':
            r=await c.post('https://threatfox-api.abuse.ch/api/v1/',headers={'Auth-Key':cfg['auth_key'],'Content-Type':'application/json'},json={'query':'get_iocs','days':int(cfg.get('days') or 1)}); r.raise_for_status(); data=r.json(); return {'kind':'iocs','items':(data.get('data') or [])[:limit]}
        if iid=='otx':
            r=await c.get('https://otx.alienvault.com/api/v1/pulses/subscribed',params={'limit':limit},headers={'X-OTX-API-KEY':cfg['api_key']}); r.raise_for_status(); return {'kind':'pulses','items':r.json().get('results',[])[:limit]}
        if iid=='greynoise':
            ip=cfg.get('test_ip') or '8.8.8.8'; headers={'key':cfg['api_key']} if cfg.get('api_key') else {}; r=await c.get(f'https://api.greynoise.io/v3/community/{ip}',headers=headers);
            if r.status_code not in (200,404): r.raise_for_status()
            return {'kind':'ip_context','items':[r.json() if r.content else {'status':r.status_code}]}
        if iid=='abuseipdb':
            ip=cfg.get('test_ip') or '8.8.8.8'; r=await c.get('https://api.abuseipdb.com/api/v2/check',params={'ipAddress':ip,'maxAgeInDays':90,'verbose':''},headers={'Key':cfg['api_key'],'Accept':'application/json'}); r.raise_for_status(); return {'kind':'ip_context','items':[r.json().get('data',{})]}
        if iid=='virustotal':
            indicator=cfg.get('test_ip') or '8.8.8.8'; r=await c.get(f'https://www.virustotal.com/api/v3/ip_addresses/{indicator}',headers={'x-apikey':cfg['api_key']}); r.raise_for_status(); return {'kind':'ip_context','items':[r.json().get('data',{})]}
        if iid=='webhook':
            headers={}; ah=cfg.get('auth_header','');
            if ah: headers['Authorization']=ah
            r=await c.get(cfg['base_url'],headers=headers); return {'kind':'response','items':[{'status_code':r.status_code,'body':r.text[:2000]}]}
    if iid=='aws':
        import boto3
        session=boto3.Session(aws_access_key_id=cfg.get('access_key_id') or None,aws_secret_access_key=cfg.get('secret_access_key') or None,region_name=cfg.get('region') or 'us-east-1')
        sh=session.client('securityhub'); data=sh.get_findings(MaxResults=min(limit,100),SortCriteria=[{'Field':'UpdatedAt','SortOrder':'desc'}])
        return {'kind':'findings','items':data.get('Findings',[])[:limit]}
    if iid=='gcp':
        from google.oauth2 import service_account
        from google.auth.transport.requests import AuthorizedSession
        info=json.loads(cfg['service_account_json']); creds=service_account.Credentials.from_service_account_info(info,scopes=['https://www.googleapis.com/auth/cloud-platform']); sess=AuthorizedSession(creds)
        parent=f'organizations/{cfg["organization_id"]}/sources/-'; url=f'https://securitycenter.googleapis.com/v2/{parent}/findings'
        r=sess.get(url,params={'pageSize':limit,'orderBy':'event_time desc'},timeout=25); r.raise_for_status(); return {'kind':'findings','items':r.json().get('listFindingsResults',[])[:limit]}
    raise ValueError('Live data is not supported for this provider')

async def test_provider(iid:str,cfg:dict)->tuple[bool,str]:
    try:
        if iid in ('slack','teams','smtp'): return (bool(cfg), 'Configuration present; use Send Test for an explicit notification test.')
        data=await fetch_provider(iid,cfg,1); return True,f'Authenticated query succeeded ({len(data.get("items",[]))} item sample).'
    except Exception as e:return False,str(e)[:700]

async def send_test(iid:str,cfg:dict,message:str)->str:
    if iid=='slack':
        async with httpx.AsyncClient(timeout=15) as c:r=await c.post(cfg['webhook_url'],json={'text':message}); r.raise_for_status(); return f'Slack HTTP {r.status_code}'
    if iid=='teams':
        async with httpx.AsyncClient(timeout=15) as c:r=await c.post(cfg['webhook_url'],json={'text':message}); r.raise_for_status(); return f'Teams HTTP {r.status_code}'
    if iid=='webhook':
        headers={'Content-Type':'application/json'}; ah=cfg.get('auth_header');
        if ah:headers['Authorization']=ah
        async with httpx.AsyncClient(timeout=15) as c:r=await c.post(cfg['base_url'],json={'source':'Hive Mind Security','message':message},headers=headers); r.raise_for_status(); return f'Webhook HTTP {r.status_code}'
    if iid=='smtp':
        msg=EmailMessage(); msg['Subject']='Hive Mind Security integration test'; msg['From']=cfg['from_address']; msg['To']=cfg['to_address']; msg.set_content(message)
        host=cfg['host']; port=int(cfg.get('port') or 587)
        if str(cfg.get('ssl','')).lower() in ('1','true','yes'):
            with smtplib.SMTP_SSL(host,port,context=ssl.create_default_context(),timeout=15) as s:
                if cfg.get('username'):s.login(cfg['username'],cfg.get('password',''));s.send_message(msg)
        else:
            with smtplib.SMTP(host,port,timeout=15) as s:
                s.ehlo(); s.starttls(context=ssl.create_default_context()); s.ehlo()
                if cfg.get('username'):s.login(cfg['username'],cfg.get('password',''));s.send_message(msg)
        return 'SMTP test message sent'
    raise ValueError('This provider does not send notifications')
