#!/usr/bin/env bash
set -euo pipefail
APPROOT="${XDG_DATA_HOME:-$HOME/.local/share}/HiveMindSecurity"
SYSTEMD_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user"
DESKTOP_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
if command -v systemctl >/dev/null 2>&1; then
  systemctl --user disable --now hive-security.service >/dev/null 2>&1 || true
fi
rm -f "$SYSTEMD_DIR/hive-security.service" "$DESKTOP_DIR/hive-security.desktop" "$HOME/.local/bin/hive-security" "$HOME/.local/bin/hive-security-stop"
command -v systemctl >/dev/null 2>&1 && systemctl --user daemon-reload >/dev/null 2>&1 || true
echo "HIVE SECURITY application launchers/service removed."
echo "Persistent data was NOT deleted: $APPROOT/data"
echo "To remove all HIVE data manually, delete $APPROOT after making any required backup."
