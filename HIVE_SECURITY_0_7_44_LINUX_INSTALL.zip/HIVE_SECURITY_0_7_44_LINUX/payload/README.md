# HIVE SECURITY 0.7.44 — Linux Build

0.7.44 ports the HIVE SECURITY 0.7.37 application to a native Linux installation workflow. It installs into the current user's XDG data location, preserves HIVE data across upgrades, runs the FastAPI backend as a systemd user service when available, provides a detached fallback launcher, adds a desktop application entry, and provisions Ollama + Meta Llama 3.2 3B using Ollama's official Linux installer.

The application feature set remains aligned with the 0.7.37 Windows build, including hybrid pentest parsing, STIG/pentest lifecycle cleanup, ATT&CK and Kill Chain correlation, OSIRIS Global Intelligence map/legend, incident planning, report studio, scanner, evidence, GRC, Academy, backup/restore, and local AI. Native Windows STIG quick checks remain Windows-only; Linux can import benchmark/report content and can use SSH credentialed assessment workflows.

0.7.44 fixes Firefox login false-failure messaging and restores OpenFreeMap basemap rendering by allowing MapLibre workers, updating MapLibre to the current OpenFreeMap-supported integration, and using the documented Liberty style.
