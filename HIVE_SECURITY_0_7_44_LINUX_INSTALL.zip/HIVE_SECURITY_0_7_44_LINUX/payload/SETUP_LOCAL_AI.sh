#!/usr/bin/env bash
set -euo pipefail
MODEL="${1:-llama3.2:3b}"
APPROOT="${HMS_APPROOT:-${XDG_DATA_HOME:-$HOME/.local/share}/HiveMindSecurity}"
LOGDIR="$APPROOT/logs"
mkdir -p "$LOGDIR"

have_api() {
  python3 - <<'PY' >/dev/null 2>&1
import urllib.request
try:
    with urllib.request.urlopen('http://127.0.0.1:11434/api/tags', timeout=2) as r:
        raise SystemExit(0 if 200 <= getattr(r,'status',200) < 400 else 1)
except Exception:
    raise SystemExit(1)
PY
}

model_present() {
  python3 - "$MODEL" <<'PY' >/dev/null 2>&1
import json,sys,urllib.request
want=sys.argv[1]
try:
    with urllib.request.urlopen('http://127.0.0.1:11434/api/tags', timeout=4) as r: data=json.load(r)
except Exception: raise SystemExit(1)
names=[str(m.get('name','')) for m in data.get('models',[])]
base=want.split(':',1)[0]
raise SystemExit(0 if any(n==want or n.startswith(base+':') for n in names) else 1)
PY
}

# If a working local Ollama service already has the requested model, reuse it exactly as-is.
if have_api && model_present; then
  echo "LOCAL AI already ready: Ollama + $MODEL. Reusing existing installation and model."
  exit 0
fi

# A reachable Ollama API is sufficient even if the CLI is not on this user's PATH.
if ! have_api && ! command -v ollama >/dev/null 2>&1; then
  echo "Ollama is not installed or reachable. Installing from the official Ollama Linux installer..."
  command -v curl >/dev/null 2>&1 || { echo "ERROR: curl is required to install Ollama." >&2; exit 18; }
  curl -fsSL https://ollama.com/install.sh | sh
fi

if ! have_api; then
  echo "Starting existing Ollama service on 127.0.0.1:11434..."
  if command -v systemctl >/dev/null 2>&1; then
    systemctl --user start ollama.service >/dev/null 2>&1 || true
    if [[ ${EUID:-$(id -u)} -eq 0 ]]; then systemctl start ollama.service >/dev/null 2>&1 || true; else sudo -n systemctl start ollama.service >/dev/null 2>&1 || true; fi
  fi
  if ! have_api && command -v ollama >/dev/null 2>&1; then
    nohup setsid ollama serve >"$LOGDIR/ollama.log" 2>&1 </dev/null &
  fi
  for _ in $(seq 1 40); do have_api && break; sleep 1; done
fi

have_api || { echo "ERROR: Ollama did not become available on http://127.0.0.1:11434" >&2; exit 18; }

if model_present; then
  echo "LOCAL AI already ready: Ollama + $MODEL. Existing model retained."
  exit 0
fi

command -v ollama >/dev/null 2>&1 || { echo "ERROR: Ollama service is reachable but the ollama CLI is unavailable, so $MODEL cannot be pulled automatically." >&2; exit 18; }
echo "Local model $MODEL is not installed; downloading it once..."
ollama pull "$MODEL"
model_present || { echo "ERROR: $MODEL was not found after pull." >&2; exit 18; }
echo "LOCAL AI VERIFIED: Ollama + $MODEL"
