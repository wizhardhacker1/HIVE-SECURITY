(() => {
  'use strict';

  const byId = (id) => document.getElementById(id);
  const heading = byId('lh');
  const description = byId('ld');
  const username = byId('lu');
  const password = byId('lp');
  const confirmLabel = byId('lconfirmLabel');
  const confirmPassword = byId('lpc');
  const button = byId('lb');
  const errorBox = byId('le');
  const statusBox = byId('loginStatus');
  let needsSetup = false;
  let submitting = false;
  let authenticated = false;

  function showError(message) {
    if (errorBox) errorBox.textContent = String(message || 'Authentication failed.');
  }

  function setBusy(busy, text) {
    if (button) {
      button.disabled = !!busy;
      if (text) button.textContent = text;
    }
  }

  async function readJson(response) {
    try { return await response.json(); }
    catch (_) { return {}; }
  }

  async function loadStatus() {
    try {
      if (statusBox) statusBox.textContent = 'Checking local HIVE service…';
      const response = await fetch('/api/auth/status', {
        method: 'GET',
        credentials: 'same-origin',
        cache: 'no-store',
        headers: { 'Accept': 'application/json' }
      });
      const data = await readJson(response);
      if (!response.ok) throw new Error(data.detail || `Service returned HTTP ${response.status}`);

      needsSetup = !!data.needs_setup;
      if (data.authenticated) {
        window.location.assign('/');
        return;
      }

      if (needsSetup) {
        heading.textContent = 'Create administrator';
        description.textContent = 'First-run setup. Create the local administrator account. Use at least 12 characters.';
        button.textContent = 'Create secure portal';
        confirmLabel.style.display = 'block';
        confirmPassword.style.display = 'block';
        password.autocomplete = 'new-password';
      } else {
        button.textContent = 'Sign in';
      }
      if (statusBox) statusBox.textContent = 'Local HIVE service connected.';
    } catch (error) {
      if (statusBox) statusBox.textContent = 'HIVE service connection problem.';
      showError(`Unable to contact the local HIVE API: ${error.message}. Reload the page or check the HIVE service log.`);
    }
  }

  async function submitLogin() {
    if (submitting || authenticated) return;
    submitting = true;
    showError('');
    const user = (username?.value || '').trim();
    const pass = password?.value || '';
    if (!user) { submitting = false; showError('Username is required.'); username?.focus(); return; }
    if (!pass) { submitting = false; showError('Password is required.'); password?.focus(); return; }
    if (needsSetup && pass !== (confirmPassword?.value || '')) {
      submitting = false;
      showError('Passwords do not match.');
      return;
    }

    const endpoint = needsSetup ? '/api/auth/setup' : '/api/auth/login';
    setBusy(true, needsSetup ? 'Creating…' : 'Signing in…');
    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        credentials: 'same-origin',
        cache: 'no-store',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username: user, password: pass })
      });
      const data = await readJson(response);
      if (!response.ok) throw new Error(data.detail || `Authentication failed (HTTP ${response.status})`);
      authenticated = true;
      showError('');
      if (statusBox) statusBox.textContent = 'Authenticated. Opening HIVE SECURITY…';
      setBusy(true, 'Opening HIVE…');
      window.location.replace('/');
      return;
    } catch (error) {
      if (authenticated) {
        window.location.replace('/');
        return;
      }
      submitting = false;
      showError(error.message || 'Authentication failed.');
      setBusy(false, needsSetup ? 'Create secure portal' : 'Sign in');
    }
  }

  button?.addEventListener('click', submitLogin);
  password?.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') submitLogin();
  });
  confirmPassword?.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') submitLogin();
  });

  loadStatus();
})();
