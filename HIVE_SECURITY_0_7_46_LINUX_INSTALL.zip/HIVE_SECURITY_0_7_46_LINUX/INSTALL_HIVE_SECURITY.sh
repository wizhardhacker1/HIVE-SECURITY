#!/usr/bin/env bash
set -euo pipefail
VERSION="0.7.46"
MODEL="llama3.2:3b"

# Resolve the real desktop user before choosing persistent paths. This prevents
# sudo/root upgrades from silently creating a second empty HIVE database.
TARGET_USER="$(id -un)"
TARGET_HOME="$HOME"
if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
  candidate="${SUDO_USER:-}"
  if [[ -z "$candidate" || "$candidate" == "root" ]]; then
    candidate="$(logname 2>/dev/null || true)"
  fi
  if [[ -z "$candidate" || "$candidate" == "root" ]]; then
    mapfile -t hive_users < <(getent passwd | awk -F: '$3>=1000 && $3<60000 && $6 ~ /^\/home\// {print $1}')
    if [[ ${#hive_users[@]} -eq 1 ]]; then candidate="${hive_users[0]}"; fi
  fi
  if [[ -n "$candidate" && "$candidate" != "root" ]]; then
    TARGET_USER="$candidate"
    TARGET_HOME="$(getent passwd "$TARGET_USER" | cut -d: -f6)"
  fi
fi
TARGET_UID="$(id -u "$TARGET_USER")"
TARGET_GID="$(id -g "$TARGET_USER")"
APPROOT="${TARGET_HOME}/.local/share/HiveMindSecurity"
APPDIR="$APPROOT/app"
DATADIR="$APPROOT/data"
LOGDIR="$APPROOT/logs"
PAYLOAD="$(cd "$(dirname "${BASH_SOURCE[0]}")/payload" && pwd)"
SYSTEMD_DIR="${TARGET_HOME}/.config/systemd/user"
DESKTOP_DIR="${TARGET_HOME}/.local/share/applications"
BIN_DIR="${TARGET_HOME}/.local/bin"

say(){ printf '%s\n' "$*"; }
fail(){ echo "ERROR: $*" >&2; exit "${2:-1}"; }

say "===================================================="
say "  HIVE SECURITY $VERSION FULL LINUX INSTALLER"
say "===================================================="
say "  Fedora/RHEL + Ubuntu/Debian compatible"
say "  Includes LOCAL AI provisioning: Ollama + Meta Llama 3.2 3B"
say "===================================================="
say

[[ -f "$PAYLOAD/app/main.py" ]] || fail "Installer payload is incomplete: app/main.py missing." 2
[[ -f "$PAYLOAD/app/static/login.html" ]] || fail "Installer payload is incomplete: login.html missing." 2
[[ -f "$PAYLOAD/run.py" ]] || fail "Installer payload is incomplete: run.py missing." 2
[[ -f "$PAYLOAD/requirements-linux.txt" ]] || fail "Installer payload is incomplete: requirements-linux.txt missing." 2

as_root() {
  if [[ ${EUID:-$(id -u)} -eq 0 ]]; then "$@"; else sudo "$@"; fi
}

run_user() {
  if [[ "$(id -un)" == "$TARGET_USER" ]]; then
    HOME="$TARGET_HOME" XDG_DATA_HOME="$TARGET_HOME/.local/share" XDG_CONFIG_HOME="$TARGET_HOME/.config" XDG_RUNTIME_DIR="/run/user/$TARGET_UID" DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$TARGET_UID/bus" "$@"
  elif [[ ${EUID:-$(id -u)} -eq 0 ]]; then
    runuser -u "$TARGET_USER" -- env HOME="$TARGET_HOME" XDG_DATA_HOME="$TARGET_HOME/.local/share" XDG_CONFIG_HOME="$TARGET_HOME/.config" XDG_RUNTIME_DIR="/run/user/$TARGET_UID" DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$TARGET_UID/bus" "$@"
  else
    sudo -u "$TARGET_USER" env HOME="$TARGET_HOME" XDG_DATA_HOME="$TARGET_HOME/.local/share" XDG_CONFIG_HOME="$TARGET_HOME/.config" XDG_RUNTIME_DIR="/run/user/$TARGET_UID" DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$TARGET_UID/bus" "$@"
  fi
}

venv_works() {
  local py="$1" t
  t="$(mktemp -d "${TMPDIR:-/tmp}/hive-venv-test.XXXXXX")"
  if "$py" -m venv "$t/venv" >/dev/null 2>&1 && [[ -x "$t/venv/bin/python" ]]; then
    rm -rf "$t"; return 0
  fi
  rm -rf "$t"; return 1
}

install_prereqs() {
  local need_packages=0
  command -v python3 >/dev/null 2>&1 || need_packages=1
  command -v curl >/dev/null 2>&1 || need_packages=1
  if command -v python3 >/dev/null 2>&1 && ! venv_works "$(command -v python3)"; then
    need_packages=1
    say "Python is installed, but its venv/ensurepip support is missing."
  fi
  if [[ $need_packages -eq 0 ]]; then return 0; fi
  say "Installing required system packages, including Python venv support..."
  if command -v dnf >/dev/null 2>&1; then
    as_root dnf install -y python3 python3-pip python3-devel gcc openssl-devel libffi-devel curl xdg-utils
  elif command -v apt-get >/dev/null 2>&1; then
    as_root apt-get update
    as_root apt-get install -y python3 python3-venv python3-pip python3-dev build-essential libssl-dev libffi-dev curl xdg-utils || true
    # Some Debian/Ubuntu derivatives split venv by exact interpreter version.
    if command -v python3 >/dev/null 2>&1 && ! venv_works "$(command -v python3)"; then
      pyver="$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
      say "Generic python3-venv did not enable venv for Python $pyver; trying python${pyver}-venv..."
      as_root apt-get install -y "python${pyver}-venv" || true
    fi
  else
    fail "Unsupported package manager. Install Python 3.11+, pip/venv, curl, compiler tools, OpenSSL/libffi headers, then rerun." 3
  fi
}

select_python() {
  local candidate
  # Prefer versions with broad dependency support, but accept any >=3.11 interpreter whose venv works.
  for candidate in python3.13 python3.12 python3.11 python3 python3.14; do
    command -v "$candidate" >/dev/null 2>&1 || continue
    "$candidate" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)' >/dev/null 2>&1 || continue
    if venv_works "$(command -v "$candidate")"; then
      command -v "$candidate"; return 0
    fi
  done
  return 1
}
install_prereqs

install_stig_prereqs() {
  say "Checking Linux STIG/OpenSCAP prerequisites..."
  if command -v dnf >/dev/null 2>&1; then
    if ! command -v oscap >/dev/null 2>&1 || [[ ! -d /usr/share/xml/scap/ssg/content ]]; then
      say "Installing OpenSCAP scanner and SCAP Security Guide content..."
      as_root dnf install -y openscap-scanner scap-security-guide || say "WARNING: OpenSCAP/SCAP content installation was not completed. HIVE will show the missing prerequisite in STIG Compliance."
    fi
  elif command -v apt-get >/dev/null 2>&1; then
    if ! command -v oscap >/dev/null 2>&1; then
      say "Installing OpenSCAP scanner and SCAP Security Guide content..."
      as_root apt-get update
      as_root apt-get install -y libopenscap8 scap-security-guide || as_root apt-get install -y openscap-scanner scap-security-guide || say "WARNING: OpenSCAP/SCAP content installation was not completed. HIVE will show the missing prerequisite in STIG Compliance."
    fi
  fi
}
install_stig_prereqs

PYTHON="$(select_python || true)"
[[ -n "$PYTHON" ]] || fail "No Python 3.11+ interpreter with working venv/ensurepip support was found. On Debian/Ubuntu install python3-venv (or python3.X-venv) and rerun." 3
"$PYTHON" - <<'PY' || exit 3
import sys
if sys.version_info < (3,11):
    raise SystemExit(f'ERROR: Python 3.11+ is required; found {sys.version.split()[0]}')
print('Python', sys.version.split()[0], 'OK')
PY

say "Install user: $TARGET_USER"
say "Persistent root: $APPROOT"

# If this target has no DB yet, recover exactly one prior HIVE data directory
# left under another home (a common result of earlier sudo/root installer runs).
if [[ ! -f "$DATADIR/hive_mind_security.db" ]]; then
  candidates=()
  for d in /root/.local/share/HiveMindSecurity/data /home/*/.local/share/HiveMindSecurity/data; do
    [[ -f "$d/hive_mind_security.db" ]] || continue
    [[ "$d" == "$DATADIR" ]] && continue
    candidates+=("$d")
  done
  if [[ ${#candidates[@]} -eq 1 ]]; then
    say "Recovering existing HIVE persistent data from: ${candidates[0]}"
    mkdir -p "$DATADIR"
    cp -a "${candidates[0]}/." "$DATADIR/"
  elif [[ ${#candidates[@]} -gt 1 ]]; then
    say "WARNING: Multiple older HIVE databases were found; automatic migration was skipped to avoid choosing the wrong one."
  fi
fi

mkdir -p "$APPROOT" "$DATADIR" "$LOGDIR" "$BIN_DIR" "$DESKTOP_DIR"
chown -R "$TARGET_UID:$TARGET_GID" "$APPROOT" "$TARGET_HOME/.local" 2>/dev/null || true
chmod 700 "$APPROOT" "$DATADIR" "$LOGDIR" 2>/dev/null || true

say "[1/10] Stopping an existing HIVE SECURITY service..."
if command -v systemctl >/dev/null 2>&1; then
  run_user systemctl --user stop hive-security.service >/dev/null 2>&1 || true
fi
if [[ -f "$APPROOT/server.pid" ]]; then
  pid=$(cat "$APPROOT/server.pid" 2>/dev/null || true)
  [[ "$pid" =~ ^[0-9]+$ ]] && kill "$pid" >/dev/null 2>&1 || true
  rm -f "$APPROOT/server.pid"
fi

# Clean up a stale HIVE process from an earlier install before treating 8765 as a conflict.
port_open() {
  "$PYTHON" -c "import socket,sys; s=socket.socket(); s.settimeout(.35); r=s.connect_ex(('127.0.0.1',8765)); s.close(); sys.exit(0 if r==0 else 1)"
}

if port_open; then
  say "Port 8765 is still active; checking whether it belongs to an existing HIVE SECURITY process..."
  hive_pids=""
  if command -v lsof >/dev/null 2>&1; then
    hive_pids="$(lsof -nP -t -iTCP:8765 -sTCP:LISTEN 2>/dev/null || true)"
  elif command -v fuser >/dev/null 2>&1; then
    hive_pids="$(fuser 8765/tcp 2>/dev/null || true)"
  fi
  for pid in $hive_pids; do
    [[ "$pid" =~ ^[0-9]+$ ]] || continue
    cmd="$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null || true)"
    cwd="$(readlink -f "/proc/$pid/cwd" 2>/dev/null || true)"
    if [[ "$cmd $cwd" == *"HiveMindSecurity"* ]] || [[ "$cmd" == *"hive-security"* ]] || { [[ "$cwd" == "$APPROOT"* ]] && [[ "$cmd" == *"run.py"* || "$cmd" == *"uvicorn"* ]]; }; then
      say "Stopping stale HIVE SECURITY process PID $pid..."
      kill "$pid" >/dev/null 2>&1 || true
      for _ in {1..20}; do kill -0 "$pid" >/dev/null 2>&1 || break; sleep .25; done
      kill -9 "$pid" >/dev/null 2>&1 || true
    fi
  done
  sleep .5
fi

if port_open; then
  fail "Port 8765 is still in use. HIVE will not terminate an unidentified process. Run: sudo ss -ltnp 'sport = :8765'" 9
fi

say "[2/10] Staging the HIVE SECURITY application..."
STAGE="$APPROOT/app.new"
rm -rf "$STAGE"
mkdir -p "$STAGE"
cp -a "$PAYLOAD/." "$STAGE/"
chmod +x "$STAGE/SETUP_LOCAL_AI.sh" "$STAGE/hive-security" "$STAGE/hive-security-stop"

say "[3/10] Creating private Python environment..."
"$PYTHON" -m venv "$STAGE/.venv" || fail "Failed to create Python virtual environment even after venv prerequisite repair. Install python3-venv or the matching python3.X-venv package and rerun." 6

say "[4/10] Installing Python dependencies..."
"$STAGE/.venv/bin/python" -m pip install --upgrade pip
"$STAGE/.venv/bin/python" -m pip install -r "$STAGE/requirements-linux.txt" || fail "Python dependency installation failed." 7

say "[5/10] Verifying HIVE SECURITY payload..."
HMS_DATA_DIR="$DATADIR" "$STAGE/.venv/bin/python" - <<PY || fail "Application verification failed." 8
import sys
from pathlib import Path
sys.path.insert(0, r'''$STAGE''')
import app.main as m
expected='$VERSION'
print(f'Installer version: {expected}; installed payload version: {m.VERSION}')
assert m.VERSION == expected, f'Wrong installed version: {m.VERSION} (expected {expected})'
assert (m.STATIC/'login.html').is_file()
assert Path(r'''$STAGE/run.py''').is_file()
assert Path(r'''$STAGE/SETUP_LOCAL_AI.sh''').is_file()
print(f'HIVE SECURITY {expected} payload verification passed.')
PY

say "[6/10] Activating application files while preserving persistent data..."
rm -rf "$APPROOT/app.prev"
if [[ -d "$APPDIR" ]]; then mv "$APPDIR" "$APPROOT/app.prev"; fi
mv "$STAGE" "$APPDIR"
chown -R "$TARGET_UID:$TARGET_GID" "$APPROOT" 2>/dev/null || true

say "[7/10] Installing user service and desktop launcher..."
mkdir -p "$SYSTEMD_DIR"
cat > "$SYSTEMD_DIR/hive-security.service" <<UNIT
[Unit]
Description=HIVE SECURITY local cybersecurity portal
After=network.target

[Service]
Type=simple
WorkingDirectory=$APPDIR
Environment=HMS_DATA_DIR=$DATADIR
ExecStart=$APPDIR/.venv/bin/python $APPDIR/run.py
Restart=on-failure
RestartSec=3
StandardOutput=append:$LOGDIR/server.log
StandardError=append:$LOGDIR/server.err.log

[Install]
WantedBy=default.target
UNIT

cat > "$APPROOT/hive-security" <<EOF2
#!/usr/bin/env bash
exec "$APPDIR/hive-security" "\$@"
EOF2
cat > "$APPROOT/hive-security-stop" <<EOF2
#!/usr/bin/env bash
exec "$APPDIR/hive-security-stop" "\$@"
EOF2
chmod +x "$APPROOT/hive-security" "$APPROOT/hive-security-stop"
ln -sfn "$APPROOT/hive-security" "$BIN_DIR/hive-security"
ln -sfn "$APPROOT/hive-security-stop" "$BIN_DIR/hive-security-stop"

cat > "$DESKTOP_DIR/hive-security.desktop" <<EOF2
[Desktop Entry]
Type=Application
Name=HIVE SECURITY
Comment=Local cybersecurity operations portal
Exec=$APPROOT/hive-security
Icon=$APPDIR/app/static/icon-256.png
Terminal=false
Categories=Security;Network;System;
StartupNotify=true
EOF2
chmod 644 "$DESKTOP_DIR/hive-security.desktop"
chown -R "$TARGET_UID:$TARGET_GID" "$SYSTEMD_DIR" "$DESKTOP_DIR" "$BIN_DIR" 2>/dev/null || true
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$DESKTOP_DIR" >/dev/null 2>&1 || true

if command -v systemctl >/dev/null 2>&1 && run_user systemctl --user daemon-reload >/dev/null 2>&1; then
  run_user systemctl --user enable hive-security.service >/dev/null 2>&1 || true
fi

say "[8/10] Provisioning LOCAL AI..."
if ! run_user env HMS_APPROOT="$APPROOT" "$APPDIR/SETUP_LOCAL_AI.sh" "$MODEL"; then
  say "WARNING: Local AI provisioning did not complete. Core HIVE SECURITY is installed."
  say "Retry later with: $APPDIR/SETUP_LOCAL_AI.sh $MODEL"
fi

say "[9/10] Starting HIVE SECURITY in the background..."
if command -v systemctl >/dev/null 2>&1 && run_user systemctl --user daemon-reload >/dev/null 2>&1; then
  run_user systemctl --user restart hive-security.service
else
  run_user env HMS_DATA_DIR="$DATADIR" nohup setsid "$APPDIR/.venv/bin/python" "$APPDIR/run.py" >>"$LOGDIR/server.log" 2>>"$LOGDIR/server.err.log" </dev/null &
  echo $! > "$APPROOT/server.pid"
fi

say "[10/10] Waiting for secure portal..."
if ! "$APPDIR/.venv/bin/python" - <<'PY'
import time, urllib.request
url='http://127.0.0.1:8765/login'
for _ in range(75):
    try:
        with urllib.request.urlopen(url,timeout=1.5) as r:
            if 200 <= getattr(r,'status',200) < 400:
                print('Portal ready:',url); raise SystemExit(0)
    except Exception: pass
    time.sleep(1)
raise SystemExit(1)
PY
then
  echo "ERROR: Installation completed, but HIVE did not become ready. Logs: $LOGDIR/server.err.log" >&2
  exit 11
fi

say
say "===================================================="
say "INSTALL COMPLETE - HIVE SECURITY $VERSION FOR LINUX"
say "Application:     $APPDIR"
say "Persistent data: $DATADIR"
say "Logs:            $LOGDIR"
say "Portal:          http://127.0.0.1:8765/login"
say "Launcher:        $APPROOT/hive-security"
say "CLI:             $BIN_DIR/hive-security"
say "Stop:            $BIN_DIR/hive-security-stop"
say "===================================================="
say "Launch from your desktop application menu as HIVE SECURITY or run: hive-security"
