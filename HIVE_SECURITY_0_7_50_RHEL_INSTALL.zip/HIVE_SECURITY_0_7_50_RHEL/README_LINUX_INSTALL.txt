HIVE SECURITY 0.7.50 RHEL-FAMILY INSTALLER

Target: RHEL, Rocky Linux, AlmaLinux, CentOS Stream and compatible dnf-based systems.

HIVE SECURITY 0.7.50 - FULL LINUX INSTALLER
==========================================

SUPPORTED TARGETS
- Fedora / RHEL-family Linux with dnf
- Ubuntu / Debian-family Linux with apt
- Python 3.11 or newer
- x86_64 is the primary tested packaging target; Python dependencies may also support other architectures when wheels/packages are available.

INSTALL
1. Extract the entire archive.
2. Open a terminal in the extracted HIVE_SECURITY_0_7_40_LINUX folder.
3. Run:
     chmod +x INSTALL_HIVE_SECURITY.sh
     ./INSTALL_HIVE_SECURITY.sh
4. The installer may ask for sudo only when Linux system prerequisites or Ollama must be installed.
5. After installation, start HIVE from the desktop application menu or run:
     ~/.local/bin/hive-security

LOCATIONS
Application:      ~/.local/share/HiveMindSecurity/app
Persistent data:  ~/.local/share/HiveMindSecurity/data
Logs:             ~/.local/share/HiveMindSecurity/logs
Desktop launcher: ~/.local/share/applications/hive-security.desktop
Systemd service:  ~/.config/systemd/user/hive-security.service
Portal:           http://127.0.0.1:8765/login

LOCAL AI
- Reuses an existing Ollama installation when present.
- Otherwise uses Ollama's official Linux installer.
- Ensures Meta Llama 3.2 3B (llama3.2:3b) is available.
- Ollama API remains local at http://127.0.0.1:11434.
- First-time model provisioning requires Internet access and roughly 2+ GB of model storage.
- If provisioning is unavailable during install, HIVE core remains installed and setup can be retried with:
     ~/.local/share/HiveMindSecurity/app/SETUP_LOCAL_AI.sh llama3.2:3b

BACKGROUND SERVICE
- On normal systemd desktops, HIVE runs as a systemd USER service. Closing the terminal does not stop the application.
- If systemd user services are unavailable, the launcher uses a detached nohup/setsid fallback.

UPGRADES / DATA
- Re-running the installer replaces application code but preserves ~/.local/share/HiveMindSecurity/data.
- The existing HIVE database, encryption key, integrations, findings, reports, backups, and user accounts remain in the persistent data directory.

PLATFORM NOTES
- HIVE's web portal, report ingestion, hybrid parser, ATT&CK/Kill Chain correlation, OSIRIS intelligence, scanner, reporting, Academy, GRC, evidence, backups, and local AI are platform-neutral.
- Native Windows STIG quick-scan checks remain Windows-only by design. On Linux, import STIG/CKL/CKLB/XCCDF content or use remote/other supported assessment workflows.
- SSH credentialed scanning works from Linux. WinRM support is retained for authorized Windows targets.

STOP
  ~/.local/bin/hive-security-stop
or
  systemctl --user stop hive-security.service

UNINSTALL APPLICATION LAUNCHERS/SERVICE
  ./UNINSTALL_HIVE_SECURITY.sh
The uninstaller intentionally preserves persistent HIVE data.

0.7.50 upgrade notes:
- Maps use OpenFreeMap through MapLibre. No CARTO or HIVE map API key is required.
- Root/sudo installs resolve the desktop user before selecting HIVE's persistent data path.
- If exactly one prior HIVE database exists under another home, the installer recovers it automatically rather than forcing a new admin setup.
- Existing Ollama + llama3.2:3b installations are reused; the model is not pulled again when already present.

0.7.50 fixes Firefox login false-failure messaging and restores OpenFreeMap basemap rendering by allowing MapLibre workers, updating MapLibre to the current OpenFreeMap-supported integration, and using the documented Liberty style.

LINUX STIG QUICK SCAN
- HIVE uses OpenSCAP on Linux with matching installed SCAP Security Guide content.
- Debian/Ubuntu installs use openscap-scanner plus the split ssg-* content packages (Ubuntu: ssg-debderived; Debian: ssg-debian).
- HIVE intentionally does not pin libopenscap8/libopenscap25t64/libopenscap33; APT resolves the correct OpenSCAP runtime library for the OS release.
- RHEL-family systems use the matching RHEL DISA STIG profile when present.
- Fedora/Ubuntu/Debian content is selected only when matching content and a STIG profile are installed.
- HIVE refuses to apply unrelated distribution content.
- Some OpenSCAP checks require elevated privileges; official/root-run XCCDF/CKL results can still be imported.

0.7.50 installer fix:
- The installer application version is now stored as HIVE_VERSION instead of VERSION.
- This prevents /etc/os-release from overwriting HIVE's installer version on distributions whose os-release file defines VERSION (for example VERSION="2026.3").
- Payload verification now compares the HIVE application version only against HIVE_VERSION.

RHEL/OpenSCAP hardening in 0.7.50:
- Supports both dnf and dnf5.
- Verifies the installer is running on a RHEL-family distribution.
- Discovers SCAP Security Guide datastreams across common RHEL content locations.
- Requires matching RHEL major-release content and refuses cross-release STIG benchmarks.
- Verifies a DISA STIG profile exists before reporting native STIG capability.
