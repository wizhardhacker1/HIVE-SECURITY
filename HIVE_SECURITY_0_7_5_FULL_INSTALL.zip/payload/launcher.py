import ctypes
import os
import subprocess
import sys
import time
import urllib.request
import webbrowser
from pathlib import Path

APPROOT = Path(os.environ.get('LOCALAPPDATA', str(Path.home() / 'AppData' / 'Local'))) / 'HiveMindSecurity'
APPDIR = APPROOT / 'app'
LOGDIR = APPROOT / 'logs'
URL = 'http://127.0.0.1:8765/login'


def message(title: str, text: str, error: bool = False) -> None:
    flags = 0x10 if error else 0x40
    try:
        ctypes.windll.user32.MessageBoxW(None, text, title, flags)
    except Exception:
        pass


def ready() -> bool:
    try:
        req = urllib.request.Request(URL, headers={'User-Agent': 'HiveMindSecurity-Launcher/0.6.1'})
        with urllib.request.urlopen(req, timeout=1.5) as r:
            return 200 <= getattr(r, 'status', 200) < 400
    except Exception:
        return False


def read_logs() -> str:
    parts = []
    for name in ('server.err.log', 'server.log'):
        p = LOGDIR / name
        if p.exists():
            try:
                txt = p.read_text(encoding='utf-8', errors='replace')[-5000:]
                if txt.strip():
                    parts.append(f'--- {name} ---\n{txt}')
            except Exception:
                pass
    return '\n\n'.join(parts) or 'No server log output was available.'


def run_hidden(args, cwd=None, timeout=30):
    creationflags = 0
    startupinfo = None
    if os.name == 'nt':
        creationflags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = 0
    return subprocess.run(args, cwd=str(cwd) if cwd else None, capture_output=True, text=True,
                          timeout=timeout, creationflags=creationflags, startupinfo=startupinfo)


def main() -> int:
    if ready():
        webbrowser.open(URL)
        return 0

    pyexe = APPDIR / '.venv' / 'Scripts' / 'python.exe'
    stop_ps1 = APPROOT / 'STOP_HIVE_MIND_SECURITY.ps1'
    start_ps1 = APPDIR / 'START_SERVER.ps1'
    run_py = APPDIR / 'run.py'

    missing = [str(p) for p in (pyexe, stop_ps1, start_ps1, run_py) if not p.exists()]
    if missing:
        message('Hive Mind Security', 'The installation is incomplete. Re-run INSTALL_HIVE_MIND_SECURITY.bat.\n\nMissing:\n' + '\n'.join(missing), True)
        return 12

    LOGDIR.mkdir(parents=True, exist_ok=True)

    try:
        stop = run_hidden([
            'powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(stop_ps1),
            '-Port', '8765', '-FailIfForeign'
        ], cwd=APPROOT, timeout=20)
    except Exception as e:
        message('Hive Mind Security', f'Could not inspect port 8765.\n\n{e}', True)
        return 9

    if stop.returncode >= 9:
        details = (stop.stderr or stop.stdout or '').strip()
        message('Hive Mind Security', 'Port 8765 is being used by another application. Close that application and try again.' + (f'\n\n{details}' if details else ''), True)
        return 9

    try:
        start = run_hidden([
            'powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(start_ps1),
            '-PythonExe', str(pyexe), '-AppDir', str(APPDIR), '-LogDir', str(LOGDIR),
            '-PidFile', str(APPROOT / 'server.pid')
        ], cwd=APPDIR, timeout=20)
    except Exception as e:
        message('Hive Mind Security', f'Could not start the local secure portal.\n\n{e}', True)
        return 14

    if start.returncode != 0:
        message('Hive Mind Security', 'The local server process could not be launched.\n\n' + ((start.stderr or start.stdout or '').strip() or read_logs()), True)
        return 14

    deadline = time.time() + 30
    while time.time() < deadline:
        if ready():
            webbrowser.open(URL)
            return 0
        time.sleep(0.5)

    message('Hive Mind Security', 'The application started but the secure portal did not become ready.\n\nLogs:\n' + read_logs(), True)
    return 11


if __name__ == '__main__':
    raise SystemExit(main())
