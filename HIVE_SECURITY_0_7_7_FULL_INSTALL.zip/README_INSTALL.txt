HIVE SECURITY 0.7.7 - FULL WINDOWS INSTALLER
INCLUDING LOCAL AI: OLLAMA + META LLAMA 3.2 3B

1. Extract the ENTIRE ZIP to a normal folder.
2. Double-click INSTALL_HIVE_MIND_SECURITY.bat.
3. The installer creates/updates %LOCALAPPDATA%\HiveMindSecurity\app and preserves persistent data in %LOCALAPPDATA%\HiveMindSecurity\data.
4. It installs Hive Mind Python dependencies into a private virtual environment and builds the branded HiveMindSecurity.exe launcher.
5. It checks for Ollama. If Ollama is already installed, that installation is reused. If it is missing, the installer installs the official Windows Ollama package.
6. It checks for Meta Llama 3.2 3B (llama3.2:3b). If the model is missing it downloads it, then performs a real local inference health check before Hive Mind installation is reported complete.
7. Ollama remains on the local loopback API at http://127.0.0.1:11434 for Hive Mind local AI features.
8. First-time Ollama/model provisioning requires internet access. The Llama 3.2 3B Ollama model is about 2 GB, so allow time and disk space for the download.
9. A repair/retry script is installed at %LOCALAPPDATA%\HiveMindSecurity\SETUP_LOCAL_AI.bat.
10. Desktop/Start Menu shortcuts and browser icons use the Hive Mind shield.
11. The built-in Pentest Scanner does not require Nessus or Nmap. Optional SSH/WinRM support is part of Hive Mind's own Python environment.
12. Credentialed scanning requires the target system to permit the selected protocol and valid authorized credentials.

Normal launcher:
%LOCALAPPDATA%\HiveMindSecurity\HiveMindSecurity.exe

Persistent data:
%LOCALAPPDATA%\HiveMindSecurity\data

Local AI:
Ollama API: http://127.0.0.1:11434
Model: llama3.2:3b
