# HIVE SECURITY 0.7.7

## Built-in Authorized Pentest Scanner

HIVE SECURITY now includes a local-first vulnerability/exposure scanner that does not require Nessus or Nmap. The scanner performs bounded TCP service discovery, HTTP/TLS posture checks, selected exposed-service and legacy-banner checks, optional credentialed read-only inventory, encrypted result storage, tracked-finding import, and PDF reporting.

### Scan profiles
- Quick: common infrastructure/application ports.
- Standard: TCP 1-1024 plus common database, management, cache, search, and web application ports.
- Targets: one IP, DNS name, or CIDR up to /27 (32 usable hosts).
- Authorization confirmation is mandatory before a scan can start.
- No exploit execution, password spraying, persistence, destructive checks, stealth/evasion, or automatic scope expansion.

### Credentialed scanning
Administrator User Information now includes an optional encrypted scan credential profile per Hive Mind user:
- SSH username + password and/or private key for Linux/Unix read-only inventory.
- Windows WinRM username + password + optional domain for read-only inventory/configuration queries.
- Secrets are encrypted at rest with the Hive Mind local data key and are never returned to the browser after saving.
- Analysts may use only their own saved credential profile; administrators can select configured profiles.

### Reports and findings
Each completed scan produces an encrypted-at-rest PDF pentest scan report. Findings can also be imported into the existing Tracked Finding Register for remediation, ownership, status updates, and remediation reporting.

## Existing platform capabilities
0.7.7 retains the secure local portal, user administration/RBAC, unified operations, SOC/IR lifecycle, vulnerability board, STIG helper/import, third-party pentest report ingestion, tracked findings/remediation PDFs, threat feeds/integrations, Red/Blue/Purple workspaces, playbooks, GRC frameworks, Analyst Toolbox, and the Security+/SecurityX/CISSP/LFCS/CEH learning and exam system.

Persistent application data remains under `%LOCALAPPDATA%\HiveMindSecurity\data` and is preserved during upgrades.

## Local AI provisioning in 0.7.7

The full Windows installer now treats LOCAL AI as an installation component rather than an optional undocumented post-step. It checks for Ollama, installs Ollama from its official Windows distribution when missing, provisions `llama3.2:3b`, verifies the loopback API on `127.0.0.1:11434`, and runs a real inference health check. Existing Ollama/model installations are reused. `SETUP_LOCAL_AI.bat` remains available for repair/retry.

## STIG remediation guidance in 0.7.7
Imported STIG findings now use the authoritative Fix Text when it is present in CKL/CKLB/XCCDF content. If an imported result omits Fix Text, HIVE SECURITY generates conservative supplemental remediation guidance from the rule title, IDs, and finding details for common Windows security controls. Unknown rules remain explicit rather than inventing registry values or commands. Re-import older scan files to populate guidance for legacy findings.
