@echo off
setlocal EnableExtensions
set "VERSION=0.7.7"
set "APPROOT=%LOCALAPPDATA%\HiveMindSecurity"
set "APPDIR=%APPROOT%\app"
set "DATADIR=%APPROOT%\data"
set "LOGDIR=%APPROOT%\logs"
set "HMS_DATA_DIR=%DATADIR%"

if not exist "%APPDIR%\run.py" goto :missingapp
if not exist "%APPDIR%\WAIT_FOR_PORTAL.py" goto :missingapp
if not exist "%APPDIR%\START_SERVER.ps1" goto :missingapp
if not exist "%APPROOT%\STOP_HIVE_MIND_SECURITY.ps1" goto :missingapp
if not exist "%LOGDIR%" mkdir "%LOGDIR%" >nul 2>nul

cd /d "%APPDIR%"
echo Starting HIVE SECURITY %VERSION%...
powershell -NoProfile -ExecutionPolicy Bypass -File "%APPROOT%\STOP_HIVE_MIND_SECURITY.ps1" -Port 8765 -FailIfForeign
if errorlevel 9 (
  echo ERROR: Port 8765 is being used by another application.
  pause
  exit /b 9
)

if not exist "%APPDIR%\.venv\Scripts\python.exe" (
  echo ERROR: HIVE SECURITY private Python environment is missing.
  echo Re-run INSTALL_HIVE_MIND_SECURITY.bat.
  pause
  exit /b 13
)
set "PYEXE=%APPDIR%\.venv\Scripts\python.exe"

powershell -NoProfile -ExecutionPolicy Bypass -File "%APPDIR%\START_SERVER.ps1" -PythonExe "%PYEXE%" -AppDir "%APPDIR%" -LogDir "%LOGDIR%" -PidFile "%APPROOT%\server.pid"
if errorlevel 1 (
  echo ERROR: Could not launch the HIVE SECURITY server process.
  pause
  exit /b 14
)

echo Waiting for the secure portal...
"%PYEXE%" "%APPDIR%\WAIT_FOR_PORTAL.py" "http://127.0.0.1:8765/login" 25
if errorlevel 1 goto :startupfail

echo Secure portal is ready.
start "" http://127.0.0.1:8765/login
endlocal
exit /b 0

:startupfail
echo.
echo ERROR: HIVE SECURITY did not become ready on http://127.0.0.1:8765/login
echo.
echo ----- SERVER ERROR LOG -----
if exist "%LOGDIR%\server.err.log" type "%LOGDIR%\server.err.log"
if exist "%LOGDIR%\server.log" type "%LOGDIR%\server.log"
echo ----- END SERVER LOG -----
echo Logs are saved under: %LOGDIR%
pause
exit /b 11

:missingapp
echo ERROR: HIVE SECURITY application files are incomplete under:
echo   %APPDIR%
echo Re-run INSTALL_HIVE_MIND_SECURITY.bat.
pause
exit /b 12
