HIVE SECURITY 0.7.45 - Docker + Podman Two-Container Deployment

CONTENTS
  hive/      HIVE SECURITY application image build context
  ollama/    Ollama + Meta Llama 3.2 3B image build context
  compose.yaml
             Recommended LAN-server deployment. HIVE is published on port 8765.
             Ollama is NOT published and is reachable only by HIVE on hive-backend.
  compose.standalone-macvlan.yaml
             Optional standalone-appliance deployment where HIVE receives its own LAN IP.
  .env.example
  START_HIVE_CONTAINERS.sh
  STOP_HIVE_CONTAINERS.sh
  STATUS_HIVE_CONTAINERS.sh

QUICK START
  cp .env.example .env
  ./START_HIVE_CONTAINERS.sh

Docker manually:
  docker compose up -d --build

Podman manually:
  podman compose up -d --build

HIVE-to-OLLAMA CONNECTION
  HIVE uses http://ollama:11434. The name "ollama" is resolved by container DNS on
  the private hive-backend network. Ollama port 11434 is not exposed to the LAN.

VERIFY
  ./STATUS_HIVE_CONTAINERS.sh

PERSISTENCE
  hive-data    HIVE database, encryption key, reports, evidence and backups
  ollama-data  Ollama models, including llama3.2:3b

UPGRADES
  Rebuilding/replacing containers does not remove these named volumes. Do not run
  compose down -v unless you intentionally want to delete persistent HIVE/Ollama data.

NETWORK MODES
  Default compose.yaml: users connect to http://SERVER-IP:8765.
  Standalone macvlan: copy .env.example to .env, edit interface/subnet/gateway/IP,
  then run the standalone compose file. HIVE joins both the LAN and private backend;
  Ollama joins only the private backend.

SECURITY
  The HIVE application container runs as an unprivileged user. Ollama remains private.
  No --privileged mode is used. Host-level checks that require direct OS access may not
  function identically from inside a container.
