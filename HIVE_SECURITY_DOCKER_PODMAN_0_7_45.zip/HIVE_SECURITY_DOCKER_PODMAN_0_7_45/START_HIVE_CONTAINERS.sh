#!/bin/sh
set -eu
ENGINE="${CONTAINER_ENGINE:-}"
if [ -z "$ENGINE" ]; then
  if command -v docker >/dev/null 2>&1; then ENGINE=docker
  elif command -v podman >/dev/null 2>&1; then ENGINE=podman
  else echo "ERROR: Install Docker or Podman first." >&2; exit 2
  fi
fi
if [ "$ENGINE" = docker ]; then
  docker compose up -d --build
else
  podman compose up -d --build
fi
printf '\nHIVE SECURITY: http://<this-server-IP>:%s\n' "${HIVE_PORT:-8765}"
printf 'Ollama remains private on the hive-backend network.\n'
