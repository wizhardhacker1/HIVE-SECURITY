#!/bin/sh
set -eu
ENGINE="${CONTAINER_ENGINE:-}"
if [ -z "$ENGINE" ]; then
  if command -v docker >/dev/null 2>&1; then ENGINE=docker
  elif command -v podman >/dev/null 2>&1; then ENGINE=podman
  else echo "ERROR: Docker/Podman not found." >&2; exit 2
  fi
fi
$ENGINE ps --filter name=hive-security --filter name=hive-ollama
printf '\nHIVE -> Ollama connectivity test:\n'
$ENGINE exec hive-security python - <<'PY' || true
import json, urllib.request
u='http://ollama:11434/api/tags'
try:
    with urllib.request.urlopen(u, timeout=5) as r:
        d=json.load(r)
    print('CONNECTED:', u)
    print('MODELS:', ', '.join(m.get('name','') for m in d.get('models',[])) or '(none)')
except Exception as e:
    print('FAILED:', e)
PY
