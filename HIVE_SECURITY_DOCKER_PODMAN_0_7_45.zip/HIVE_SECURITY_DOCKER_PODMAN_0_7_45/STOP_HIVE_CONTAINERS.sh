#!/bin/sh
set -eu
ENGINE="${CONTAINER_ENGINE:-}"
if [ -z "$ENGINE" ]; then
  if command -v docker >/dev/null 2>&1; then ENGINE=docker
  elif command -v podman >/dev/null 2>&1; then ENGINE=podman
  else echo "ERROR: Docker/Podman not found." >&2; exit 2
  fi
fi
if [ "$ENGINE" = docker ]; then docker compose down
else podman compose down
fi
