HIVE SECURITY 0.7.45 - Docker/Podman Build Context

Build with Docker:
  docker build -t hive-security:0.7.45 .

Build with Podman:
  podman build -t hive-security:0.7.45 .

This image expects persistent data at /data and Ollama at http://ollama:11434 by default.
Important environment variables:
  HMS_DATA_DIR=/data
  HMS_OLLAMA_URL=http://ollama:11434
  HMS_OLLAMA_MODEL=llama3.2:3b
  HMS_ALLOWED_HOSTS=*
  HMS_BIND_HOST=0.0.0.0
  HMS_PORT=8765

Use the combined deployment bundle for the recommended two-container configuration.
