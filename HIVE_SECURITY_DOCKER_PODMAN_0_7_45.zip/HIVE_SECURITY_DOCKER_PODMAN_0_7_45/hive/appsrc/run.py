import os
import uvicorn

if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host=os.getenv("HMS_BIND_HOST", "0.0.0.0"),
        port=int(os.getenv("HMS_PORT", "8765")),
        reload=False,
        log_level=os.getenv("HMS_LOG_LEVEL", "info"),
    )
