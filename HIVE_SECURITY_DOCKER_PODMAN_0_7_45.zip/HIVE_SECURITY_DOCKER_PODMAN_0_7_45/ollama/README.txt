HIVE Ollama Container 0.7.45

Build with Docker:
  docker build -t hive-ollama:0.7.45 .

Build with Podman:
  podman build -t hive-ollama:0.7.45 .

The image provisions llama3.2:3b on first start and reuses the model from /root/.ollama thereafter.
The recommended combined deployment does NOT publish port 11434 to the LAN; only HIVE can reach it on the private hive-backend network.
