#!/bin/sh
set -eu
MODEL="${HIVE_OLLAMA_MODEL:-llama3.2:3b}"
export OLLAMA_HOST="${OLLAMA_BIND:-0.0.0.0:11434}"

ollama serve &
PID=$!
trap 'kill "$PID" 2>/dev/null || true; wait "$PID" 2>/dev/null || true' INT TERM EXIT

TRIES=0
until ollama list >/dev/null 2>&1; do
  TRIES=$((TRIES+1))
  if [ "$TRIES" -ge 60 ]; then
    echo "ERROR: Ollama service did not become ready." >&2
    exit 1
  fi
  sleep 1
done

if ! ollama list 2>/dev/null | awk 'NR>1 {print $1}' | grep -Fxq "$MODEL"; then
  echo "Provisioning HIVE local AI model: $MODEL"
  ollama pull "$MODEL"
else
  echo "Reusing existing Ollama model: $MODEL"
fi

wait "$PID"
