from __future__ import annotations
import asyncio, base64, binascii, hashlib, ipaddress, json, os, re, secrets, socket, sqlite3, ssl, subprocess, tempfile, time, urllib.parse, zipfile, uuid
from contextvars import ContextVar
from io import BytesIO
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import httpx
import xml.etree.ElementTree as ET
from cryptography.fernet import Fernet, InvalidToken
from fastapi import FastAPI, HTTPException, UploadFile, File, Request, Response
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from pypdf import PdfReader
from docx import Document
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from app.providers import fetch_provider, test_provider, send_test

ROOT=Path(__file__).resolve().parent.parent
DATA=Path(os.getenv('HMS_DATA_DIR',Path(os.getenv('LOCALAPPDATA',ROOT))/'HiveMindSecurity'/'data' if os.getenv('LOCALAPPDATA') else ROOT/'data'))
DATA.mkdir(parents=True,exist_ok=True)
DB=DATA/'hive_mind_security.db'; KEYFILE=DATA/'.hms.key'; BACKUPS=DATA/'backups'; BACKUPS.mkdir(exist_ok=True)
REPORT_STORE=DATA/'pentest_reports'; REPORT_STORE.mkdir(exist_ok=True)
REMEDIATION_STORE=DATA/'remediation_reports'; REMEDIATION_STORE.mkdir(exist_ok=True)
SCAN_REPORT_STORE=DATA/'scan_reports'; SCAN_REPORT_STORE.mkdir(exist_ok=True)
STATIC=ROOT/'app'/'static'; APPDATA=ROOT/'app'/'data'; VERSION='0.7.3'
app=FastAPI(title='Hive Mind Security',version=VERSION,description='Cybersecurity mission command, SOC, threat intelligence, team operations, GRC, live integrations, security toolbox, and certification academy.')
app.mount('/static',StaticFiles(directory=STATIC),name='static')

NEWS_FEEDS=[
 ('CISA Advisories','https://www.cisa.gov/cybersecurity-advisories/all.xml','Government / Advisories','https://www.cisa.gov/news-events/cybersecurity-advisories'),
 ('BleepingComputer','https://www.bleepingcomputer.com/feed/','Breaking / Malware / Ransomware','https://www.bleepingcomputer.com/'),
 ('The Hacker News','https://feeds.feedburner.com/TheHackersNews','Threat Intelligence / Vulnerabilities','https://thehackernews.com/'),
 ('Dark Reading','https://www.darkreading.com/rss.xml','Enterprise / Threat Research','https://www.darkreading.com/'),
 ('SecurityWeek','https://feeds.feedburner.com/securityweek','Enterprise / ICS / Vulnerabilities','https://www.securityweek.com/'),
 ('Cybersecurity Dive','https://www.cybersecuritydive.com/feeds/news/','Business / Regulation / Strategy','https://www.cybersecuritydive.com/'),
 ('CyberScoop','https://cyberscoop.com/feed/','Government / Policy / National Security','https://cyberscoop.com/'),
 ('The Record','https://therecord.media/feed','Cybercrime / Global Incidents','https://therecord.media/'),
 ('Krebs on Security','https://krebsonsecurity.com/feed/','Investigations / Cybercrime','https://krebsonsecurity.com/')
]
CERTS={
 'security-plus':{'name':'CompTIA Security+','exam':'SY0-701','type':'multiple-choice','domains':['General Security Concepts','Threats, Vulnerabilities & Mitigations','Security Architecture','Security Operations','Security Program Management & Oversight']},
 'securityx':{'name':'CompTIA SecurityX','exam':'CAS-005','type':'scenario','domains':['Governance, Risk, and Compliance','Security Architecture','Security Engineering','Security Operations']},
 'cissp':{'name':'ISC2 CISSP','exam':'Current outline','type':'scenario','domains':['Security and Risk Management','Asset Security','Security Architecture and Engineering','Communication and Network Security','Identity and Access Management','Security Assessment and Testing','Security Operations','Software Development Security']},
 'lfcs':{'name':'Linux Foundation Certified System Administrator','exam':'LFCS','type':'performance-based','domains':['Operations and Deployment','Networking','Storage','Essential Commands','Users and Groups']},
 'ceh':{'name':'EC-Council Certified Ethical Hacker','exam':'CEH v13 / 312-50','type':'knowledge + practical preparation','domains':['Introduction to Ethical Hacking','Footprinting and Reconnaissance','Scanning Networks','Enumeration','Vulnerability Analysis','System Hacking','Malware Threats','Sniffing','Social Engineering','Denial-of-Service','Session Hijacking','Evading IDS, Firewalls, and Honeypots','Hacking Web Servers','Hacking Web Applications','SQL Injection','Hacking Wireless Networks','Hacking Mobile Platforms','IoT and OT Hacking','Cloud Computing','Cryptography']}
}


EXAM_REQUIREMENTS={
 'security-plus':{'official_format':'Maximum 90 questions • 90 minutes • multiple-choice + performance-based','official_pass':'750 on a 100–900 scaled score','practice_pass_percent':83,'practice_note':'Hive Mind uses 83% as a conservative raw-score practice threshold. CompTIA uses scaled scoring, so this is not an official raw-score conversion.'},
 'securityx':{'official_format':'Maximum 90 questions • 165 minutes • multiple-choice + performance-based','official_pass':'Pass/fail only; CompTIA does not publish a scaled passing score','practice_pass_percent':80,'practice_note':'Because CompTIA does not publish a numeric SecurityX cut score, Hive Mind uses 80% as a readiness threshold, not an official passing score.'},
 'cissp':{'official_format':'CAT • 100–150 items • 3 hours • multiple-choice + advanced item types','official_pass':'700 out of 1000 scaled points','practice_pass_percent':70,'practice_note':'Hive Mind uses 70% as a practice threshold. ISC2 uses psychometric scaled scoring; 70% raw is not an official conversion of 700/1000.'},
 'lfcs':{'official_format':'Performance-based command-line exam • 2 hours','official_pass':'66% practice benchmark used by the LFCS study guide in Hive Mind','practice_pass_percent':66,'practice_note':'Hive Mind applies the 66% benchmark to its knowledge checks. The real LFCS is performance-based, so hands-on lab performance remains essential.'},
 'ceh':{'official_format':'125 multiple-choice questions • 4 hours','official_pass':'Form-dependent cut score; EC-Council states typical passing cut scores range from 65% to 85%','practice_pass_percent':85,'practice_note':'Hive Mind uses the top of EC-Council’s published typical cut-score range (85%) as a conservative practice threshold.'}
}
for _cert,_req in EXAM_REQUIREMENTS.items():
 if _cert in CERTS: CERTS[_cert]['requirements']=_req

BANKS={k:json.loads((APPDATA/f'{f}.json').read_text(encoding='utf-8')) for k,f in {'security-plus':'security_plus','securityx':'securityx','cissp':'cissp','lfcs':'lfcs','ceh':'ceh'}.items()}

STUDY_AIDS={
 'security-plus':{
  'overview':'Use this path to build broad operational security fundamentals before taking timed scenario exams.',
  'quick_refs':['CIA triad + AAA','Common ports and secure protocols','PKI, hashing, encryption and key management','IAM, MFA and least privilege','Network segmentation, Zero Trust and cloud shared responsibility','Incident response, logging, SIEM and vulnerability management','Risk, policy, third-party and compliance concepts'],
  'labs':['Map an incident to the IR lifecycle','Review HTTP security headers','Build a least-privilege access matrix','Write a basic detection rule from a log event','Prioritize a KEV-matched vulnerability'],
  'flashcards':[['Integrity','Protection against unauthorized modification.'],['RTO','Target time to restore a service after disruption.'],['RPO','Maximum tolerable data loss measured in time.'],['SASE','Cloud-delivered networking and security architecture.'],['SCAP','Standards that support automated vulnerability and configuration assessment.']]
 },
 'securityx':{
  'overview':'Advanced architecture and operations study path using scenario-based decision making, not simple memorization.',
  'quick_refs':['Enterprise risk and governance decision patterns','Zero Trust, SASE, microsegmentation and secure architecture','Cloud, container, API, OT/ICS and AI security','Cryptographic architecture and post-quantum planning','Threat modeling and attack-path analysis','Advanced detection, SIEM/XDR, UEBA, threat intelligence and automation','Incident command, forensics, resilience and recovery','Supply-chain, SBOM and secure engineering'],
  'labs':['Design a three-tier microsegmentation policy','Create a Zero Trust access decision flow','Map an attack chain to required telemetry','Draft a cloud guardrail policy-as-code control','Build a purple-team validation for a MITRE technique','Perform a tabletop for ransomware plus identity compromise'],
  'flashcards':[['Microsegmentation','Granular east-west isolation that limits lateral movement.'],['SASE','Converged cloud-delivered networking and security capabilities.'],['SCAP','Security Content Automation Protocol; supports standardized configuration and vulnerability assessment.'],['UEBA','Behavior analytics used to identify anomalous user/entity activity.'],['Data diode','Unidirectional gateway used where one-way data transfer is required.']]
 },
 'cissp':{
  'overview':'Managerial and architectural review across the eight CISSP domains. Focus on risk-based decisions and business alignment.',
  'quick_refs':['Risk: inherent vs residual, treatment, ALE, due care/diligence','Data ownership, classification, lifecycle and retention','Secure design principles and security models','Network architecture and secure protocols','IAM lifecycle, federation, privileged access and access models','Assessment independence, vulnerability testing and penetration testing','IR, BCP/DR, evidence, logging and recovery','Secure SDLC, testing, dependencies and software supply chain'],
  'labs':['Create a BIA for a critical service','Build a data classification matrix','Review an architecture for single points of failure','Design joiner-mover-leaver controls','Create an incident evidence chain-of-custody checklist'],
  'flashcards':[['Residual risk','Risk remaining after controls are applied.'],['Due care','Reasonable protective actions expected from an organization.'],['Due diligence','Ongoing investigation and verification that controls remain appropriate/effective.'],['RTO','Maximum targeted restoration time.'],['RPO','Maximum acceptable data loss expressed as time.']]
 },
 'lfcs':{
  'overview':'Hands-on Linux administration path. Practice commands in a disposable Linux VM and verify every change.',
  'quick_refs':['Files: ls, cd, pwd, find, cp, mv, rm, mkdir, chmod, chown, grep, sed, awk, tar','Systems: systemctl, journalctl, ps, top, kill, nice, cron, systemd timers','Users: useradd, usermod, passwd, groups, sudo, visudo','Networking: ip addr, ip route, ss, dig, hostnamectl, SSH, firewalld/ufw','Services: web servers, SSH, TLS, databases, NFS/Samba and mail basics','Storage: lsblk, fdisk/parted, mkfs, mount, fstab, LVM, RAID, quotas'],
  'labs':['Create and archive a directory tree, then restore it','Create a user/group and safe sudo rule','Create and enable a systemd service','Configure a static route and validate connectivity','Deploy a basic web service and validate TLS/headers','Create an LVM volume, filesystem, mount point and persistent fstab entry','Troubleshoot a failed service using systemctl and journalctl'],
  'flashcards':[['systemctl enable --now','Enable a service at boot and start it immediately.'],['journalctl -u UNIT -f','Follow logs for a systemd unit.'],['usermod -aG GROUP USER','Append a user to a supplementary group.'],['ss -lntp','List listening TCP sockets and process information.'],['lsblk -f','Show block devices and filesystem metadata.'],['visudo','Safely edit and syntax-check sudoers.']]
 },
 'ceh':{
  'overview':'CEH preparation path organized around the current 20-module ethical-hacking curriculum. Use only systems you own or have explicit written authorization to test.',
  'quick_refs':['Rules of engagement, scope, authorization, evidence handling and reporting','Five-phase ethical-hacking workflow: reconnaissance, scanning, gaining access, maintaining access, covering tracks — study as concepts, not unauthorized activity','OSINT and footprinting sources','Host, port, service and OS discovery concepts','Enumeration and vulnerability-analysis workflow','Authentication, password storage, privilege and hardening concepts','Malware behavior and defensive analysis','Packet capture, spoofing and network defense','Social-engineering indicators and user protections','DoS/DDoS concepts and resilience','Session security, tokens and transport protections','IDS/firewall/honeypot roles and detection','Web server and web application attack surfaces','Injection flaws and secure parameterized queries','Wireless security standards and segmentation','Mobile application/platform security','IoT/OT safety, segmentation and monitoring','Cloud shared responsibility, IAM and logging','Cryptography, PKI, hashing and key management','Professional reporting, remediation and retesting'],
  'labs':['Write a rules-of-engagement document for a fictional assessment','Perform passive OSINT on a domain you own and document only public metadata','Run service discovery against an isolated lab VM and compare results with its known configuration','Review a deliberately vulnerable lab application and map findings to CWE categories without attacking public systems','Analyze a packet capture from a lab and identify protocols, endpoints and suspicious patterns','Review password hashes created in the lab using the Password Hash Audit tool and a small approved candidate list','Create a web-server hardening checklist and verify headers on a lab service','Build an incident-style timeline from a simulated phishing scenario','Create a cloud IAM least-privilege review checklist','Write a final pentest-style finding with evidence, risk, remediation and retest steps'],
  'flashcards':[['Rules of Engagement','Written constraints defining scope, allowed techniques, timing, contacts, stop conditions and evidence handling.'],['Footprinting','Collection of information about a target environment, preferably passive first and only within authorization.'],['Enumeration','Active identification of users, services, shares or other details from an authorized target.'],['Vulnerability Analysis','Systematic identification and prioritization of weaknesses before remediation or authorized validation.'],['Least Privilege','Grant only the access necessary for a task and no more.'],['Salt','Unique random value added before password hashing to defeat precomputed rainbow tables.'],['Parameterized Query','SQL statement structure that separates code from user-supplied data to reduce injection risk.'],['WPA3','Modern Wi-Fi security generation providing stronger protections than legacy WPA/WPA2 configurations.'],['Cloud Shared Responsibility','Security duties are split between the cloud provider and customer depending on service model.'],['PKI','Certificates, certificate authorities, keys and policies used to establish trust and secure communications.'],['Honeypot','Decoy system or service designed to attract and observe suspicious activity.'],['CWE','Common Weakness Enumeration: taxonomy for software and hardware weakness types.']]
 }
}


CEH_VIDEOS=[
 {'title':'EC-Council CEH Overview','provider':'YouTube / EC-Council','embed':'https://www.youtube-nocookie.com/embed/V_i3wCtn0qA','note':'Official EC-Council overview. Use alongside the current course outline because older overview videos may reference earlier CEH versions.'},
 {'title':'Current CEH Program & Course Outline','provider':'EC-Council','url':'https://www.eccouncil.org/train-certify/certified-ethical-hacker-ceh-v13-north-america/','note':'Current program outline, exam details and module descriptions.'},
 {'title':'CEH Master / Practical Overview','provider':'EC-Council','url':'https://www.eccouncil.org/train-certify/ceh-master/','note':'Official overview of the optional practical path and lab-oriented assessment.'}
]

STUDY_LESSONS={
 'security-plus':[
  {'title':'Security Foundations & Architecture','objectives':['Apply CIA, AAA and Zero Trust concepts','Compare secure architecture patterns','Choose compensating controls'],'topics':['Security control categories','Zero Trust','Segmentation','Cloud shared responsibility','Resilience and availability'],'practice':['Sketch trust boundaries for a three-tier app','Explain why a control is preventive, detective, corrective or compensating']},
  {'title':'Threats, Vulnerabilities & Mitigations','objectives':['Recognize common attack paths','Prioritize exposure','Select practical mitigations'],'topics':['Social engineering','Malware','Vulnerability classes','Attack surfaces','Hardening','Patch and configuration management'],'practice':['Take one KEV CVE and create a remediation priority statement','Build a threat-to-control mapping']},
  {'title':'Identity, Cryptography & Data Protection','objectives':['Select authentication methods','Understand certificate trust','Protect data states'],'topics':['MFA','Federation','PAM','PKI','Hashing','Encryption','Key lifecycle','Data classification'],'practice':['Map joiner-mover-leaver controls','Inspect a TLS certificate and identify issuer/validity/SANs']},
  {'title':'Security Operations & Incident Response','objectives':['Triage alerts','Build timelines','Contain and recover'],'topics':['Logging','SIEM','EDR','Threat intel','Vulnerability management','IR lifecycle','Backups'],'practice':['Create an incident timeline from five events','Write a basic IOC hunt for Splunk or KQL']},
  {'title':'Governance, Risk & Program Management','objectives':['Translate technical issues into risk','Apply policy and third-party concepts','Prepare for scenario questions'],'topics':['Risk treatment','Policies/standards/procedures','Vendor risk','Awareness','Audits','BCP/DR'],'practice':['Write a risk statement with likelihood, impact and treatment','Build a one-page third-party security checklist']}
 ],
 'securityx':[
  {'title':'Governance, Risk & Enterprise Security','objectives':['Make risk-based architecture decisions','Select controls for business constraints','Evaluate supply-chain and AI risk'],'topics':['Enterprise risk','GRC','Third-party risk','AI guardrails','SBOM','Policy enforcement','Security automation'],'practice':['Compare two architecture options and defend the lower-risk choice','Create an AI workload guardrail checklist']},
  {'title':'Zero Trust, SASE & Segmentation','objectives':['Design trust decisions','Separate control and data planes','Limit lateral movement'],'topics':['PDP/PEP','SASE','Microsegmentation','ZTNA','Identity context','Network trust boundaries'],'practice':['Design a three-tier microsegmentation matrix','Draw a PDP-to-PEP decision flow']},
  {'title':'Advanced Cloud, API, Container & OT Security','objectives':['Select controls for hybrid environments','Protect APIs and workloads','Recognize OT safety constraints'],'topics':['Cloud IAM','CASB','Workload identity','API gateways','Containers','Kubernetes','OT/ICS','Data diodes'],'practice':['Threat-model a cloud API','Design a one-way OT telemetry pattern']},
  {'title':'Cryptography & Resilient Architecture','objectives':['Choose enterprise cryptographic controls','Plan key management','Reason about post-quantum migration'],'topics':['PKI','HSM','Key splitting','Forward secrecy','Post-quantum planning','Certificate lifecycle','Resilience'],'practice':['Build a certificate lifecycle checklist','Create a crypto-agility migration plan']},
  {'title':'Advanced Security Operations','objectives':['Correlate ambiguous telemetry','Use behavior analytics','Improve detection engineering'],'topics':['SIEM/XDR','UEBA','Threat intelligence','Automation','Central logging','Detection engineering','DFIR'],'practice':['Build a telemetry matrix for one ATT&CK behavior','Investigate a suspicious timeline and identify missing evidence']},
  {'title':'Incident Command, Recovery & Purple Validation','objectives':['Coordinate complex incidents','Protect evidence','Validate controls continuously'],'topics':['Incident command','Forensics','Containment tradeoffs','BCP/DR','Purple teaming','ATT&CK','Retesting'],'practice':['Run a ransomware tabletop','Create a Purple validation with expected telemetry and pass/fail criteria']}
 ],
 'cissp':[
  {'title':'Security & Risk Management','objectives':['Prioritize business risk','Apply governance and ethics','Understand compliance responsibilities'],'topics':['Risk assessment','Policies','Legal/regulatory','Threat modeling','BCP concepts'],'practice':['Create a risk register entry and treatment rationale']},
  {'title':'Asset & Data Security','objectives':['Classify information','Assign ownership','Protect data lifecycle'],'topics':['Classification','Retention','Handling','Privacy','Media sanitization'],'practice':['Build a data classification and handling matrix']},
  {'title':'Architecture, Engineering & Networks','objectives':['Apply secure design principles','Evaluate crypto and physical controls','Design secure communications'],'topics':['Security models','Cryptography','Hardware security','Network segmentation','Secure protocols'],'practice':['Review an architecture for trust boundaries and single points of failure']},
  {'title':'IAM, Assessment & Operations','objectives':['Manage identity lifecycle','Plan assurance activities','Run secure operations'],'topics':['Federation','PAM','Access models','Audit/testing','IR','DR','Logging'],'practice':['Design joiner-mover-leaver controls and an access review']},
  {'title':'Software Development Security','objectives':['Integrate security into SDLC','Manage dependencies','Choose testing methods'],'topics':['Secure SDLC','SAST/DAST','Threat modeling','CI/CD','Supply chain'],'practice':['Build a secure release gate checklist']}
 ],
 'lfcs':[
  {'title':'Essential Commands','objectives':['Navigate and manipulate files','Process text','Archive and redirect I/O'],'topics':['ls/cd/pwd/find','cp/mv/rm','chmod/chown','grep/sed/awk','tar/gzip','pipes/redirection'],'practice':['Create /tmp/exam/data, add files, archive the tree and restore it to /tmp/backup','Use grep/sed/awk to extract fields from a sample log']},
  {'title':'Running Systems','objectives':['Manage services and processes','Read logs','Schedule work'],'topics':['systemctl','journalctl','ps/top','kill/nice','cron','systemd timers','boot targets'],'practice':['Create and enable a systemd service','Troubleshoot a failed service using systemctl status and journalctl']},
  {'title':'Users, Groups & Sudo','objectives':['Manage local identities','Control group membership','Delegate privilege safely'],'topics':['useradd/usermod','groupadd','passwd','id/groups','visudo','sudoers'],'practice':['Create a user/group and add a least-privilege sudo rule']},
  {'title':'Networking','objectives':['Configure addresses and routes','Troubleshoot name resolution','Manage host firewall'],'topics':['ip addr/link/route','ss','DNS','SSH','firewalld','ufw','iptables/nftables'],'practice':['Configure a test address/route in a disposable VM and validate it','Allow an approved service through the firewall and verify listening sockets']},
  {'title':'Service Configuration','objectives':['Deploy common services','Validate service state','Apply TLS basics'],'topics':['Apache/Nginx','SSH','NFS/Samba','Databases','Postfix','TLS certificates'],'practice':['Deploy a basic web virtual host and enable it at boot','Validate logs and listening ports']},
  {'title':'Storage Management','objectives':['Partition and format storage','Configure persistent mounts','Manage LVM/RAID/quotas'],'topics':['fdisk/parted','mkfs/fsck','mount/fstab','LVM','mdadm','quotas'],'practice':['Create a loop-backed test disk, filesystem and persistent mount','Create and extend an LVM logical volume in a lab']}
 ],
 'ceh':[
  {'title': 'Ethical Hacking Foundations', 'objectives': ['Explain authorization, scope and professional ethics', 'Apply risk and threat-intelligence concepts'], 'topics': ['Rules of engagement', 'Risk management', 'Cyber Kill Chain', 'MITRE ATT&CK', 'Legal/compliance boundaries'], 'practice': ['Draft a scoped authorization statement', 'Map a simulated attack chain to defensive controls']},
  {'title': 'Footprinting & Reconnaissance', 'objectives': ['Differentiate passive and active discovery', 'Collect only authorized/public metadata'], 'topics': ['OSINT', 'WHOIS', 'DNS', 'Search engines', 'Social media', 'Email metadata'], 'practice': ['Document passive OSINT for a domain you own', 'Identify what information should be removed from public exposure']},
  {'title': 'Scanning Networks', 'objectives': ['Interpret host and service discovery', 'Select safe scanning approaches'], 'topics': ['Host discovery', 'Port scanning', 'Service/version detection', 'OS detection', 'Scan detection'], 'practice': ['Scan an isolated lab subnet', 'Compare open ports with expected services']},
  {'title': 'Enumeration', 'objectives': ['Recognize enumeration targets and defensive controls', 'Document evidence safely'], 'topics': ['DNS', 'SMB', 'SNMP', 'LDAP', 'NTP', 'Service banners'], 'practice': ['Enumerate only a lab service', 'Recommend one hardening control for each exposed service']},
  {'title': 'Vulnerability Analysis', 'objectives': ['Prioritize vulnerabilities using exploitability and impact', 'Use CVE/CWE/CVSS appropriately'], 'topics': ['CVE', 'CWE', 'CVSS', 'CISA KEV', 'Scanner validation', 'False positives'], 'practice': ['Prioritize five sample findings', 'Write validation steps that do not require exploitation']},
  {'title': 'System Security & Passwords', 'objectives': ['Explain password storage and authentication weaknesses', 'Apply least privilege and hardening'], 'topics': ['Password hashing', 'Salts', 'MFA', 'Privilege', 'Patching', 'Secure configuration'], 'practice': ['Generate strong passwords in the toolbox', 'Audit a lab hash against a small approved candidate list']},
  {'title': 'Malware Threats', 'objectives': ['Classify malware behavior', 'Choose safe analysis and containment approaches'], 'topics': ['Ransomware', 'Trojans', 'Worms', 'Loaders', 'Indicators', 'Sandboxing'], 'practice': ['Classify a simulated malware alert', 'Build a containment checklist']},
  {'title': 'Sniffing & Network Defense', 'objectives': ['Interpret packet-capture evidence', 'Explain spoofing and segmentation defenses'], 'topics': ['Packet capture', 'ARP', 'DNS', 'TLS', 'Switch security', 'Network monitoring'], 'practice': ['Analyze a supplied lab PCAP', 'Identify where encryption prevents content inspection']},
  {'title': 'Social Engineering', 'objectives': ['Recognize manipulation techniques', 'Design layered user and technical defenses'], 'topics': ['Phishing', 'Pretexting', 'Baiting', 'MFA fatigue', 'BEC', 'Awareness'], 'practice': ['Triage a simulated phishing email', 'Write a user-verification procedure']},
  {'title': 'DoS & Availability', 'objectives': ['Differentiate DoS/DDoS patterns', 'Plan resilience and response'], 'topics': ['Volumetric attacks', 'Application exhaustion', 'Rate limiting', 'CDN/WAF', 'Capacity', 'Runbooks'], 'practice': ['Build a DDoS response checklist', 'Identify telemetry needed to distinguish outage from attack']},
  {'title': 'Session Security', 'objectives': ['Explain session/token risk', 'Apply secure cookie and transport controls'], 'topics': ['Cookies', 'Tokens', 'TLS', 'Session fixation', 'Expiration', 'CSRF'], 'practice': ['Inspect a sample JWT without trusting it', 'Review secure session-cookie settings']},
  {'title': 'IDS, Firewalls & Honeypots', 'objectives': ['Explain defensive control roles', 'Interpret alert and evasion concepts defensively'], 'topics': ['IDS/IPS', 'WAF', 'Firewall', 'Honeypot', 'Segmentation', 'Logging'], 'practice': ['Map a safe lab test to expected alerts', 'Document detection gaps and retest criteria']},
  {'title': 'Web Server Security', 'objectives': ['Identify web-server exposure', 'Apply hardening and patching'], 'topics': ['TLS', 'Headers', 'Directory exposure', 'Patching', 'Service accounts', 'Logging'], 'practice': ['Review headers on a lab server', 'Create a web-server hardening checklist']},
  {'title': 'Web Application Security', 'objectives': ['Recognize common application weaknesses', 'Use secure testing methodology'], 'topics': ['OWASP concepts', 'Authentication', 'Access control', 'Input validation', 'File upload', 'Business logic'], 'practice': ['Threat-model a sample web form', 'Map findings to secure coding controls']},
  {'title': 'SQL Injection Defense', 'objectives': ['Explain injection root cause', 'Select prevention and validation controls'], 'topics': ['Parameterized queries', 'ORM safety', 'Input handling', 'DB least privilege', 'Logging'], 'practice': ['Rewrite an unsafe sample query conceptually', 'Create detection indicators for injection attempts']},
  {'title': 'Wireless Security', 'objectives': ['Compare wireless security standards', 'Plan secure enterprise Wi-Fi'], 'topics': ['WPA2/WPA3', '802.1X', 'Guest isolation', 'Rogue AP detection', 'RF monitoring'], 'practice': ['Design a segmented guest/corporate WLAN', 'Review a sample wireless configuration']},
  {'title': 'Mobile Platform Security', 'objectives': ['Identify mobile threats', 'Apply application/device controls'], 'topics': ['Permissions', 'Secure storage', 'MDM', 'App signing', 'API security', 'Jailbreak/root risk'], 'practice': ['Review a mobile-app permission set', 'Build a mobile hardening checklist']},
  {'title': 'IoT & OT Security', 'objectives': ['Recognize safety and availability constraints', 'Plan segmentation and monitoring'], 'topics': ['IoT identity', 'Firmware', 'OT protocols', 'Passive monitoring', 'Safety', 'Change control'], 'practice': ['Design an OT monitoring architecture', 'Prioritize a vulnerable IoT device remediation']},
  {'title': 'Cloud Computing Security', 'objectives': ['Apply shared responsibility', 'Review IAM, logging and exposure'], 'topics': ['IAM', 'Storage exposure', 'Cloud logs', 'Secrets', 'Network controls', 'Containers'], 'practice': ['Review a fictional cloud IAM policy', 'Build a cloud incident evidence checklist']},
  {'title': 'Cryptography', 'objectives': ['Select appropriate cryptographic controls', 'Explain PKI and password hashing'], 'topics': ['Symmetric/asymmetric encryption', 'Hashing', 'Salting', 'PKI', 'Certificates', 'Key lifecycle'], 'practice': ['Compare hashing versus encryption', 'Inspect a certificate chain in a lab']}
 ]
}


# 0.5.4 expanded certification learning paths. These are original study aids and
# practice questions; official provider resources are linked for current objectives.
CERT_VIDEOS={
 'security-plus':[
  {'title':'How to Pass Your SY0-701 Security+ Exam in 2026','provider':'Professor Messer','kind':'Video','url':'https://www.youtube.com/watch?v=KiEptGbnEBc','embed':'https://www.youtube-nocookie.com/embed/KiEptGbnEBc','validated_at':'2026-09-08','validation':'Verified public video','note':'Current SY0-701 exam-preparation overview from Professor Messer. The exact public video ID was validated before this build.'},
  {'title':'Professor Messer SY0-701 Security+ Training Course','provider':'Professor Messer','kind':'Playlist','url':'https://www.youtube.com/playlist?list=PLG49S3nxzAnl4QDVqK-hOnoqcSKEIDDuv','validated_at':'2026-09-08','validation':'Verified playlist','note':'Full SY0-701 playlist organized around the current Security+ objectives.'},
  {'title':'CompTIA Security+ Exam Objectives','provider':'CompTIA','kind':'Official resource','url':'https://www.comptia.org/training/resources/exam-objectives','validated_at':'2026-09-08','validation':'Provider resource','note':'Use CompTIA exam objectives as the authoritative scope checklist; video resources are supplemental.'}
 ],
 'securityx':[
  {'title':'CompTIA SecurityX CAS-005 Video Course','provider':'HowToNetwork','kind':'Video course','url':'https://www.howtonetwork.com/courses/comptia/comptia-securityx-certification/','validated_at':'2026-09-08','validation':'Verified public course page with video player','note':'Current CAS-005-labelled advanced SecurityX video course. Third-party training; verify topics against CompTIA objectives.'},
  {'title':'CompTIA SecurityX Certification Overview','provider':'CompTIA','kind':'Official resource','url':'https://www.comptia.org/certifications/securityx','validated_at':'2026-09-08','validation':'Provider resource','note':'Authoritative certification reference for SecurityX / CAS-005 scope and requirements.'},
  {'title':'CompTIA Exam Objectives','provider':'CompTIA','kind':'Official resource','url':'https://www.comptia.org/training/resources/exam-objectives','validated_at':'2026-09-08','validation':'Provider resource','note':'Use the current CAS-005 objectives to verify every study topic.'}
 ],
 'cissp':[
  {'title':'CISSP: Your Journey Begins Here','provider':'ISC2TV','kind':'Video','url':'https://www.youtube.com/watch?v=s5u14qE2qBs','embed':'https://www.youtube-nocookie.com/embed/s5u14qE2qBs','validated_at':'2026-09-08','validation':'Verified public ISC2 video','note':'Public video published by ISC2TV; validated before this build.'},
  {'title':'CISSP: An Inside Look','provider':'ISC2','kind':'Official video','url':'https://cloud.connect.isc2.org/cissp-an-inside-look','validated_at':'2026-09-08','validation':'Verified official video landing page','note':'ISC2 on-demand CISSP video covering domains, preparation and the certification journey.'},
  {'title':'CISSP Exam Outline','provider':'ISC2','kind':'Official resource','url':'https://www.isc2.org/certifications/cissp/cissp-certification-exam-outline','validated_at':'2026-09-08','validation':'Verified official outline','note':'Current eight-domain outline. Use this as the authoritative content map.'}
 ],
 'lfcs':[
  {'title':'LFCS Certification & Current Domains','provider':'Linux Foundation','kind':'Official resource','url':'https://training.linuxfoundation.org/certification/linux-foundation-certified-sysadmin-lfcs/','validated_at':'2026-09-08','validation':'Verified official LFCS page','note':'Current LFCS domains, competencies and performance-based exam details.'},
  {'title':'Linux System Administration Essentials (LFS207)','provider':'Linux Foundation','kind':'Official e-learning','url':'https://training.linuxfoundation.org/training/linux-system-administration-essentials-lfs207/','validated_at':'2026-09-08','validation':'Verified official training page','note':'Official Linux Foundation system-administration course aligned to skills tested by LFCS. Course access may require enrollment.'},
  {'title':'Linux Foundation Video Channel','provider':'Linux Foundation','kind':'Video channel','url':'https://www.youtube.com/@LinuxfoundationOrg','validated_at':'2026-09-08','validation':'Verified public channel','note':'Official Linux Foundation YouTube channel for Linux, containers and open-source operations. Use current videos as supplemental learning.'}
 ],
 'ceh':[
  {'title':'Get the AI Edge with CEH v13','provider':'EC-Council','kind':'Video','url':'https://www.youtube.com/watch?v=O8jjNj3hGIQ','embed':'https://www.youtube-nocookie.com/embed/O8jjNj3hGIQ','validated_at':'2026-09-08','validation':'Verified public EC-Council video','note':'Official EC-Council CEH v13 overview. This replaces the older v11 video used in previous builds.'},
  {'title':'CEH v13 with the AI Edge','provider':'EC-Council','kind':'Video','url':'https://www.youtube.com/watch?v=pI8EQzABsP4','embed':'https://www.youtube-nocookie.com/embed/pI8EQzABsP4','validated_at':'2026-09-08','validation':'Verified public EC-Council video','note':'Official CEH v13 overview video.'},
  {'title':'Current CEH v13 Program & Course Outline','provider':'EC-Council','kind':'Official resource','url':'https://www.eccouncil.org/train-certify/certified-ethical-hacker-ceh-v13-north-america/','validated_at':'2026-09-08','validation':'Verified official CEH v13 page','note':'Authoritative current program/module reference. EC-Council notes that YouTube is supplemental and not a substitute for official training.'}
 ]
}

RESOURCE_HEALTH_ALLOWED_HOSTS={
 'www.youtube.com','youtube.com','www.youtube-nocookie.com','cloud.connect.isc2.org','www.isc2.org',
 'training.linuxfoundation.org','www.eccouncil.org','www.comptia.org','www.howtonetwork.com'
}


STUDY_AIDS.update({
 'security-plus':{
  'overview':'Expanded CompTIA Security+ SY0-701 preparation path with domain-by-domain lessons, scenario practice, quick references, flashcards, labs, videos and an 80-question original practice bank.',
  'quick_refs':['Security controls: preventive, deterrent, detective, corrective, compensating and directive','CIA, AAA, non-repudiation, least privilege, separation of duties and Zero Trust','Cryptography: symmetric/asymmetric, hashing, salts, digital signatures, certificates, PKI and key lifecycle','Threat actors, attack surfaces, social engineering, malware, supply chain and vulnerability concepts','Architecture: segmentation, VLANs, DMZs, NAC, SASE, SD-WAN, cloud shared responsibility, containers and virtualization','Identity: MFA factors, federation, SSO, RBAC/ABAC, PAM, provisioning and access reviews','Operations: logs, SIEM, EDR/XDR, SOAR, baselines, hardening, patching, backups and change management','Incident response: preparation, detection, analysis, containment, eradication, recovery and lessons learned','Vulnerability management: discovery, validation, prioritization, remediation, retesting, CVE/CVSS and KEV','Governance: policies, standards, procedures, risk register, third parties, privacy, audits, awareness and metrics'],
  'labs':['Build a control matrix for a fictional SaaS application','Inspect TLS and HTTP security headers on a local lab service','Create a least-privilege RBAC matrix for help desk, analyst and administrator roles','Triage a simulated phishing email and document indicators without opening attachments','Build a SIEM hunt from a sample failed-login event','Prioritize a set of vulnerabilities using asset criticality, exposure, CVSS and CISA KEV','Design a backup plan with RTO/RPO and test evidence','Run a tabletop through the six incident-response phases','Create a vendor risk questionnaire and minimum-security requirements','Use Hive Mind Toolbox to parse IOCs and decode a benign sample artifact'],
  'flashcards':[['Zero Trust','Never trust implicitly; continually evaluate identity, device, context and policy before granting least-privilege access.'],['RTO','Target maximum time to restore a service after disruption.'],['RPO','Maximum acceptable data loss measured backward in time.'],['Salting','Adding a unique random value before password hashing to defeat precomputed tables.'],['Digital Signature','Provides integrity, origin authentication and non-repudiation when the private key is protected.'],['PAM','Controls and monitors privileged identities and privileged sessions.'],['SASE','Cloud-delivered convergence of networking and security capabilities.'],['KEV','CISA catalog of vulnerabilities known to be exploited in the wild.'],['DLP','Controls intended to detect or prevent unauthorized movement or exposure of sensitive data.'],['SOAR','Security orchestration, automation and response used to coordinate repeatable workflows.'],['Compensating Control','Alternative control used when the preferred control cannot be implemented.'],['Data Minimization','Collect and retain only data necessary for the stated purpose.']]
 },
 'securityx':{
  'overview':'Expanded CompTIA SecurityX CAS-005 preparation path for senior security architecture and operations decisions, with advanced scenario modules, labs, videos, flashcards and an 80-question original practice bank.',
  'quick_refs':['Risk-driven architecture: business impact, threat modeling, trust boundaries and control trade-offs','Zero Trust: policy decision/enforcement points, identity context, continuous evaluation and microsegmentation','Hybrid and multi-cloud architecture: IAM, secrets, control planes, logging, workload identity and shared responsibility','Secure software and APIs: threat modeling, CI/CD controls, SBOM, signing, secrets, dependency and runtime protection','Cryptographic architecture: PKI, key custody, HSM/KMS, rotation, algorithm agility and post-quantum planning','OT/ICS and IoT: safety, deterministic availability, passive discovery, segmentation, jump hosts and data diodes','Advanced detection: SIEM/XDR, UEBA, threat intelligence, behavioral analytics, detection engineering and SOAR','Resilience: BIA, RTO/RPO, immutable backups, alternate processing, chaos testing and recovery validation','GRC: control inheritance, exceptions, third-party risk, privacy, audit evidence and continuous monitoring','Incident leadership: command structure, evidence strategy, scoping, containment trade-offs, communications and post-incident improvement'],
  'labs':['Design a Zero Trust access flow with PDP/PEP and device posture','Create a multi-account cloud landing-zone security baseline','Threat-model an API-driven application and identify trust boundaries','Design a secrets-management and key-rotation architecture','Build an OT segmentation design that preserves safety and one-way telemetry where appropriate','Create a detection engineering plan for identity compromise using SIEM and UEBA','Run a ransomware plus identity-compromise tabletop with executive communications','Review a fictional software supply chain and build an SBOM/signing control plan','Write a third-party exception with compensating controls and an expiration date','Create a Purple-Team validation plan and define expected telemetry and success criteria'],
  'flashcards':[['PDP','Policy Decision Point evaluates context and decides whether access should be allowed.'],['PEP','Policy Enforcement Point applies the access decision at the resource boundary.'],['Microsegmentation','Granular east-west isolation intended to limit lateral movement.'],['Data Diode','One-way gateway used when information must flow in only one direction.'],['Algorithm Agility','Ability to replace cryptographic algorithms and keys without redesigning the entire system.'],['SBOM','Inventory of software components and dependencies used for supply-chain visibility.'],['UEBA','Behavior analytics for detecting anomalous user or entity activity.'],['Control Inheritance','Reuse of controls provided by a shared platform or service rather than duplicating them per system.'],['Blast Radius','Scope of systems, identities or data affected if a component is compromised.'],['Immutable Backup','Backup protected from modification/deletion for a defined retention period.'],['Threat Model','Structured analysis of assets, trust boundaries, threats and mitigations.'],['Security Debt','Accumulated risk from deferred security work, exceptions and outdated design choices.']]
 },
 'cissp':{
  'overview':'Expanded ISC2 CISSP preparation across all eight domains, emphasizing the manager/architect perspective, risk-based decisions, official-domain alignment, scenario practice, videos and an 80-question original bank.',
  'quick_refs':['Domain 1: ethics, governance, policy, legal/regulatory, risk, BCP, personnel and supply-chain risk','Domain 2: classification, ownership, handling, data lifecycle, retention, remanence and privacy','Domain 3: secure design principles, models, cryptography, physical security and architecture assessment','Domain 4: secure network design, protocols, segmentation, remote access and network attacks/defenses','Domain 5: identity lifecycle, access models, federation, authentication, authorization, PAM and access reviews','Domain 6: assessment strategy, control testing, audits, vulnerability assessment, penetration testing and reporting','Domain 7: investigations, IR, logging, DR, backups, patching, change, evidence and operational resilience','Domain 8: SDLC, secure coding, testing, software supply chain, CI/CD, APIs and acquired software','CISSP decision lens: protect people and business objectives first, follow policy/law, choose risk-based governance, then technical detail','Quantitative risk: SLE × ARO = ALE; compare treatment cost with expected risk reduction while accounting for qualitative factors'],
  'labs':['Perform a BIA and derive RTO/RPO for three services','Create a data-classification and handling matrix','Review an architecture for single points of failure and trust-boundary risks','Design a network segmentation model for users, servers, management and third parties','Create joiner-mover-leaver and privileged-access review workflows','Write an independent security assessment plan with evidence and reporting','Build an incident evidence chain-of-custody and retention checklist','Create a secure SDLC release gate for code, dependencies, secrets and deployment','Compare risk treatment options using ALE plus qualitative impact','Draft a board-level risk statement that separates inherent and residual risk'],
  'flashcards':[['Due Care','Reasonable protective actions expected from an organization.'],['Due Diligence','Ongoing investigation and verification that controls remain appropriate and effective.'],['Residual Risk','Risk remaining after controls are implemented.'],['Data Owner','Business role accountable for classification and protection requirements.'],['Data Custodian','Role that implements and operates controls on behalf of the data owner.'],['Bell-LaPadula','Confidentiality model commonly summarized as no read up and no write down.'],['Biba','Integrity model commonly summarized as no read down and no write up.'],['Defense in Depth','Multiple complementary control layers so one failure does not expose the asset.'],['Federation','Trust relationship allowing identities from one domain to authenticate to another.'],['Chain of Custody','Documented control and transfer history for evidence.'],['BIA','Analysis of business impact used to prioritize continuity and recovery requirements.'],['SDLC','Lifecycle for planning, developing, testing, deploying, operating and retiring software securely.']]
 },
 'lfcs':{
  'overview':'Expanded Linux Foundation Certified System Administrator preparation aligned to the current five LFCS domains. Because LFCS is performance-based, the path emphasizes command-line labs, troubleshooting, videos and an 80-question original review bank.',
  'quick_refs':['Operations & Deployment 25%: kernel parameters, processes/services, scheduled jobs, packages/repos, recovery, VMs, containers and SELinux','Networking 25%: IPv4/IPv6, hostname resolution, time sync, troubleshooting, OpenSSH, filtering/NAT, static routes, bridges/bonds and reverse proxy/load balancing','Storage 20%: LVM, VFS, filesystems, remote filesystems, network block devices, swap, automounters and storage performance','Essential Commands 20%: Git basics, service configuration/troubleshooting, performance, constraints, disk-space troubleshooting and SSL certificates','Users & Groups 10%: local accounts/groups, profiles, resource limits, ACLs and LDAP identities','Core diagnostics: systemctl status, journalctl, ps, top, ss, ip, lsblk, df, du, findmnt and dmesg','Safe persistence: validate configuration before reboot, use systemd enablement, fstab cautiously and test mounts with mount -a','Permissions: mode bits, ownership, ACLs, sticky/setgid/setuid concepts and least privilege','Networking: verify link/address/route/DNS/listener/firewall separately to isolate failures','Storage: identify block device → partition/LVM → filesystem → mount → persistence → permissions → performance'],
  'labs':['Tune a kernel parameter temporarily and persistently, then verify both','Troubleshoot and repair a failed systemd service from logs','Create a scheduled job and prove it executed','Install a package from a configured repository and verify package ownership of a file','Create and run a rootless container in a disposable VM','Apply an SELinux context/boolean change appropriate to a lab service and verify enforcement','Configure IPv4/IPv6 addressing, DNS and a static route in a lab','Configure OpenSSH safely and validate client/server settings','Create a packet-filter rule and verify it with ss plus a local connection test','Create a bridge or bond in a disposable VM/network namespace','Create and extend an LVM logical volume and filesystem','Configure swap and an automounted filesystem','Use Git to clone/init, modify, inspect status and commit a local repository','Diagnose disk-space exhaustion with df/du/find and safely reclaim lab space','Create users/groups, resource limits and ACLs, then verify effective access'],
  'flashcards':[['systemctl enable --now','Enable a unit at boot and start it immediately.'],['journalctl -u UNIT','Show logs for a specific systemd unit.'],['sysctl -w','Change a kernel parameter at runtime; persistence requires a sysctl configuration file.'],['ss -lntp','List listening TCP sockets with process information when permitted.'],['ip route','Display or manage the kernel routing table.'],['findmnt','Show mounted filesystems and their sources/options.'],['lsblk -f','Show block devices with filesystem metadata.'],['mount -a','Attempt mounts defined in fstab; useful for validating changes before reboot.'],['setfacl/getfacl','Set or inspect POSIX ACLs.'],['ulimit','Inspect or set shell resource limits; system-wide policy may use limits.conf/systemd settings.'],['semanage/restorecon','Common SELinux tools for persistent context policy and applying default labels.'],['git status','Show working-tree and staging-area state.']]
 }
})

STUDY_LESSONS.update({
 'security-plus':[
  {'title':'Security Foundations & Control Types','objectives':['Apply CIA/AAA and non-repudiation','Differentiate control categories and functions','Use Zero Trust and least privilege concepts'],'topics':['CIA','AAA','Control types','Zero Trust','Least privilege','Separation of duties'],'practice':['Classify ten sample controls by type and function','Choose controls for a remote-work access scenario']},
  {'title':'Cryptography, PKI & Secrets','objectives':['Select encryption/hash/signature use cases','Explain PKI and certificate trust','Protect keys and secrets'],'topics':['AES','RSA/ECC','Hashing','Salts','HMAC','Digital signatures','PKI','KMS/HSM'],'practice':['Map confidentiality/integrity/authenticity requirements to cryptographic primitives','Inspect a lab certificate chain and identify issuer, subject and expiry']},
  {'title':'Threat Actors, Social Engineering & Malware','objectives':['Recognize threat motivations and techniques','Identify social-engineering indicators','Choose layered mitigations'],'topics':['Threat actors','Phishing','BEC','MFA fatigue','Malware','Ransomware','Supply chain'],'practice':['Triage a simulated phishing message and document indicators','Build preventive/detective/corrective controls for ransomware']},
  {'title':'Vulnerabilities & Secure Configuration','objectives':['Prioritize vulnerabilities','Distinguish scanning from validation','Apply hardening and patching'],'topics':['CVE','CVSS','KEV','Misconfiguration','Patching','Baselines','False positives'],'practice':['Prioritize five findings using exploitation, exposure and asset criticality','Create a remediation validation checklist']},
  {'title':'Network & Infrastructure Security','objectives':['Design segmentation and secure access','Recognize common network defenses','Select secure protocols'],'topics':['VLAN','DMZ','NAC','Firewall','IDS/IPS','VPN','SASE','SD-WAN','Secure protocols'],'practice':['Draw a segmented branch-office design','Replace insecure protocols in a sample architecture']},
  {'title':'Cloud, Virtualization & Application Architecture','objectives':['Apply shared responsibility','Protect workloads and APIs','Recognize container/virtualization risks'],'topics':['IaaS/PaaS/SaaS','Containers','Hypervisors','APIs','Serverless','Secrets','CASB'],'practice':['Assign security responsibilities for IaaS, PaaS and SaaS','Threat-model a simple containerized web application']},
  {'title':'Identity & Access Management','objectives':['Choose authentication factors','Design authorization','Manage identity lifecycle'],'topics':['MFA','SSO','Federation','RBAC','ABAC','PAM','Provisioning','Access review'],'practice':['Create an RBAC matrix','Design joiner-mover-leaver controls with periodic review']},
  {'title':'Security Operations & Monitoring','objectives':['Use logs and telemetry','Explain SIEM/EDR/XDR/SOAR roles','Build repeatable operations'],'topics':['Logging','SIEM','EDR','XDR','SOAR','Baselines','Time sync','Change management'],'practice':['Map a suspicious login to required telemetry','Build a simple detection-to-response workflow']},
  {'title':'Incident Response, Forensics & Recovery','objectives':['Apply IR lifecycle','Preserve evidence appropriately','Plan backup/recovery'],'topics':['IR lifecycle','Evidence','Chain of custody','Backups','RTO','RPO','DR'],'practice':['Run a six-phase tabletop for account takeover','Create backup verification evidence for a critical service']},
  {'title':'Governance, Risk, Privacy & Third Parties','objectives':['Differentiate policy artifacts','Assess risk and vendors','Apply privacy and awareness concepts'],'topics':['Policy','Standard','Procedure','Risk register','Third-party risk','Privacy','Awareness','Metrics'],'practice':['Write a risk statement and treatment','Create a vendor minimum-security checklist']}
 ],
 'securityx':[
  {'title':'Enterprise Governance & Risk Architecture','objectives':['Align architecture to business risk','Evaluate control trade-offs','Manage exceptions and inherited controls'],'topics':['Risk appetite','Control inheritance','Exceptions','Metrics','Third-party risk','Continuous monitoring'],'practice':['Document an architecture exception with compensating controls and expiration']},
  {'title':'Zero Trust & Identity-Centric Architecture','objectives':['Design PDP/PEP flows','Use continuous context','Reduce implicit trust'],'topics':['PDP','PEP','Device posture','Workload identity','Microsegmentation','PAM'],'practice':['Design a Zero Trust access path for an administrative application']},
  {'title':'Hybrid / Multi-Cloud Security','objectives':['Secure cloud control planes','Design identity/logging guardrails','Manage secrets and workload access'],'topics':['Landing zones','Cloud IAM','KMS','Secrets','Cloud logs','Cross-account trust','CSPM'],'practice':['Create a multi-account guardrail checklist and central logging design']},
  {'title':'Secure Software, APIs & Supply Chain','objectives':['Threat-model applications','Secure CI/CD','Assess third-party components'],'topics':['API security','CI/CD','SBOM','Signing','SAST/DAST','Dependency risk','Secrets scanning'],'practice':['Design release gates for a signed containerized application']},
  {'title':'Advanced Network & Service Architecture','objectives':['Design resilient segmentation','Select secure service connectivity','Protect east-west traffic'],'topics':['SASE','SD-WAN','mTLS','Service mesh','WAF','Reverse proxy','DDoS resilience'],'practice':['Compare service-mesh mTLS with perimeter-only TLS for east-west protection']},
  {'title':'Cryptographic Architecture & Algorithm Agility','objectives':['Design key lifecycle','Choose HSM/KMS boundaries','Plan cryptographic migration'],'topics':['PKI','HSM','KMS','Envelope encryption','Rotation','PQC planning'],'practice':['Create an algorithm-agility migration plan for a legacy application']},
  {'title':'OT/ICS, IoT & Safety-Critical Security','objectives':['Protect availability and safety','Use passive monitoring','Design controlled trust boundaries'],'topics':['ICS zones','Jump hosts','Data diode','Passive discovery','Safety','Change control'],'practice':['Design one-way telemetry from an OT zone to enterprise monitoring']},
  {'title':'Detection Engineering, XDR & Threat Intelligence','objectives':['Build high-fidelity detections','Use behavior and intelligence','Measure coverage'],'topics':['SIEM','XDR','UEBA','Threat intel','ATT&CK','Detection-as-code','SOAR'],'practice':['Write a detection hypothesis and expected telemetry for identity compromise']},
  {'title':'Incident Command, Forensics & Resilience','objectives':['Lead complex incidents','Balance containment with business impact','Validate recovery'],'topics':['Incident command','Forensics','Communications','Immutable backup','BIA','Recovery validation'],'practice':['Run a ransomware + identity compromise tabletop with decision points']},
  {'title':'Architecture Assurance & Purple Validation','objectives':['Test architecture assumptions','Design safe validation','Translate gaps into engineering work'],'topics':['Threat modeling','Purple team','Breach simulation','Control testing','Retest','Evidence'],'practice':['Create a Purple-Team test plan with success criteria and telemetry']}
 ],
 'cissp':[
  {'title':'Domain 1A — Ethics, Governance & Policy','objectives':['Apply professional ethics','Align security governance to business','Differentiate policy/standard/procedure/guideline'],'topics':['ISC2 ethics','Governance','Roles','Policy hierarchy','Due care','Due diligence'],'practice':['Choose the best governance response to a policy exception']},
  {'title':'Domain 1B — Risk, BCP & Supply Chain','objectives':['Perform qualitative/quantitative risk analysis','Plan continuity requirements','Manage supplier risk'],'topics':['SLE/ARO/ALE','Risk treatment','BIA','BCP','SCRM','Awareness'],'practice':['Calculate ALE and compare a control investment','Create BIA priorities for three services']},
  {'title':'Domain 2 — Asset Security','objectives':['Classify data/assets','Assign ownership/custody','Manage lifecycle and retention'],'topics':['Classification','Ownership','Handling','Retention','Remanence','Privacy','DLP'],'practice':['Create a classification/handling matrix for customer, HR and public data']},
  {'title':'Domain 3A — Secure Design & Security Models','objectives':['Apply secure design principles','Recognize security models','Assess architecture risk'],'topics':['Defense in depth','Fail secure','Least privilege','Bell-LaPadula','Biba','Zero Trust'],'practice':['Review a design for violations of least privilege and separation of duties']},
  {'title':'Domain 3B — Cryptography & Physical Security','objectives':['Select cryptographic protections','Manage keys/certificates','Apply physical defense layers'],'topics':['Symmetric/asymmetric','Hashing','PKI','Key lifecycle','Site design','Environmental controls'],'practice':['Map data states to encryption and key-custody controls']},
  {'title':'Domain 4 — Communication & Network Security','objectives':['Design secure network architecture','Protect communications','Select segmentation and remote-access controls'],'topics':['OSI/TCP-IP','VLAN','Firewall','VPN','Wireless','TLS','Network attacks'],'practice':['Design user/server/management/third-party network zones']},
  {'title':'Domain 5 — Identity & Access Management','objectives':['Manage identity lifecycle','Choose authentication/authorization','Control privileged access'],'topics':['Federation','MFA','RBAC','ABAC','PAM','Provisioning','Access review'],'practice':['Build joiner-mover-leaver plus quarterly access recertification']},
  {'title':'Domain 6 — Security Assessment & Testing','objectives':['Plan independent assessment','Choose test methods','Analyze and communicate results'],'topics':['Audit','Vulnerability assessment','Penetration test','Code review','BAS','KPIs/KRIs'],'practice':['Create an assessment plan with scope, independence, evidence and reporting']},
  {'title':'Domain 7A — Investigations & Incident Response','objectives':['Preserve evidence','Apply incident lifecycle','Coordinate legal/HR/regulatory needs'],'topics':['Evidence','Chain of custody','IR','Investigations','Logging','Monitoring'],'practice':['Create an evidence-preservation checklist for insider data theft']},
  {'title':'Domain 7B — Resilience, DR & Operations','objectives':['Plan recovery','Operate secure change/patch processes','Validate backups and recovery'],'topics':['DR','RTO/RPO','Backups','Change','Patch','Configuration','Capacity'],'practice':['Build a recovery test plan with measurable success criteria']},
  {'title':'Domain 8A — Secure SDLC & Testing','objectives':['Integrate security throughout SDLC','Choose appropriate testing','Use threat modeling'],'topics':['Requirements','Threat modeling','SAST','DAST','IAST','Code review','Release gates'],'practice':['Create secure acceptance criteria for a new API']},
  {'title':'Domain 8B — Software Supply Chain & DevSecOps','objectives':['Manage dependencies and acquired software','Secure CI/CD','Protect build artifacts and secrets'],'topics':['SBOM','Signing','Dependencies','CI/CD','Secrets','Containers','APIs'],'practice':['Build a software supply-chain release checklist']}
 ],
 'lfcs':[
  {'title':'Operations & Deployment I — Kernel, Processes & Services','objectives':['Configure runtime/persistent kernel settings','Troubleshoot processes/services','Recover failed services'],'topics':['sysctl','ps/top','systemctl','journalctl','signals','resource use'],'practice':['Set a sysctl value temporarily and persistently','Repair a failed unit from logs']},
  {'title':'Operations & Deployment II — Jobs, Packages & Recovery','objectives':['Schedule work','Manage packages/repos','Recover from common failures'],'topics':['cron','systemd timers','apt/dnf','repositories','rescue','boot troubleshooting'],'practice':['Create a scheduled job and verify logs','Identify which package owns a file']},
  {'title':'Operations & Deployment III — VMs, Containers & SELinux','objectives':['Operate libvirt VMs','Manage containers','Apply mandatory access control'],'topics':['virsh','libvirt','podman/docker concepts','images','volumes','SELinux'],'practice':['Run a rootless lab container','Diagnose an SELinux denial without disabling enforcement']},
  {'title':'Networking I — Addressing, DNS & Time','objectives':['Configure IPv4/IPv6','Troubleshoot resolution','Synchronize time'],'topics':['ip addr','ip route','resolv.conf/systemd-resolved','dig','chrony'],'practice':['Configure a lab address and route','Diagnose a DNS failure step by step']},
  {'title':'Networking II — SSH, Filtering, NAT & Routing','objectives':['Secure SSH','Configure packet filtering/NAT','Manage static routing'],'topics':['sshd_config','ssh keys','nftables/firewalld','NAT','routes'],'practice':['Harden a lab SSH service without locking yourself out','Add and validate a firewall rule']},
  {'title':'Networking III — Bridges, Bonds & Proxies','objectives':['Configure link aggregation/bridging','Operate reverse proxy/load balancing','Troubleshoot listeners'],'topics':['bridge','bond','NetworkManager','Nginx/HAProxy concepts','ss','curl'],'practice':['Create a disposable bridge or bond','Proxy a local test service and validate headers']},
  {'title':'Storage I — Filesystems, Swap & Persistence','objectives':['Create/troubleshoot filesystems','Configure persistent mounts','Manage swap'],'topics':['lsblk','mkfs','fsck','mount','fstab','swap'],'practice':['Create a loop-backed filesystem and safe fstab entry','Add and remove lab swap']},
  {'title':'Storage II — LVM, Remote Storage & Automounters','objectives':['Create/extend LVM','Use remote filesystems/block devices','Configure automount'],'topics':['pv/vg/lv','resize2fs/xfs_growfs','NFS','iSCSI concepts','autofs'],'practice':['Extend an LVM volume and filesystem','Configure an automounted lab share']},
  {'title':'Essential Commands I — Git, Services & Certificates','objectives':['Perform basic Git operations','Configure/troubleshoot services','Inspect TLS certificates'],'topics':['git','systemctl','journalctl','openssl','curl'],'practice':['Initialize, commit and inspect a local Git repo','Inspect a certificate with openssl']},
  {'title':'Essential Commands II — Performance & Disk Troubleshooting','objectives':['Diagnose performance','Identify service constraints','Resolve disk-space issues'],'topics':['top','free','vmstat','iostat concepts','df','du','find'],'practice':['Find the largest consumers in a full lab filesystem','Differentiate inode exhaustion from block exhaustion']},
  {'title':'Users & Groups I — Accounts, Profiles & Limits','objectives':['Manage users/groups','Configure environment profiles','Set resource limits'],'topics':['useradd','usermod','groupadd','profiles','ulimit','limits.conf'],'practice':['Create a user/group with a defined shell and supplementary group','Set and verify a lab resource limit']},
  {'title':'Users & Groups II — ACLs & Directory Identity','objectives':['Manage ACLs','Explain LDAP identity integration','Validate effective access'],'topics':['setfacl','getfacl','default ACL','LDAP','NSS/PAM concepts'],'practice':['Grant an ACL without changing base ownership','Explain the identity lookup path for an LDAP-backed user']}
 ]
})

TEAM_GUIDES={
 'red':{
   'purpose':'Plan, execute, and document authorized adversary-simulation activities with explicit scope, safety controls, evidence capture, and remediation tracking.',
   'workflow':['1. Confirm written authorization, scope, exclusions, contacts, time window, and stop conditions.','2. Build the asset and trust-boundary inventory for the engagement.','3. Select ATT&CK-aligned hypotheses and expected defensive telemetry.','4. Perform controlled discovery and validation using approved techniques only.','5. Record evidence, affected controls, detection outcome, impact, and reproduction notes.','6. Stop immediately on safety triggers, production instability, or scope ambiguity.','7. Convert validated weaknesses into findings with owners, remediation, and retest criteria.'],
   'sections':{
     'Engagement Management':['Rules of engagement','Scope and exclusions','Approvals and emergency contacts','Testing windows','Safety and stop conditions','Evidence handling and cleanup'],
     'Recon & Exposure Review':['DNS and certificate review','Service inventory','External attack-surface validation','HTTP/TLS posture','Cloud exposure review','Identity exposure review'],
     'Attack-Path Planning':['Initial-access hypothesis','Privilege boundaries','Trust relationships','Lateral-movement opportunities','Critical asset paths','Expected detections and telemetry'],
     'Web & API Review':['Authentication/session controls','Authorization boundaries','Input validation','API security posture','Secrets handling','Business-logic abuse cases'],
     'Cloud & Identity':['IAM policy review','Privileged paths','Federation trust','Storage exposure','Network controls','Audit/logging coverage'],
     'Evidence & Reporting':['Finding severity','Reproduction notes','Evidence references','Business impact','Root cause','Remediation and retest status']},
   'commands':[
    {'name':'Service discovery - light','cmd':'nmap -sV --version-light <AUTHORIZED_TARGET>','use':'Identify exposed services on an owned or explicitly authorized target.'},
    {'name':'TCP port inventory','cmd':'nmap -sT -Pn --top-ports 100 <AUTHORIZED_TARGET>','use':'Review common TCP exposure without stealth options.'},
    {'name':'HTTP response headers','cmd':'curl -I https://<AUTHORIZED_TARGET>','use':'Review server, cache, HSTS, CSP, cookie, and other HTTP security headers.'},
    {'name':'HTTP verbose transaction','cmd':'curl -vk https://<AUTHORIZED_TARGET>/','use':'Inspect the TLS/HTTP exchange for an authorized service.'},
    {'name':'TLS certificate inspection','cmd':'openssl s_client -connect <AUTHORIZED_TARGET>:443 -servername <AUTHORIZED_TARGET> -showcerts','use':'Inspect certificate chain and negotiated TLS details.'},
    {'name':'Certificate metadata','cmd':'echo | openssl s_client -connect <AUTHORIZED_TARGET>:443 -servername <AUTHORIZED_TARGET> 2>/dev/null | openssl x509 -noout -issuer -subject -dates -fingerprint -sha256','use':'Summarize issuer, subject, validity, and fingerprint.'},
    {'name':'DNS record review','cmd':'nslookup <AUTHORIZED_DOMAIN>','use':'Review basic DNS resolution for an authorized domain.'},
    {'name':'DNS detailed review','cmd':'dig <AUTHORIZED_DOMAIN> A AAAA MX TXT NS +noall +answer','use':'Review common DNS records and security-relevant TXT records.'},
    {'name':'Route path review','cmd':'tracert <AUTHORIZED_TARGET>   # Windows\ntraceroute <AUTHORIZED_TARGET> # Linux/macOS','use':'Understand the network path to an authorized system.'},
    {'name':'Whois ownership review','cmd':'whois <AUTHORIZED_DOMAIN_OR_IP>','use':'Review public registration and network ownership metadata.'},
    {'name':'Local web fingerprint','cmd':'curl -sS https://<AUTHORIZED_TARGET>/robots.txt','use':'Review a publicly exposed robots file without bypassing access controls.'},
    {'name':'Hash engagement artifact','cmd':'certutil -hashfile <FILE> SHA256   # Windows\nsha256sum <FILE>                    # Linux','use':'Create an integrity hash for collected evidence or test artifacts.'}
   ]
 },
 'blue':{
   'purpose':'Investigate, hunt, contain, eradicate, recover, and improve detections using endpoint, identity, network, cloud, and application telemetry.',
   'workflow':['1. Validate alert fidelity, affected asset criticality, and identity context.','2. Scope hosts, users, IPs, processes, files, cloud resources, and the relevant time window.','3. Preserve evidence and build a defensible timeline.','4. Enrich indicators and map observed behavior to ATT&CK.','5. Contain according to confidence, impact, and business continuity requirements.','6. Eradicate root cause, rotate exposed credentials, and recover from a trusted state.','7. Tune detections, document lessons learned, and create Purple-Team retest work.'],
   'sections':{
     'SOC Triage':['Alert validation','Asset criticality','Identity context','IOC enrichment','Timeline building','Severity and escalation decision'],
     'Threat Hunting':['Hypothesis creation','Data-source selection','Baseline comparison','Rare process/network behavior','Persistence indicators','Lateral movement and identity abuse'],
     'Windows DFIR':['Security/System/Application logs','PowerShell logging','Scheduled tasks/services','Network connections','Autoruns/persistence review','Defender/Sysmon telemetry'],
     'Linux DFIR':['journalctl/auth logs','Processes and sockets','systemd services/timers','Cron persistence','File and package review','SSH access and sudo activity'],
     'Detection Engineering':['Sigma concepts','Splunk/KQL/Elastic queries','ATT&CK coverage','False-positive analysis','Rule testing','Detection-as-code lifecycle'],
     'Incident Response':['Containment options','Credential reset planning','Host isolation','Recovery validation','Post-incident review','Executive communication']},
   'commands':[
    {'name':'Windows active TCP sessions','cmd':'Get-NetTCPConnection | Sort-Object State,RemoteAddress | Format-Table -Auto','use':'Triage local and remote TCP sessions.'},
    {'name':'Windows process inventory','cmd':'Get-Process | Sort-Object CPU -Descending | Select-Object -First 30 Name,Id,CPU,Path','use':'Review process activity and high-CPU processes.'},
    {'name':'Windows Security log - recent failures','cmd':'Get-WinEvent -FilterHashtable @{LogName="Security";Id=4625;StartTime=(Get-Date).AddHours(-4)} | Select-Object TimeCreated,Id,Message','use':'Review recent failed logons.'},
    {'name':'Windows Security log - successful logons','cmd':'Get-WinEvent -FilterHashtable @{LogName="Security";Id=4624;StartTime=(Get-Date).AddHours(-4)} | Select-Object TimeCreated,Id,Message','use':'Review recent successful logons during incident scoping.'},
    {'name':'PowerShell operational events','cmd':'Get-WinEvent -LogName "Microsoft-Windows-PowerShell/Operational" -MaxEvents 100','use':'Review recent PowerShell activity when logging is enabled.'},
    {'name':'Defender status','cmd':'Get-MpComputerStatus | Select-Object AntivirusEnabled,RealTimeProtectionEnabled,AntivirusSignatureLastUpdated','use':'Validate Microsoft Defender protection state.'},
    {'name':'Scheduled tasks inventory','cmd':'Get-ScheduledTask | Where-Object {$_.State -ne "Disabled"} | Select-Object TaskName,TaskPath,State','use':'Review enabled scheduled tasks for suspicious persistence.'},
    {'name':'Windows file hash','cmd':'Get-FileHash <FILE> -Algorithm SHA256','use':'Hash evidence or a suspicious file without executing it.'},
    {'name':'Linux listening services','cmd':'ss -lntup','use':'List listening services and owning processes.'},
    {'name':'Linux process tree','cmd':'ps auxf','use':'Review process ancestry and unusual long-running processes.'},
    {'name':'Linux authentication activity','cmd':'journalctl _COMM=sshd --since "-4 hours"','use':'Review SSH daemon activity on systemd-based Linux systems.'},
    {'name':'Systemd unit logs','cmd':'journalctl -u <SERVICE> --since "-4 hours"','use':'Review service-specific events.'},
    {'name':'Linux evidence hash','cmd':'sha256sum <FILE>','use':'Generate an integrity hash before evidence handling.'},
    {'name':'Linux cron inventory','cmd':'crontab -l; ls -la /etc/cron.* /var/spool/cron 2>/dev/null','use':'Review common cron persistence locations.'},
    {'name':'DNS cache - Windows','cmd':'Get-DnsClientCache | Sort-Object Entry','use':'Review cached DNS names during endpoint triage.'}
   ]
 },
 'purple':{
   'purpose':'Run collaborative, safe validation cycles that prove whether expected telemetry, detections, analyst workflows, and response controls work for an agreed ATT&CK behavior.',
   'workflow':['1. Choose a business-relevant threat behavior or ATT&CK technique.','2. Define a safe validation method, success criteria, rollback, and evidence requirements.','3. Document expected endpoint, identity, network, cloud, and application telemetry.','4. Execute only the approved validation action.','5. Compare observed logs, alerts, enrichment, and analyst context with expectations.','6. Record visibility, parser, detection, severity, enrichment, and response gaps.','7. Remediate, rerun the same validation, and close only with evidence.'],
   'sections':{
     'Technique Planning':['Threat scenario','ATT&CK tactic/technique','Business relevance','Preconditions','Safe test method','Rollback and cleanup'],
     'Telemetry Matrix':['EDR events','Windows/Linux logs','Identity-provider logs','DNS/proxy/firewall','Cloud audit logs','Application telemetry'],
     'Detection Validation':['Did a rule fire?','Was severity correct?','Was context sufficient?','Were false positives acceptable?','Did automation behave correctly?','Could an analyst act quickly?'],
     'Gap Management':['Missing sensor','Missing event/field','Parser or normalization issue','Rule logic gap','Response/playbook gap','Owner and due date'],
     'Retest & Coverage':['Repeat same behavior','Compare evidence','Verify control change','Update ATT&CK coverage','Document residual risk','Close with proof']},
   'commands':[
    {'name':'Sigma rule validation','cmd':'sigma check <RULE.yml>','use':'Validate Sigma rule structure before conversion or promotion.'},
    {'name':'Sigma rule conversion - Splunk','cmd':'sigma convert -t splunk <RULE.yml>','use':'Convert an approved Sigma rule into a Splunk-oriented query for validation.'},
    {'name':'Windows event presence check','cmd':'Get-WinEvent -FilterHashtable @{LogName="Security";StartTime=(Get-Date).AddMinutes(-30)} -MaxEvents 200','use':'Confirm expected Windows telemetry exists after a safe validation.'},
    {'name':'PowerShell telemetry check','cmd':'Get-WinEvent -LogName "Microsoft-Windows-PowerShell/Operational" -MaxEvents 100','use':'Verify PowerShell operational telemetry is collected.'},
    {'name':'Linux telemetry check','cmd':'journalctl --since "-30 minutes"','use':'Confirm Linux events were generated during a controlled validation.'},
    {'name':'Sysmon telemetry check','cmd':'Get-WinEvent -LogName "Microsoft-Windows-Sysmon/Operational" -MaxEvents 100','use':'Confirm Sysmon telemetry is present when Sysmon is deployed.'},
    {'name':'Splunk validation pattern','cmd':'index=<INDEX> earliest=-30m <SAFE_TEST_MARKER> | stats count by host, sourcetype','use':'Search for an agreed benign marker generated by the test.'},
    {'name':'Sentinel / KQL validation pattern','cmd':'search "<SAFE_TEST_MARKER>" | summarize count() by $table, Computer','use':'Look for an agreed benign marker across Sentinel tables.'},
    {'name':'Elastic validation pattern','cmd':'Kibana / Discover: search for "<SAFE_TEST_MARKER>" over the validation window','use':'Verify an expected benign marker appears in Elastic telemetry.'},
    {'name':'Validation workflow','cmd':'Technique -> Safe Test -> Expected Telemetry -> Observed Telemetry -> Detection -> Response -> Gap -> Retest','use':'Use this sequence for every Purple-Team validation.'}
   ]
 }
}

# Expanded safe operational command/reference library. Commands are intended for owned systems, authorized labs, or defensive investigation.
TEAM_GUIDES['red']['commands'].extend([
 {'name':'HTTP methods review','cmd':'curl -i -X OPTIONS https://<AUTHORIZED_TARGET>/','use':'Identify HTTP methods the authorized application advertises.'},
 {'name':'Security.txt review','cmd':'curl -sS https://<AUTHORIZED_TARGET>/.well-known/security.txt','use':'Review the published vulnerability-disclosure/security contact file.'},
 {'name':'Certificate SAN inventory','cmd':'echo | openssl s_client -connect <AUTHORIZED_TARGET>:443 -servername <AUTHORIZED_TARGET> 2>/dev/null | openssl x509 -noout -ext subjectAltName','use':'Review certificate subject alternative names for the scoped service.'},
 {'name':'TLS protocol check','cmd':'openssl s_client -tls1_2 -connect <AUTHORIZED_TARGET>:443 -servername <AUTHORIZED_TARGET>','use':'Confirm an approved target can negotiate TLS 1.2.'},
 {'name':'DNS TXT review','cmd':'dig TXT <AUTHORIZED_DOMAIN> +short','use':'Review SPF, verification, and other TXT records without altering anything.'},
 {'name':'DMARC record review','cmd':'dig TXT _dmarc.<AUTHORIZED_DOMAIN> +short','use':'Review published DMARC policy for an authorized domain.'},
 {'name':'SPF record review','cmd':'dig TXT <AUTHORIZED_DOMAIN> +short | grep -i spf','use':'Review the authorized domain SPF policy.'},
 {'name':'Local Windows route inventory','cmd':'Get-NetRoute | Sort-Object DestinationPrefix | Format-Table -Auto','use':'Document routing on an authorized Windows test endpoint.'},
 {'name':'Local Windows listening ports','cmd':'Get-NetTCPConnection -State Listen | Sort-Object LocalPort | Format-Table -Auto','use':'Inventory services listening on an authorized Windows test endpoint.'},
 {'name':'Local Linux listening ports','cmd':'ss -lntup','use':'Inventory listening services on an authorized Linux test endpoint.'},
 {'name':'Local Linux firewall state','cmd':'sudo nft list ruleset   # or: sudo firewall-cmd --list-all','use':'Review local firewall policy on an authorized Linux system.'},
 {'name':'Local Windows firewall profiles','cmd':'Get-NetFirewallProfile | Select-Object Name,Enabled,DefaultInboundAction,DefaultOutboundAction','use':'Review Windows firewall profile posture on an authorized endpoint.'},
 {'name':'Local certificate store','cmd':'Get-ChildItem Cert:\\LocalMachine\\My | Select Subject,Issuer,NotAfter,Thumbprint','use':'Inventory local machine certificates on an authorized Windows endpoint.'},
 {'name':'Linux certificate file metadata','cmd':'openssl x509 -in <CERTIFICATE.pem> -noout -subject -issuer -dates -fingerprint -sha256','use':'Inspect a certificate file supplied for the engagement.'},
 {'name':'File metadata - Windows','cmd':'Get-Item <FILE> | Select FullName,Length,CreationTimeUtc,LastWriteTimeUtc','use':'Document metadata for an authorized engagement artifact.'},
 {'name':'File metadata - Linux','cmd':'stat <FILE>','use':'Document metadata for an authorized engagement artifact.'}
])
TEAM_GUIDES['blue']['commands'].extend([
 {'name':'Windows services inventory','cmd':'Get-CimInstance Win32_Service | Select Name,State,StartMode,StartName,PathName','use':'Review service configuration and unusual executable paths.'},
 {'name':'Windows startup entries','cmd':'Get-CimInstance Win32_StartupCommand | Select Name,Command,Location,User','use':'Review common startup persistence entries.'},
 {'name':'Windows local administrators','cmd':'Get-LocalGroupMember Administrators','use':'Check membership of the local Administrators group.'},
 {'name':'Windows user accounts','cmd':'Get-LocalUser | Select Name,Enabled,LastLogon,PasswordLastSet','use':'Review local account state during triage.'},
 {'name':'Windows Defender detections','cmd':'Get-MpThreatDetection | Select InitialDetectionTime,ThreatName,Resources,ActionSuccess','use':'Review Microsoft Defender detection history.'},
 {'name':'Windows installed hotfixes','cmd':'Get-HotFix | Sort-Object InstalledOn -Descending | Select -First 30','use':'Review recently installed Windows hotfixes.'},
 {'name':'Windows ARP / neighbor cache','cmd':'Get-NetNeighbor | Sort-Object State,IPAddress | Format-Table -Auto','use':'Review recently observed local-network neighbors.'},
 {'name':'Windows DNS configuration','cmd':'Get-DnsClientServerAddress | Format-Table -Auto','use':'Validate configured DNS resolvers during endpoint/network investigation.'},
 {'name':'Linux failed logins','cmd':'lastb -a | head -50','use':'Review recent failed login activity when lastb data is available.'},
 {'name':'Linux successful logins','cmd':'last -a | head -50','use':'Review recent interactive login history.'},
 {'name':'Linux user/group inventory','cmd':'getent passwd; getent group','use':'Review local/directory-resolved accounts and groups.'},
 {'name':'Linux sudo events','cmd':'journalctl _COMM=sudo --since "-24 hours"','use':'Review sudo execution history on systemd systems.'},
 {'name':'Linux systemd enabled units','cmd':'systemctl list-unit-files --state=enabled','use':'Review enabled services/timers for suspicious persistence.'},
 {'name':'Linux recently modified files','cmd':'find /etc /usr/local/bin /tmp -xdev -type f -mtime -2 -printf "%TY-%Tm-%Td %TH:%TM %p\\n" 2>/dev/null | sort -r | head -100','use':'Find recently modified files in common investigation locations.'},
 {'name':'Linux package history - RPM','cmd':'dnf history list | head -30','use':'Review recent package operations on RPM-based systems.'},
 {'name':'Linux package history - Debian','cmd':'grep -E " install | upgrade | remove " /var/log/dpkg.log | tail -50','use':'Review recent package operations on Debian-based systems.'},
 {'name':'Linux firewall review','cmd':'sudo nft list ruleset','use':'Review active nftables rules during network containment analysis.'},
 {'name':'Certificate remote check','cmd':'echo | openssl s_client -connect <HOST>:443 -servername <HOST> 2>/dev/null | openssl x509 -noout -subject -issuer -dates -fingerprint -sha256','use':'Inspect a remote certificate during phishing or service investigations.'},
 {'name':'HTTP header triage','cmd':'curl -sS -D - -o /dev/null https://<HOST>/','use':'Review response headers for an investigated web endpoint.'},
 {'name':'Hash directory files - PowerShell','cmd':'Get-ChildItem <PATH> -File | Get-FileHash -Algorithm SHA256','use':'Create hashes for a small investigation artifact directory.'}
])
TEAM_GUIDES['purple']['commands'].extend([
 {'name':'Windows Security event count','cmd':'Get-WinEvent -FilterHashtable @{LogName="Security";StartTime=(Get-Date).AddMinutes(-30)} | Group-Object Id | Sort Count -Descending | Select -First 25 Count,Name','use':'Confirm which Windows Security event IDs appeared in the validation window.'},
 {'name':'Sysmon event count','cmd':'Get-WinEvent -LogName "Microsoft-Windows-Sysmon/Operational" -ErrorAction SilentlyContinue | Select -First 500 | Group-Object Id | Sort Count -Descending','use':'Check event-type visibility from Sysmon after a safe test.'},
 {'name':'PowerShell 4104 presence','cmd':'Get-WinEvent -FilterHashtable @{LogName="Microsoft-Windows-PowerShell/Operational";Id=4104;StartTime=(Get-Date).AddMinutes(-30)}','use':'Validate script-block logging coverage when enabled.'},
 {'name':'Windows audit policy review','cmd':'auditpol /get /category:*','use':'Document Windows audit policy before or after a detection validation.'},
 {'name':'Linux audit service status','cmd':'systemctl status auditd --no-pager','use':'Confirm Linux audit service collection state where auditd is deployed.'},
 {'name':'Linux audit recent events','cmd':'ausearch -ts recent 2>/dev/null | tail -100','use':'Review recent auditd events generated around the validation window.'},
 {'name':'Linux auth telemetry window','cmd':'journalctl -u ssh --since "-30 minutes" 2>/dev/null || journalctl -u sshd --since "-30 minutes"','use':'Verify authentication telemetry for a benign identity validation.'},
 {'name':'DNS telemetry validation pattern','cmd':'Search DNS telemetry for <SAFE_TEST_DOMAIN> during the agreed validation window','use':'Check that benign test-domain resolution is visible centrally.'},
 {'name':'Proxy telemetry validation pattern','cmd':'Search proxy/SWG telemetry for <SAFE_TEST_URL> during the agreed validation window','use':'Validate URL visibility and user/device enrichment.'},
 {'name':'Firewall telemetry validation pattern','cmd':'Search firewall telemetry for src=<TEST_HOST> dst=<TEST_DESTINATION> during the validation window','use':'Validate expected network connection telemetry.'},
 {'name':'Identity sign-in validation pattern','cmd':'Search identity-provider logs for <TEST_IDENTITY> during the agreed validation window','use':'Validate identity log ingestion and enrichment.'},
 {'name':'Detection QA checklist','cmd':'Trigger? -> Correct severity? -> Entity context? -> ATT&CK tag? -> Owner? -> Response link? -> False positive notes?','use':'Use as the minimum quality gate before promoting a detection.'},
 {'name':'Retest evidence checklist','cmd':'Same test -> Same scope -> Telemetry captured -> Rule fired -> Analyst context adequate -> Response verified -> Evidence attached','use':'Prove remediation with repeatable evidence rather than subjective closure.'}
])

FRAMEWORKS={
 'NIST CSF 2.0':{'use':'Use for program-level cybersecurity outcomes and executive posture tracking.','areas':['Govern','Identify','Protect','Detect','Respond','Recover'],'controls':['Define cybersecurity roles and risk governance','Maintain asset and data inventory','Prioritize and treat cyber risk','Protect identities and privileged access','Protect data and platforms','Collect security telemetry','Detect and analyze adverse events','Coordinate incident response','Contain and eradicate incidents','Recover services and improve controls']},
 'CIS Controls v8':{'use':'Use for prioritized technical safeguards and implementation tracking.','areas':['IG1','IG2','IG3'],'controls':['Inventory enterprise assets','Inventory software assets','Protect data','Secure configurations','Account management','Access control management','Continuous vulnerability management','Audit log management','Email and browser protections','Malware defenses','Data recovery','Network infrastructure management','Network monitoring and defense','Security awareness','Service provider management','Application software security','Incident response management','Penetration testing']},
 'ISO 27001':{'use':'Use for ISMS governance, risk treatment and evidence-oriented control management.','areas':['Organization','People','Physical','Technology'],'controls':['ISMS scope and context','Leadership and policy','Risk assessment methodology','Risk treatment plan','Statement of Applicability','Competence and awareness','Documented information control','Operational planning','Performance evaluation','Internal audit','Management review','Corrective action']},
 'NIST RMF / 800-53':{'use':'Use for control selection, implementation, assessment, authorization and continuous monitoring.','areas':['Prepare','Categorize','Select','Implement','Assess','Authorize','Monitor'],'controls':['System categorization','Control baseline selection','Control tailoring','Implementation evidence','Assessment procedures','POA&M tracking','Authorization package','Continuous monitoring strategy']},
 'PCI DSS':{'use':'Use when protecting payment-card environments and cardholder-data flows.','areas':['Network','Accounts','Data','Vulnerability','Monitoring','Governance'],'controls':['Define cardholder-data environment','Network security controls','Secure configurations','Protect stored account data','Encrypt transmission','Anti-malware controls','Secure development','Restrict access by need to know','Strong authentication','Physical access controls','Log and monitor access','Test security regularly','Maintain security policy']},
 'HIPAA Security Rule':{'use':'Use for HIPAA Security Rule safeguard tracking for electronic protected health information (ePHI). This is a control-tracking aid, not legal advice or an attestation of compliance.','areas':['Administrative Safeguards','Physical Safeguards','Technical Safeguards','Organizational Requirements'],'controls':['Perform security risk analysis and risk management','Assign security responsibility','Implement workforce security procedures','Manage information access','Security awareness and training','Security incident procedures','Contingency planning and data backup','Periodic security evaluation','Facility access controls','Workstation use and security','Device and media controls','Unique user identification and access control','Emergency access procedures','Automatic logoff where appropriate','Encryption and decryption controls','Audit controls for systems containing ePHI','Integrity controls for ePHI','Person or entity authentication','Transmission security','Business associate and organizational safeguard documentation']},
 'SOC 2':{'use':'Use to organize evidence around Trust Services Criteria and operational control effectiveness.','areas':['Security','Availability','Confidentiality','Processing Integrity','Privacy'],'controls':['Control environment','Risk assessment','Logical access','Change management','System operations','Monitoring','Incident response','Vendor management','Business continuity','Evidence retention']}
}

PLAYBOOKS=[
 {'id':'phishing-bec','title':'Phishing / BEC Investigation','team':'blue','severity':'high','use':'Triage suspicious email, credential-harvest, invoice fraud, or business-email-compromise reports.','trigger':'Reported suspicious message, impossible travel, suspicious mailbox rule, or credential-use alert.','steps':['Preserve the original message and headers.','Identify recipients, sender infrastructure, URLs, attachments and reply-to anomalies.','Search mail telemetry for matching sender, subject, URL and message ID.','Check identity logs for suspicious sign-ins, MFA changes and mailbox rules.','Contain by removing malicious messages and restricting compromised accounts as appropriate.','Reset exposed credentials and revoke sessions when compromise is confirmed.','Block validated malicious indicators at email/web controls.','Document scope, impact, evidence and user notifications.','Tune detections and run a Purple retest.']},
 {'id':'ransomware','title':'Ransomware / Mass Encryption','team':'blue','severity':'critical','use':'Respond to suspected encryption, destructive malware, ransom notes or rapid file modification.','trigger':'EDR ransomware alert, mass file rename, ransom note, backup tampering, or abnormal SMB activity.','steps':['Declare incident and assign commander.','Isolate affected hosts from the network while preserving evidence.','Disable compromised accounts/tokens and restrict lateral-movement paths.','Identify patient zero, encryption scope and affected shares.','Protect backups and verify immutable/recovery copies.','Collect volatile and endpoint evidence before reimaging where feasible.','Eradicate persistence and initial-access vector.','Recover from trusted backups and validate business services.','Rotate exposed secrets and privileged credentials.','Capture lessons learned, detection gaps and Purple retest actions.']},
 {'id':'account-compromise','title':'Compromised Identity / Account Takeover','team':'blue','severity':'high','use':'Investigate suspicious authentication, MFA abuse, token theft or privileged account misuse.','trigger':'Impossible travel, MFA fatigue, unusual token use, anomalous admin action, or user report.','steps':['Validate the alert and business context.','Review sign-ins, device, IP, geolocation, token and MFA events.','Scope mailbox, cloud, VPN and privileged actions.','Revoke active sessions and tokens as appropriate.','Reset credentials and re-register MFA if compromise is confirmed.','Review OAuth grants, forwarding rules and persistence changes.','Hunt for the same indicators across other accounts.','Document impact and tune identity detections.']},
 {'id':'malware-endpoint','title':'Malware / Suspicious Endpoint','team':'blue','severity':'high','use':'Investigate suspicious process, file, persistence or endpoint-detection alerts.','trigger':'EDR alert, malicious hash, suspicious child process or user report.','steps':['Capture alert metadata and endpoint criticality.','Record process tree, network connections, hashes and persistence locations.','Isolate host if risk warrants.','Collect forensic artifacts and timeline evidence.','Enrich indicators using configured threat intelligence.','Identify root cause and initial access.','Remove persistence/malware or rebuild from trusted media.','Validate endpoint health before reconnection.','Create detection and Purple validation follow-up.']},
 {'id':'web-attack','title':'Web Application Attack','team':'blue','severity':'high','use':'Investigate suspicious HTTP behavior, WAF alerts, exploitation attempts or application compromise.','trigger':'WAF/IDS alert, unusual 4xx/5xx burst, webshell indicator, or suspicious application log.','steps':['Preserve WAF, reverse-proxy and application logs.','Identify source IPs, target paths, methods, parameters and user/session context.','Correlate with authentication, host and database events.','Determine exploit success versus blocked attempt.','Contain compromised instances or sessions.','Patch vulnerable component and remove malicious artifacts.','Rotate exposed application secrets.','Add detections and retest safely.']},
 {'id':'cloud-compromise','title':'Cloud Control-Plane Compromise','team':'blue','severity':'critical','use':'Respond to suspicious cloud API activity, exposed keys, privilege escalation or destructive cloud actions.','trigger':'Unusual IAM change, new key, disabled logging, public storage exposure or impossible admin activity.','steps':['Preserve cloud audit logs and affected resource metadata.','Identify principal, source IP, token/key and sequence of API actions.','Disable exposed credentials and revoke sessions.','Review IAM changes, persistence, network and storage exposure.','Restore logging and guardrails if altered.','Scope data access and exfiltration indicators.','Rebuild or remediate affected resources from known-good configuration.','Rotate secrets and review trust policies.','Add detections and Purple validation.']},
 {'id':'data-exfil','title':'Suspected Data Exfiltration','team':'blue','severity':'critical','use':'Investigate unusual outbound transfer, cloud sharing, archive creation or sensitive-data access.','trigger':'DLP alert, unusual egress volume, mass download, archive tooling or suspicious external share.','steps':['Identify data owner, classification and regulatory impact.','Preserve DLP, proxy, network, endpoint and cloud logs.','Scope user, device, destination, volume and time window.','Contain active transfer paths while preserving business continuity.','Validate whether data actually left organizational control.','Revoke malicious shares/tokens and restrict compromised identities.','Engage legal/privacy leadership when required.','Document affected records, evidence and notification decisions.']},
 {'id':'vuln-kev','title':'Known Exploited Vulnerability Emergency Remediation','team':'blue','severity':'critical','use':'Drive rapid response when an internet-facing or critical asset is affected by a known-exploited vulnerability.','trigger':'CISA KEV match or confirmed active exploitation against a vulnerable asset.','steps':['Validate affected product/version and asset exposure.','Determine internet reachability and business criticality.','Search telemetry for exploitation indicators.','Apply vendor mitigation or isolate the service if patching cannot occur immediately.','Patch or upgrade using change controls appropriate to urgency.','Validate remediation with version/configuration evidence.','Hunt for compromise before closing.','Record exception and compensating controls if remediation is deferred.']},
 {'id':'red-external','title':'Authorized External Exposure Review','team':'red','severity':'medium','use':'Structured, low-impact review of externally exposed services during an authorized engagement.','trigger':'Approved external assessment with written scope and stop conditions.','steps':['Confirm scope, authorization, exclusions and testing window.','Inventory authorized domains/IPs and ownership.','Review DNS, certificates and exposed services.','Inspect HTTP/TLS posture and externally visible metadata.','Document only validated findings with evidence.','Stop on instability or scope ambiguity.','Deliver remediation recommendations and explicit retest criteria.']},
 {'id':'purple-identity','title':'Purple Validation — Suspicious Identity Behavior','team':'purple','severity':'medium','use':'Validate identity telemetry, alerting and analyst workflow using an agreed benign test pattern.','trigger':'Planned ATT&CK-aligned identity detection exercise.','steps':['Choose behavior and map it to ATT&CK.','Define safe test, expected telemetry and rollback.','Confirm test identity and maintenance window.','Execute only the agreed benign validation.','Verify identity, endpoint, SIEM and alert telemetry.','Measure alert quality, context and analyst response.','Record gaps with owners and due dates.','Retest after remediation and close with evidence.']},
 {'id':'purple-endpoint','title':'Purple Validation — Endpoint Execution Telemetry','team':'purple','severity':'medium','use':'Validate endpoint process/event collection and detections using safe markers or benign administrative actions.','trigger':'Planned endpoint detection validation.','steps':['Define the expected process/event chain.','Confirm host, sensor health and logging configuration.','Run the approved benign test marker/action.','Verify endpoint and centralized telemetry arrival.','Check detection, severity, enrichment and analyst context.','Record parser, collection or rule gaps.','Tune controls and repeat the identical test.']},
 {'id':'ddos','title':'DDoS / Service Availability','team':'blue','severity':'high','use':'Coordinate response to traffic floods or service exhaustion affecting availability.','trigger':'Availability degradation with anomalous traffic volume or provider DDoS alert.','steps':['Confirm service impact and establish incident command.','Capture traffic characteristics, source distribution and targeted endpoints.','Engage CDN/ISP/DDoS protection provider.','Apply rate limiting or upstream filtering where appropriate.','Protect origin infrastructure and monitor capacity.','Preserve evidence and communications timeline.','Validate service recovery and update resilience controls.']}
]

INTEGRATION_CATALOG={
 'cisa':{'name':'CISA KEV','category':'Free Threat Data','fields':[],'secret':[],'hint':'No key required; live catalog.'},
 'feodo':{'name':'abuse.ch Feodo Tracker','category':'Free Threat Data','fields':[],'secret':[],'hint':'No key required; active botnet C2 feed.'},
 'dshield':{'name':'SANS ISC / DShield','category':'Free Threat Data','fields':[],'secret':[],'hint':'Community source telemetry; not a blocklist.'},
 'spamhaus':{'name':'Spamhaus DROP','category':'Free Threat Data','fields':[],'secret':[],'hint':'Free high-confidence malicious netblocks; attribution required.'},
 'threatfox':{'name':'ThreatFox','category':'Threat Intelligence','fields':['auth_key','days'],'secret':['auth_key'],'hint':'Free abuse.ch Auth-Key; recent IOC feed.'},
 'greynoise':{'name':'GreyNoise Community','category':'Threat Intelligence','fields':['api_key','test_ip'],'secret':['api_key'],'hint':'Optional free API key; community IP context.'},
 'otx':{'name':'AlienVault OTX','category':'Threat Intelligence','fields':['api_key'],'secret':['api_key'],'hint':'Community API key.'},
 'abuseipdb':{'name':'AbuseIPDB','category':'Threat Intelligence','fields':['api_key','test_ip'],'secret':['api_key'],'hint':'API key for IP reputation checks.'},
 'virustotal':{'name':'VirusTotal','category':'Threat Intelligence','fields':['api_key','test_ip'],'secret':['api_key'],'hint':'Public/community API key; respect provider terms.'},
 'splunk':{'name':'Splunk','category':'SIEM','fields':['base_url','token'],'secret':['token'],'hint':'https://splunk.example:8089'},
 'sentinel':{'name':'Microsoft Sentinel','category':'SIEM','fields':['tenant_id','client_id','client_secret','subscription_id','resource_group','workspace_name'],'secret':['client_secret'],'hint':'Azure app credentials plus workspace details.'},
 'elastic':{'name':'Elastic Security','category':'SIEM','fields':['base_url','api_key'],'secret':['api_key'],'hint':'Elastic URL + API key.'},
 'defender':{'name':'Microsoft Defender XDR','category':'EDR/XDR','fields':['tenant_id','client_id','client_secret'],'secret':['client_secret'],'hint':'Microsoft security API app credentials.'},
 'crowdstrike':{'name':'CrowdStrike Falcon','category':'EDR/XDR','fields':['base_url','client_id','client_secret'],'secret':['client_secret'],'hint':'Falcon OAuth client.'},
 'misp':{'name':'MISP','category':'Threat Intelligence','fields':['base_url','api_key'],'secret':['api_key'],'hint':'MISP URL + automation key.'},
 'opencti':{'name':'OpenCTI','category':'Threat Intelligence','fields':['base_url','token'],'secret':['token'],'hint':'OpenCTI GraphQL endpoint.'},
 'taxii':{'name':'STIX/TAXII 2.1','category':'Threat Intelligence','fields':['base_url','collection_id','username','password'],'secret':['password'],'hint':'TAXII collection.'},
 'nvd':{'name':'NVD','category':'Vulnerability','fields':['api_key'],'secret':['api_key'],'hint':'Works without a key at lower rate; key improves rate limits.'},
 'jira':{'name':'Jira','category':'Ticketing / ITSM','fields':['base_url','email','api_token','project_key','jql'],'secret':['api_token'],'hint':'Atlassian API token.'},
 'servicenow':{'name':'ServiceNow','category':'Ticketing / ITSM','fields':['base_url','username','password','table'],'secret':['password'],'hint':'Instance credentials and table.'},
 'slack':{'name':'Slack Webhook','category':'Notifications','fields':['webhook_url'],'secret':['webhook_url'],'hint':'Incoming webhook URL.'},
 'teams':{'name':'Microsoft Teams Webhook','category':'Notifications','fields':['webhook_url'],'secret':['webhook_url'],'hint':'Workflow/webhook URL.'},
 'smtp':{'name':'SMTP','category':'Notifications','fields':['host','port','username','password','from_address','to_address','ssl'],'secret':['password'],'hint':'Mail relay settings.'},
 'aws':{'name':'AWS Security Hub','category':'Cloud Security','fields':['region','access_key_id','secret_access_key'],'secret':['access_key_id','secret_access_key'],'hint':'Leave keys blank to use normal AWS credential chain.'},
 'azure':{'name':'Azure Security','category':'Cloud Security','fields':['tenant_id','client_id','client_secret','subscription_id'],'secret':['client_secret'],'hint':'Azure app credentials.'},
 'gcp':{'name':'Google Cloud SCC','category':'Cloud Security','fields':['organization_id','service_account_json'],'secret':['service_account_json'],'hint':'Organization ID + service-account JSON.'},
 'webhook':{'name':'Generic Webhook/API','category':'Automation','fields':['base_url','auth_header'],'secret':['auth_header'],'hint':'HTTP endpoint with optional Authorization value.'}
}
NO_KEY={'cisa','feodo','dshield','spamhaus'}

COUNTRY_CENTROIDS={'US':[39.8,-98.6],'CA':[56.1,-106.3],'MX':[23.6,-102.5],'BR':[-14.2,-51.9],'AR':[-38.4,-63.6],'CL':[-35.7,-71.5],'CO':[4.6,-74.1],'GB':[55.4,-3.4],'IE':[53.1,-8.2],'FR':[46.2,2.2],'DE':[51.2,10.4],'NL':[52.1,5.3],'BE':[50.5,4.5],'ES':[40.5,-3.7],'PT':[39.4,-8.2],'IT':[41.9,12.6],'PL':[51.9,19.1],'UA':[48.4,31.2],'RU':[61.5,105.3],'SE':[60.1,18.6],'NO':[60.5,8.5],'FI':[61.9,25.7],'DK':[56.3,9.5],'CZ':[49.8,15.5],'RO':[45.9,24.9],'TR':[38.96,35.24],'IL':[31.0,34.9],'SA':[23.9,45.1],'AE':[23.4,53.8],'IN':[20.6,79.0],'PK':[30.4,69.3],'BD':[23.7,90.4],'CN':[35.9,104.2],'JP':[36.2,138.3],'KR':[35.9,127.8],'TW':[23.7,121.0],'HK':[22.3,114.2],'SG':[1.35,103.8],'TH':[15.9,101.0],'VN':[14.1,108.3],'ID':[-0.8,113.9],'MY':[4.2,101.98],'PH':[12.9,121.8],'AU':[-25.3,133.8],'NZ':[-40.9,174.9],'ZA':[-30.6,22.9],'NG':[9.1,8.7],'EG':[26.8,30.8],'KE':[-0.02,37.9],'MA':[31.8,-7.1],'IR':[32.4,53.7],'IQ':[33.2,43.7]}
THREAT_CACHE={'ts':0,'data':None}
CURRENT_USER=ContextVar('hms_current_user',default='system')
CURRENT_IP=ContextVar('hms_current_ip',default='local')
PH=PasswordHasher(time_cost=3,memory_cost=65536,parallelism=2)
SESSION_HOURS=12

def conn():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def _harden_private_file(path:Path):
 try:
  if os.name=='nt':
   user=os.environ.get('USERNAME','')
   if user:subprocess.run(['icacls',str(path),'/inheritance:r','/grant:r',f'{user}:F'],capture_output=True,text=True,timeout=8)
  else: os.chmod(path,0o600)
 except Exception: pass

def key():
 if not KEYFILE.exists():
  KEYFILE.write_bytes(Fernet.generate_key()); _harden_private_file(KEYFILE)
 return KEYFILE.read_bytes()
def enc(v:str)->str:return Fernet(key()).encrypt((v or '').encode()).decode()
def dec(v:str)->str:
 try:return Fernet(key()).decrypt((v or '').encode()).decode()
 except (InvalidToken,ValueError):return ''
def enc_bytes(v:bytes)->bytes:return Fernet(key()).encrypt(v)
def dec_bytes(v:bytes)->bytes:return Fernet(key()).decrypt(v)
def audit(action,detail=''):
 actor=CURRENT_USER.get(); ip=CURRENT_IP.get()
 with conn() as c:c.execute('insert into audit(action,detail,actor,source_ip) values(?,?,?,?)',(action,str(detail)[:4000],actor,ip))

def init_db():
 with conn() as c:c.executescript('''
 CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,owner TEXT DEFAULT '',team TEXT DEFAULT 'blue',status TEXT DEFAULT 'open',priority TEXT DEFAULT 'medium',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS risks(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,likelihood INTEGER DEFAULT 3,impact INTEGER DEFAULT 3,owner TEXT DEFAULT '',treatment TEXT DEFAULT '',status TEXT DEFAULT 'open',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS incidents(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,severity TEXT DEFAULT 'medium',status TEXT DEFAULT 'investigating',commander TEXT DEFAULT '',summary TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS assets(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,kind TEXT DEFAULT 'server',criticality TEXT DEFAULT 'medium',owner TEXT DEFAULT '',location TEXT DEFAULT '',status TEXT DEFAULT 'active',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS integrations(id TEXT PRIMARY KEY,enabled INTEGER DEFAULT 0,config_json TEXT DEFAULT '{}',status TEXT DEFAULT 'not_configured',last_test TEXT DEFAULT '',last_error TEXT DEFAULT '',updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,action TEXT NOT NULL,detail TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS study(id INTEGER PRIMARY KEY AUTOINCREMENT,cert TEXT NOT NULL,score INTEGER,total INTEGER,domain_json TEXT DEFAULT '{}',mode TEXT DEFAULT 'practice',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS vulnerabilities(id INTEGER PRIMARY KEY AUTOINCREMENT,cve TEXT DEFAULT '',title TEXT NOT NULL,severity TEXT DEFAULT 'medium',asset TEXT DEFAULT '',owner TEXT DEFAULT '',status TEXT DEFAULT 'open',due_date TEXT DEFAULT '',source TEXT DEFAULT 'manual',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS engagements(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,scope TEXT DEFAULT '',owner TEXT DEFAULT '',status TEXT DEFAULT 'planning',roe TEXT DEFAULT '',stop_conditions TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS team_findings(id INTEGER PRIMARY KEY AUTOINCREMENT,team TEXT NOT NULL,title TEXT NOT NULL,severity TEXT DEFAULT 'medium',status TEXT DEFAULT 'open',asset TEXT DEFAULT '',attack_id TEXT DEFAULT '',evidence TEXT DEFAULT '',remediation TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS purple_tests(id INTEGER PRIMARY KEY AUTOINCREMENT,technique TEXT NOT NULL,hypothesis TEXT DEFAULT '',expected_telemetry TEXT DEFAULT '',observed TEXT DEFAULT '',detection TEXT DEFAULT '',gap TEXT DEFAULT '',owner TEXT DEFAULT '',status TEXT DEFAULT 'planned',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS investigations(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,status TEXT DEFAULT 'open',severity TEXT DEFAULT 'medium',summary TEXT DEFAULT '',iocs TEXT DEFAULT '',timeline TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS toolbox_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,tool TEXT NOT NULL,input_summary TEXT DEFAULT '',output TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS incident_lifecycle(id INTEGER PRIMARY KEY AUTOINCREMENT,incident_id INTEGER NOT NULL,phase TEXT NOT NULL,status TEXT DEFAULT 'pending',notes TEXT DEFAULT '',owner TEXT DEFAULT '',updated_at TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(incident_id,phase));
 CREATE TABLE IF NOT EXISTS framework_checks(id INTEGER PRIMARY KEY AUTOINCREMENT,framework TEXT NOT NULL,control TEXT NOT NULL,status TEXT DEFAULT 'not_started',owner TEXT DEFAULT '',evidence TEXT DEFAULT '',updated_at TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(framework,control));
 CREATE TABLE IF NOT EXISTS playbook_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,playbook_id TEXT NOT NULL,title TEXT NOT NULL,team TEXT DEFAULT 'blue',status TEXT DEFAULT 'open',owner TEXT DEFAULT '',notes TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS stig_findings(id INTEGER PRIMARY KEY AUTOINCREMENT,scan_id TEXT DEFAULT '',benchmark TEXT DEFAULT '',rule_id TEXT DEFAULT '',vuln_id TEXT DEFAULT '',title TEXT NOT NULL,category TEXT DEFAULT 'CAT II',severity TEXT DEFAULT 'medium',status TEXT DEFAULT 'Open',asset TEXT DEFAULT '',source TEXT DEFAULT '',finding_details TEXT DEFAULT '',comments TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS stig_scans(id INTEGER PRIMARY KEY AUTOINCREMENT,scan_id TEXT UNIQUE,asset TEXT DEFAULT '',profile TEXT DEFAULT '',source TEXT DEFAULT '',summary TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT DEFAULT 'admin',enabled INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP,last_login TEXT DEFAULT '');
 CREATE TABLE IF NOT EXISTS sessions(id INTEGER PRIMARY KEY AUTOINCREMENT,token_hash TEXT UNIQUE NOT NULL,username TEXT NOT NULL,csrf_token TEXT NOT NULL,expires_at INTEGER NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS auth_failures(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT DEFAULT '',source_ip TEXT DEFAULT '',attempted_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS pentest_reports(id TEXT PRIMARY KEY,name TEXT NOT NULL,client TEXT DEFAULT '',original_filename TEXT NOT NULL,sha256 TEXT NOT NULL,encrypted_path TEXT NOT NULL,extracted_text_enc TEXT DEFAULT '',parser TEXT DEFAULT '',ai_status TEXT DEFAULT '',finding_count INTEGER DEFAULT 0,uploaded_by TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS tracked_findings(id INTEGER PRIMARY KEY AUTOINCREMENT,report_id TEXT DEFAULT '',source TEXT DEFAULT 'manual',title TEXT NOT NULL,severity TEXT DEFAULT 'medium',status TEXT DEFAULT 'open',asset TEXT DEFAULT '',cve TEXT DEFAULT '',cwe TEXT DEFAULT '',cvss TEXT DEFAULT '',category TEXT DEFAULT '',description_enc TEXT DEFAULT '',evidence_enc TEXT DEFAULT '',remediation_enc TEXT DEFAULT '',owner TEXT DEFAULT '',due_date TEXT DEFAULT '',fixed_at TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS remediation_reports(id TEXT PRIMARY KEY,finding_id INTEGER NOT NULL,encrypted_path TEXT NOT NULL,sha256 TEXT NOT NULL,created_by TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS pentest_scans(id TEXT PRIMARY KEY,name TEXT NOT NULL,target TEXT NOT NULL,profile TEXT DEFAULT 'standard',credential_user TEXT DEFAULT '',status TEXT DEFAULT 'queued',summary_json TEXT DEFAULT '{}',result_enc TEXT DEFAULT '',finding_count INTEGER DEFAULT 0,report_path TEXT DEFAULT '',created_by TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,finished_at TEXT DEFAULT '');
 CREATE TABLE IF NOT EXISTS scan_credentials(username TEXT PRIMARY KEY,cred_type TEXT DEFAULT '',target_username TEXT DEFAULT '',secret_enc TEXT DEFAULT '',domain TEXT DEFAULT '',key_enc TEXT DEFAULT '',updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS watchlists(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT DEFAULT 'ioc',value TEXT NOT NULL,label TEXT DEFAULT '',severity TEXT DEFAULT 'medium',status TEXT DEFAULT 'active',notes TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS scheduled_scans(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,target TEXT NOT NULL,profile TEXT DEFAULT 'quick',credential_user TEXT DEFAULT '',interval_hours INTEGER DEFAULT 168,enabled INTEGER DEFAULT 1,last_run TEXT DEFAULT '',next_run TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS evidence_items(id INTEGER PRIMARY KEY AUTOINCREMENT,investigation_id INTEGER DEFAULT 0,name TEXT NOT NULL,kind TEXT DEFAULT 'note',sha256 TEXT DEFAULT '',encrypted_path TEXT DEFAULT '',notes_enc TEXT DEFAULT '',created_by TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS detections(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,kind TEXT DEFAULT 'sigma',attack_id TEXT DEFAULT '',status TEXT DEFAULT 'draft',content TEXT DEFAULT '',notes TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS notification_rules(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,event_type TEXT DEFAULT 'critical_finding',severity TEXT DEFAULT 'high',enabled INTEGER DEFAULT 1,channel TEXT DEFAULT 'in_app',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS notification_events(id INTEGER PRIMARY KEY AUTOINCREMENT,rule_id INTEGER DEFAULT 0,event_type TEXT DEFAULT '',title TEXT NOT NULL,detail TEXT DEFAULT '',status TEXT DEFAULT 'new',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS asset_notes(id INTEGER PRIMARY KEY AUTOINCREMENT,asset_id INTEGER NOT NULL,note TEXT NOT NULL,created_by TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS user_certifications(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT NOT NULL,certification TEXT NOT NULL,credential_id TEXT DEFAULT '',issued_date TEXT DEFAULT '',expires_date TEXT DEFAULT '',verification_url TEXT DEFAULT '',notes TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);

 ''')
 cols={r[1] for r in c.execute('pragma table_info(audit)').fetchall()}
 if 'actor' not in cols:c.execute("alter table audit add column actor TEXT DEFAULT ''")
 if 'source_ip' not in cols:c.execute("alter table audit add column source_ip TEXT DEFAULT ''")
 study_cols={r[1] for r in c.execute('pragma table_info(study)').fetchall()}
 if 'domain_json' not in study_cols:c.execute("alter table study add column domain_json TEXT DEFAULT '{}'")
 if 'mode' not in study_cols:c.execute("alter table study add column mode TEXT DEFAULT 'practice'")
init_db()

class Task(BaseModel): title:str; owner:str=''; team:str='blue'; status:str='open'; priority:str='medium'
class Risk(BaseModel): title:str; likelihood:int=Field(3,ge=1,le=5); impact:int=Field(3,ge=1,le=5); owner:str=''; treatment:str=''; status:str='open'
class Incident(BaseModel): title:str; severity:str='medium'; status:str='investigating'; commander:str=''; summary:str=''
class IncidentPhase(BaseModel): phase:str; status:str='pending'; notes:str=''; owner:str=''
class VulnerabilityUpdate(BaseModel): status:str='open'; owner:str=''; due_date:str=''
class Asset(BaseModel): name:str; kind:str='server'; criticality:str='medium'; owner:str=''; location:str=''; status:str='active'
class IntegrationConfig(BaseModel): enabled:bool=True; config:dict[str,Any]={}
class Grade(BaseModel): answers:list[str]; mode:str='practice'
class CheckAnswer(BaseModel): question_id:str; answer:str
class Vulnerability(BaseModel): cve:str=''; title:str; severity:str='medium'; asset:str=''; owner:str=''; status:str='open'; due_date:str=''; source:str='manual'
class Engagement(BaseModel): name:str; scope:str=''; owner:str=''; status:str='planning'; roe:str=''; stop_conditions:str=''
class TeamFinding(BaseModel): team:str; title:str; severity:str='medium'; status:str='open'; asset:str=''; attack_id:str=''; evidence:str=''; remediation:str=''
class PurpleTest(BaseModel): technique:str; hypothesis:str=''; expected_telemetry:str=''; observed:str=''; detection:str=''; gap:str=''; owner:str=''; status:str='planned'
class Investigation(BaseModel): title:str; status:str='open'; severity:str='medium'; summary:str=''; iocs:str=''; timeline:str=''
class ToolboxInput(BaseModel): value:str=''; operation:str=''; extra:str=''
class FrameworkCheck(BaseModel): framework:str; control:str; status:str='not_started'; owner:str=''; evidence:str=''
class PlaybookRun(BaseModel): playbook_id:str; title:str; team:str='blue'; status:str='open'; owner:str=''; notes:str=''
class AuthSetup(BaseModel): username:str='admin'; password:str
class AuthLogin(BaseModel): username:str; password:str
class UserCreate(BaseModel): username:str; password:str; role:str='analyst'; enabled:bool=True
class UserUpdate(BaseModel): role:str=''; enabled:bool|None=None; password:str=''
class ScanCredentialUpdate(BaseModel): cred_type:str=''; target_username:str=''; secret:str=''; domain:str=''; private_key:str=''; clear:bool=False
class UserCertification(BaseModel): certification:str; credential_id:str=''; issued_date:str=''; expires_date:str=''; verification_url:str=''; notes:str=''
class PentestScanRequest(BaseModel): name:str=''; target:str; profile:str='standard'; credential_user:str=''; authorized:bool=False; import_findings:bool=True
class TrackedFinding(BaseModel):
 title:str; severity:str='medium'; status:str='open'; asset:str=''; cve:str=''; cwe:str=''; cvss:str=''; category:str=''; description:str=''; evidence:str=''; remediation:str=''; owner:str=''; due_date:str=''; report_id:str=''; source:str='manual'
class FindingUpdate(BaseModel):
 title:str=''; severity:str=''; status:str=''; asset:str=''; cve:str=''; cwe:str=''; cvss:str=''; category:str=''; description:str=''; evidence:str=''; remediation:str=''; owner:str=''; due_date:str=''
class NotificationTest(BaseModel): message:str='Hive Mind Security integration test: connectivity verified.'
class WatchItem(BaseModel): kind:str='ioc'; value:str; label:str=''; severity:str='medium'; status:str='active'; notes:str=''
class ScheduledScan(BaseModel): name:str; target:str; profile:str='quick'; credential_user:str=''; interval_hours:int=Field(168,ge=1,le=8760); enabled:bool=True
class DetectionRule(BaseModel): name:str; kind:str='sigma'; attack_id:str=''; status:str='draft'; content:str=''; notes:str=''
class NotificationRule(BaseModel): name:str; event_type:str='critical_finding'; severity:str='high'; enabled:bool=True; channel:str='in_app'
class AssetNote(BaseModel): note:str
class EvidenceNote(BaseModel): investigation_id:int=0; name:str; notes:str=''


def _token_hash(token:str)->str:return hashlib.sha256(token.encode()).hexdigest()
def _session_from_request(request:Request):
 token=request.cookies.get('hms_session','')
 if not token:return None
 now=int(time.time())
 with conn() as c:
  row=c.execute('select username,csrf_token,expires_at from sessions where token_hash=?',(_token_hash(token),)).fetchone()
  if not row:return None
  if int(row['expires_at'])<now:
   c.execute('delete from sessions where token_hash=?',(_token_hash(token),));return None
  u=c.execute('select username,role,enabled from users where username=?',(row['username'],)).fetchone()
  if not u or not u['enabled']:return None
  return {'username':u['username'],'role':u['role'],'csrf_token':row['csrf_token'],'expires_at':row['expires_at']}

def _auth_required_count()->int:
 with conn() as c:return c.execute('select count(*) from users where enabled=1').fetchone()[0]

@app.middleware('http')
async def secure_portal(request:Request,call_next):
 path=request.url.path
 host=(request.headers.get('host') or '').split(':')[0].lower()
 if host not in ('127.0.0.1','localhost','::1'):return JSONResponse({'detail':'Invalid host'},status_code=400)
 public=path=='/login' or path.startswith('/static/') or path in ('/api/auth/status','/api/auth/setup','/api/auth/login')
 sess=None if public else _session_from_request(request)
 if not public and not sess:
  if path.startswith('/api/'):return JSONResponse({'detail':'Authentication required'},status_code=401)
  return RedirectResponse('/login',status_code=303)
 if sess:
  request.state.user=sess['username'];request.state.role=sess['role'];request.state.csrf=sess['csrf_token']
  tok1=CURRENT_USER.set(sess['username']);tok2=CURRENT_IP.set(request.client.host if request.client else 'local')
  if sess['role']=='viewer' and request.method in ('POST','PUT','PATCH','DELETE') and path!='/api/auth/logout':
   CURRENT_USER.reset(tok1);CURRENT_IP.reset(tok2);return JSONResponse({'detail':'Viewer role is read-only.'},status_code=403)
  if request.method in ('POST','PUT','PATCH','DELETE') and request.headers.get('X-CSRF-Token','')!=sess['csrf_token']:
   CURRENT_USER.reset(tok1);CURRENT_IP.reset(tok2);return JSONResponse({'detail':'CSRF validation failed'},status_code=403)
 else:tok1=tok2=None
 try:resp=await call_next(request)
 finally:
  if sess:CURRENT_USER.reset(tok1);CURRENT_IP.reset(tok2)
 resp.headers['X-Content-Type-Options']='nosniff';resp.headers['X-Frame-Options']='DENY';resp.headers['Referrer-Policy']='no-referrer';resp.headers['Permissions-Policy']='camera=(), microphone=(), geolocation=()';resp.headers['Cache-Control']='no-store'
 resp.headers['Content-Security-Policy']="default-src 'self' https://unpkg.com; script-src 'self' 'unsafe-inline' https://unpkg.com; style-src 'self' 'unsafe-inline' https://unpkg.com; img-src 'self' data: https:; connect-src 'self' https:; frame-src https://cybermap.kaspersky.com https://www.youtube-nocookie.com"
 return resp

@app.get('/login',response_class=HTMLResponse)
def login_page():return (STATIC/'login.html').read_text(encoding='utf-8')
@app.get('/api/auth/status')
def auth_status(request:Request):
 sess=_session_from_request(request)
 return {'needs_setup':_auth_required_count()==0,'authenticated':bool(sess),'user':sess['username'] if sess else '','csrf_token':sess['csrf_token'] if sess else ''}
@app.post('/api/auth/setup')
def auth_setup(x:AuthSetup,response:Response):
 if _auth_required_count()!=0:raise HTTPException(409,'Administrator account is already configured.')
 username=re.sub(r'[^A-Za-z0-9_.-]','',x.username.strip())[:64] or 'admin'
 if len(x.password)<12:raise HTTPException(400,'Password must be at least 12 characters.')
 with conn() as c:c.execute('insert into users(username,password_hash,role) values(?,?,?)',(username,PH.hash(x.password),'admin'))
 CURRENT_USER.set(username);audit('auth.admin.setup',username)
 token=secrets.token_urlsafe(32);csrf=secrets.token_urlsafe(24);exp=int(time.time())+SESSION_HOURS*3600
 with conn() as c:c.execute('insert into sessions(token_hash,username,csrf_token,expires_at) values(?,?,?,?)',(_token_hash(token),username,csrf,exp))
 response.set_cookie('hms_session',token,httponly=True,samesite='strict',secure=False,max_age=SESSION_HOURS*3600,path='/')
 return {'ok':True,'user':username,'csrf_token':csrf}
@app.post('/api/auth/login')
def auth_login(x:AuthLogin,response:Response,request:Request):
 ip=request.client.host if request.client else 'local';now=int(time.time());user=x.username.strip()
 with conn() as c:
  c.execute('delete from auth_failures where attempted_at<?',(now-86400,));fails=c.execute('select count(*) from auth_failures where source_ip=? and attempted_at>?',(ip,now-900)).fetchone()[0]
  u=c.execute('select * from users where username=? and enabled=1',(user,)).fetchone()
 if fails>=5:
  CURRENT_IP.set(ip);audit('auth.login.blocked',f'{user}:rate-limit');raise HTTPException(429,'Too many failed login attempts. Try again later.')
 try:
  if not u:raise VerifyMismatchError
  PH.verify(u['password_hash'],x.password)
 except VerifyMismatchError:
  with conn() as c:c.execute('insert into auth_failures(username,source_ip,attempted_at) values(?,?,?)',(user,ip,now))
  CURRENT_IP.set(ip);audit('auth.login.failed',user);raise HTTPException(401,'Invalid username or password.')
 with conn() as c:c.execute('delete from auth_failures where source_ip=?',(ip,))
 with conn() as c:
  c.execute('delete from sessions where expires_at<?',(int(time.time()),));c.execute('update users set last_login=CURRENT_TIMESTAMP where username=?',(u['username'],))
 token=secrets.token_urlsafe(32);csrf=secrets.token_urlsafe(24);exp=int(time.time())+SESSION_HOURS*3600
 with conn() as c:c.execute('insert into sessions(token_hash,username,csrf_token,expires_at) values(?,?,?,?)',(_token_hash(token),u['username'],csrf,exp))
 CURRENT_USER.set(u['username']);audit('auth.login',u['username'])
 response.set_cookie('hms_session',token,httponly=True,samesite='strict',secure=False,max_age=SESSION_HOURS*3600,path='/')
 return {'ok':True,'user':u['username'],'csrf_token':csrf}
@app.post('/api/auth/logout')
def auth_logout(request:Request,response:Response):
 token=request.cookies.get('hms_session','')
 if token:
  with conn() as c:c.execute('delete from sessions where token_hash=?',(_token_hash(token),))
 audit('auth.logout',getattr(request.state,'user',''))
 response.delete_cookie('hms_session',path='/');return {'ok':True}
@app.get('/api/auth/me')
def auth_me(request:Request):return {'user':request.state.user,'role':request.state.role,'csrf_token':request.state.csrf}


def _require_admin(request:Request):
 if getattr(request.state,'role','')!='admin': raise HTTPException(403,'Administrator role required.')

@app.get('/api/users')
def users_list(request:Request):
 _require_admin(request)
 with conn() as c:
  rows=[dict(r) for r in c.execute("select u.id,u.username,u.role,u.enabled,u.created_at,u.last_login,coalesce(sc.cred_type,'') scan_credential_type,coalesce(sc.target_username,'') scan_username,coalesce(sc.domain,'') scan_domain,case when sc.secret_enc!='' or sc.key_enc!='' then 1 else 0 end scan_credential_configured from users u left join scan_credentials sc on sc.username=u.username order by u.username").fetchall()]
 return rows

@app.post('/api/users')
def users_create(x:UserCreate,request:Request):
 _require_admin(request);username=re.sub(r'[^A-Za-z0-9_.-]','',x.username.strip())[:64]
 if not username:raise HTTPException(400,'Username is required.')
 if len(x.password)<12:raise HTTPException(400,'Password must be at least 12 characters.')
 role=x.role.lower().strip()
 if role not in ('admin','analyst','viewer'):raise HTTPException(400,'Role must be admin, analyst, or viewer.')
 try:
  with conn() as c:c.execute('insert into users(username,password_hash,role,enabled) values(?,?,?,?)',(username,PH.hash(x.password),role,1 if x.enabled else 0))
 except sqlite3.IntegrityError:raise HTTPException(409,'Username already exists.')
 audit('auth.user.create',f'{username}:{role}');return {'ok':True,'username':username}

@app.patch('/api/users/{username}')
def users_update(username:str,x:UserUpdate,request:Request):
 _require_admin(request)
 with conn() as c:
  row=c.execute('select * from users where username=?',(username,)).fetchone()
  if not row:raise HTTPException(404,'User not found.')
  role=(x.role or row['role']).lower()
  if role not in ('admin','analyst','viewer'):raise HTTPException(400,'Invalid role.')
  enabled=row['enabled'] if x.enabled is None else (1 if x.enabled else 0)
  if username==request.state.user and not enabled:raise HTTPException(400,'You cannot disable your own active account.')
  if row['role']=='admin' and (role!='admin' or not enabled):
   admins=c.execute("select count(*) from users where role='admin' and enabled=1").fetchone()[0]
   if admins<=1:raise HTTPException(400,'At least one enabled administrator is required.')
  if x.password:
   if len(x.password)<12:raise HTTPException(400,'Password must be at least 12 characters.')
   c.execute('update users set role=?,enabled=?,password_hash=? where username=?',(role,enabled,PH.hash(x.password),username));c.execute('delete from sessions where username=?',(username,))
  else:c.execute('update users set role=?,enabled=? where username=?',(role,enabled,username))
 audit('auth.user.update',f'{username}:{role}:enabled={enabled}');return {'ok':True}

@app.delete('/api/users/{username}')
def users_delete(username:str,request:Request):
 _require_admin(request)
 if username==request.state.user:raise HTTPException(400,'You cannot delete the account currently signed in.')
 with conn() as c:
  row=c.execute('select role,enabled from users where username=?',(username,)).fetchone()
  if not row:raise HTTPException(404,'User not found.')
  if row['role']=='admin' and row['enabled']:
   admins=c.execute("select count(*) from users where role='admin' and enabled=1").fetchone()[0]
   if admins<=1:raise HTTPException(400,'At least one enabled administrator is required.')
  c.execute('delete from sessions where username=?',(username,));c.execute('delete from scan_credentials where username=?',(username,));c.execute('delete from user_certifications where username=?',(username,));c.execute('delete from users where username=?',(username,))
 audit('auth.user.delete',username);return {'ok':True}

@app.get('/api/users/{username}/certifications')
def user_certifications_list(username:str,request:Request):
 _require_admin(request)
 with conn() as c:
  if not c.execute('select 1 from users where username=?',(username,)).fetchone():raise HTTPException(404,'User not found.')
  return [dict(r) for r in c.execute('select * from user_certifications where username=? order by certification,issued_date desc,id desc',(username,)).fetchall()]

@app.post('/api/users/{username}/certifications')
def user_certifications_create(username:str,x:UserCertification,request:Request):
 _require_admin(request); cert=x.certification.strip()[:200]
 if not cert:raise HTTPException(400,'Certification is required.')
 url=x.verification_url.strip()[:1000]
 if url and not re.match(r'^https?://',url,re.I):raise HTTPException(400,'Verification URL must use http:// or https://.')
 with conn() as c:
  if not c.execute('select 1 from users where username=?',(username,)).fetchone():raise HTTPException(404,'User not found.')
  cur=c.execute('insert into user_certifications(username,certification,credential_id,issued_date,expires_date,verification_url,notes) values(?,?,?,?,?,?,?)',(username,cert,x.credential_id.strip()[:200],x.issued_date.strip()[:20],x.expires_date.strip()[:20],url,x.notes.strip()[:4000]))
 audit('auth.user.certification.create',f'{username}:{cert}');return {'ok':True,'id':cur.lastrowid}

@app.patch('/api/users/{username}/certifications/{cert_id}')
def user_certifications_update(username:str,cert_id:int,x:UserCertification,request:Request):
 _require_admin(request); cert=x.certification.strip()[:200]
 if not cert:raise HTTPException(400,'Certification is required.')
 url=x.verification_url.strip()[:1000]
 if url and not re.match(r'^https?://',url,re.I):raise HTTPException(400,'Verification URL must use http:// or https://.')
 with conn() as c:
  if not c.execute('select 1 from user_certifications where id=? and username=?',(cert_id,username)).fetchone():raise HTTPException(404,'Certification record not found.')
  c.execute('update user_certifications set certification=?,credential_id=?,issued_date=?,expires_date=?,verification_url=?,notes=?,updated_at=CURRENT_TIMESTAMP where id=? and username=?',(cert,x.credential_id.strip()[:200],x.issued_date.strip()[:20],x.expires_date.strip()[:20],url,x.notes.strip()[:4000],cert_id,username))
 audit('auth.user.certification.update',f'{username}:{cert_id}:{cert}');return {'ok':True}

@app.delete('/api/users/{username}/certifications/{cert_id}')
def user_certifications_delete(username:str,cert_id:int,request:Request):
 _require_admin(request)
 with conn() as c:
  cur=c.execute('delete from user_certifications where id=? and username=?',(cert_id,username))
  if not cur.rowcount:raise HTTPException(404,'Certification record not found.')
 audit('auth.user.certification.delete',f'{username}:{cert_id}');return {'ok':True}

@app.patch('/api/users/{username}/scan-credentials')
def user_scan_credentials(username:str,x:ScanCredentialUpdate,request:Request):
 _require_admin(request)
 with conn() as c:
  u=c.execute('select username from users where username=?',(username,)).fetchone()
  if not u:raise HTTPException(404,'User not found.')
  if x.clear:
   c.execute('delete from scan_credentials where username=?',(username,));audit('scan.credentials.clear',username);return {'ok':True,'configured':False}
  ctype=x.cred_type.strip().lower()
  if ctype not in ('ssh','winrm'):raise HTTPException(400,'Credential type must be SSH or WinRM.')
  target_user=x.target_username.strip()[:200]
  if not target_user:raise HTTPException(400,'Target username is required.')
  old=c.execute('select * from scan_credentials where username=?',(username,)).fetchone()
  secret_enc=enc(x.secret) if x.secret else (old['secret_enc'] if old else '')
  key_enc=enc(x.private_key) if x.private_key else (old['key_enc'] if old else '')
  if not secret_enc and not key_enc:raise HTTPException(400,'Provide a password or private key.')
  c.execute('insert into scan_credentials(username,cred_type,target_username,secret_enc,domain,key_enc,updated_at) values(?,?,?,?,?,?,CURRENT_TIMESTAMP) on conflict(username) do update set cred_type=excluded.cred_type,target_username=excluded.target_username,secret_enc=excluded.secret_enc,domain=excluded.domain,key_enc=excluded.key_enc,updated_at=CURRENT_TIMESTAMP',(username,ctype,target_user,secret_enc,x.domain.strip()[:200],key_enc))
 audit('scan.credentials.update',f'{username}:{ctype}:{target_user}')
 return {'ok':True,'configured':True,'cred_type':ctype,'target_username':target_user,'domain':x.domain.strip()[:200]}

def _get_scan_credential(username:str)->dict:
 if not username:return {}
 with conn() as c:r=c.execute('select * from scan_credentials where username=?',(username,)).fetchone()
 if not r:return {}
 d=dict(r);d['secret']=dec(d.pop('secret_enc',''));d['private_key']=dec(d.pop('key_enc',''));return d

@app.get('/',response_class=HTMLResponse)
def home():return (STATIC/'index.html').read_text(encoding='utf-8')
@app.get('/api/health')
def health():return {'status':'ok','product':'Hive Mind Security','version':VERSION,'data_dir':str(DATA)}
@app.get('/api/system')
def system():return {'version':VERSION,'data_dir':str(DATA),'database':str(DB),'backups':str(BACKUPS),'python':os.sys.version.split()[0]}

@app.get('/api/dashboard')
def dashboard():
 with conn() as c:
  q=lambda s:c.execute(s).fetchone()[0]
  total=q("select count(*) from integrations where enabled=1")+len(NO_KEY); healthy=q("select count(*) from integrations where enabled=1 and status='healthy'")
  study=q('select count(*) from study')
  return {'open_tasks':q("select count(*) from tasks where status!='done'"),'open_risks':q("select count(*) from risks where status='open'"),'active_incidents':q("select count(*) from incidents where status!='closed'"),'assets':q("select count(*) from assets where status='active'"),'open_vulns':q("select count(*) from vulnerabilities where status!='closed'"),'investigations':q("select count(*) from investigations where status!='closed'"),'integrations':total,'healthy_integrations':healthy,'academy_attempts':study,'tracked_findings':q("select count(*) from tracked_findings where lower(status) not in ('fixed','remediated','closed')")}

@app.get('/api/news')
async def news(limit:int=45):
 items=[]; sources=[]
 async with httpx.AsyncClient(timeout=12,follow_redirects=True,headers={'User-Agent':f'HiveMindSecurity/{VERSION}'}) as client:
  for source,url,category,home in NEWS_FEEDS:
   status={'name':source,'category':category,'home':home,'feed':url,'ok':False,'count':0,'error':''}
   try:
    r=await client.get(url);r.raise_for_status();root=ET.fromstring(r.content); found=[]
    for e in root.findall('.//item')[:10]:
     title=(e.findtext('title') or 'Untitled').strip(); link=(e.findtext('link') or '').strip(); published=(e.findtext('pubDate') or e.findtext('date') or '').strip()
     if link.startswith('https://') or link.startswith('http://'):found.append({'source':source,'category':category,'title':title,'link':link,'published':published})
    # Atom fallback
    if not found:
     ns={'a':'http://www.w3.org/2005/Atom'}
     for e in root.findall('.//a:entry',ns)[:10]:
      title=(e.findtext('a:title',default='Untitled',namespaces=ns) or 'Untitled').strip(); le=e.find('a:link',ns); link=(le.get('href') if le is not None else '') or ''; published=(e.findtext('a:updated',default='',namespaces=ns) or '').strip()
      if link.startswith('https://') or link.startswith('http://'):found.append({'source':source,'category':category,'title':title,'link':link,'published':published})
    items.extend(found); status['ok']=True; status['count']=len(found)
   except Exception as e:status['error']=str(e)[:180]
   sources.append(status)
 return {'generated_at':datetime.now(timezone.utc).isoformat(),'items':items[:max(1,min(limit,90))],'sources':sources}

@app.get('/api/kev')
async def kev(limit:int=30):
 try:
  async with httpx.AsyncClient(timeout=15,follow_redirects=True) as c:r=await c.get('https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json');r.raise_for_status();d=r.json()
  return sorted(d.get('vulnerabilities',[]),key=lambda x:x.get('dateAdded',''),reverse=True)[:limit]
 except Exception as e:return {'error':str(e),'vulnerabilities':[]}

async def geo_ip(client,ip):
 try:
  r=await client.get(f'https://ipwho.is/{ip}'); d=r.json();
  if d.get('success') is False:return None
  return {'lat':d.get('latitude'),'lon':d.get('longitude'),'country':d.get('country_code'),'city':d.get('city'),'asn':(d.get('connection') or {}).get('asn'),'org':(d.get('connection') or {}).get('org')}
 except Exception:return None

def extract_dshield(d):
 if isinstance(d,list):return d
 if isinstance(d,dict):
  for k in ('sources','data','source'):
   v=d.get(k)
   if isinstance(v,list):return v
   if isinstance(v,dict):
    for vv in v.values():
     if isinstance(vv,list):return vv
 return []

@app.get('/api/threat-map')
async def threat_map(refresh:bool=False):
 now=time.time()
 if THREAT_CACHE['data'] and not refresh and now-THREAT_CACHE['ts']<300:return THREAT_CACHE['data']
 events=[]; errors=[]
 async with httpx.AsyncClient(timeout=18,follow_redirects=True,headers={'User-Agent':f'HiveMindSecurity/{VERSION}'}) as c:
  try:
   r=await c.get('https://feodotracker.abuse.ch/downloads/ipblocklist_recommended.json');r.raise_for_status()
   for x in r.json()[:120]:
    cc=x.get('country'); pos=COUNTRY_CENTROIDS.get(cc)
    if pos:events.append({'source':'Feodo Tracker','kind':'Botnet C2','ip':x.get('ip_address'),'port':x.get('port'),'malware':x.get('malware'),'country':cc,'lat':pos[0],'lon':pos[1],'first_seen':x.get('first_seen'),'last_seen':x.get('last_online'),'confidence':'high','note':'Active/recent botnet command-and-control infrastructure.'})
  except Exception as e:errors.append('Feodo: '+str(e)[:120])
  try:
   r=await c.get('https://isc.sans.edu/api/sources/attacks/25?json');r.raise_for_status(); src=extract_dshield(r.json())[:18]
   geos=await asyncio.gather(*[geo_ip(c,str(x.get('ip') or x.get('source') or '').strip()) for x in src])
   for x,g in zip(src,geos):
    ip=str(x.get('ip') or x.get('source') or '').strip()
    if g and g.get('lat') is not None:events.append({'source':'SANS ISC / DShield','kind':'Reported source activity','ip':ip,'country':g.get('country'),'city':g.get('city'),'lat':g.get('lat'),'lon':g.get('lon'),'reports':x.get('count') or x.get('reports'),'targets':x.get('attacks') or x.get('targets'),'first_seen':x.get('firstseen'),'last_seen':x.get('lastseen'),'confidence':'community','note':'Community-reported source activity; this feed is not a blocklist.'})
  except Exception as e:errors.append('DShield: '+str(e)[:120])
 data={'generated_at':datetime.now(timezone.utc).isoformat(),'events':events,'sources':['abuse.ch Feodo Tracker','SANS ISC / DShield'],'errors':errors,'meaning':'Markers represent real malicious infrastructure or reported source activity from the named feed. Hive Mind does not invent attack paths. Source-to-destination arcs are only shown when an attached organizational telemetry source supplies both endpoints.'}
 THREAT_CACHE.update(ts=now,data=data); return data

# CRUD helpers
@app.get('/api/tasks')
def tasks():
 with conn() as c:return [dict(x) for x in c.execute('select * from tasks order by id desc').fetchall()]
@app.post('/api/tasks')
def add_task(x:Task):
 with conn() as c:c.execute('insert into tasks(title,owner,team,status,priority) values(?,?,?,?,?)',(x.title,x.owner,x.team,x.status,x.priority))
 audit('task.create',x.title);return {'ok':True}
@app.put('/api/tasks/{record_id}')
def task_update(record_id:int,x:Task):
 with conn() as c:
  if not c.execute('select 1 from tasks where id=?',(record_id,)).fetchone():raise HTTPException(404,'Task not found')
  c.execute('update tasks set title=?,owner=?,team=?,status=?,priority=? where id=?',(x.title,x.owner,x.team,x.status,x.priority,record_id))
 audit('task.update',f'{record_id}:{x.title}');return {'ok':True}
@app.delete('/api/tasks/{record_id}')
def task_delete(record_id:int):
 with conn() as c:
  r=c.execute('select title from tasks where id=?',(record_id,)).fetchone()
  if not r:raise HTTPException(404,'Task not found')
  c.execute('delete from tasks where id=?',(record_id,))
 audit('task.delete',f'{record_id}:{r["title"]}');return {'ok':True}
@app.get('/api/risks')
def risks():
 with conn() as c:a=[dict(x) for x in c.execute('select * from risks order by id desc').fetchall()]
 for r in a:r['score']=r['likelihood']*r['impact']
 return a
@app.post('/api/risks')
def add_risk(x:Risk):
 with conn() as c:c.execute('insert into risks(title,likelihood,impact,owner,treatment,status) values(?,?,?,?,?,?)',(x.title,x.likelihood,x.impact,x.owner,x.treatment,x.status))
 audit('risk.create',x.title);return {'ok':True}
@app.get('/api/incidents')
def incidents():
 with conn() as c:return [dict(x) for x in c.execute('select * from incidents order by id desc').fetchall()]
@app.post('/api/incidents')
def add_incident(x:Incident):
 phases=['Detect & Validate','Scope & Preserve','Contain','Eradicate','Recover','Lessons Learned']
 with conn() as c:
  c.execute('insert into incidents(title,severity,status,commander,summary) values(?,?,?,?,?)',(x.title,x.severity,x.status,x.commander,x.summary));iid=c.execute('select last_insert_rowid()').fetchone()[0]
  for i,p in enumerate(phases):c.execute('insert or ignore into incident_lifecycle(incident_id,phase,status) values(?,?,?)',(iid,p,'active' if i==0 else 'pending'))
 audit('incident.declare',f'{iid}:{x.title}');return {'ok':True,'id':iid}
@app.get('/api/incidents/{incident_id}/lifecycle')
def incident_lifecycle(incident_id:int):
 with conn() as c:
  if not c.execute('select 1 from incidents where id=?',(incident_id,)).fetchone():raise HTTPException(404,'Incident not found')
  return [dict(x) for x in c.execute('select * from incident_lifecycle where incident_id=? order by id',(incident_id,)).fetchall()]
@app.put('/api/incidents/{incident_id}/lifecycle')
def incident_lifecycle_update(incident_id:int,x:IncidentPhase):
 allowed=['Detect & Validate','Scope & Preserve','Contain','Eradicate','Recover','Lessons Learned'];statuses=['pending','active','complete','blocked']
 if x.phase not in allowed or x.status not in statuses:raise HTTPException(400,'Invalid lifecycle phase or status')
 with conn() as c:
  if not c.execute('select 1 from incidents where id=?',(incident_id,)).fetchone():raise HTTPException(404,'Incident not found')
  c.execute('insert into incident_lifecycle(incident_id,phase,status,notes,owner,updated_at) values(?,?,?,?,?,CURRENT_TIMESTAMP) on conflict(incident_id,phase) do update set status=excluded.status,notes=excluded.notes,owner=excluded.owner,updated_at=CURRENT_TIMESTAMP',(incident_id,x.phase,x.status,x.notes,x.owner))
 audit('incident.lifecycle.update',f'{incident_id}:{x.phase}:{x.status}');return {'ok':True}
@app.delete('/api/incidents/{incident_id}')
def incident_delete(incident_id:int):
 with conn() as c:
  r=c.execute('select title from incidents where id=?',(incident_id,)).fetchone()
  if not r:raise HTTPException(404,'Incident not found')
  c.execute('delete from incident_lifecycle where incident_id=?',(incident_id,));c.execute('delete from incidents where id=?',(incident_id,))
 audit('incident.delete',f'{incident_id}:{r["title"]}');return {'ok':True}
@app.get('/api/assets')
def assets():
 with conn() as c:return [dict(x) for x in c.execute('select * from assets order by id desc').fetchall()]
@app.post('/api/assets')
def add_asset(x:Asset):
 with conn() as c:c.execute('insert into assets(name,kind,criticality,owner,location,status) values(?,?,?,?,?,?)',(x.name,x.kind,x.criticality,x.owner,x.location,x.status))
 audit('asset.create',x.name);return {'ok':True}
@app.get('/api/vulnerabilities')
def vulns():
 with conn() as c:return [dict(x) for x in c.execute('select * from vulnerabilities order by id desc').fetchall()]
@app.post('/api/vulnerabilities')
def add_vuln(x:Vulnerability):
 with conn() as c:c.execute('insert into vulnerabilities(cve,title,severity,asset,owner,status,due_date,source) values(?,?,?,?,?,?,?,?)',(x.cve,x.title,x.severity,x.asset,x.owner,x.status,x.due_date,x.source))
 audit('vulnerability.create',x.cve or x.title);return {'ok':True}
@app.put('/api/vulnerabilities/{finding_id}')
def update_vulnerability(finding_id:int,x:VulnerabilityUpdate):
 if x.status not in ('open','in_progress','risk_accepted','remediated','closed'):raise HTTPException(400,'Invalid vulnerability status')
 with conn() as c:
  r=c.execute('select * from vulnerabilities where id=?',(finding_id,)).fetchone()
  if not r:raise HTTPException(404,'Vulnerability finding not found')
  c.execute('update vulnerabilities set status=?,owner=?,due_date=? where id=?',(x.status,x.owner[:200],x.due_date[:32],finding_id))
 audit('vulnerability.update',f'{finding_id}:{x.status}:{x.owner}');return {'ok':True}
@app.delete('/api/vulnerabilities/{finding_id}')
def delete_vulnerability(finding_id:int):
 with conn() as c:
  r=c.execute('select * from vulnerabilities where id=?',(finding_id,)).fetchone()
  if not r:raise HTTPException(404,'Tracked finding not found')
  c.execute('delete from vulnerabilities where id=?',(finding_id,))
 audit('vulnerability.delete',f'{finding_id}:{r["cve"] or r["title"]}');return {'ok':True}

@app.get('/api/team/{team}')
def team_guide(team:str):
 if team not in TEAM_GUIDES:raise HTTPException(404,'Unknown team')
 return TEAM_GUIDES[team]
@app.get('/api/engagements')
def engagements():
 with conn() as c:return [dict(x) for x in c.execute('select * from engagements order by id desc').fetchall()]
@app.post('/api/engagements')
def add_engagement(x:Engagement):
 with conn() as c:c.execute('insert into engagements(name,scope,owner,status,roe,stop_conditions) values(?,?,?,?,?,?)',(x.name,x.scope,x.owner,x.status,x.roe,x.stop_conditions))
 audit('red.engagement.create',x.name);return {'ok':True}
@app.get('/api/team-findings')
def team_findings(team:str=''):
 with conn() as c:
  if team:return [dict(x) for x in c.execute('select * from team_findings where team=? order by id desc',(team,)).fetchall()]
  return [dict(x) for x in c.execute('select * from team_findings order by id desc').fetchall()]
@app.post('/api/team-findings')
def add_team_finding(x:TeamFinding):
 with conn() as c:c.execute('insert into team_findings(team,title,severity,status,asset,attack_id,evidence,remediation) values(?,?,?,?,?,?,?,?)',(x.team,x.title,x.severity,x.status,x.asset,x.attack_id,x.evidence,x.remediation))
 audit(f'{x.team}.finding.create',x.title);return {'ok':True}
@app.get('/api/purple-tests')
def purple_tests():
 with conn() as c:return [dict(x) for x in c.execute('select * from purple_tests order by id desc').fetchall()]
@app.post('/api/purple-tests')
def add_purple(x:PurpleTest):
 with conn() as c:c.execute('insert into purple_tests(technique,hypothesis,expected_telemetry,observed,detection,gap,owner,status) values(?,?,?,?,?,?,?,?)',(x.technique,x.hypothesis,x.expected_telemetry,x.observed,x.detection,x.gap,x.owner,x.status))
 audit('purple.test.create',x.technique);return {'ok':True}
@app.get('/api/investigations')
def investigations():
 with conn() as c:return [dict(x) for x in c.execute('select * from investigations order by id desc').fetchall()]
@app.post('/api/investigations')
def add_investigation(x:Investigation):
 with conn() as c:c.execute('insert into investigations(title,status,severity,summary,iocs,timeline) values(?,?,?,?,?,?)',(x.title,x.status,x.severity,x.summary,x.iocs,x.timeline))
 audit('blue.investigation.create',x.title);return {'ok':True}


# User-entered operational records: full edit/delete support -----------------
def _must_row(c,table:str,rid:int,label:str):
 r=c.execute(f'select * from {table} where id=?',(rid,)).fetchone()
 if not r: raise HTTPException(404,f'{label} not found')
 return r

@app.put('/api/investigations/{record_id}')
def investigation_update(record_id:int,x:Investigation):
 with conn() as c:
  _must_row(c,'investigations',record_id,'Investigation')
  c.execute('update investigations set title=?,status=?,severity=?,summary=?,iocs=?,timeline=? where id=?',(x.title,x.status,x.severity,x.summary,x.iocs,x.timeline,record_id))
 audit('blue.investigation.update',f'{record_id}:{x.title}');return {'ok':True}
@app.delete('/api/investigations/{record_id}')
def investigation_delete(record_id:int):
 with conn() as c:
  r=_must_row(c,'investigations',record_id,'Investigation');c.execute('delete from investigations where id=?',(record_id,))
 audit('blue.investigation.delete',f'{record_id}:{r["title"]}');return {'ok':True}

@app.put('/api/incidents/{record_id}')
def incident_update(record_id:int,x:Incident):
 with conn() as c:
  _must_row(c,'incidents',record_id,'Incident');c.execute('update incidents set title=?,severity=?,status=?,commander=?,summary=? where id=?',(x.title,x.severity,x.status,x.commander,x.summary,record_id))
 audit('incident.update',f'{record_id}:{x.title}:{x.status}');return {'ok':True}

@app.put('/api/assets/{record_id}')
def asset_update(record_id:int,x:Asset):
 with conn() as c:_must_row(c,'assets',record_id,'Asset');c.execute('update assets set name=?,kind=?,criticality=?,owner=?,location=?,status=? where id=?',(x.name,x.kind,x.criticality,x.owner,x.location,x.status,record_id))
 audit('asset.update',f'{record_id}:{x.name}');return {'ok':True}
@app.delete('/api/assets/{record_id}')
def asset_delete(record_id:int):
 with conn() as c:r=_must_row(c,'assets',record_id,'Asset');c.execute('delete from assets where id=?',(record_id,))
 audit('asset.delete',f'{record_id}:{r["name"]}');return {'ok':True}

@app.put('/api/risks/{record_id}')
def risk_update(record_id:int,x:Risk):
 with conn() as c:_must_row(c,'risks',record_id,'Risk');c.execute('update risks set title=?,likelihood=?,impact=?,owner=?,treatment=?,status=? where id=?',(x.title,x.likelihood,x.impact,x.owner,x.treatment,x.status,record_id))
 audit('risk.update',f'{record_id}:{x.title}');return {'ok':True}
@app.delete('/api/risks/{record_id}')
def risk_delete(record_id:int):
 with conn() as c:r=_must_row(c,'risks',record_id,'Risk');c.execute('delete from risks where id=?',(record_id,))
 audit('risk.delete',f'{record_id}:{r["title"]}');return {'ok':True}

@app.put('/api/engagements/{record_id}')
def engagement_update(record_id:int,x:Engagement):
 with conn() as c:_must_row(c,'engagements',record_id,'Engagement');c.execute('update engagements set name=?,scope=?,owner=?,status=?,roe=?,stop_conditions=? where id=?',(x.name,x.scope,x.owner,x.status,x.roe,x.stop_conditions,record_id))
 audit('red.engagement.update',f'{record_id}:{x.name}');return {'ok':True}
@app.delete('/api/engagements/{record_id}')
def engagement_delete(record_id:int):
 with conn() as c:r=_must_row(c,'engagements',record_id,'Engagement');c.execute('delete from engagements where id=?',(record_id,))
 audit('red.engagement.delete',f'{record_id}:{r["name"]}');return {'ok':True}

@app.put('/api/team-findings/{record_id}')
def team_finding_update(record_id:int,x:TeamFinding):
 with conn() as c:_must_row(c,'team_findings',record_id,'Team finding');c.execute('update team_findings set team=?,title=?,severity=?,status=?,asset=?,attack_id=?,evidence=?,remediation=? where id=?',(x.team,x.title,x.severity,x.status,x.asset,x.attack_id,x.evidence,x.remediation,record_id))
 audit(f'{x.team}.finding.update',f'{record_id}:{x.title}');return {'ok':True}
@app.delete('/api/team-findings/{record_id}')
def team_finding_delete(record_id:int):
 with conn() as c:r=_must_row(c,'team_findings',record_id,'Team finding');c.execute('delete from team_findings where id=?',(record_id,))
 audit(f'{r["team"]}.finding.delete',f'{record_id}:{r["title"]}');return {'ok':True}

@app.put('/api/purple-tests/{record_id}')
def purple_update(record_id:int,x:PurpleTest):
 with conn() as c:_must_row(c,'purple_tests',record_id,'Purple validation');c.execute('update purple_tests set technique=?,hypothesis=?,expected_telemetry=?,observed=?,detection=?,gap=?,owner=?,status=? where id=?',(x.technique,x.hypothesis,x.expected_telemetry,x.observed,x.detection,x.gap,x.owner,x.status,record_id))
 audit('purple.test.update',f'{record_id}:{x.technique}');return {'ok':True}
@app.delete('/api/purple-tests/{record_id}')
def purple_delete(record_id:int):
 with conn() as c:r=_must_row(c,'purple_tests',record_id,'Purple validation');c.execute('delete from purple_tests where id=?',(record_id,))
 audit('purple.test.delete',f'{record_id}:{r["technique"]}');return {'ok':True}

@app.put('/api/playbook-runs/{record_id}')
def playbook_run_update(record_id:int,x:PlaybookRun):
 with conn() as c:_must_row(c,'playbook_runs',record_id,'Playbook run');c.execute('update playbook_runs set playbook_id=?,title=?,team=?,status=?,owner=?,notes=? where id=?',(x.playbook_id,x.title,x.team,x.status,x.owner,x.notes,record_id))
 audit('playbook.run.update',f'{record_id}:{x.title}:{x.status}');return {'ok':True}
@app.delete('/api/playbook-runs/{record_id}')
def playbook_run_delete(record_id:int):
 with conn() as c:r=_must_row(c,'playbook_runs',record_id,'Playbook run');c.execute('delete from playbook_runs where id=?',(record_id,))
 audit('playbook.run.delete',f'{record_id}:{r["title"]}');return {'ok':True}

@app.delete('/api/study-history/{record_id}')
def study_history_delete(record_id:int):
 with conn() as c:r=_must_row(c,'study',record_id,'Study attempt');c.execute('delete from study where id=?',(record_id,))
 audit('academy.history.delete',f'{record_id}:{r["cert"]}');return {'ok':True}

@app.delete('/api/framework-check')
def framework_check_delete(framework:str,control:str):
 with conn() as c:c.execute('delete from framework_checks where framework=? and control=?',(framework,control))
 audit('framework.check.reset',f'{framework}:{control}');return {'ok':True}

@app.delete('/api/integrations/{iid}')
def integration_reset(iid:str):
 with conn() as c:
  if not c.execute('select 1 from integrations where id=?',(iid,)).fetchone(): raise HTTPException(404,'Integration configuration not found')
  c.execute("update integrations set enabled=0,config_json='{}',status='not_configured',last_error='',updated_at=CURRENT_TIMESTAMP where id=?",(iid,))
 audit('integration.reset',iid);return {'ok':True}

# Third-party pentest reports and tracked findings ----------------------------
def _safe_name(name:str)->str:return re.sub(r'[^A-Za-z0-9._-]','_',Path(name or 'report').name)[:180]
def _extract_report_text(name:str,data:bytes)->tuple[str,str]:
 ext=Path(name).suffix.lower()
 if ext=='.pdf':
  reader=PdfReader(BytesIO(data));return '\n'.join((p.extract_text() or '') for p in reader.pages),'PDF text extraction'
 if ext=='.docx':
  d=Document(BytesIO(data));return '\n'.join(p.text for p in d.paragraphs),'DOCX text extraction'
 if ext in ('.txt','.md','.csv','.json','.xml','.html','.htm'):
  txt=data.decode('utf-8','replace')
  if ext in ('.html','.htm'):txt=re.sub(r'<[^>]+>',' ',txt)
  return txt,'Text extraction'
 raise ValueError('Supported pentest report formats: PDF, DOCX, TXT, MD, CSV, JSON, XML, HTML.')
def _defender_scan_bytes(name:str,data:bytes)->str:
 if os.name!='nt':return 'not_available'
 mpcmd=None
 candidates=[]
 for base in (os.environ.get('ProgramFiles',''),os.environ.get('ProgramData','')):
  if base:candidates+=list(Path(base).glob('Windows Defender/MpCmdRun.exe'))+list(Path(base).glob('Microsoft/Windows Defender/Platform/*/MpCmdRun.exe'))
 if candidates:mpcmd=str(sorted(candidates)[-1])
 if not mpcmd:return 'not_available'
 tmp=Path(tempfile.gettempdir())/('hms_'+secrets.token_hex(8)+'_'+_safe_name(name));tmp.write_bytes(data)
 try:
  r=subprocess.run([mpcmd,'-Scan','-ScanType','3','-File',str(tmp),'-DisableRemediation'],capture_output=True,text=True,timeout=120)
  if r.returncode==2:raise ValueError('Microsoft Defender reported a threat in the uploaded report. Upload rejected.')
  return 'clean' if r.returncode==0 else 'scan_unknown'
 finally:
  try:tmp.unlink()
  except Exception:pass
def _heuristic_findings(text:str)->list[dict]:
 lines=[re.sub(r'\s+',' ',x).strip() for x in text.replace('\r','\n').split('\n') if x.strip()];out=[]
 sev_re=re.compile(r'\b(critical|high|medium|moderate|low|informational|info)\b',re.I);title_re=re.compile(r'^(?:finding|vulnerability|issue|observation|risk)\s*(?:#|id|no\.?|:)?.{0,12}[:\-–]\s*(.+)$',re.I)
 for i,line in enumerate(lines):
  m=title_re.match(line)
  if not m:continue
  title=m.group(1).strip()[:240];window=' '.join(lines[i:min(i+12,len(lines))])[:5000];sm=sev_re.search(window);sev=(sm.group(1).lower() if sm else 'medium').replace('moderate','medium').replace('informational','info')
  cm=re.search(r'CVE-\d{4}-\d{4,7}',window,re.I);wm=re.search(r'CWE-\d+',window,re.I)
  out.append({'title':title,'severity':sev,'description':window[:2400],'evidence':'','remediation':'','cve':cm.group(0) if cm else '','cwe':wm.group(0) if wm else ''})
  if len(out)>=80:break
 return out
async def _ollama_findings(text:str)->tuple[list[dict],str]:
 url='http://127.0.0.1:11434/api/chat';model='llama3.2:3b'
 prompt=("You are a local cybersecurity report extraction assistant. Extract only findings explicitly supported by the supplied third-party penetration-test report. Do not invent vulnerabilities. Return strict JSON with key findings containing objects with: title, severity (critical/high/medium/low/info), asset, cve, cwe, cvss, category, description, evidence, remediation. Keep evidence grounded in the report and remediation concise. Report text follows:\n\n"+text[:60000])
 try:
  async with httpx.AsyncClient(timeout=90) as c:
   r=await c.post(url,json={'model':model,'stream':False,'messages':[{'role':'user','content':prompt}],'format':'json'});r.raise_for_status();d=r.json();content=((d.get('message') or {}).get('content') or '{}');obj=json.loads(content);rows=obj.get('findings',[]) if isinstance(obj,dict) else []
  return [x for x in rows[:100] if isinstance(x,dict) and x.get('title')],f'{model} local'
 except Exception as e:return [],f'unavailable: {str(e)[:160]}'
def _finding_row(r)->dict:
 d=dict(r);d['description']=dec(d.pop('description_enc',''));d['evidence']=dec(d.pop('evidence_enc',''));d['remediation']=dec(d.pop('remediation_enc',''));return d
def _insert_tracked_finding(c,x:dict,report_id='',source='manual'):
 c.execute('insert into tracked_findings(report_id,source,title,severity,status,asset,cve,cwe,cvss,category,description_enc,evidence_enc,remediation_enc,owner,due_date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(report_id,source,x.get('title','Tracked finding')[:300],(x.get('severity') or 'medium').lower(),x.get('status','open'),x.get('asset',''),x.get('cve',''),x.get('cwe',''),str(x.get('cvss','')),x.get('category',''),enc(x.get('description','')),enc(x.get('evidence','')),enc(x.get('remediation','')),x.get('owner',''),x.get('due_date','')))
 return c.execute('select last_insert_rowid()').fetchone()[0]
def _pdf_for_finding(f:dict)->bytes:
 buf=BytesIO();doc=SimpleDocTemplate(buf,pagesize=letter,rightMargin=.65*inch,leftMargin=.65*inch,topMargin=.65*inch,bottomMargin=.65*inch,title='Hive Mind Security Remediation Report');styles=getSampleStyleSheet();styles.add(ParagraphStyle(name='SmallGray',parent=styles['BodyText'],fontSize=8,textColor=colors.grey,leading=10));story=[]
 story += [Paragraph('HIVE MIND SECURITY - REMEDIATION REPORT',styles['Title']),Paragraph(f"Finding #{f['id']} - {f['title']}",styles['Heading2']),Spacer(1,8)]
 meta=[['Severity',f.get('severity','')],['Status',f.get('status','')],['Asset',f.get('asset','')],['CVE',f.get('cve','')],['CWE',f.get('cwe','')],['CVSS',f.get('cvss','')],['Owner',f.get('owner','')],['Fixed At',f.get('fixed_at','')],['Source',f.get('source','')]];tbl=Table(meta,colWidths=[1.25*inch,5.6*inch]);tbl.setStyle(TableStyle([('BACKGROUND',(0,0),(0,-1),colors.HexColor('#e6e6e6')),('GRID',(0,0),(-1,-1),.25,colors.grey),('VALIGN',(0,0),(-1,-1),'TOP'),('FONTNAME',(0,0),(0,-1),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),9)]));story+=[tbl,Spacer(1,12)]
 for h,k in [('Original Finding','description'),('Evidence','evidence'),('Remediation Performed / Recommendation','remediation')]:story += [Paragraph(h,styles['Heading3']),Paragraph((f.get(k) or 'Not documented.').replace('\n','<br/>'),styles['BodyText']),Spacer(1,9)]
 story += [Spacer(1,8),Paragraph('Generated by Hive Mind Security. This report records the application finding state and supporting evidence; independent validation may still be required.',styles['SmallGray'])];doc.build(story);return buf.getvalue()
def _create_remediation_pdf(finding_id:int)->str:
 with conn() as c:r=c.execute('select * from tracked_findings where id=?',(finding_id,)).fetchone()
 if not r:raise HTTPException(404,'Finding not found')
 f=_finding_row(r);pdf=_pdf_for_finding(f);rid=secrets.token_hex(12);raw_hash=hashlib.sha256(pdf).hexdigest();path=REMEDIATION_STORE/f'{rid}.pdf.hmsenc';path.write_bytes(enc_bytes(pdf));_harden_private_file(path)
 with conn() as c:c.execute('insert into remediation_reports(id,finding_id,encrypted_path,sha256,created_by) values(?,?,?,?,?)',(rid,finding_id,str(path),raw_hash,CURRENT_USER.get()))
 audit('finding.remediation_report.create',f'{finding_id}:{rid}');return rid
@app.get('/api/ai/status')
async def ai_status():
 try:
  async with httpx.AsyncClient(timeout=3) as c:r=await c.get('http://127.0.0.1:11434/api/tags');r.raise_for_status();names=[x.get('name','') for x in r.json().get('models',[])]
  return {'available':True,'endpoint':'loopback only','model':'llama3.2:3b','installed_models':names,'privacy':'Report content is sent only to the local loopback Ollama service.'}
 except Exception as e:return {'available':False,'endpoint':'loopback only','model':'llama3.2:3b','detail':str(e)[:180]}
@app.get('/api/pentest-reports')
def pentest_reports():
 with conn() as c:return [dict(x) for x in c.execute('select id,name,client,original_filename,sha256,parser,ai_status,finding_count,uploaded_by,created_at from pentest_reports order by created_at desc').fetchall()]
@app.post('/api/pentest-reports/import')
async def pentest_import(file:UploadFile=File(...),name:str='',client:str=''):
 data=await file.read()
 if not data:raise HTTPException(400,'The uploaded report is empty.')
 if len(data)>40*1024*1024:raise HTTPException(413,'Pentest report exceeds the 40 MB secure upload limit.')
 fname=_safe_name(file.filename or 'pentest-report')
 try:scan=_defender_scan_bytes(fname,data);text,parser=_extract_report_text(fname,data)
 except Exception as e:raise HTTPException(400,f'Report rejected or could not be parsed: {e}')
 if len(text.strip())<40:raise HTTPException(400,'Very little extractable text was found. A scanned-image report may require OCR before import.')
 rid=secrets.token_hex(12);path=REPORT_STORE/f'{rid}.report.hmsenc';path.write_bytes(enc_bytes(data));_harden_private_file(path);sha=hashlib.sha256(data).hexdigest();heur=_heuristic_findings(text);ai,ai_state=await _ollama_findings(text);proposals=ai if ai else heur;source='local-ai' if ai else 'report-parser'
 with conn() as c:
  c.execute('insert into pentest_reports(id,name,client,original_filename,sha256,encrypted_path,extracted_text_enc,parser,ai_status,finding_count,uploaded_by) values(?,?,?,?,?,?,?,?,?,?,?)',(rid,(name or Path(fname).stem)[:240],client[:240],fname,sha,str(path),enc(text[:500000]),parser+'; Defender='+scan,ai_state,len(proposals),CURRENT_USER.get()))
  for x in proposals:_insert_tracked_finding(c,x,rid,source)
 audit('pentest.report.import',f'{rid}:{fname}:{len(proposals)} findings:{source}');return {'ok':True,'report_id':rid,'findings_created':len(proposals),'parser':parser,'defender':scan,'ai':ai_state}
@app.post('/api/pentest-reports/{report_id}/ai-parse')
async def pentest_ai_parse(report_id:str):
 with conn() as c:r=c.execute('select * from pentest_reports where id=?',(report_id,)).fetchone()
 if not r:raise HTTPException(404,'Pentest report not found')
 text=dec(r['extracted_text_enc']);ai,state=await _ollama_findings(text)
 if not ai:raise HTTPException(503,'Local Llama AI is unavailable: '+state)
 with conn() as c:
  c.execute("delete from tracked_findings where report_id=? and source in ('local-ai','report-parser')",(report_id,))
  for x in ai:_insert_tracked_finding(c,x,report_id,'local-ai')
  c.execute('update pentest_reports set ai_status=?,finding_count=? where id=?',(state,len(ai),report_id))
 audit('pentest.report.ai_parse',f'{report_id}:{len(ai)} findings');return {'ok':True,'findings_created':len(ai),'ai':state}
@app.delete('/api/pentest-reports/{report_id}')
def pentest_delete(report_id:str):
 with conn() as c:
  r=c.execute('select * from pentest_reports where id=?',(report_id,)).fetchone()
  if not r:raise HTTPException(404,'Pentest report not found')
  n=c.execute('select count(*) from tracked_findings where report_id=?',(report_id,)).fetchone()[0];ids=[x[0] for x in c.execute('select id from tracked_findings where report_id=?',(report_id,)).fetchall()]
  for fid in ids:
   for rr in c.execute('select encrypted_path from remediation_reports where finding_id=?',(fid,)).fetchall():
    try:Path(rr[0]).unlink(missing_ok=True)
    except Exception:pass
   c.execute('delete from remediation_reports where finding_id=?',(fid,))
  c.execute('delete from tracked_findings where report_id=?',(report_id,));c.execute('delete from pentest_reports where id=?',(report_id,))
 try:Path(r['encrypted_path']).unlink(missing_ok=True)
 except Exception:pass
 audit('pentest.report.delete',f'{report_id}:{r["original_filename"]}:{n} associated findings deleted');return {'ok':True,'deleted_findings':n}
@app.get('/api/tracked-findings')
def tracked_findings():
 with conn() as c:return [_finding_row(x) for x in c.execute('select * from tracked_findings order by case severity when "critical" then 1 when "high" then 2 when "medium" then 3 when "low" then 4 else 5 end,id desc').fetchall()]
@app.post('/api/tracked-findings')
def tracked_finding_create(x:TrackedFinding):
 with conn() as c:fid=_insert_tracked_finding(c,x.model_dump(),x.report_id,x.source)
 audit('finding.create',f'{fid}:{x.title}');return {'ok':True,'id':fid}
@app.put('/api/tracked-findings/{finding_id}')
def tracked_finding_update(finding_id:int,x:FindingUpdate):
 with conn() as c:r=c.execute('select * from tracked_findings where id=?',(finding_id,)).fetchone()
 if not r:raise HTTPException(404,'Finding not found')
 old=_finding_row(r);d=x.model_dump();new={k:(d[k] if d[k] != '' else old.get(k,'')) for k in d};status=(new.get('status') or old['status']).lower();fixed_at=old.get('fixed_at','')
 if status in ('fixed','remediated','closed') and old['status'].lower() not in ('fixed','remediated','closed'):fixed_at=datetime.now(timezone.utc).isoformat()
 with conn() as c:c.execute('update tracked_findings set title=?,severity=?,status=?,asset=?,cve=?,cwe=?,cvss=?,category=?,description_enc=?,evidence_enc=?,remediation_enc=?,owner=?,due_date=?,fixed_at=?,updated_at=CURRENT_TIMESTAMP where id=?',(new['title'],new['severity'].lower(),status,new['asset'],new['cve'],new['cwe'],new['cvss'],new['category'],enc(new['description']),enc(new['evidence']),enc(new['remediation']),new['owner'],new['due_date'],fixed_at,finding_id))
 audit('finding.update',f'{finding_id}:{old["status"]}->{status}:{new["title"]}');report_id=''
 if status in ('fixed','remediated','closed') and old['status'].lower() not in ('fixed','remediated','closed'):report_id=_create_remediation_pdf(finding_id)
 return {'ok':True,'remediation_report_id':report_id}
@app.delete('/api/tracked-findings/{finding_id}')
def tracked_finding_delete(finding_id:int):
 with conn() as c:
  r=c.execute('select * from tracked_findings where id=?',(finding_id,)).fetchone()
  if not r:raise HTTPException(404,'Finding not found')
  reports=c.execute('select encrypted_path from remediation_reports where finding_id=?',(finding_id,)).fetchall();c.execute('delete from remediation_reports where finding_id=?',(finding_id,));c.execute('delete from tracked_findings where id=?',(finding_id,))
 for rr in reports:
  try:Path(rr[0]).unlink(missing_ok=True)
  except Exception:pass
 audit('finding.delete',f'{finding_id}:{r["title"]}');return {'ok':True}
@app.get('/api/tracked-findings/{finding_id}/remediation-reports')
def finding_reports(finding_id:int):
 with conn() as c:return [dict(x) for x in c.execute('select id,finding_id,sha256,created_by,created_at from remediation_reports where finding_id=? order by created_at desc',(finding_id,)).fetchall()]
@app.get('/api/remediation-reports/{report_id}.pdf')
def remediation_pdf(report_id:str,download:int=0):
 with conn() as c:r=c.execute('select * from remediation_reports where id=?',(report_id,)).fetchone()
 if not r:raise HTTPException(404,'Remediation report not found')
 try:data=dec_bytes(Path(r['encrypted_path']).read_bytes())
 except Exception:raise HTTPException(500,'Remediation report could not be decrypted.')
 audit('finding.remediation_report.export',report_id);disp='attachment' if download else 'inline';return StreamingResponse(BytesIO(data),media_type='application/pdf',headers={'Content-Disposition':f'{disp}; filename="HiveMind-Remediation-{r["finding_id"]}.pdf"'})

@app.get('/api/frameworks')
def frameworks():
 with conn() as c: rows=[dict(x) for x in c.execute('select * from framework_checks').fetchall()]
 saved={(r['framework'],r['control']):r for r in rows}
 out={}
 for name,meta in FRAMEWORKS.items():
  controls=[]
  for control in meta['controls']:
   r=saved.get((name,control),{})
   controls.append({'control':control,'status':r.get('status','not_started'),'owner':r.get('owner',''),'evidence':r.get('evidence','')})
  out[name]={**meta,'controls':controls}
 return out
@app.post('/api/framework-check')
def framework_check(x:FrameworkCheck):
 if x.framework not in FRAMEWORKS or x.control not in FRAMEWORKS[x.framework]['controls']:raise HTTPException(400,'Unknown framework/control')
 with conn() as c:c.execute('insert into framework_checks(framework,control,status,owner,evidence,updated_at) values(?,?,?,?,?,CURRENT_TIMESTAMP) on conflict(framework,control) do update set status=excluded.status,owner=excluded.owner,evidence=excluded.evidence,updated_at=CURRENT_TIMESTAMP',(x.framework,x.control,x.status,x.owner,x.evidence))
 audit('framework.update',f'{x.framework}:{x.control}:{x.status}');return {'ok':True}

@app.get('/api/playbooks')
def playbooks(team:str=''):
 return [x for x in PLAYBOOKS if not team or x['team']==team]
@app.get('/api/playbook-runs')
def playbook_runs():
 with conn() as c:return [dict(x) for x in c.execute('select * from playbook_runs order by id desc limit 100').fetchall()]
@app.post('/api/playbook-runs')
def add_playbook_run(x:PlaybookRun):
 pb=next((p for p in PLAYBOOKS if p['id']==x.playbook_id),None)
 if not pb:raise HTTPException(404,'Unknown playbook')
 with conn() as c:c.execute('insert into playbook_runs(playbook_id,title,team,status,owner,notes) values(?,?,?,?,?,?)',(x.playbook_id,x.title or pb['title'],x.team or pb['team'],x.status,x.owner,x.notes))
 audit('playbook.start',x.playbook_id);return {'ok':True}



# STIG Compliance -------------------------------------------------------------
def _stig_cat_from_severity(v:str)->str:
 v=(v or '').strip().lower()
 if v in ('high','cat i','category i','1'): return 'CAT I'
 if v in ('low','cat iii','category iii','3'): return 'CAT III'
 return 'CAT II'

def _stig_norm_status(v:str)->str:
 t=(v or '').strip().lower().replace('_',' ').replace('-',' ')
 if t in ('not a finding','notafinding','pass','passed','fixed','compliant'): return 'Not a Finding'
 if t in ('not applicable','notapplicable','na','n/a'): return 'Not Applicable'
 if t in ('not reviewed','notreviewed','not checked','unknown','informational'): return 'Not Reviewed'
 return 'Open'

def _save_stig_scan(asset:str, profile:str, source:str, findings:list[dict]):
 scan_id=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+hashlib.sha1(f'{asset}|{profile}|{time.time_ns()}'.encode()).hexdigest()[:8]
 counts={'CAT I':0,'CAT II':0,'CAT III':0,'Open':0,'Not a Finding':0,'Not Applicable':0,'Not Reviewed':0}
 with conn() as c:
  for f in findings:
   cat=f.get('category') or _stig_cat_from_severity(f.get('severity',''))
   st=_stig_norm_status(f.get('status',''))
   counts[cat]=counts.get(cat,0)+(1 if st=='Open' else 0); counts[st]=counts.get(st,0)+1
   c.execute('insert into stig_findings(scan_id,benchmark,rule_id,vuln_id,title,category,severity,status,asset,source,finding_details,comments) values(?,?,?,?,?,?,?,?,?,?,?,?)',(
    scan_id,f.get('benchmark',''),f.get('rule_id',''),f.get('vuln_id',''),f.get('title') or f.get('rule_id') or 'STIG finding',cat,f.get('severity',''),st,asset,source,f.get('finding_details',''),f.get('comments','')))
  c.execute('insert into stig_scans(scan_id,asset,profile,source,summary) values(?,?,?,?,?)',(scan_id,asset,profile,source,json.dumps(counts)))
 audit('stig.scan',f'{source}:{asset}:{profile}:{scan_id}')
 return {'scan_id':scan_id,'asset':asset,'profile':profile,'source':source,'counts':counts,'findings':findings}

def _ps(command:str)->tuple[int,str]:
 if os.name!='nt': return (127,'Native Windows STIG quick scan is available only on Windows.')
 try:
  r=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-Command',command],capture_output=True,text=True,timeout=20)
  return r.returncode,(r.stdout or r.stderr or '').strip()
 except Exception as e:return (1,str(e))

def _native_windows_stig_quick_scan()->list[dict]:
 # Local defensive checks only. They are intentionally labeled baseline checks because a complete
 # official STIG assessment requires the applicable DISA benchmark plus manual checks/SCC results.
 checks=[
  ('HMS-WIN-001','Guest account must be disabled','CAT I','high',"(Get-LocalUser -Name 'Guest' -ErrorAction SilentlyContinue).Enabled",lambda x:x.strip().lower()=='false','Guest account should be disabled.'),
  ('HMS-WIN-002','Windows Firewall Domain profile must be enabled','CAT I','high',"(Get-NetFirewallProfile -Profile Domain).Enabled",lambda x:x.strip().lower()=='true','Domain firewall profile should be enabled.'),
  ('HMS-WIN-003','Windows Firewall Private profile must be enabled','CAT II','medium',"(Get-NetFirewallProfile -Profile Private).Enabled",lambda x:x.strip().lower()=='true','Private firewall profile should be enabled.'),
  ('HMS-WIN-004','Windows Firewall Public profile must be enabled','CAT II','medium',"(Get-NetFirewallProfile -Profile Public).Enabled",lambda x:x.strip().lower()=='true','Public firewall profile should be enabled.'),
  ('HMS-WIN-005','SMBv1 server protocol must be disabled','CAT I','high',"(Get-SmbServerConfiguration).EnableSMB1Protocol",lambda x:x.strip().lower()=='false','SMBv1 should be disabled.'),
  ('HMS-WIN-006','PowerShell Script Block Logging should be enabled','CAT II','medium',"(Get-ItemProperty -Path 'HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\PowerShell\\ScriptBlockLogging' -Name EnableScriptBlockLogging -ErrorAction SilentlyContinue).EnableScriptBlockLogging",lambda x:x.strip()=='1','Enable Script Block Logging where required by policy.'),
  ('HMS-WIN-007','Remote Desktop NLA should be required','CAT II','medium',"(Get-ItemProperty 'HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Terminal Server\\WinStations\\RDP-Tcp' -Name UserAuthentication -ErrorAction SilentlyContinue).UserAuthentication",lambda x:x.strip()=='1','Require Network Level Authentication for RDP.'),
  ('HMS-WIN-008','LM hash storage should be disabled','CAT I','high',"(Get-ItemProperty 'HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Lsa' -Name NoLMHash -ErrorAction SilentlyContinue).NoLMHash",lambda x:x.strip()=='1','Do not store LAN Manager hash values.'),
  ('HMS-WIN-009','Anonymous SAM enumeration should be restricted','CAT II','medium',"(Get-ItemProperty 'HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Lsa' -Name RestrictAnonymousSAM -ErrorAction SilentlyContinue).RestrictAnonymousSAM",lambda x:x.strip()=='1','Restrict anonymous enumeration of SAM accounts.'),
  ('HMS-WIN-010','AutoRun should be disabled by policy','CAT II','medium',"(Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer' -Name NoDriveTypeAutoRun -ErrorAction SilentlyContinue).NoDriveTypeAutoRun",lambda x:x.strip() in ('255','0xFF'),'Disable AutoRun through policy.'),
  ('HMS-WIN-011','Windows Defender real-time protection should be enabled','CAT I','high',"(Get-MpComputerStatus -ErrorAction SilentlyContinue).RealTimeProtectionEnabled",lambda x:x.strip().lower()=='true','Real-time antimalware protection should be enabled.'),
  ('HMS-WIN-012','Secure Boot should be enabled where supported','CAT III','low',"try { Confirm-SecureBootUEFI } catch { 'UNKNOWN' }",lambda x:x.strip().lower()=='true','Verify Secure Boot where applicable to the platform and benchmark.')
 ]
 out=[]
 for rid,title,cat,sev,cmd,ok,note in checks:
  rc,val=_ps(cmd); passed=(rc==0 and ok(val)); status='Not a Finding' if passed else ('Not Reviewed' if val in ('','UNKNOWN') or rc!=0 else 'Open')
  out.append({'benchmark':'Hive Mind Windows STIG Baseline Helper','rule_id':rid,'vuln_id':'','title':title,'category':cat,'severity':sev,'status':status,'finding_details':f'Observed: {val or "no value returned"}. {note}','comments':'This native helper is not a substitute for an official DISA STIG/SCC assessment.'})
 return out

def _parse_stig_upload(name:str,data:bytes)->tuple[str,list[dict]]:
 lower=name.lower(); findings=[]; benchmark='Imported STIG Results'
 if lower.endswith('.cklb') or lower.endswith('.json'):
  obj=json.loads(data.decode('utf-8-sig',errors='replace')); benchmark=obj.get('title') or obj.get('stigs',[{}])[0].get('display_name','Imported CKLB') if isinstance(obj,dict) else 'Imported CKLB'
  stigs=obj.get('stigs',[]) if isinstance(obj,dict) else []
  for st in stigs:
   benchmark=st.get('display_name') or st.get('title') or benchmark
   for r in st.get('rules',[]) or []:
    findings.append({'benchmark':benchmark,'rule_id':r.get('rule_id',''),'vuln_id':r.get('group_id') or r.get('vuln_id',''),'title':r.get('rule_title') or r.get('title') or r.get('rule_id',''),'severity':r.get('severity',''),'category':_stig_cat_from_severity(r.get('severity','')),'status':r.get('status','Not Reviewed'),'finding_details':r.get('finding_details',''),'comments':r.get('comments','')})
 elif lower.endswith('.ckl') or lower.endswith('.xml'):
  root=ET.fromstring(data)
  # Supports classic CKL and common XCCDF result shapes.
  benchmark=root.findtext('.//STIG_INFO/SI_DATA[SID_NAME="title"]/SID_DATA') or root.attrib.get('id') or 'Imported CKL/XCCDF'
  vulns=root.findall('.//VULN')
  if vulns:
   for v in vulns:
    attrs={}
    for sd in v.findall('.//STIG_DATA'):
     k=sd.findtext('VULN_ATTRIBUTE') or ''; attrs[k]=sd.findtext('ATTRIBUTE_DATA') or ''
    sev=attrs.get('Severity','')
    findings.append({'benchmark':benchmark,'rule_id':attrs.get('Rule_ID',''),'vuln_id':attrs.get('Vuln_Num',''),'title':attrs.get('Rule_Title') or attrs.get('Vuln_Num',''),'severity':sev,'category':_stig_cat_from_severity(sev),'status':v.findtext('STATUS') or 'Not Reviewed','finding_details':v.findtext('FINDING_DETAILS') or '','comments':v.findtext('COMMENTS') or ''})
  else:
   ns={'x':'http://checklists.nist.gov/xccdf/1.2'}
   for rr in root.findall('.//x:rule-result',ns)+root.findall('.//rule-result'):
    sev=rr.attrib.get('severity',''); result=(rr.findtext('x:result',namespaces=ns) or rr.findtext('result') or '')
    status='Not a Finding' if result.lower() in ('pass','fixed') else ('Not Applicable' if result.lower() in ('notapplicable','notselected') else ('Not Reviewed' if result.lower() in ('unknown','notchecked','informational') else 'Open'))
    findings.append({'benchmark':benchmark,'rule_id':rr.attrib.get('idref',''),'vuln_id':'','title':rr.attrib.get('idref',''),'severity':sev,'category':_stig_cat_from_severity(sev),'status':status,'finding_details':f'XCCDF result: {result}','comments':''})
 else: raise ValueError('Supported result files: .ckl, .cklb, .xml or .json')
 return benchmark,findings

@app.get('/api/stig/summary')
def stig_summary():
 with conn() as c:
  rows=[dict(x) for x in c.execute('select * from stig_findings order by id desc').fetchall()]
  scans=[dict(x) for x in c.execute('select * from stig_scans order by id desc limit 25').fetchall()]
 open_rows=[r for r in rows if r['status']=='Open']
 return {'open':len(open_rows),'cat1':sum(r['category']=='CAT I' for r in open_rows),'cat2':sum(r['category']=='CAT II' for r in open_rows),'cat3':sum(r['category']=='CAT III' for r in open_rows),'not_a_finding':sum(r['status']=='Not a Finding' for r in rows),'not_reviewed':sum(r['status']=='Not Reviewed' for r in rows),'not_applicable':sum(r['status']=='Not Applicable' for r in rows),'findings':rows[:500],'scans':scans}


@app.get('/api/stig/scans/{scan_id}')
def stig_scan_detail(scan_id:str):
 with conn() as c:
  scan=c.execute('select * from stig_scans where scan_id=?',(scan_id,)).fetchone()
  if not scan: raise HTTPException(404,'STIG scan not found')
  findings=[dict(x) for x in c.execute('select * from stig_findings where scan_id=? order by category,id',(scan_id,)).fetchall()]
 sr=dict(scan)
 try: sr['counts']=json.loads(sr.get('summary') or '{}')
 except Exception: sr['counts']={}
 return {'scan':sr,'findings':findings}

@app.delete('/api/stig/scans/{scan_id}')
def stig_delete_scan(scan_id:str):
 with conn() as c:
  scan=c.execute('select * from stig_scans where scan_id=?',(scan_id,)).fetchone()
  if not scan: raise HTTPException(404,'STIG scan not found')
  count=c.execute('select count(*) from stig_findings where scan_id=?',(scan_id,)).fetchone()[0]
  c.execute('delete from stig_findings where scan_id=?',(scan_id,))
  c.execute('delete from stig_scans where scan_id=?',(scan_id,))
 audit('stig.scan.delete',f'{scan_id}:{count} findings')
 return {'ok':True,'deleted_scan':scan_id,'deleted_findings':count}

@app.delete('/api/stig/scans')
def stig_clear_history():
 with conn() as c:
  scans=c.execute('select count(*) from stig_scans').fetchone()[0]
  findings=c.execute('select count(*) from stig_findings').fetchone()[0]
  c.execute('delete from stig_findings')
  c.execute('delete from stig_scans')
 audit('stig.history.clear',f'{scans} scans:{findings} findings')
 return {'ok':True,'deleted_scans':scans,'deleted_findings':findings}

@app.post('/api/stig/scan-local')
def stig_scan_local():
 if os.name!='nt': raise HTTPException(400,'Native STIG quick scan currently supports the local Windows host only.')
 asset=os.environ.get('COMPUTERNAME',socket.gethostname()); findings=_native_windows_stig_quick_scan()
 return _save_stig_scan(asset,'Windows Local Baseline Helper','native',findings)

@app.post('/api/stig/import')
async def stig_import(file:UploadFile=File(...), asset:str=''):
 data=await file.read()
 if len(data)>25*1024*1024: raise HTTPException(413,'STIG result file exceeds 25 MB import limit.')
 try: benchmark,findings=_parse_stig_upload(file.filename or 'stig-results',data)
 except Exception as e: raise HTTPException(400,f'Could not parse STIG result file: {e}')
 if not findings: raise HTTPException(400,'No STIG rule results were found in the uploaded file.')
 return _save_stig_scan(asset or socket.gethostname(),benchmark,'import',findings)

@app.post('/api/stig/{finding_id}/status')
def stig_update_status(finding_id:int,x:ToolboxInput):
 status=_stig_norm_status(x.value)
 with conn() as c:
  if not c.execute('select 1 from stig_findings where id=?',(finding_id,)).fetchone(): raise HTTPException(404,'Finding not found')
  c.execute('update stig_findings set status=?,comments=?,updated_at=CURRENT_TIMESTAMP where id=?',(status,x.extra or '',finding_id))
 audit('stig.finding.update',f'{finding_id}:{status}'); return {'ok':True,'status':status}

@app.get('/api/certs')
def certs():return CERTS
@app.get('/api/study-aids/{cert}')
def study_aids(cert:str):
 if cert not in STUDY_AIDS:raise HTTPException(404,'Unknown certification')
 return {'cert':CERTS[cert],**STUDY_AIDS[cert],'lessons':STUDY_LESSONS.get(cert,[]),'videos':CERT_VIDEOS.get(cert,[]),'question_count':len(BANKS.get(cert,[]))}
@app.get('/api/study-aids/{cert}/resource-health')
async def study_resource_health(cert:str):
 if cert not in CERT_VIDEOS: raise HTTPException(404,'Unknown certification')
 out=[]
 async with httpx.AsyncClient(follow_redirects=True,timeout=httpx.Timeout(7.0),headers={'User-Agent':'Hive-Mind-Security/0.5.5'}) as client:
  for r in CERT_VIDEOS.get(cert,[]):
   url=r.get('url','')
   try:
    parsed=urllib.parse.urlparse(url)
    if parsed.scheme!='https' or (parsed.hostname or '').lower() not in RESOURCE_HEALTH_ALLOWED_HOSTS:
     out.append({'title':r.get('title','Resource'),'url':url,'ok':False,'status':'blocked','detail':'Resource host is not on the approved study-resource allowlist.'}); continue
    resp=await client.get(url)
    ok=200 <= resp.status_code < 400
    out.append({'title':r.get('title','Resource'),'url':url,'ok':ok,'status':resp.status_code,'final_url':str(resp.url)})
   except Exception as e:
    out.append({'title':r.get('title','Resource'),'url':url,'ok':False,'status':'unreachable','detail':str(e)[:180]})
 return {'cert':cert,'checked_at':datetime.now(timezone.utc).isoformat(),'resources':out}

@app.get('/api/quiz/{cert}')
def quiz(cert:str,length:int=10,domain:str=''):
 if cert not in BANKS:raise HTTPException(404,'Unknown certification')
 bank=BANKS[cert];
 if domain: bank=[q for q in bank if q.get('domain')==domain]
 import random; bank=bank.copy(); random.shuffle(bank); chosen=bank[:max(1,min(length,len(bank)))]
 return [{k:v for k,v in q.items() if k not in ('correct','explanation')} for q in chosen]
@app.post('/api/quiz/{cert}/check')
def check_quiz_answer(cert:str,x:CheckAnswer):
 if cert not in BANKS: raise HTTPException(404,'Unknown certification')
 q=next((q for q in BANKS[cert] if str(q.get('id'))==str(x.question_id)),None)
 if not q: raise HTTPException(404,'Question not found')
 answer=str(q.get('correct','')).upper(); chosen=str(x.answer or '').upper(); ok=chosen==answer
 return {'id':q['id'],'correct':ok,'answer':answer,'answer_text':q.get(answer,''),'explanation':q.get('explanation',''),'domain':q.get('domain','Other')}

@app.post('/api/quiz/{cert}/grade')
def grade(cert:str,x:Grade):
 if cert not in BANKS:raise HTTPException(404,'Unknown certification')
 bank={str(q['id']):q for q in BANKS[cert]}; score=0; results=[]; domains={}
 for token in x.answers:
  try:qid,ans=token.split(':',1)
  except ValueError:continue
  q=bank.get(qid)
  if not q:continue
  ok=ans.upper()==str(q['correct']).upper();score+=int(ok); d=q.get('domain','Other');domains.setdefault(d,[0,0]);domains[d][1]+=1;domains[d][0]+=int(ok)
  results.append({'id':q['id'],'correct':ok,'answer':q['correct'],'explanation':q['explanation'],'domain':d})
 total=len(results); dstat={k:{'correct':v[0],'total':v[1],'percent':round(100*v[0]/v[1]) if v[1] else 0} for k,v in domains.items()}
 with conn() as c:c.execute('insert into study(cert,score,total,domain_json,mode) values(?,?,?,?,?)',(cert,score,total,json.dumps(dstat),x.mode))
 percent=round(score*100/total) if total else 0
 req=EXAM_REQUIREMENTS.get(cert,{}); threshold=int(req.get('practice_pass_percent',70)); passed=percent>=threshold
 return {'score':score,'total':total,'percent':percent,'domains':dstat,'results':results,'passed':passed,'practice_pass_percent':threshold,'official_pass':req.get('official_pass',''),'official_format':req.get('official_format',''),'practice_note':req.get('practice_note','')}
@app.get('/api/study-history')
def study_history(cert:str=''):
 with conn() as c:
  rows=c.execute('select * from study where cert=? order by id desc limit 30',(cert,)).fetchall() if cert else c.execute('select * from study order by id desc limit 50').fetchall()
 return [dict(x) for x in rows]

@app.get('/api/integrations/catalog')
def integration_catalog():return INTEGRATION_CATALOG
@app.get('/api/integrations')
def integrations():
 with conn() as c:rows={r['id']:dict(r) for r in c.execute('select * from integrations').fetchall()}
 out=[]
 for iid,meta in INTEGRATION_CATALOG.items():
  if iid in NO_KEY:
   out.append({'id':iid,**meta,'enabled':True,'status':'built_in','last_test':'','last_error':'','config':{}});continue
  r=rows.get(iid,{});cfg=json.loads(r.get('config_json') or '{}');safe={k:('••••••••' if k in meta.get('secret',[]) and cfg.get(k) else cfg.get(k,'')) for k in meta['fields']}
  out.append({'id':iid,**meta,'enabled':bool(r.get('enabled',0)),'status':r.get('status','not_configured'),'last_test':r.get('last_test',''),'last_error':r.get('last_error',''),'config':safe})
 return out
@app.put('/api/integrations/{iid}')
def save_integration(iid:str,x:IntegrationConfig):
 if iid not in INTEGRATION_CATALOG:raise HTTPException(404,'Unknown integration')
 if iid in NO_KEY:return {'ok':True,'built_in':True}
 meta=INTEGRATION_CATALOG[iid]
 with conn() as c:
  old=c.execute('select config_json from integrations where id=?',(iid,)).fetchone();oldcfg=json.loads(old[0]) if old else {};cfg={}
  for f in meta['fields']:
   v=str(x.config.get(f,'')).strip()
   if f in meta.get('secret',[]):
    if v in ('','••••••••') and oldcfg.get(f):cfg[f]=oldcfg[f]
    elif v:cfg[f]=enc(v)
   else:cfg[f]=v
  c.execute('insert into integrations(id,enabled,config_json,status,updated_at) values(?,?,?,?,CURRENT_TIMESTAMP) on conflict(id) do update set enabled=excluded.enabled,config_json=excluded.config_json,status=excluded.status,updated_at=CURRENT_TIMESTAMP',(iid,int(x.enabled),json.dumps(cfg),'configured'))
 audit('integration.save',iid);return {'ok':True}
def get_cfg(iid):
 with conn() as c:r=c.execute('select config_json from integrations where id=?',(iid,)).fetchone()
 if not r:return {}
 cfg=json.loads(r[0]);meta=INTEGRATION_CATALOG[iid]
 for s in meta.get('secret',[]):
  if cfg.get(s):cfg[s]=dec(cfg[s])
 return cfg
@app.post('/api/integrations/{iid}/test')
async def test_integration(iid:str):
 if iid not in INTEGRATION_CATALOG:raise HTTPException(404,'Unknown integration')
 if iid in NO_KEY:
  if iid=='cisa':d=await kev(1);ok=not isinstance(d,dict)
  elif iid in ('feodo','dshield'):d=await threat_map(True);ok=bool(d.get('events'))
  elif iid=='spamhaus':
   try:
    async with httpx.AsyncClient(timeout=12) as c:r=await c.get('https://www.spamhaus.org/drop/drop_v4.json');r.raise_for_status();ok=True
   except Exception:ok=False
  else:
   try:
    async with httpx.AsyncClient(timeout=12) as c:r=await c.get('https://services.nvd.nist.gov/rest/json/cves/2.0',params={'resultsPerPage':1});r.raise_for_status();ok=True
   except Exception:ok=False
  return {'ok':ok,'status':'healthy' if ok else 'error','detail':'Built-in public feed query '+('succeeded' if ok else 'failed')}
 cfg=get_cfg(iid);ok,detail=await test_provider(iid,cfg);status='healthy' if ok else 'error';now=datetime.now(timezone.utc).isoformat()
 with conn() as c:c.execute('update integrations set status=?,last_test=?,last_error=? where id=?',(status,now,'' if ok else detail,iid))
 audit('integration.test',f'{iid}:{status}');return {'ok':ok,'status':status,'detail':detail,'tested_at':now}
@app.get('/api/integrations/{iid}/data')
async def integration_data(iid:str,limit:int=50):
 if iid=='cisa':return {'kind':'kev','items':await kev(limit)}
 if iid in ('feodo','dshield'):return await threat_map()
 if iid=='spamhaus':
  async with httpx.AsyncClient(timeout=15) as c:r=await c.get('https://www.spamhaus.org/drop/drop_v4.json');r.raise_for_status();return {'kind':'netblocks','items':r.json()[:limit] if isinstance(r.json(),list) else r.json()}
 if iid=='nvd':
  cfg=get_cfg('nvd') if 'nvd' in INTEGRATION_CATALOG else {};headers={'apiKey':cfg.get('api_key')} if cfg.get('api_key') else {}
  async with httpx.AsyncClient(timeout=15) as c:r=await c.get('https://services.nvd.nist.gov/rest/json/cves/2.0',params={'resultsPerPage':min(limit,100)},headers=headers);r.raise_for_status();return {'kind':'cves','items':r.json().get('vulnerabilities',[])}
 if iid not in INTEGRATION_CATALOG:raise HTTPException(404,'Unknown integration')
 cfg=get_cfg(iid)
 if not cfg:raise HTTPException(400,'Integration is not configured')
 try:return await fetch_provider(iid,cfg,limit)
 except Exception as e:raise HTTPException(502,str(e)[:800])
@app.post('/api/integrations/{iid}/send-test')
async def send_notification_test(iid:str,x:NotificationTest):
 cfg=get_cfg(iid)
 try:detail=await send_test(iid,cfg,x.message);audit('integration.send_test',iid);return {'ok':True,'detail':detail}
 except Exception as e:raise HTTPException(502,str(e)[:800])


# Built-in authorized pentest scanner ----------------------------------------
SCAN_PORTS={20:'ftp-data',21:'ftp',22:'ssh',23:'telnet',25:'smtp',53:'dns',80:'http',110:'pop3',111:'rpcbind',135:'msrpc',139:'netbios',143:'imap',389:'ldap',443:'https',445:'smb',465:'smtps',587:'submission',636:'ldaps',993:'imaps',995:'pop3s',1433:'mssql',1521:'oracle',2049:'nfs',3306:'mysql',3389:'rdp',5432:'postgres',5900:'vnc',6379:'redis',8080:'http-alt',8443:'https-alt',9200:'elasticsearch',27017:'mongodb'}
QUICK_PORTS=[22,23,25,53,80,110,135,139,143,389,443,445,465,587,636,993,995,1433,1521,2049,3306,3389,5432,5900,6379,8080,8443,9200,27017]
STANDARD_PORTS=sorted(set(list(range(1,1025))+[1433,1521,2049,3306,3389,5432,5900,6379,8080,8443,9200,27017]))

def _scan_targets(raw:str,profile:str='standard',credentialed:bool=False)->list[str]:
 raw=raw.strip()
 try:
  if '/' in raw:
   net=ipaddress.ip_network(raw,strict=False)
   max_hosts=256 if (profile=='standard' or credentialed) else 1024
   hosts=[str(x) for x in net.hosts()]
   if len(hosts)>max_hosts:raise ValueError(f'{profile.title()} scans are limited to {max_hosts} usable hosts. Quick supports up to /22; Standard and credentialed scans support up to /24.')
   return hosts
  try:ipaddress.ip_address(raw);return [raw]
  except ValueError:
   infos=socket.getaddrinfo(raw,None,type=socket.SOCK_STREAM);ips=[]
   for i in infos:
    ip=i[4][0]
    if ip not in ips:ips.append(ip)
   return ips[:8] or [raw]
 except Exception as e:raise HTTPException(400,str(e))

def _tcp_probe(host:str,port:int,timeout=.35)->dict|None:
 try:
  with socket.create_connection((host,port),timeout=timeout) as sock:
   sock.settimeout(.5);banner=''
   if port in (80,8080,8443,443):
    try:
     if port in (443,8443):
      ctx=ssl.create_default_context();ctx.check_hostname=False;ctx.verify_mode=ssl.CERT_NONE
      with ctx.wrap_socket(sock,server_hostname=host) as ss:
       ss.sendall(b'HEAD / HTTP/1.0\r\nHost: '+host.encode(errors='ignore')+b'\r\nUser-Agent: HiveMindSecurity/0.6.1\r\n\r\n');banner=ss.recv(2048).decode(errors='replace')
       return {'port':port,'service':SCAN_PORTS.get(port,'tcp'),'banner':banner[:800]}
     sock.sendall(b'HEAD / HTTP/1.0\r\nHost: '+host.encode(errors='ignore')+b'\r\nUser-Agent: HiveMindSecurity/0.6.1\r\n\r\n');banner=sock.recv(2048).decode(errors='replace')
    except Exception:pass
   else:
    try:banner=sock.recv(512).decode(errors='replace')
    except Exception:pass
   return {'port':port,'service':SCAN_PORTS.get(port,'tcp'),'banner':banner[:800]}
 except Exception:return None

def _tls_info(host:str,port:int)->dict:
 try:
  ctx=ssl.create_default_context();ctx.check_hostname=False;ctx.verify_mode=ssl.CERT_NONE
  with socket.create_connection((host,port),timeout=2) as raw:
   with ctx.wrap_socket(raw,server_hostname=host) as s:
    cert=s.getpeercert();return {'protocol':s.version(),'cipher':s.cipher()[0] if s.cipher() else '', 'subject':str(cert.get('subject',''))[:500],'notAfter':cert.get('notAfter','')}
 except Exception as e:return {'error':str(e)[:300]}

def _http_assess(host:str,port:int,tls:bool)->tuple[dict,list[dict]]:
 url=f"{'https' if tls else 'http'}://{host}:{port}/";out={'url':url};find=[]
 try:
  r=httpx.get(url,timeout=3,follow_redirects=True,verify=False,headers={'User-Agent':f'HiveMindSecurity/{VERSION}'})
  out.update({'status':r.status_code,'server':r.headers.get('server',''),'headers':dict(r.headers)})
  h={k.lower():v for k,v in r.headers.items()}
  missing=[]
  for key,label in [('content-security-policy','Content-Security-Policy'),('x-content-type-options','X-Content-Type-Options'),('x-frame-options','X-Frame-Options')]:
   if key not in h:missing.append(label)
  if tls and 'strict-transport-security' not in h:missing.append('Strict-Transport-Security')
  if missing:find.append({'title':'HTTP security headers missing','severity':'low','asset':host,'category':'Web Configuration','description':'The service did not return these recommended browser security headers: '+', '.join(missing)+'.','evidence':url+' returned HTTP '+str(r.status_code),'remediation':'Configure appropriate HTTP security headers after compatibility testing.'})
  if not tls:find.append({'title':'Unencrypted HTTP service exposed','severity':'medium','asset':host,'category':'Transport Security','description':'An HTTP service is reachable without TLS.','evidence':url,'remediation':'Use HTTPS/TLS for authenticated or sensitive web services and redirect cleartext HTTP where appropriate.'})
 except Exception as e:out['error']=str(e)[:300]
 return out,find

def _service_findings(host:str,opens:list[dict])->list[dict]:
 f=[];ports={x['port'] for x in opens}
 risky={23:('Telnet service exposed','high','Replace Telnet with SSH and restrict management access.'),21:('FTP service exposed','medium','Prefer SFTP/FTPS and disable plaintext authentication.'),445:('SMB service reachable','medium','Restrict SMB to trusted networks, require signing where appropriate, and disable SMBv1.'),3389:('RDP service reachable','medium','Restrict RDP exposure, require NLA/MFA through a secured access path, and monitor logons.'),5900:('VNC service reachable','medium','Restrict VNC to trusted management networks and use authenticated encrypted access.'),6379:('Redis service reachable','high','Bind Redis to trusted interfaces only and require authentication/TLS where supported.'),9200:('Elasticsearch service reachable','high','Restrict Elasticsearch to trusted networks and require authentication/TLS.'),27017:('MongoDB service reachable','high','Restrict MongoDB exposure and require authentication/TLS.')}
 for port,(title,sev,rem) in risky.items():
  if port in ports:f.append({'title':title,'severity':sev,'asset':host,'category':'Exposed Service','description':f'TCP/{port} is reachable from the scanner host. Reachability alone does not prove compromise.','evidence':f'{host}:{port} accepted a TCP connection.','remediation':rem})
 for x in opens:
  b=(x.get('banner') or '').lower()
  if 'server: apache/2.2' in b:f.append({'title':'Legacy Apache 2.2 banner detected','severity':'high','asset':host,'category':'Software Lifecycle','description':'The web server banner identifies Apache 2.2, an end-of-life branch.','evidence':x.get('banner','')[:500],'remediation':'Upgrade to a vendor-supported web server release and verify application compatibility.'})
  if 'openssh_5.' in b or 'openssh_6.' in b:f.append({'title':'Legacy OpenSSH banner detected','severity':'medium','asset':host,'category':'Software Lifecycle','description':'The SSH banner indicates an old OpenSSH major release.','evidence':x.get('banner','')[:500],'remediation':'Upgrade using the operating-system vendor supported packages and review SSH hardening.'})
 return f

def _credentialed_scan(host:str,cred:dict)->tuple[dict,list[dict]]:
 if not cred:return ({'status':'not_configured'},[])
 ctype=cred.get('cred_type','');user=cred.get('target_username','');secret=cred.get('secret','');key=cred.get('private_key','');find=[]
 if ctype=='ssh':
  try:
   import paramiko, io
   cli=paramiko.SSHClient();cli.set_missing_host_key_policy(paramiko.AutoAddPolicy())
   kw={'hostname':host,'username':user,'timeout':5,'banner_timeout':5,'auth_timeout':5,'look_for_keys':False,'allow_agent':False}
   if key:kw['pkey']=paramiko.RSAKey.from_private_key(io.StringIO(key),password=secret or None)
   else:kw['password']=secret
   cli.connect(**kw)
   cmds=['uname -a','cat /etc/os-release 2>/dev/null | head -20','id','uptime','ss -lnt 2>/dev/null | head -80']
   data={}
   for cmd in cmds:
    _i,o,e=cli.exec_command(cmd,timeout=7);data[cmd]=(o.read().decode(errors='replace')+e.read().decode(errors='replace'))[:8000]
   cli.close()
   osrel=data.get(cmds[1],'')
   if re.search(r'(?im)^ID=(ubuntu|debian)',osrel):
    # no sudo, no package changes: read-only package status
    pass
   return ({'status':'ok','type':'ssh','username':user,'inventory':data},find)
  except Exception as e:return ({'status':'failed','type':'ssh','error':str(e)[:500]},[])
 if ctype=='winrm':
  try:
   import winrm
   endpoint=f'http://{host}:5985/wsman';uname=(cred.get('domain','')+'\\' if cred.get('domain') else '')+user
   ses=winrm.Session(endpoint,auth=(uname,secret),transport='ntlm',server_cert_validation='ignore')
   ps="$ErrorActionPreference='SilentlyContinue'; Get-CimInstance Win32_OperatingSystem | Select Caption,Version,BuildNumber,LastBootUpTime | ConvertTo-Json; Get-HotFix | Sort InstalledOn -Descending | Select -First 20 HotFixID,InstalledOn | ConvertTo-Json; Get-NetFirewallProfile | Select Name,Enabled | ConvertTo-Json; Get-SmbServerConfiguration | Select EnableSMB1Protocol,RequireSecuritySignature | ConvertTo-Json"
   r=ses.run_ps(ps);text=(r.std_out+r.std_err).decode(errors='replace')[:20000]
   if '"EnableSMB1Protocol":  true' in text.lower().replace('true','true'):pass
   return ({'status':'ok' if r.status_code==0 else 'partial','type':'winrm','username':uname,'inventory':text},find)
  except Exception as e:return ({'status':'failed','type':'winrm','error':str(e)[:500]},[])
 return ({'status':'unsupported'},[])

def _scan_report_pdf(scan:dict,result:dict)->bytes:
 buf=BytesIO();styles=getSampleStyleSheet();styles.add(ParagraphStyle(name='Tiny',parent=styles['BodyText'],fontSize=7,leading=9,textColor=colors.grey));doc=SimpleDocTemplate(buf,pagesize=letter,rightMargin=.55*inch,leftMargin=.55*inch,topMargin=.55*inch,bottomMargin=.55*inch,title='Hive Mind Security Pentest Scan Report');story=[]
 story += [Paragraph('HIVE MIND SECURITY - AUTHORIZED PENTEST SCAN REPORT',styles['Title']),Paragraph(scan.get('name') or scan.get('target','Assessment'),styles['Heading2']),Spacer(1,6)]
 meta=[['Scan ID',scan.get('id','')],['Target',scan.get('target','')],['Profile',scan.get('profile','')],['Credential Profile',scan.get('credential_user','') or 'None'],['Started By',scan.get('created_by','')],['Created',scan.get('created_at','')],['Status',scan.get('status','')]]
 t=Table(meta,colWidths=[1.35*inch,5.35*inch]);t.setStyle(TableStyle([('GRID',(0,0),(-1,-1),.25,colors.grey),('BACKGROUND',(0,0),(0,-1),colors.HexColor('#e6e6e6')),('VALIGN',(0,0),(-1,-1),'TOP'),('FONTNAME',(0,0),(0,-1),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),8)]));story += [t,Spacer(1,10)]
 summary=result.get('summary',{});story += [Paragraph('Executive Summary',styles['Heading2']),Paragraph(f"Hosts assessed: {summary.get('hosts',0)} &nbsp;&nbsp; Open services: {summary.get('open_ports',0)} &nbsp;&nbsp; Findings: {summary.get('findings',0)}",styles['BodyText']),Paragraph('Hive Mind performs non-exploit validation and configuration review. A clean result does not prove the target is vulnerability-free.',styles['Tiny']),Spacer(1,10)]
 for h in result.get('hosts',[]):
  story += [Paragraph('Host: '+str(h.get('host','')),styles['Heading2']),Paragraph('Open TCP services: '+(', '.join(str(x.get('port'))+'/'+x.get('service','tcp') for x in h.get('open_ports',[])) or 'None observed'),styles['BodyText'])]
  cred=h.get('credentialed',{});story += [Paragraph('Credentialed assessment: '+str(cred.get('status','not used')),styles['BodyText']),Spacer(1,5)]
  hf=h.get('findings',[])
  if not hf:story += [Paragraph('No findings generated by the enabled checks.',styles['BodyText'])]
  for i,f in enumerate(hf,1):
   story += [Paragraph(f"{i}. {f.get('title','Finding')} [{str(f.get('severity','')).upper()}]",styles['Heading3']),Paragraph((f.get('description') or '').replace('&','&amp;').replace('<','&lt;').replace('>','&gt;'),styles['BodyText']),Paragraph('<b>Evidence:</b> '+(f.get('evidence') or 'Not recorded').replace('&','&amp;').replace('<','&lt;').replace('>','&gt;'),styles['BodyText']),Paragraph('<b>Remediation:</b> '+(f.get('remediation') or '').replace('&','&amp;').replace('<','&lt;').replace('>','&gt;'),styles['BodyText']),Spacer(1,7)]
  story += [Spacer(1,10)]
 doc.build(story);return buf.getvalue()

def _run_builtin_scan(scan_id:str,x:PentestScanRequest,actor:str)->dict:
 profile=x.profile if x.profile in ('quick','standard') else 'standard';cred=_get_scan_credential(x.credential_user);targets=_scan_targets(x.target,profile,bool(cred));ports=QUICK_PORTS if profile=='quick' else STANDARD_PORTS;hosts=[];all_find=[];open_count=0
 for host in targets:
  opens=[]
  # bounded concurrency for local workstation safety
  import concurrent.futures
  with concurrent.futures.ThreadPoolExecutor(max_workers=80) as ex:
   futs=[ex.submit(_tcp_probe,host,p,.25 if profile=='standard' else .4) for p in ports]
   for f in concurrent.futures.as_completed(futs):
    r=f.result()
    if r:opens.append(r)
  opens.sort(key=lambda z:z['port']);open_count+=len(opens);find=_service_findings(host,opens);http=[];tls=[]
  for o in opens:
   if o['port'] in (80,8080):
    h,ff=_http_assess(host,o['port'],False);http.append(h);find+=ff
   if o['port'] in (443,8443):
    tls.append({'port':o['port'],**_tls_info(host,o['port'])});h,ff=_http_assess(host,o['port'],True);http.append(h);find+=ff
  cdata,cf=_credentialed_scan(host,cred);find+=cf
  # dedupe by title/evidence
  uniq=[];seen=set()
  for f in find:
   k=(f.get('title'),f.get('evidence'))
   if k not in seen:seen.add(k);uniq.append(f);all_find.append(f)
  hosts.append({'host':host,'open_ports':opens,'http':http,'tls':tls,'credentialed':cdata,'findings':uniq})
 result={'summary':{'hosts':len(hosts),'open_ports':open_count,'findings':len(all_find)},'hosts':hosts}
 with conn() as c:
  if x.import_findings:
   for f in all_find:_insert_tracked_finding(c,f,source='built-in scan')
  row=c.execute('select * from pentest_scans where id=?',(scan_id,)).fetchone();scan=dict(row) if row else {'id':scan_id,'name':x.name,'target':x.target,'profile':profile,'credential_user':x.credential_user,'created_by':actor,'created_at':''}
  scan['status']='complete';pdf=_scan_report_pdf(scan,result);rp=SCAN_REPORT_STORE/f'{scan_id}.pdf.hmsenc';rp.write_bytes(enc_bytes(pdf));_harden_private_file(rp)
  c.execute("update pentest_scans set status='complete',summary_json=?,result_enc=?,finding_count=?,report_path=?,finished_at=CURRENT_TIMESTAMP where id=?",(json.dumps(result['summary']),enc(json.dumps(result)),len(all_find),str(rp),scan_id))
 audit('pentest.scan.complete',f'{scan_id}:{x.target}:hosts={len(hosts)}:findings={len(all_find)}')
 return result

@app.get('/api/pentest-scans/credential-profiles')
def pentest_scan_credential_profiles(request:Request):
 with conn() as c:
  if getattr(request.state,'role','')=='admin':
   rows=c.execute("select u.username,sc.cred_type,sc.target_username,sc.domain from users u join scan_credentials sc on sc.username=u.username where u.enabled=1 order by u.username").fetchall()
  else:
   rows=c.execute("select u.username,sc.cred_type,sc.target_username,sc.domain from users u join scan_credentials sc on sc.username=u.username where u.enabled=1 and u.username=?",(request.state.user,)).fetchall()
 return [dict(r) for r in rows]

@app.get('/api/pentest-scans')
def pentest_scans():
 with conn() as c:return [dict(r) for r in c.execute("select id,name,target,profile,credential_user,status,summary_json,finding_count,created_by,created_at,finished_at from pentest_scans order by created_at desc limit 50").fetchall()]

@app.post('/api/pentest-scans')
def pentest_scan_start(x:PentestScanRequest,request:Request):
 if not x.authorized:raise HTTPException(400,'You must confirm that you are authorized to assess the target.')
 if x.credential_user:
  if getattr(request.state,'role','')!='admin' and x.credential_user!=request.state.user:raise HTTPException(403,'Analysts may use only their own configured scan credential profile.')
  with conn() as c:u=c.execute('select username from users where username=?',(x.credential_user,)).fetchone()
  if not u:raise HTTPException(400,'Selected credential user does not exist.')
  if not _get_scan_credential(x.credential_user):raise HTTPException(400,'Selected user does not have scan credentials configured.')
 # validate and bound scope before writing
 profile=x.profile if x.profile in ('quick','standard') else 'standard';_scan_targets(x.target,profile,bool(x.credential_user));sid=uuid.uuid4().hex[:24];name=(x.name.strip() or f'Assessment {x.target}')[:240]
 with conn() as c:c.execute('insert into pentest_scans(id,name,target,profile,credential_user,status,created_by) values(?,?,?,?,?,?,?)',(sid,name,x.target.strip(),profile,x.credential_user,'running',request.state.user))
 audit('pentest.scan.start',f'{sid}:{x.target}:{profile}:credential={x.credential_user or "none"}')
 try:r=_run_builtin_scan(sid,x,request.state.user)
 except Exception as e:
  with conn() as c:c.execute("update pentest_scans set status='failed',summary_json=?,finished_at=CURRENT_TIMESTAMP where id=?",(json.dumps({'error':str(e)[:1000]}),sid))
  audit('pentest.scan.failed',f'{sid}:{str(e)[:300]}');raise HTTPException(500,'Scan failed: '+str(e)[:500])
 return {'ok':True,'scan_id':sid,'summary':r['summary']}

@app.get('/api/pentest-scans/{scan_id}')
def pentest_scan_detail(scan_id:str):
 with conn() as c:r=c.execute('select * from pentest_scans where id=?',(scan_id,)).fetchone()
 if not r:raise HTTPException(404,'Scan not found.')
 d=dict(r);d['result']=json.loads(dec(d.pop('result_enc','')) or '{}');return d

@app.get('/api/pentest-scans/{scan_id}/report')
def pentest_scan_report(scan_id:str):
 with conn() as c:r=c.execute('select report_path,name from pentest_scans where id=?',(scan_id,)).fetchone()
 if not r or not r['report_path']:raise HTTPException(404,'Scan report not available.')
 path=Path(r['report_path'])
 if not path.exists():raise HTTPException(404,'Encrypted scan report file is missing.')
 raw=dec_bytes(path.read_bytes());fname=re.sub(r'[^A-Za-z0-9_.-]+','_',r['name'])[:80]+'_pentest_report.pdf'
 return StreamingResponse(BytesIO(raw),media_type='application/pdf',headers={'Content-Disposition':f'inline; filename="{fname}"'})

@app.delete('/api/pentest-scans/{scan_id}')
def pentest_scan_delete(scan_id:str):
 with conn() as c:
  r=c.execute('select report_path,target from pentest_scans where id=?',(scan_id,)).fetchone()
  if not r:raise HTTPException(404,'Scan not found.')
  if r['report_path']:
   try:Path(r['report_path']).unlink(missing_ok=True)
   except Exception:pass
  c.execute('delete from pentest_scans where id=?',(scan_id,))
 audit('pentest.scan.delete',f'{scan_id}:{r["target"]}');return {'ok':True}


# ---- Connected Security Operations / Exposure Management 0.7.0 ----
def _rows(sql,args=()):
 with conn() as c:return [dict(r) for r in c.execute(sql,args).fetchall()]
def _one(sql,args=()):
 with conn() as c:
  r=c.execute(sql,args).fetchone();return dict(r) if r else None

def _asset_matches(name:str):
 q=(name or '').strip().lower()
 if not q:return []
 return _rows("select * from assets where lower(name)=? or lower(location)=? order by id desc",(q,q))

@app.get('/api/exposure/summary')
async def exposure_summary():
 assets=_rows('select * from assets order by id desc'); vulns=_rows("select * from vulnerabilities where status not in ('closed','remediated') order by id desc"); tracked=_rows("select id,title,severity,status,asset,cve,owner,due_date,source,created_at from tracked_findings where status not in ('closed','remediated','fixed') order by id desc")
 kev_rows=await kev(250); kev_list=kev_rows if isinstance(kev_rows,list) else kev_rows.get('vulnerabilities',[]); kev_ids={str(x.get('cveID','')).upper():x for x in kev_list}
 exposures=[]
 for v in vulns+tracked:
  cve=str(v.get('cve') or '').upper(); asset=v.get('asset') or ''; sev=(v.get('severity') or 'medium').lower(); k=kev_ids.get(cve)
  score={'critical':4,'high':3,'medium':2,'low':1}.get(sev,1)+(4 if k else 0)
  exposures.append({**v,'cisa_kev':bool(k),'kev':k,'priority_score':score,'asset_records':_asset_matches(asset)})
 exposures.sort(key=lambda x:x['priority_score'],reverse=True)
 return {'assets':len(assets),'open_exposures':len(exposures),'kev_matches':sum(1 for x in exposures if x['cisa_kev']),'critical':sum(1 for x in exposures if str(x.get('severity')).lower()=='critical'),'items':exposures[:250]}

@app.get('/api/assets/{asset_id}/intelligence')
def asset_intelligence(asset_id:int):
 a=_one('select * from assets where id=?',(asset_id,))
 if not a:raise HTTPException(404,'Asset not found')
 names={str(a.get('name','')).lower(),str(a.get('location','')).lower()}; names.discard('')
 scans=[]
 for r in _rows("select id,name,target,profile,status,summary_json,finding_count,created_at,finished_at from pentest_scans order by created_at desc limit 100"):
  if str(r.get('target','')).lower() in names: scans.append(r)
 v=[]
 for r in _rows('select * from vulnerabilities order by id desc'):
  if str(r.get('asset','')).lower() in names:v.append(r)
 f=[]
 for r in _rows("select id,title,severity,status,asset,cve,owner,due_date,source,created_at from tracked_findings order by id desc"):
  if str(r.get('asset','')).lower() in names:f.append(r)
 inv=[]
 for r in _rows('select * from investigations order by id desc'):
  text=' '.join(str(r.get(k,'') or '') for k in ('title','summary','iocs','timeline')).lower()
  if any(n in text for n in names):inv.append(r)
 notes=_rows('select * from asset_notes where asset_id=? order by id desc',(asset_id,))
 return {'asset':a,'scans':scans,'vulnerabilities':v,'findings':f,'investigations':inv,'notes':notes}

@app.post('/api/assets/{asset_id}/notes')
def add_asset_note(asset_id:int,x:AssetNote):
 if not _one('select id from assets where id=?',(asset_id,)):raise HTTPException(404,'Asset not found')
 with conn() as c:c.execute('insert into asset_notes(asset_id,note,created_by) values(?,?,?)',(asset_id,x.note[:8000],CURRENT_USER.get()))
 audit('asset.note.create',f'{asset_id}:{x.note[:120]}');return {'ok':True}
@app.delete('/api/assets/{asset_id}/notes/{note_id}')
def delete_asset_note(asset_id:int,note_id:int):
 with conn() as c:c.execute('delete from asset_notes where id=? and asset_id=?',(note_id,asset_id))
 audit('asset.note.delete',f'{asset_id}:{note_id}');return {'ok':True}

@app.get('/api/watchlists')
def get_watchlists():return _rows('select * from watchlists order by id desc')
@app.post('/api/watchlists')
def add_watchlist(x:WatchItem):
 with conn() as c:c.execute('insert into watchlists(kind,value,label,severity,status,notes) values(?,?,?,?,?,?)',(x.kind,x.value.strip(),x.label,x.severity,x.status,x.notes))
 audit('watchlist.create',x.value);return {'ok':True}
@app.put('/api/watchlists/{rid}')
def edit_watchlist(rid:int,x:WatchItem):
 with conn() as c:c.execute('update watchlists set kind=?,value=?,label=?,severity=?,status=?,notes=?,updated_at=CURRENT_TIMESTAMP where id=?',(x.kind,x.value.strip(),x.label,x.severity,x.status,x.notes,rid))
 audit('watchlist.update',rid);return {'ok':True}
@app.delete('/api/watchlists/{rid}')
def del_watchlist(rid:int):
 with conn() as c:c.execute('delete from watchlists where id=?',(rid,))
 audit('watchlist.delete',rid);return {'ok':True}
@app.get('/api/watchlists/matches')
async def watch_matches():
 ws=_rows("select * from watchlists where status='active'"); matches=[]
 threat=await threat_map(False); newsd=await news(90); kevdata=await kev(250); kevlist=kevdata if isinstance(kevdata,list) else kevdata.get('vulnerabilities',[])
 corpus=[('Threat Activity',json.dumps(x),x) for x in threat.get('events',[])]+[('Cyber News',json.dumps(x),x) for x in newsd.get('items',[])]+[('CISA KEV',json.dumps(x),x) for x in kevlist]
 for w in ws:
  val=w['value'].lower()
  for src,text,obj in corpus:
   if val and val in text.lower():matches.append({'watch_id':w['id'],'value':w['value'],'source':src,'match':obj})
 return {'matches':matches[:200],'checked':len(ws)}

@app.get('/api/scheduled-scans')
def scheduled_scans():return _rows('select * from scheduled_scans order by id desc')
@app.post('/api/scheduled-scans')
def scheduled_add(x:ScheduledScan):
 profile=x.profile if x.profile in ('quick','standard') else 'quick';_scan_targets(x.target,profile,bool(x.credential_user)); nxt=datetime.now(timezone.utc).isoformat()
 with conn() as c:c.execute('insert into scheduled_scans(name,target,profile,credential_user,interval_hours,enabled,next_run) values(?,?,?,?,?,?,?)',(x.name,x.target,profile,x.credential_user,x.interval_hours,1 if x.enabled else 0,nxt))
 audit('scheduled_scan.create',f'{x.name}:{x.target}');return {'ok':True}
@app.put('/api/scheduled-scans/{rid}')
def scheduled_edit(rid:int,x:ScheduledScan):
 profile=x.profile if x.profile in ('quick','standard') else 'quick';_scan_targets(x.target,profile,bool(x.credential_user))
 with conn() as c:c.execute('update scheduled_scans set name=?,target=?,profile=?,credential_user=?,interval_hours=?,enabled=? where id=?',(x.name,x.target,profile,x.credential_user,x.interval_hours,1 if x.enabled else 0,rid))
 audit('scheduled_scan.update',rid);return {'ok':True}
@app.delete('/api/scheduled-scans/{rid}')
def scheduled_delete(rid:int):
 with conn() as c:c.execute('delete from scheduled_scans where id=?',(rid,))
 audit('scheduled_scan.delete',rid);return {'ok':True}
@app.post('/api/scheduled-scans/{rid}/run')
def scheduled_run(rid:int,request:Request):
 row=_one('select * from scheduled_scans where id=?',(rid,));
 if not row:raise HTTPException(404,'Schedule not found')
 req=PentestScanRequest(name=row['name'],target=row['target'],profile=row['profile'],credential_user=row['credential_user'],authorized=True,import_findings=True)
 result=pentest_scan_start(req,request)
 now=datetime.now(timezone.utc); nxt=datetime.fromtimestamp(now.timestamp()+int(row['interval_hours'])*3600,timezone.utc).isoformat()
 with conn() as c:c.execute('update scheduled_scans set last_run=?,next_run=? where id=?',(now.isoformat(),nxt,rid))
 return result

@app.get('/api/evidence')
def evidence(investigation_id:int=0):
 sql='select id,investigation_id,name,kind,sha256,created_by,created_at from evidence_items';args=()
 if investigation_id:sql+=' where investigation_id=?';args=(investigation_id,)
 return _rows(sql+' order by id desc',args)
@app.post('/api/evidence/note')
def evidence_note(x:EvidenceNote):
 raw=x.notes.encode();sha=hashlib.sha256(raw).hexdigest()
 with conn() as c:c.execute("insert into evidence_items(investigation_id,name,kind,sha256,notes_enc,created_by) values(?,?,?,?,?,?)",(x.investigation_id,x.name,'note',sha,enc(x.notes),CURRENT_USER.get()))
 audit('evidence.note.create',f'{x.investigation_id}:{x.name}:{sha}');return {'ok':True,'sha256':sha}
@app.post('/api/evidence/upload')
async def evidence_upload(file:UploadFile=File(...),investigation_id:int=0):
 raw=await file.read();
 if len(raw)>40*1024*1024:raise HTTPException(413,'Evidence file exceeds 40 MB limit')
 eid=uuid.uuid4().hex;sha=hashlib.sha256(raw).hexdigest();path=DATA/'evidence';path.mkdir(exist_ok=True);fp=path/f'{eid}.hmsenc';fp.write_bytes(enc_bytes(raw));_harden_private_file(fp)
 with conn() as c:c.execute('insert into evidence_items(investigation_id,name,kind,sha256,encrypted_path,created_by) values(?,?,?,?,?,?)',(investigation_id,(file.filename or 'evidence')[:240],'file',sha,str(fp),CURRENT_USER.get()))
 audit('evidence.file.create',f'{investigation_id}:{file.filename}:{sha}');return {'ok':True,'sha256':sha}
@app.put('/api/evidence/{rid}')
def evidence_edit(rid:int,x:EvidenceNote):
 row=_one('select * from evidence_items where id=?',(rid,))
 if not row:raise HTTPException(404,'Evidence not found')
 if row.get('kind')!='note':raise HTTPException(400,'Uploaded evidence files are immutable; replace the file instead of editing its bytes.')
 raw=x.notes.encode();sha=hashlib.sha256(raw).hexdigest()
 with conn() as c:c.execute('update evidence_items set investigation_id=?,name=?,sha256=?,notes_enc=? where id=?',(x.investigation_id,x.name,sha,enc(x.notes),rid))
 audit('evidence.note.update',f'{rid}:{x.name}:{sha}');return {'ok':True,'sha256':sha}

@app.delete('/api/evidence/{rid}')
def evidence_delete(rid:int):
 row=_one('select * from evidence_items where id=?',(rid,));
 if not row:raise HTTPException(404,'Evidence not found')
 if row.get('encrypted_path'):
  try:Path(row['encrypted_path']).unlink(missing_ok=True)
  except Exception:pass
 with conn() as c:c.execute('delete from evidence_items where id=?',(rid,))
 audit('evidence.delete',f'{rid}:{row["name"]}:{row["sha256"]}');return {'ok':True}

@app.get('/api/detections')
def detections():return _rows('select * from detections order by id desc')
@app.post('/api/detections')
def detection_add(x:DetectionRule):
 with conn() as c:c.execute('insert into detections(name,kind,attack_id,status,content,notes) values(?,?,?,?,?,?)',(x.name,x.kind,x.attack_id,x.status,x.content,x.notes))
 audit('detection.create',x.name);return {'ok':True}
@app.put('/api/detections/{rid}')
def detection_edit(rid:int,x:DetectionRule):
 with conn() as c:c.execute('update detections set name=?,kind=?,attack_id=?,status=?,content=?,notes=?,updated_at=CURRENT_TIMESTAMP where id=?',(x.name,x.kind,x.attack_id,x.status,x.content,x.notes,rid))
 audit('detection.update',rid);return {'ok':True}
@app.delete('/api/detections/{rid}')
def detection_delete(rid:int):
 with conn() as c:c.execute('delete from detections where id=?',(rid,))
 audit('detection.delete',rid);return {'ok':True}
@app.get('/api/attack/coverage')
def attack_coverage():
 rows=[]
 for r in _rows("select attack_id,title,status,'finding' source from team_findings where attack_id<>''")+_rows("select technique attack_id,hypothesis title,status,'purple' source from purple_tests where technique<>''")+_rows("select attack_id,name title,status,'detection' source from detections where attack_id<>''"):rows.append(r)
 by={}
 for r in rows:
  for tid in re.findall(r'T\d{4}(?:\.\d{3})?',str(r.get('attack_id','')).upper()):by.setdefault(tid,[]).append(r)
 return {'techniques':[{'technique':k,'items':v,'detections':sum(1 for x in v if x['source']=='detection'),'tests':sum(1 for x in v if x['source']=='purple'),'findings':sum(1 for x in v if x['source']=='finding')} for k,v in sorted(by.items())]}

@app.get('/api/notifications')
def notification_data():return {'rules':_rows('select * from notification_rules order by id desc'),'events':_rows('select * from notification_events order by id desc limit 100')}
@app.post('/api/notifications/rules')
def notification_add(x:NotificationRule):
 with conn() as c:c.execute('insert into notification_rules(name,event_type,severity,enabled,channel) values(?,?,?,?,?)',(x.name,x.event_type,x.severity,1 if x.enabled else 0,x.channel))
 audit('notification_rule.create',x.name);return {'ok':True}
@app.put('/api/notifications/rules/{rid}')
def notification_edit(rid:int,x:NotificationRule):
 with conn() as c:c.execute('update notification_rules set name=?,event_type=?,severity=?,enabled=?,channel=? where id=?',(x.name,x.event_type,x.severity,1 if x.enabled else 0,x.channel,rid))
 audit('notification_rule.update',rid);return {'ok':True}
@app.delete('/api/notifications/rules/{rid}')
def notification_delete(rid:int):
 with conn() as c:c.execute('delete from notification_rules where id=?',(rid,))
 audit('notification_rule.delete',rid);return {'ok':True}
@app.post('/api/notifications/evaluate')
async def notification_evaluate():
 rules=_rows('select * from notification_rules where enabled=1');created=0
 exp=await exposure_summary()
 for rule in rules:
  candidates=[]
  if rule['event_type']=='critical_finding':candidates=[x for x in exp['items'] if str(x.get('severity')).lower()=='critical']
  elif rule['event_type']=='kev_match':candidates=[x for x in exp['items'] if x.get('cisa_kev')]
  for x in candidates[:20]:
   title=f"{rule['event_type']}: {x.get('cve') or x.get('title')}"
   with conn() as c:
    exists=c.execute('select id from notification_events where rule_id=? and title=?',(rule['id'],title)).fetchone()
    if not exists:c.execute('insert into notification_events(rule_id,event_type,title,detail) values(?,?,?,?)',(rule['id'],rule['event_type'],title,json.dumps({'asset':x.get('asset'),'severity':x.get('severity')})));created+=1
 audit('notifications.evaluate',created);return {'ok':True,'created':created}
@app.delete('/api/notifications/events/{rid}')
def notification_event_delete(rid:int):
 with conn() as c:c.execute('delete from notification_events where id=?',(rid,))
 audit('notification_event.delete',rid);return {'ok':True}

@app.get('/api/reports/executive.pdf')
async def executive_report():
 exp=await exposure_summary(); inc=_rows("select * from incidents where status!='closed'"); risks=_rows("select *,likelihood*impact score from risks where status!='closed'"); st=stig_summary()
 bio=BytesIO();doc=SimpleDocTemplate(bio,pagesize=letter,rightMargin=.55*inch,leftMargin=.55*inch,topMargin=.55*inch,bottomMargin=.55*inch);styles=getSampleStyleSheet();story=[Paragraph('Hive Mind Security — Executive Security Report',styles['Title']),Paragraph(datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),styles['Normal']),Spacer(1,12)]
 data=[['Metric','Value'],['Assets',str(exp['assets'])],['Open exposures',str(exp['open_exposures'])],['Critical exposures',str(exp['critical'])],['CISA KEV matches',str(exp['kev_matches'])],['Active incidents',str(len(inc))],['Open risks',str(len(risks))],['Open STIG findings',str(st.get('open',0))]];t=Table(data,colWidths=[3.5*inch,2*inch]);t.setStyle(TableStyle([('GRID',(0,0),(-1,-1),.4,colors.grey),('BACKGROUND',(0,0),(-1,0),colors.lightgrey),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('PADDING',(0,0),(-1,-1),6)]));story+=[t,Spacer(1,14),Paragraph('Top Exposure Priorities',styles['Heading2'])]
 for x in exp['items'][:15]:story.append(Paragraph(f"{x.get('severity','').upper()} — {x.get('cve') or x.get('title')} — {x.get('asset') or 'Unassigned'}{' — CISA KEV' if x.get('cisa_kev') else ''}",styles['BodyText']))
 doc.build(story);bio.seek(0);audit('report.executive.generate',f"exposures={exp['open_exposures']}");return StreamingResponse(bio,media_type='application/pdf',headers={'Content-Disposition':'inline; filename="hive_mind_executive_report.pdf"'})



@app.get('/api/remediation/queue')
def remediation_queue():
 out=[]
 for x in _rows('select id,cve,title,severity,asset,owner,status,due_date,source,created_at from vulnerabilities order by id desc'):
  out.append({**x,'record_type':'vulnerability','record_id':x['id']})
 for x in _rows('select id,cve,title,severity,asset,owner,status,due_date,source,created_at from tracked_findings order by id desc'):
  out.append({**x,'record_type':'tracked_finding','record_id':x['id']})
 for x in _rows('select id,vuln_id cve,title,severity,asset,\'\' owner,status,\'\' due_date,source,created_at from stig_findings order by id desc'):
  out.append({**x,'record_type':'stig','record_id':x['id']})
 rank={'critical':4,'high':3,'medium':2,'low':1};out.sort(key=lambda x:(str(x.get('status','')).lower() in ('closed','remediated','fixed'),-rank.get(str(x.get('severity','')).lower(),0),str(x.get('due_date',''))))
 return out[:500]

def _run_schedule_row(row:dict,actor='scheduler'):
 req=PentestScanRequest(name=row['name'],target=row['target'],profile=row['profile'],credential_user=row['credential_user'],authorized=True,import_findings=True)
 profile=req.profile if req.profile in ('quick','standard') else 'quick';_scan_targets(req.target,profile,bool(req.credential_user));sid=uuid.uuid4().hex[:24]
 with conn() as c:c.execute('insert into pentest_scans(id,name,target,profile,credential_user,status,created_by) values(?,?,?,?,?,?,?)',(sid,row['name'],row['target'],profile,row['credential_user'],'running',actor))
 tok=CURRENT_USER.set(actor)
 try:
  _run_builtin_scan(sid,req,actor);now=datetime.now(timezone.utc);nxt=datetime.fromtimestamp(now.timestamp()+int(row['interval_hours'])*3600,timezone.utc).isoformat()
  with conn() as c:c.execute('update scheduled_scans set last_run=?,next_run=? where id=?',(now.isoformat(),nxt,row['id']))
 except Exception as e:
  with conn() as c:c.execute("update pentest_scans set status='failed',summary_json=?,finished_at=CURRENT_TIMESTAMP where id=?",(json.dumps({'error':str(e)[:1000]}),sid))
  audit('scheduled_scan.failed',f"{row['id']}:{str(e)[:300]}")
 finally:CURRENT_USER.reset(tok)

async def _scheduled_scan_loop():
 while True:
  try:
   now=datetime.now(timezone.utc)
   for row in _rows('select * from scheduled_scans where enabled=1'):
    try:due=not row.get('next_run') or datetime.fromisoformat(row['next_run'].replace('Z','+00:00'))<=now
    except Exception:due=True
    if due:await asyncio.to_thread(_run_schedule_row,row,'scheduler')
  except Exception:pass
  await asyncio.sleep(60)

@app.on_event('startup')
async def _start_schedule_worker():
 asyncio.create_task(_scheduled_scan_loop())

# Functional toolbox
PRIVATE_NETS=[ipaddress.ip_network('10.0.0.0/8'),ipaddress.ip_network('172.16.0.0/12'),ipaddress.ip_network('192.168.0.0/16'),ipaddress.ip_network('127.0.0.0/8'),ipaddress.ip_network('169.254.0.0/16')]
def save_tool(tool,inp,out):
 with conn() as c:c.execute('insert into toolbox_runs(tool,input_summary,output) values(?,?,?)',(tool,inp[:500],json.dumps(out)[:6000]))
 return out
@app.post('/api/toolbox/hash')
def tb_hash(x:ToolboxInput):return save_tool('hash',x.value,{'md5':hashlib.md5(x.value.encode()).hexdigest(),'sha1':hashlib.sha1(x.value.encode()).hexdigest(),'sha256':hashlib.sha256(x.value.encode()).hexdigest(),'sha512':hashlib.sha512(x.value.encode()).hexdigest()})
@app.post('/api/toolbox/encode')
def tb_encode(x:ToolboxInput):
 op=x.operation.lower();v=x.value
 try:
  if op=='base64-encode':o=base64.b64encode(v.encode()).decode()
  elif op=='base64-decode':o=base64.b64decode(v).decode(errors='replace')
  elif op=='url-encode':o=urllib.parse.quote(v,safe='')
  elif op=='url-decode':o=urllib.parse.unquote(v)
  elif op=='hex-encode':o=v.encode().hex()
  elif op=='hex-decode':o=bytes.fromhex(v).decode(errors='replace')
  else:raise ValueError('Unknown operation')
  return save_tool('encode',v,{'operation':op,'result':o})
 except Exception as e:raise HTTPException(400,str(e))
@app.post('/api/toolbox/ioc-parse')
def tb_ioc(x:ToolboxInput):
 text=x.value;ips=sorted(set(re.findall(r'\b(?:\d{1,3}\.){3}\d{1,3}\b',text)));urls=sorted(set(re.findall(r'https?://[^\s<>()"\']+',text)));emails=sorted(set(re.findall(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b',text)));hashes=sorted(set(re.findall(r'\b(?:[A-Fa-f0-9]{64}|[A-Fa-f0-9]{40}|[A-Fa-f0-9]{32})\b',text)))
 return save_tool('ioc-parse',text,{'ips':ips,'urls':urls,'emails':emails,'hashes':hashes,'count':len(ips)+len(urls)+len(emails)+len(hashes)})
@app.post('/api/toolbox/subnet')
def tb_subnet(x:ToolboxInput):
 try:n=ipaddress.ip_network(x.value.strip(),strict=False);o={'network':str(n.network_address),'broadcast':str(n.broadcast_address) if n.version==4 else 'n/a','prefix':n.prefixlen,'netmask':str(n.netmask),'addresses':n.num_addresses,'first':str(next(n.hosts(),n.network_address)),'last':str(list(n.hosts())[-1]) if n.num_addresses<65538 else str(n[-2])}
 except Exception as e:raise HTTPException(400,str(e))
 return save_tool('subnet',x.value,o)
@app.post('/api/toolbox/jwt')
def tb_jwt(x:ToolboxInput):
 try:
  p=x.value.split('.');
  if len(p)<2:raise ValueError('JWT must contain at least header.payload')
  de=lambda s:json.loads(base64.urlsafe_b64decode(s+'='*((4-len(s)%4)%4)).decode())
  o={'header':de(p[0]),'payload':de(p[1]),'warning':'Decoded for inspection only; signature is NOT verified.'}
 except Exception as e:raise HTTPException(400,str(e))
 return save_tool('jwt',x.value[:80],o)
@app.post('/api/toolbox/regex')
def tb_regex(x:ToolboxInput):
 try:r=re.compile(x.operation);matches=[m.group(0) for m in r.finditer(x.value)][:200]
 except Exception as e:raise HTTPException(400,str(e))
 return save_tool('regex',x.operation,{'matches':matches,'count':len(matches)})
@app.post('/api/toolbox/query-builder')
def tb_query(x:ToolboxInput):
 v=x.value.strip();kind=x.operation.lower();safe=v.replace('"','\\"')
 q={'splunk':f'index=* (src_ip="{safe}" OR dest_ip="{safe}" OR url="{safe}") | stats count min(_time) as firstSeen max(_time) as lastSeen by host,source', 'kql':f'Search * | where tostring(*) contains "{safe}" | take 100', 'elastic':json.dumps({'query':{'query_string':{'query':f'"{safe}"'}}},indent=2), 'sigma':f'title: IOC Hunt - {safe}\nstatus: experimental\nlogsource:\n  category: network_connection\ndetection:\n  selection:\n    DestinationIp: {safe}\n  condition: selection\nlevel: medium'}
 if kind not in q:raise HTTPException(400,'Choose splunk, kql, elastic, or sigma')
 return save_tool('query-builder',v,{'platform':kind,'query':q[kind]})

@app.post('/api/toolbox/password-generate')
def toolbox_password_generate(x:ToolboxInput):
 try:length=max(12,min(128,int(x.value or '20')))
 except:length=20
 count=max(1,min(20,int(x.extra or '5') if str(x.extra or '').isdigit() else 5))
 import string
 alphabet=string.ascii_letters+string.digits+'!@#$%^&*()-_=+[]{}:,.?'
 def one():
  while True:
   p=''.join(secrets.choice(alphabet) for _ in range(length))
   if any(c.islower() for c in p) and any(c.isupper() for c in p) and any(c.isdigit() for c in p) and any(c in '!@#$%^&*()-_=+[]{}:,.?' for c in p):return p
 vals=[one() for _ in range(count)]
 audit('toolbox.password.generate',f'length={length}:count={count}')
 return {'length':length,'count':count,'passwords':vals,'note':'Generated locally with Python secrets; passwords are not stored in toolbox history.'}

@app.post('/api/toolbox/password-hash-audit')
def toolbox_password_hash_audit(x:ToolboxInput):
 target=(x.value or '').strip(); candidates=[v for v in (x.extra or '').splitlines() if v][:5000]; op=(x.operation or 'auto').lower()
 if not target:raise HTTPException(400,'Password hash is required.')
 if not candidates:raise HTTPException(400,'Provide one or more authorized candidate passwords, one per line.')
 if len(candidates)>5000:raise HTTPException(400,'Candidate list is limited to 5,000 entries per local audit.')
 found=None;alg=op
 if target.startswith('$argon2') or op=='argon2':
  alg='argon2'
  for cand in candidates:
   try:
    if PH.verify(target,cand):found=cand;break
   except Exception:pass
 else:
  if op=='auto':
   alg={32:'md5',40:'sha1',64:'sha256',128:'sha512'}.get(len(target),'')
  if alg not in ('md5','sha1','sha256','sha512'):raise HTTPException(400,'Choose MD5, SHA1, SHA256, SHA512, or Argon2; auto-detection uses hash length for common hex digests.')
  for cand in candidates:
   if hashlib.new(alg,cand.encode()).hexdigest().lower()==target.lower():found=cand;break
 audit('toolbox.password.hash_audit',f'algorithm={alg}:candidates={len(candidates)}:matched={bool(found)}')
 return {'algorithm':alg,'tested':len(candidates),'matched':bool(found),'match':found if found else None,'note':'Local authorized candidate-list audit only. No brute-force, remote cracking, or credential spraying is performed.'}

@app.delete('/api/toolbox/history/{run_id}')
def toolbox_history_delete(run_id:int):
 with conn() as c:
  r=c.execute('select tool from toolbox_runs where id=?',(run_id,)).fetchone()
  if not r:raise HTTPException(404,'Tool run not found')
  c.execute('delete from toolbox_runs where id=?',(run_id,))
 audit('toolbox.history.delete',f'{run_id}:{r["tool"]}');return {'ok':True}
@app.get('/api/toolbox/history')
def tb_history():
 with conn() as c:return [dict(x) for x in c.execute('select * from toolbox_runs order by id desc limit 30').fetchall()]

@app.get('/api/audit')
def get_audit():
 with conn() as c:return [dict(x) for x in c.execute('select * from audit order by id desc limit 200').fetchall()]
@app.post('/api/backup')
def backup():
 stamp=datetime.now().strftime('%Y%m%d_%H%M%S');path=BACKUPS/f'hive_mind_security_{stamp}.zip'
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
  if DB.exists():z.write(DB,DB.name)
  if KEYFILE.exists():z.write(KEYFILE,KEYFILE.name)
 audit('backup.create',path.name);return {'ok':True,'file':str(path)}
